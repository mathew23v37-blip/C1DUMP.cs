"""Site-user managed CPM alternate accounts for car purchases.

Car jobs always use these alts. Site accounts stay; game login is not required
for create / select / rotate / backlog. Users pick an email prefix and password;
each new alt is {prefix}{6 digits}@proton.me.
"""

from __future__ import annotations

import logging
import os
import random
import re
import secrets
import string
import time
import uuid
from typing import Any, Dict, List, Optional

from persistence import atomic_write_json, load_json, seed_data_file

log = logging.getLogger("tnnr-user-cpm-alts")

_FILE = seed_data_file("user_cpm_alts.json", default={"users": {}})


def _postgres_alts_enabled() -> bool:
    """Use the same production switch as site accounts; keep JSON for local use."""
    try:
        import accounts
        return bool(accounts.postgres_enabled())
    except Exception:
        return False


def _ensure_postgres_alt_schema(conn) -> None:
    conn.execute("""
        CREATE TABLE IF NOT EXISTS managed_alt_preferences (
            site_user_id TEXT PRIMARY KEY REFERENCES site_users(user_id) ON DELETE CASCADE,
            email_prefix TEXT NOT NULL DEFAULT '',
            password TEXT NOT NULL DEFAULT '',
            password_set_at DOUBLE PRECISION,
            email_domain TEXT NOT NULL DEFAULT 'proton.me',
            active_id TEXT NOT NULL DEFAULT '',
            updated_at DOUBLE PRECISION NOT NULL
        )
    """)
    conn.execute("ALTER TABLE managed_alt_preferences ADD COLUMN IF NOT EXISTS active_id TEXT NOT NULL DEFAULT ''")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS managed_alt_accounts (
            account_id TEXT PRIMARY KEY,
            site_user_id TEXT NOT NULL REFERENCES site_users(user_id) ON DELETE CASCADE,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            firebase_uid TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'active',
            initialized BOOLEAN NOT NULL DEFAULT FALSE,
            car_count_last INTEGER NOT NULL DEFAULT 0,
            car_count_checked_at DOUBLE PRECISION,
            created_at DOUBLE PRECISION NOT NULL,
            reason TEXT NOT NULL DEFAULT '',
            actions JSONB NOT NULL DEFAULT '[]'::jsonb,
            updated_at DOUBLE PRECISION NOT NULL
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_managed_alt_accounts_user ON managed_alt_accounts(site_user_id, created_at DESC)")


def _load_postgres() -> Dict[str, Any]:
    from postgres_db import connection
    with connection() as conn, conn.transaction():
        _ensure_postgres_alt_schema(conn)
        prefs = [dict(row) for row in conn.execute("SELECT * FROM managed_alt_preferences").fetchall()]
        accounts = [dict(row) for row in conn.execute("SELECT * FROM managed_alt_accounts ORDER BY created_at ASC").fetchall()]
    users: Dict[str, Any] = {}
    for pref in prefs:
        user_id = str(pref.get("site_user_id") or "")
        if user_id:
            users[user_id] = {
                "accounts": [],
                "active_id": str(pref.get("active_id") or "") or None,
                "preference": {
                    "email_prefix": str(pref.get("email_prefix") or ""),
                    "password": str(pref.get("password") or ""),
                    "password_set_at": pref.get("password_set_at"),
                    "email_domain": str(pref.get("email_domain") or EMAIL_DOMAIN),
                },
            }
    for row in accounts:
        user_id = str(row.get("site_user_id") or "")
        if not user_id:
            continue
        bucket = users.setdefault(user_id, {"accounts": [], "active_id": None, "preference": {}})
        bucket["accounts"].append({
            "id": str(row.get("account_id") or ""),
            "email": str(row.get("email") or ""),
            "password": str(row.get("password") or ""),
            "firebase_uid": str(row.get("firebase_uid") or ""),
            "status": str(row.get("status") or "active"),
            "initialized": bool(row.get("initialized")),
            "car_count_last": int(row.get("car_count_last") or 0),
            "car_count_checked_at": row.get("car_count_checked_at"),
            "created_at": float(row.get("created_at") or 0),
            "reason": str(row.get("reason") or ""),
            "actions": list(row.get("actions") or []),
        })
    return {"users": users}


def _save_postgres(data: Dict[str, Any]) -> None:
    from postgres_db import connection
    from psycopg.types.json import Jsonb
    now = time.time()
    users = data.get("users") if isinstance(data, dict) else {}
    with connection() as conn, conn.transaction():
        _ensure_postgres_alt_schema(conn)
        for raw_user_id, raw_bucket in (users or {}).items():
            if not isinstance(raw_bucket, dict):
                continue
            site_user_id = str(raw_user_id or "").strip()
            if not site_user_id:
                continue
            # Preserve referential integrity; a legacy orphan remains in JSON until
            # its site user is migrated, instead of creating an unowned alt row.
            if not conn.execute("SELECT 1 FROM site_users WHERE user_id=%s", (site_user_id,)).fetchone():
                continue
            pref = raw_bucket.get("preference") if isinstance(raw_bucket.get("preference"), dict) else {}
            conn.execute("""INSERT INTO managed_alt_preferences
                (site_user_id,email_prefix,password,password_set_at,email_domain,active_id,updated_at)
                VALUES (%s,%s,%s,%s,%s,%s,%s)
                ON CONFLICT (site_user_id) DO UPDATE SET email_prefix=EXCLUDED.email_prefix,
                  password=EXCLUDED.password,password_set_at=EXCLUDED.password_set_at,
                  email_domain=EXCLUDED.email_domain,active_id=EXCLUDED.active_id,updated_at=EXCLUDED.updated_at""", (
                site_user_id, str(pref.get("email_prefix") or ""), str(pref.get("password") or ""),
                pref.get("password_set_at"), str(pref.get("email_domain") or EMAIL_DOMAIN),
                str(raw_bucket.get("active_id") or ""), now,
            ))
            for raw in raw_bucket.get("accounts") or []:
                if not isinstance(raw, dict):
                    continue
                account_id = str(raw.get("id") or "").strip()
                email = str(raw.get("email") or "").strip().lower()
                password = str(raw.get("password") or "")
                if not account_id or not email or not password:
                    continue
                conn.execute("""INSERT INTO managed_alt_accounts
                    (account_id,site_user_id,email,password,firebase_uid,status,initialized,car_count_last,
                     car_count_checked_at,created_at,reason,actions,updated_at)
                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                    ON CONFLICT (account_id) DO UPDATE SET site_user_id=EXCLUDED.site_user_id,
                      email=EXCLUDED.email,password=EXCLUDED.password,firebase_uid=EXCLUDED.firebase_uid,
                      status=EXCLUDED.status,initialized=EXCLUDED.initialized,car_count_last=EXCLUDED.car_count_last,
                      car_count_checked_at=EXCLUDED.car_count_checked_at,created_at=EXCLUDED.created_at,
                      reason=EXCLUDED.reason,actions=EXCLUDED.actions,updated_at=EXCLUDED.updated_at""", (
                    account_id, site_user_id, email, password, str(raw.get("firebase_uid") or ""),
                    str(raw.get("status") or "active"), bool(raw.get("initialized")),
                    int(raw.get("car_count_last") or 0), raw.get("car_count_checked_at"),
                    float(raw.get("created_at") or now), str(raw.get("reason") or ""),
                    Jsonb(list(raw.get("actions") or [])), now,
                ))


ALT_CAR_CAP = max(1, int(os.getenv("TNNR_ALT_CAR_CAP", "55")))
RECOVERY_MAX_TARGET_CARS = max(0, int(os.getenv("TNNR_RECOVERY_MAX_TARGET_CARS", "5")))
EMAIL_DOMAIN = os.getenv("TNNR_ALT_EMAIL_DOMAIN", "proton.me").strip() or "proton.me"
PREFIX_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]{1,20}$")


def _load() -> Dict[str, Any]:
    if _postgres_alts_enabled():
        return _load_postgres()
    data = load_json(_FILE, {"users": {}})
    if not isinstance(data, dict):
        return {"users": {}}
    data.setdefault("users", {})
    return data


def _save(data: Dict[str, Any]) -> None:
    if _postgres_alts_enabled():
        _save_postgres(data)
        return
    atomic_write_json(_FILE, data)


def _user_bucket(data: Dict[str, Any], site_user_id: str) -> Dict[str, Any]:
    users = data.setdefault("users", {})
    bucket = users.get(site_user_id)
    if not isinstance(bucket, dict):
        bucket = {"accounts": [], "active_id": None, "preference": {}}
        users[site_user_id] = bucket
    bucket.setdefault("accounts", [])
    bucket.setdefault("preference", {})
    return bucket


def list_accounts(site_user_id: str) -> List[Dict[str, Any]]:
    site_user_id = str(site_user_id or "").strip()
    if not site_user_id:
        return []
    data = _load()
    bucket = _user_bucket(data, site_user_id)
    rows = [dict(row) for row in bucket.get("accounts") or [] if isinstance(row, dict)]
    rows.sort(key=lambda row: float(row.get("created_at") or 0), reverse=True)
    return rows


def get_account(site_user_id: str, account_id: str) -> Optional[Dict[str, Any]]:
    for row in list_accounts(site_user_id):
        if str(row.get("id") or "") == str(account_id or ""):
            return row
    return None


def get_preference(site_user_id: str) -> Dict[str, Any]:
    site_user_id = str(site_user_id or "").strip()
    if not site_user_id:
        return {}
    data = _load()
    bucket = _user_bucket(data, site_user_id)
    pref = bucket.get("preference") if isinstance(bucket.get("preference"), dict) else {}
    return {
        "email_prefix": str(pref.get("email_prefix") or "").strip(),
        "has_password": bool(str(pref.get("password") or "").strip()),
        "password_set_at": pref.get("password_set_at"),
    }


def set_preference(site_user_id: str, *, email_prefix: str, password: str) -> Dict[str, Any]:
    """Save the member's alt naming + password preference (site account only)."""
    site_user_id = str(site_user_id or "").strip()
    if not site_user_id:
        return {"ok": False, "message": "Site account required."}
    prefix = str(email_prefix or "").strip()
    password = str(password or "")
    if not PREFIX_RE.match(prefix):
        return {
            "ok": False,
            "message": "Prefix must start with a letter and use 2–21 letters, numbers, or underscores (e.g. TNNR).",
        }
    if len(password) < 8 or len(password) > 64:
        return {"ok": False, "message": "Password must be 8–64 characters."}
    data = _load()
    bucket = _user_bucket(data, site_user_id)
    bucket["preference"] = {
        "email_prefix": prefix,
        "password": password,
        "password_set_at": time.time(),
        "email_domain": EMAIL_DOMAIN,
    }
    _save(data)
    return {
        "ok": True,
        "email_prefix": prefix,
        "email_domain": EMAIL_DOMAIN,
        "example": f"{prefix}123456@{EMAIL_DOMAIN}",
        "message": f"Alt preference saved. New accounts will look like {prefix}123456@{EMAIL_DOMAIN}.",
    }


def preference_ready(site_user_id: str) -> bool:
    pref = get_preference(site_user_id)
    if not pref.get("email_prefix") or not pref.get("has_password"):
        return False
    data = _load()
    bucket = _user_bucket(data, site_user_id)
    raw = bucket.get("preference") if isinstance(bucket.get("preference"), dict) else {}
    return bool(str(raw.get("password") or "").strip())


def _next_email(prefix: str, existing_emails: set) -> str:
    for _ in range(40):
        digits = f"{random.randint(0, 999999):06d}"
        email = f"{prefix}{digits}@{EMAIL_DOMAIN}".lower()
        if email not in existing_emails:
            return email
    # fallback unique
    digits = secrets.token_hex(3)
    return f"{prefix}{digits}@{EMAIL_DOMAIN}".lower()


async def _firebase_signup(email: str, password: str) -> Dict[str, Any]:
    """Create Firebase identity (same family of API as CPM login tools)."""
    import aiohttp

    try:
        from cpm_nuker import firebase_key
        key = firebase_key()
    except Exception:
        key = os.getenv("CPM_FIREBASE_KEY") or os.getenv("FIREBASE_API_KEY") or ""
    if not key:
        return {"ok": False, "message": "Firebase API key is not configured on the server."}

    url = f"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={key}"
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "UnityPlayer/2022.3.62f2 (UnityWebRequest/1.0, libcurl/8.10.1-DEV)",
        "X-Unity-Version": "2022.3.62f2",
    }
    timeout = aiohttp.ClientTimeout(total=25, connect=10)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.post(
            url,
            headers=headers,
            json={"email": email, "password": password, "returnSecureToken": True},
        ) as response:
            payload = await response.json(content_type=None)
    if payload.get("idToken"):
        return {
            "ok": True,
            "firebase_uid": payload.get("localId", ""),
            "auth": payload.get("idToken"),
            "refresh_token": payload.get("refreshToken") or "",
        }
    error = str((payload.get("error") or {}).get("message") or payload)
    return {"ok": False, "message": error[:400]}



def _alt_web_uid(email: str) -> int:
    import hashlib
    digest = hashlib.sha256(f"tnnr-alt:{email.lower()}".encode("utf-8")).hexdigest()
    return int(digest[:14], 16) % 900_000_000_000 + 100_000_000_000


def _fresh_player_record(firebase_uid: str) -> Dict[str, Any]:
    player_id = (str(firebase_uid or "")[:8] or "TNNRALT0").upper()
    return {
        "localID": player_id,
        "money": 50_000_000,
        "coin": 5_000,
        "boughtFsos": [],
        "boughtPoliceLights": [],
        "boughtPoliceSirens": [],
        "FriendsID": [],
        "LevelsDoneTime": [0.0] * 110,
        "floats": [0.0] * 54,
        "integers": [0] * 120,
        "fcar": [],
        "favouriteWheels": [],
        "favouriteVinyls": [],
        "favouriteEmojis": [],
        "emojiPacks": [],
        "flags": {},
        "animations": [],
        "wheels": [],
    }


async def _initialize_cpm_game_account(
    *,
    email: str,
    password: str,
    firebase_uid: str,
    auth: str,
    refresh_token: str = "",
) -> Dict[str, Any]:
    """Firebase signup alone is not enough — CPM needs a player save before Get Cars / inject works."""
    import asyncio
    from cpm_nuker import CPMNuker

    nuker = CPMNuker()
    web_uid = _alt_web_uid(email)
    nuker.save_token(
        web_uid,
        auth,
        email,
        password,
        refresh_token or "",
        firebase_uid or "",
    )

    loaded = False
    for attempt in range(1, 4):
        try:
            loaded = await nuker.load_account(web_uid, force=True)
        except Exception as exc:
            log.warning("Alt load attempt %s failed for %s: %s", attempt, email, exc)
            loaded = False
        if loaded:
            break
        await asyncio.sleep(min(6.0, 1.25 * attempt))

    if not loaded:
        record = _fresh_player_record(firebase_uid)
        forced = set(record.keys())
        last_msg = "player save failed"
        for save_attempt in range(1, 4):
            try:
                result = await nuker._save(web_uid, record, force_fields=forced)
            except Exception as exc:
                last_msg = str(exc)
                result = {"ok": False, "message": last_msg}
            if result.get("ok"):
                for load_attempt in range(1, 6):
                    await asyncio.sleep(min(8.0, 1.25 * load_attempt))
                    try:
                        if await nuker.load_account(web_uid, force=True):
                            loaded = True
                            break
                    except Exception:
                        pass
                if loaded:
                    break
            await asyncio.sleep(1.5 * save_attempt)
            last_msg = str(result.get("message") or last_msg)
        if not loaded:
            return {
                "ok": False,
                "message": f"Firebase user created but CPM player record would not initialize: {last_msg}",
            }

    # Wallet + rank + W16 for World Sale / playability
    try:
        await nuker.set_money(web_uid, 50_000_000)
    except Exception as exc:
        log.warning("Alt money seed failed for %s: %s", email, exc)
    try:
        await nuker.set_coin(web_uid, 5_000)
    except Exception as exc:
        log.warning("Alt coin seed failed for %s: %s", email, exc)
    try:
        rank = await nuker.set_rank(web_uid)
        if not rank.get("ok"):
            log.warning("Alt King rank seed for %s: %s", email, rank.get("message"))
    except Exception as exc:
        log.warning("Alt King rank seed failed for %s: %s", email, exc)
    try:
        w16 = await nuker.unlock_w16(web_uid)
        if not (isinstance(w16, dict) and w16.get("ok")) and w16 is not True:
            log.warning("Alt W16 seed for %s: %s", email, w16)
    except Exception as exc:
        log.warning("Alt W16 seed failed for %s: %s", email, exc)

    # Warm Get Cars until the endpoint answers (empty garage is fine).
    # Fresh Firebase+save accounts often do not expose car data until the
    # garage API has been hit successfully at least once.
    car_count = 0
    garage_ready = False
    try:
        from car_bulk_injector import (
            injection_http_session,
            login_async,
            get_garage_cars_result,
            verify_account_garage_count,
        )
        import asyncio as _asyncio

        async with injection_http_session() as session:
            for warm in range(1, 6):
                try:
                    token, _ = await _asyncio.wait_for(
                        login_async(session, email, password), timeout=18.0
                    )
                except Exception as exc:
                    log.warning("Alt warm login %s for %s: %s", warm, email, exc)
                    token = None
                if not token:
                    await _asyncio.sleep(min(6.0, 1.0 * warm))
                    continue
                try:
                    readable, cars = await _asyncio.wait_for(
                        get_garage_cars_result(session, token), timeout=18.0
                    )
                except Exception as exc:
                    log.warning("Alt warm GetCars %s for %s: %s", warm, email, exc)
                    readable, cars = False, []
                if readable:
                    garage_ready = True
                    car_count = len(cars or [])
                    log.info("Alt garage warm OK email=%s cars=%s attempt=%s", email, car_count, warm)
                    break
                await _asyncio.sleep(min(6.0, 1.25 * warm))

        if not garage_ready:
            # One more verification path through the shared helper
            probe = await verify_account_garage_count(email, password, minimum_count=0, attempts=3)
            if probe.get("ok"):
                garage_ready = True
                car_count = int(probe.get("count") or 0)

        # Seed a single free bootstrap car so CPM car-data tables exist
        # (Get Cars / World Sale behave more reliably after the first car).
        if garage_ready and car_count == 0:
            try:
                bootstrap = await _bootstrap_first_car(email, password)
                if bootstrap.get("ok"):
                    car_count = int(bootstrap.get("car_count") or 1)
                    log.info("Alt bootstrap car seeded for %s count=%s", email, car_count)
                else:
                    log.warning("Alt bootstrap car skipped for %s: %s", email, bootstrap.get("message"))
            except Exception as exc:
                log.warning("Alt bootstrap car failed for %s: %s", email, exc)
    except Exception as exc:
        log.warning("Alt garage warm failed for %s: %s", email, exc)

    return {
        "ok": True,
        "web_uid": web_uid,
        "car_count": car_count,
        "initialized": True,
        "garage_ready": garage_ready,
        "message": (
            f"CPM account initialized for {email} "
            f"({car_count} cars, garage_ready={garage_ready})."
        ),
    }


def _load_working_bootstrap_car() -> Dict[str, Any]:
    """Load a known-working car JSON (alt_bootstrap_car.json from fixed_16)."""
    import json
    from pathlib import Path as _P

    candidates = [
        _P(__file__).resolve().parent / "alt_bootstrap_car.json",
        _P(str(os.getenv("TNNR_ALT_BOOTSTRAP_CAR", "") or "")),
    ]
    try:
        from car_bulk_injector import CAR_DB_FILE
        candidates.append(_P(str(CAR_DB_FILE)))
    except Exception:
        pass

    for path in candidates:
        if not path or not str(path) or not path.exists() or not path.is_file():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            log.warning("Bootstrap JSON read failed %s: %s", path, exc)
            continue
        # alt_bootstrap_car.json shape: { "car": {...} }
        if isinstance(data, dict) and isinstance(data.get("car"), dict):
            car = data["car"]
            cid = int(car.get("CarID") or car.get("carID") or 0)
            if cid > 0:
                return car
        # fixed_16 / DB shape: { "cars": [ {...}, ... ] }
        if isinstance(data, dict) and isinstance(data.get("cars"), list):
            for entry in data["cars"]:
                if not isinstance(entry, dict):
                    continue
                cid = int(entry.get("CarID") or entry.get("carID") or 0)
                if cid > 0:
                    return entry
        if isinstance(data, list):
            for entry in data:
                if not isinstance(entry, dict):
                    continue
                cid = int(entry.get("CarID") or entry.get("carID") or 0)
                if cid > 0:
                    return entry
    return {"CarID": 13, "carID": 13}


async def _bootstrap_first_car(email: str, password: str) -> Dict[str, Any]:
    """Purchase one known-working template car so CPM loads car-data for the account."""
    import asyncio
    from car_bulk_injector import (
        injection_http_session,
        login_async,
        get_garage_cars_result,
        get_world_sale_slots,
        buy_car_from_slot,
        clone_template_to_car,
    )

    template = _load_working_bootstrap_car()
    target_id = int(template.get("CarID") or template.get("carID") or 13)
    log.info("Bootstrap using working car JSON CarID=%s", target_id)

    async with injection_http_session() as session:
        try:
            token, uid = await asyncio.wait_for(login_async(session, email, password), timeout=18.0)
        except Exception as exc:
            return {"ok": False, "message": f"bootstrap login failed: {exc}"}
        if not token:
            return {"ok": False, "message": "bootstrap authentication failed"}

        slots = []
        try:
            slots = await asyncio.wait_for(
                get_world_sale_slots(session, token, blocks=10, passes=1),
                timeout=25.0,
            )
        except Exception as exc:
            return {"ok": False, "message": f"bootstrap slots failed: {exc}"}
        if not slots:
            return {"ok": False, "message": "no World Sale slots for bootstrap"}

        try:
            car = clone_template_to_car(template, uid, target_id)
        except Exception:
            car = {"CarID": target_id, "carID": target_id}

        for slot in slots[:6]:
            try:
                ok, result, error = await asyncio.wait_for(
                    buy_car_from_slot(session, token, slot, car),
                    timeout=20.0,
                )
            except Exception as exc:
                ok, error = False, str(exc)
            if not ok:
                continue
            await asyncio.sleep(1.0)
            try:
                readable, cars = await asyncio.wait_for(
                    get_garage_cars_result(session, token), timeout=18.0
                )
            except Exception:
                readable, cars = False, []
            if readable:
                return {"ok": True, "car_count": len(cars or []), "message": "bootstrap car accepted"}
            # WS accepted — treat as primed even if GetCars lags
            return {"ok": True, "car_count": 1, "message": "bootstrap purchase accepted (garage lag)"}

    return {"ok": False, "message": "bootstrap purchases rejected"}


async def create_alt_account(site_user_id: str, *, reason: str = "rollover") -> Dict[str, Any]:
    """Provision a new managed CPM alt using the member's prefix + password."""
    site_user_id = str(site_user_id or "").strip()
    if not site_user_id:
        return {"ok": False, "message": "Site account required."}
    if not preference_ready(site_user_id):
        return {
            "ok": False,
            "need_setup": True,
            "message": "Choose an email prefix and password for managed alts before car tools can run.",
        }

    data = _load()
    bucket = _user_bucket(data, site_user_id)
    pref = bucket.get("preference") or {}
    prefix = str(pref.get("email_prefix") or "").strip()
    password = str(pref.get("password") or "")
    existing = {
        str(row.get("email") or "").lower()
        for row in (bucket.get("accounts") or [])
        if isinstance(row, dict)
    }

    last_error = "Unable to create alternate account."
    for _ in range(6):
        email = _next_email(prefix, existing)
        existing.add(email)
        created = await _firebase_signup(email, password)
        if not created.get("ok"):
            last_error = str(created.get("message") or last_error)
            if "EMAIL_EXISTS" in last_error.upper():
                continue
            continue

        init = await _initialize_cpm_game_account(
            email=email,
            password=password,
            firebase_uid=str(created.get("firebase_uid") or ""),
            auth=str(created.get("auth") or ""),
            refresh_token=str(created.get("refresh_token") or ""),
        )
        if not init.get("ok"):
            last_error = str(init.get("message") or last_error)
            log.error("Alt CPM init failed for %s: %s", email, last_error)
            # Do not persist a half-created alt that cannot log into CPM
            continue

        account = {
            "id": uuid.uuid4().hex,
            "email": email,
            "password": password,
            "firebase_uid": created.get("firebase_uid") or "",
            "status": "active",
            "initialized": True,
            "car_count_last": int(init.get("car_count") or 0),
            "car_count_checked_at": time.time(),
            "created_at": time.time(),
            "reason": reason,
            "actions": [],
        }
        # reload bucket in case of concurrent writes
        data = _load()
        bucket = _user_bucket(data, site_user_id)
        for row in bucket.get("accounts") or []:
            if isinstance(row, dict) and row.get("status") == "active":
                row["status"] = "full"
        bucket.setdefault("accounts", []).append(account)
        bucket["active_id"] = account["id"]
        _save(data)
        log.info(
            "Created+initialized managed alt site_user=%s email=%s reason=%s cars=%s",
            site_user_id, email, reason, account["car_count_last"],
        )
        return {
            "ok": True,
            "account": account,
            "alert": (
                f"New managed alternate created and initialized: {email} "
                f"({account['car_count_last']} cars). Car deliveries will use this account."
            ),
            "message": f"New managed alternate ready: {email}",
        }

    return {"ok": False, "message": last_error}


def update_car_count(site_user_id: str, account_id: str, count: int) -> None:
    data = _load()
    bucket = _user_bucket(data, site_user_id)
    for row in bucket.get("accounts") or []:
        if not isinstance(row, dict) or str(row.get("id") or "") != str(account_id):
            continue
        row["car_count_last"] = int(count)
        row["car_count_checked_at"] = time.time()
        if int(count) >= ALT_CAR_CAP and row.get("status") == "active":
            row["status"] = "full"
        break
    _save(data)


def record_action(
    site_user_id: str,
    account_id: str,
    *,
    kind: str,
    title: str = "",
    job_id: str = "",
    ok: bool = True,
    extra: Optional[Dict[str, Any]] = None,
) -> None:
    data = _load()
    bucket = _user_bucket(data, site_user_id)
    for row in bucket.get("accounts") or []:
        if not isinstance(row, dict) or str(row.get("id") or "") != str(account_id):
            continue
        actions = row.setdefault("actions", [])
        actions.append({
            "at": time.time(),
            "kind": kind,
            "title": title,
            "job_id": job_id,
            "ok": bool(ok),
            "extra": extra or {},
        })
        if len(actions) > 200:
            del actions[:-200]
        break
    _save(data)



def list_injectable_accounts(site_user_id: str, *, max_cars: Optional[int] = None) -> List[Dict[str, Any]]:
    """Accounts the member may select for a car job (under car cap)."""
    ceiling = ALT_CAR_CAP if max_cars is None else min(ALT_CAR_CAP, int(max_cars))
    rows = []
    for row in list_accounts(site_user_id):
        count = int(row.get("car_count_last") or 0)
        status = str(row.get("status") or "")
        if status == "full" and count >= ceiling:
            continue
        if count > ceiling:
            continue
        rows.append({
            "id": row.get("id"),
            "email": row.get("email"),
            "car_count": count,
            "status": status or "active",
            "is_active": status == "active",
        })
    return rows


def set_active_account(site_user_id: str, account_id: str) -> Dict[str, Any]:
    site_user_id = str(site_user_id or "").strip()
    account_id = str(account_id or "").strip()
    if not site_user_id or not account_id:
        return {"ok": False, "message": "Invalid account."}
    data = _load()
    bucket = _user_bucket(data, site_user_id)
    found = None
    for row in bucket.get("accounts") or []:
        if not isinstance(row, dict):
            continue
        if str(row.get("id") or "") == account_id:
            found = row
            if int(row.get("car_count_last") or 0) < ALT_CAR_CAP:
                row["status"] = "active"
        elif row.get("status") == "active":
            # keep others as-is unless full
            if int(row.get("car_count_last") or 0) >= ALT_CAR_CAP:
                row["status"] = "full"
    if not found:
        return {"ok": False, "message": "That managed alternate was not found."}
    bucket["active_id"] = account_id
    _save(data)
    return {"ok": True, "account_id": account_id, "email": found.get("email")}


async def resolve_active_alt_for_cars(
    site_user_id: str,
    *,
    require_under_cars: Optional[int] = None,
    account_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Return credentials for a managed alt under the car cap.

    account_id: optional manual selection. Otherwise uses active / auto-create.
    Does not use game-session login. Requires site-user alt preference.
    """
    site_user_id = str(site_user_id or "").strip()
    if not site_user_id:
        return {"ok": False, "message": "Sign in to your site account to use car tools."}

    if not preference_ready(site_user_id):
        return {
            "ok": False,
            "need_setup": True,
            "message": "Claim your alt email prefix and password on My CPM Accounts before starting car tools.",
            "setup_path": "/my-cpm-accounts",
        }

    ceiling = ALT_CAR_CAP if require_under_cars is None else min(ALT_CAR_CAP, int(require_under_cars))
    wanted_id = str(account_id or "").strip() or None

    from car_bulk_injector import verify_account_garage_count

    data = _load()
    bucket = _user_bucket(data, site_user_id)
    accounts = [row for row in (bucket.get("accounts") or []) if isinstance(row, dict)]
    active = None
    if wanted_id:
        active = next((row for row in accounts if str(row.get("id")) == wanted_id), None)
        if active is None:
            return {"ok": False, "message": "That managed alternate was not found on your account."}
    else:
        active_id = bucket.get("active_id")
        if active_id:
            active = next((row for row in accounts if str(row.get("id")) == str(active_id)), None)
        if active is None:
            active = next((row for row in accounts if row.get("status") == "active"), None)

    async def _refresh_count(account: Dict[str, Any]) -> int:
        try:
            result = await verify_account_garage_count(
                account["email"], account["password"], minimum_count=0, attempts=2,
            )
        except Exception as exc:
            log.warning("Garage count failed for %s: %s", account.get("email"), exc)
            result = {"ok": False, "count": int(account.get("car_count_last") or 0)}
            # One recovery path if the alt was saved without a CPM player record
            if not account.get("initialized"):
                try:
                    from cpm_nuker import CPMNuker
                    nuker = CPMNuker()
                    login = await nuker.account_login(account["email"], account["password"])
                    if login.get("ok"):
                        init = await _initialize_cpm_game_account(
                            email=account["email"],
                            password=account["password"],
                            firebase_uid=str(login.get("firebase_uid") or account.get("firebase_uid") or ""),
                            auth=str(login.get("auth") or ""),
                            refresh_token=str(login.get("refresh_token") or ""),
                        )
                        if init.get("ok"):
                            account["initialized"] = True
                            update_car_count(site_user_id, account["id"], int(init.get("car_count") or 0))
                            # mark initialized on disk
                            data2 = _load()
                            b2 = _user_bucket(data2, site_user_id)
                            for row in b2.get("accounts") or []:
                                if isinstance(row, dict) and str(row.get("id")) == str(account.get("id")):
                                    row["initialized"] = True
                                    row["car_count_last"] = int(init.get("car_count") or 0)
                                    break
                            _save(data2)
                            return int(init.get("car_count") or 0)
                except Exception as exc2:
                    log.warning("Alt re-init failed for %s: %s", account.get("email"), exc2)
        count = int((result or {}).get("count") or 0)
        if (result or {}).get("ok") or count >= 0:
            update_car_count(site_user_id, account["id"], count)
        return count

    alerts: List[str] = []

    if active:
        try:
            count = await _refresh_count(active)
        except Exception as exc:
            log.exception("Unable to count cars on active alt")
            return {
                "ok": False,
                "message": f"Could not read the managed alternate garage: {exc}",
            }
        if count <= ceiling:
            if wanted_id:
                set_active_account(site_user_id, active["id"])
            alerts.append(
                f"Cars will be delivered to managed alt {active['email']} ({count}/{ceiling if require_under_cars else ALT_CAR_CAP} cars)."
            )
            return {
                "ok": True,
                "email": active["email"],
                "password": active["password"],
                "account_id": active["id"],
                "car_count": count,
                "created": False,
                "alt_car_cap": ALT_CAR_CAP,
                "alerts": alerts,
                "selection": "manual" if wanted_id else "automatic",
            }
        update_car_count(site_user_id, active["id"], count)
        if wanted_id:
            return {
                "ok": False,
                "message": (
                    f"Managed alt {active['email']} already has {count} cars "
                    f"(limit {ceiling} for this job). Choose another alt or wait for a new one."
                ),
            }
        alerts.append(
            f"Managed alt {active['email']} reached {count} cars (cap {ceiling}). Creating a new alternate…"
        )

    created = await create_alt_account(
        site_user_id,
        reason="auto_rollover" if active else "first_alt",
    )
    if not created.get("ok"):
        out = {
            "ok": False,
            "message": created.get("message") or "Could not create a managed alternate account.",
        }
        if created.get("need_setup"):
            out["need_setup"] = True
            out["setup_path"] = "/my-cpm-accounts"
        return out

    account = created["account"]
    if created.get("alert"):
        alerts.append(created["alert"])
    else:
        alerts.append(f"New managed alternate created: {account['email']}.")
    alerts.append(f"Cars will be delivered to {account['email']}.")
    return {
        "ok": True,
        "email": account["email"],
        "password": account["password"],
        "account_id": account["id"],
        "car_count": 0,
        "created": True,
        "alt_car_cap": ALT_CAR_CAP,
        "alerts": alerts,
        "message": " ".join(alerts),
    }
