#!/usr/bin/env python3
"""Redis-backed shared injection job state for every web replica and worker."""

from __future__ import annotations

import json
import os
import time
import threading
import uuid
from contextlib import contextmanager
from typing import Any, Dict, Iterable, Optional


REDIS_URL = os.getenv("REDIS_URL", "").strip()
NAMESPACE = os.getenv("REDIS_NAMESPACE", "tnnr").strip() or "tnnr"
JOB_RETENTION_SECONDS = max(300, int(os.getenv("JOB_RETENTION_SECONDS", "1800")))
ACTIVE_JOB_TTL_SECONDS = max(3600, int(os.getenv("ACTIVE_JOB_TTL_SECONDS", "86400")))
MAX_JOB_EVENTS = max(200, min(2000, int(os.getenv("MAX_JOB_EVENTS", "600"))))


WORKER_POOL_SIZE = max(1, min(8, int(os.getenv("RQ_WORKER_PROCESSES", "4"))))
WORKER_LANE_LEASE_SECONDS = max(120, int(os.getenv("WORKER_LANE_LEASE_SECONDS", "180")))
WORKER_LANE_KEY = f"{NAMESPACE}:worker-lane-holders"


def worker_lane_caps(generator_active: bool, total: Optional[int] = None) -> Dict[str, int]:
    """Return the live per-lane cap; bulk gen may use the full worker pool."""
    total = WORKER_POOL_SIZE if total is None else max(1, int(total))
    if not generator_active or total == 1:
        return {"bulk": total, "other": total}
    # Keep one lane free for paid dashboard injects when possible.
    other = 1 if total >= 3 else 0
    return {"bulk": total - other, "other": max(1, other)}


_LANE_ACQUIRE_SCRIPT = """
local now = tonumber(ARGV[1])
local token = ARGV[2]
local lane = ARGV[3]
local total = tonumber(ARGV[4])
local lease = tonumber(ARGV[5])
redis.call('ZREMRANGEBYSCORE', KEYS[1], '-inf', now)
local bulk = 0
local other = 0
local king = 0
local active = false
local members = redis.call('ZRANGE', KEYS[1], 0, -1)
for _, member in ipairs(members) do
  if string.sub(member, 1, 6) == 'bulk:' then bulk = bulk + 1 end
  if string.sub(member, 1, 7) == 'other:' then other = other + 1 end
  if string.sub(member, 1, 5) == 'king:' then king = king + 1 end
  if string.sub(member, 1, 9) == 'activity:' then active = true end
end
if bulk > 0 or king > 0 then active = true end
-- King-account builds are deliberately serialized regardless of the RQ pool.
if lane == 'king' then
  if king >= 1 then return 0 end
  redis.call('ZADD', KEYS[1], now + lease, lane .. ':' .. token)
  return 1
end
-- When bulk generation is active, give it nearly the full worker pool so all
-- 500 RQ jobs can drain (target ~2 hours). Leave at most one slot for other.
local bulk_cap = total
local other_cap = total
if active and total > 1 then
  other_cap = total >= 3 and 1 or 0
  bulk_cap = total - other_cap
  if bulk_cap < 1 then bulk_cap = 1 end
end
local lane_cap = total
if active then
  lane_cap = lane == 'bulk' and bulk_cap or math.max(1, other_cap)
end
local current = lane == 'bulk' and bulk or other
if current >= lane_cap then return 0 end
redis.call('ZADD', KEYS[1], now + lease, lane .. ':' .. token)
return 1
"""

_LANE_RELEASE_SCRIPT = """
redis.call('ZREM', KEYS[1], ARGV[1])
return 1
"""


def _lane_redis():
    return get_redis()


@contextmanager
def worker_lane_slot(lane: str, *, wait_seconds: float = 900.0):
    """Reserve one dynamic worker lane slot; bulk and other work share the pool fairly."""
    lane = lane if lane in {"bulk", "king"} else "other"
    token = uuid.uuid4().hex
    member = f"{lane}:{token}"
    redis = _lane_redis()
    deadline = time.monotonic() + max(1.0, float(wait_seconds))
    acquired = False
    stop = threading.Event()
    activity_member = f"activity:{token}" if lane in {"bulk", "king"} else None
    if activity_member:
        # Mark the generator active before checking capacity, so a bulk task
        # cannot enter through the inactive/full-pool path during a race.
        redis.zadd(WORKER_LANE_KEY, {activity_member: time.time() + WORKER_LANE_LEASE_SECONDS})

    def heartbeat():
        while not stop.wait(max(10.0, WORKER_LANE_LEASE_SECONDS / 3)):
            try:
                now = time.time() + WORKER_LANE_LEASE_SECONDS
                redis.zadd(WORKER_LANE_KEY, {member: now})
                if activity_member:
                    redis.zadd(WORKER_LANE_KEY, {activity_member: now})
            except Exception:
                return

    try:
        while time.monotonic() < deadline:
            acquired = bool(redis.eval(
                _LANE_ACQUIRE_SCRIPT,
                1,
                WORKER_LANE_KEY,
                time.time(), token, lane, WORKER_POOL_SIZE, WORKER_LANE_LEASE_SECONDS,
            ))
            if acquired:
                break
            time.sleep(0.5)
        if not acquired:
            raise TimeoutError(f"No {lane} worker lane slot became available.")
        heartbeat_thread = threading.Thread(target=heartbeat, name=f"lane-heartbeat-{token[:8]}", daemon=True)
        heartbeat_thread.start()
        yield
    finally:
        if acquired:
            stop.set()
            try:
                redis.eval(_LANE_RELEASE_SCRIPT, 1, WORKER_LANE_KEY, member)
            except Exception:
                pass
        if activity_member:
            try:
                redis.eval(_LANE_RELEASE_SCRIPT, 1, WORKER_LANE_KEY, activity_member)
            except Exception:
                pass
_REDIS = None


def configured() -> bool:
    return bool(REDIS_URL)


def distributed_mode_enabled() -> bool:
    explicit = os.getenv("DISTRIBUTED_JOBS_ENABLED", "auto").strip().lower()
    if explicit in {"0", "false", "no", "off"}:
        return False
    postgres_flag = os.getenv("POSTGRES_ACCOUNTS_ENABLED", "auto").strip().lower()
    database_ready = bool(os.getenv("DATABASE_URL", "").strip()) and postgres_flag not in {
        "0", "false", "no", "off",
    }
    if explicit in {"1", "true", "yes", "on"} and not (configured() and database_ready):
        raise RuntimeError("DISTRIBUTED_JOBS_ENABLED requires both REDIS_URL and DATABASE_URL.")
    return configured() and database_ready


def get_redis():
    global _REDIS
    if not REDIS_URL:
        raise RuntimeError("REDIS_URL is required for distributed job mode.")
    if _REDIS is None:
        from redis import Redis

        _REDIS = Redis.from_url(
            REDIS_URL,
            decode_responses=False,
            socket_connect_timeout=max(1.0, float(os.getenv("REDIS_CONNECT_TIMEOUT_SECONDS", "5"))),
            socket_timeout=max(1.0, float(os.getenv("REDIS_SOCKET_TIMEOUT_SECONDS", "10"))),
            health_check_interval=30,
            retry_on_timeout=True,
        )
    return _REDIS


def _decode(value):
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return value


class InjectionJobStore:
    def __init__(self):
        self.redis = get_redis()
        self.index_key = f"{NAMESPACE}:injection:index"
        self.enqueue_lock_key = f"{NAMESPACE}:injection:enqueue-lock"

    def _key(self, job_id: str) -> str:
        return f"{NAMESPACE}:injection:job:{job_id}"

    def _job_lock(self, job_id: str):
        return self.redis.lock(
            f"{NAMESPACE}:injection:job-lock:{job_id}",
            timeout=30,
            blocking_timeout=10,
        )

    @contextmanager
    def enqueue_lock(self):
        lock = self.redis.lock(self.enqueue_lock_key, timeout=45, blocking_timeout=15)
        if not lock.acquire(blocking=True):
            raise TimeoutError("The shared injection queue is busy. Please retry shortly.")
        try:
            yield
        finally:
            try:
                lock.release()
            except Exception:
                pass

    def ping(self) -> bool:
        return bool(self.redis.ping())

    def create(self, job_id: str, job: Dict[str, Any], *, overwrite: bool = False) -> Dict[str, Any]:
        now = time.time()
        payload = dict(job)
        payload["job_id"] = job_id
        payload.setdefault("created_at", now)
        payload.setdefault("updated_at", now)
        payload.setdefault("events", [])
        payload.setdefault("result", None)
        key = self._key(job_id)
        encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        with self.redis.pipeline() as pipe:
            if overwrite:
                pipe.set(key, encoded, ex=ACTIVE_JOB_TTL_SECONDS)
            else:
                pipe.set(key, encoded, ex=ACTIVE_JOB_TTL_SECONDS, nx=True)
            pipe.zadd(self.index_key, {job_id: float(payload["created_at"])})
            pipe.execute()
        return self.get(job_id) or payload

    def get(self, job_id: str) -> Optional[Dict[str, Any]]:
        raw = self.redis.get(self._key(job_id))
        if not raw:
            return None
        try:
            value = json.loads(_decode(raw))
            return value if isinstance(value, dict) else None
        except (TypeError, ValueError, json.JSONDecodeError):
            return None

    def save(self, job_id: str, job: Dict[str, Any]) -> Dict[str, Any]:
        payload = dict(job)
        payload["job_id"] = job_id
        payload["updated_at"] = float(payload.get("updated_at") or time.time())
        terminal = payload.get("status") in {"complete", "done", "finished_with_errors", "error", "refunded"}
        ttl = JOB_RETENTION_SECONDS if terminal else ACTIVE_JOB_TTL_SECONDS
        self.redis.set(
            self._key(job_id),
            json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
            ex=ttl,
        )
        self.redis.zadd(self.index_key, {job_id: float(payload.get("created_at") or time.time())})
        return payload

    def update(self, job_id: str, **changes) -> Optional[Dict[str, Any]]:
        with self._job_lock(job_id):
            job = self.get(job_id)
            if not job:
                return None
            job.update(changes)
            job["updated_at"] = time.time()
            return self.save(job_id, job)

    def append_event(self, job_id: str, stage: str, message: str, extra=None) -> Optional[Dict[str, Any]]:
        with self._job_lock(job_id):
            job = self.get(job_id)
            if not job:
                return None
            event = {"stage": stage, "message": message, "time": time.time()}
            if isinstance(extra, dict):
                event.update(extra)
            events = job.setdefault("events", [])
            # Progress callbacks may report the same phase every few seconds.
            # Keep one public cleanup line instead of filling Redis/the UI with
            # timestamp-only duplicates.  The checkpoint still receives fresh
            # heartbeats, so suppressing the event does not hide a stalled job.
            if events:
                previous = events[-1]
                same_stage = str(previous.get("stage") or "") == str(stage or "")
                same_message = str(previous.get("message") or "").strip() == str(message or "").strip()
                cleanup_repeat = stage == "finishing" and str(previous.get("stage") or "") == "finishing"
                if (same_stage and same_message) or cleanup_repeat:
                    job["updated_at"] = time.time()
                    return self.save(job_id, job)
            events.append(event)
            if len(events) > MAX_JOB_EVENTS:
                del events[:-MAX_JOB_EVENTS]
            job["updated_at"] = time.time()
            return self.save(job_id, job)

    def finish(self, job_id: str, status: str, result: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        return self.update(
            job_id,
            status=status,
            result=result,
            password=None,
            source_password=None,
        )

    def delete(self, job_id: str) -> None:
        with self.redis.pipeline() as pipe:
            pipe.delete(self._key(job_id))
            pipe.zrem(self.index_key, job_id)
            pipe.execute()

    def list_jobs(self) -> list[tuple[str, Dict[str, Any]]]:
        ids = [_decode(value) for value in self.redis.zrange(self.index_key, 0, -1)]
        if not ids:
            return []
        raws = self.redis.mget([self._key(job_id) for job_id in ids])
        jobs = []
        missing = []
        for job_id, raw in zip(ids, raws):
            if not raw:
                missing.append(job_id)
                continue
            try:
                job = json.loads(_decode(raw))
            except (TypeError, ValueError, json.JSONDecodeError):
                missing.append(job_id)
                continue
            if isinstance(job, dict):
                jobs.append((job_id, job))
        if missing:
            self.redis.zrem(self.index_key, *missing)
        return jobs

    @staticmethod
    def _account_keys(job: Dict[str, Any]) -> set[str]:
        values = job.get("account_keys") or []
        return {str(value).strip().lower() for value in values if value}

    def find_active(self, *, web_uid: Any, kind: str, states=None):
        wanted = set(states or ("awaiting_target", "queued", "running", "resume_pending", "manual_review"))
        web_uid = str(web_uid)
        for job_id, job in self.list_jobs():
            if str(job.get("web_uid")) == web_uid and job.get("kind") == kind and job.get("status") in wanted:
                return job_id, job
        return None

    def account_conflict(self, account_keys: Iterable[str], *, exclude_job_id: Optional[str] = None):
        requested = {str(value).strip().lower() for value in account_keys if value}
        if not requested:
            return None
        for job_id, job in self.list_jobs():
            if job_id == exclude_job_id or job.get("status") not in {"queued", "running", "resume_pending", "manual_review"}:
                continue
            if requested.intersection(self._account_keys(job)):
                return job_id, job
        return None

    def capacity(self, limit: int) -> Dict[str, int]:
        active = sum(
            1
            for _, job in self.list_jobs()
            if job.get("status") in {"awaiting_target", "queued", "running", "resume_pending", "manual_review"}
        )
        return {"active": active, "limit": int(limit), "available": max(0, int(limit) - active)}

    def queue_snapshot(self, kind: str, job_id: Optional[str], *, max_concurrent: int, limit: int) -> Dict[str, Any]:
        kind = kind if kind in {"premium", "event", "catalog", "unlock_all", "clone"} else "premium"
        jobs = self.list_jobs()
        running = [job for _, job in jobs if job.get("status") == "running" and job.get("kind") == kind]
        queued = sorted(
            [(jid, job) for jid, job in jobs if job.get("status") in {"queued", "resume_pending"} and job.get("kind") == kind],
            key=lambda pair: float(pair[1].get("created_at") or 0),
        )
        position = people_ahead = None
        if job_id:
            for index, (candidate_id, _) in enumerate(queued):
                if candidate_id == job_id:
                    position = index + 1
                    people_ahead = index
                    break
            job = self.get(job_id)
            if job and job.get("status") == "running":
                position = people_ahead = 0
        return {
            "kind": kind,
            "running": len(running),
            "waiting": len(queued),
            "position": position,
            "people_ahead": people_ahead,
            "max_concurrent": int(max_concurrent),
            "capacity": self.capacity(limit),
        }

    def states(self) -> Dict[str, int]:
        states = {
            "running": 0,
            "queued": 0,
            "awaiting_target": 0,
            "resume_pending": 0,
            "manual_review": 0,
        }
        for _, job in self.list_jobs():
            status = job.get("status")
            if status in states:
                states[status] += 1
        return states


_STORE = None


def get_job_store() -> InjectionJobStore:
    global _STORE
    if _STORE is None:
        _STORE = InjectionJobStore()
    return _STORE
