#!/usr/bin/env python3
"""Shared PostgreSQL pool and schema for horizontally scaled TNNR services."""

from __future__ import annotations

import os
import threading
from contextlib import contextmanager


DATABASE_URL = os.getenv("DATABASE_URL", "").strip()
_POOL = None
_POOL_LOCK = threading.RLock()
_SCHEMA_READY = False


SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS site_users (
    user_id TEXT PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    balance BIGINT NOT NULL DEFAULT 0 CHECK (balance >= 0),
    created_at DOUBLE PRECISION NOT NULL,
    updated_at DOUBLE PRECISION NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_site_users_email_lower
    ON site_users ((lower(email)));

CREATE TABLE IF NOT EXISTS credit_ledger (
    id BIGSERIAL PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES site_users(user_id) ON DELETE CASCADE,
    entry_type TEXT NOT NULL,
    amount BIGINT NOT NULL DEFAULT 0,
    previous_balance BIGINT,
    target_balance BIGINT,
    reason TEXT NOT NULL,
    balance_after BIGINT NOT NULL,
    event_time DOUBLE PRECISION NOT NULL,
    meta JSONB NOT NULL DEFAULT '{}'::jsonb,
    source_key TEXT UNIQUE
);

CREATE INDEX IF NOT EXISTS idx_credit_ledger_user_time
    ON credit_ledger (user_id, event_time DESC);

CREATE TABLE IF NOT EXISTS stripe_topups (
    session_id TEXT PRIMARY KEY,
    event_id TEXT NOT NULL,
    user_id TEXT NOT NULL REFERENCES site_users(user_id),
    pack_id TEXT NOT NULL,
    credits BIGINT NOT NULL,
    amount_cents BIGINT NOT NULL,
    currency TEXT NOT NULL,
    fulfilled_at DOUBLE PRECISION NOT NULL,
    balance_after BIGINT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_stripe_topups_user
    ON stripe_topups (user_id, fulfilled_at DESC);

CREATE TABLE IF NOT EXISTS job_reservations (
    job_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES site_users(user_id),
    web_uid TEXT NOT NULL,
    kind TEXT NOT NULL,
    action TEXT NOT NULL,
    idempotency_key TEXT NOT NULL,
    account_keys JSONB NOT NULL DEFAULT '[]'::jsonb,
    cost BIGINT NOT NULL DEFAULT 0,
    state TEXT NOT NULL,
    payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at DOUBLE PRECISION NOT NULL,
    updated_at DOUBLE PRECISION NOT NULL,
    started_at DOUBLE PRECISION,
    completed_at DOUBLE PRECISION,
    refunded_at DOUBLE PRECISION,
    failure_message TEXT,
    checkpoint JSONB NOT NULL DEFAULT '{}'::jsonb,
    attempt_count INTEGER NOT NULL DEFAULT 0,
    max_attempts INTEGER NOT NULL DEFAULT 4,
    last_heartbeat DOUBLE PRECISION
);

ALTER TABLE job_reservations
    ADD COLUMN IF NOT EXISTS checkpoint JSONB NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE job_reservations
    ADD COLUMN IF NOT EXISTS attempt_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE job_reservations
    ADD COLUMN IF NOT EXISTS max_attempts INTEGER NOT NULL DEFAULT 4;
ALTER TABLE job_reservations
    ADD COLUMN IF NOT EXISTS last_heartbeat DOUBLE PRECISION;

CREATE UNIQUE INDEX IF NOT EXISTS uq_active_job_reservation
    ON job_reservations (idempotency_key)
    WHERE state IN ('reserved', 'awaiting_target', 'queued', 'running');

CREATE UNIQUE INDEX IF NOT EXISTS uq_resumable_job_reservation
    ON job_reservations (idempotency_key)
    WHERE state IN (
        'reserved', 'awaiting_target', 'queued', 'running',
        'resume_pending', 'manual_review'
    );

CREATE INDEX IF NOT EXISTS idx_job_reservations_state_time
    ON job_reservations (state, created_at);

CREATE TABLE IF NOT EXISTS injection_account_locks (
    account_key TEXT PRIMARY KEY,
    job_id TEXT NOT NULL REFERENCES job_reservations(job_id) ON DELETE CASCADE,
    created_at DOUBLE PRECISION NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_injection_account_locks_job
    ON injection_account_locks (job_id);

CREATE TABLE IF NOT EXISTS injection_outbox (
    job_id TEXT PRIMARY KEY REFERENCES job_reservations(job_id) ON DELETE CASCADE,
    payload JSONB NOT NULL,
    available_at DOUBLE PRECISION NOT NULL,
    dispatched_at DOUBLE PRECISION,
    attempts INTEGER NOT NULL DEFAULT 0,
    last_error TEXT,
    created_at DOUBLE PRECISION NOT NULL,
    updated_at DOUBLE PRECISION NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_injection_outbox_pending
    ON injection_outbox (available_at, created_at)
    WHERE dispatched_at IS NULL;

CREATE TABLE IF NOT EXISTS car_job_diagnostics (
    id BIGSERIAL PRIMARY KEY,
    job_id TEXT NOT NULL,
    user_id TEXT,
    kind TEXT NOT NULL,
    stage TEXT NOT NULL,
    message TEXT NOT NULL,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    event_time DOUBLE PRECISION NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_car_job_diagnostics_job_time
    ON car_job_diagnostics (job_id,event_time DESC);
CREATE INDEX IF NOT EXISTS idx_car_job_diagnostics_time
    ON car_job_diagnostics (event_time DESC);

CREATE TABLE IF NOT EXISTS site_settings (
    setting_key TEXT PRIMARY KEY,
    setting_value JSONB NOT NULL,
    updated_at DOUBLE PRECISION NOT NULL
);

CREATE TABLE IF NOT EXISTS backlog_credentials (
    id BIGSERIAL PRIMARY KEY,
    player_name TEXT NOT NULL,
    email TEXT NOT NULL,
    password TEXT NOT NULL,
    web_uid TEXT,
    recorded_at DOUBLE PRECISION NOT NULL,
    payload JSONB NOT NULL,
    source_key TEXT UNIQUE
);

CREATE INDEX IF NOT EXISTS idx_backlog_credentials_email_time
    ON backlog_credentials ((lower(email)), recorded_at DESC);

CREATE TABLE IF NOT EXISTS backlog_actions (
    id BIGSERIAL PRIMARY KEY,
    email TEXT NOT NULL,
    player_name TEXT NOT NULL,
    action TEXT NOT NULL,
    action_title TEXT NOT NULL,
    success BOOLEAN NOT NULL,
    message TEXT NOT NULL,
    web_uid TEXT,
    event_time DOUBLE PRECISION NOT NULL,
    payload JSONB NOT NULL,
    source_key TEXT UNIQUE
);

ALTER TABLE backlog_credentials ADD COLUMN IF NOT EXISTS source_key TEXT;
ALTER TABLE backlog_actions ADD COLUMN IF NOT EXISTS source_key TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS uq_backlog_credentials_source_key
    ON backlog_credentials (source_key);
CREATE UNIQUE INDEX IF NOT EXISTS uq_backlog_actions_source_key
    ON backlog_actions (source_key);

CREATE INDEX IF NOT EXISTS idx_backlog_actions_email_time
    ON backlog_actions ((lower(email)), event_time DESC);
CREATE INDEX IF NOT EXISTS idx_backlog_actions_time
    ON backlog_actions (event_time DESC);

CREATE TABLE IF NOT EXISTS live_counters (
    counter_key TEXT PRIMARY KEY,
    counter_value BIGINT NOT NULL DEFAULT 0,
    updated_at DOUBLE PRECISION NOT NULL
);

CREATE TABLE IF NOT EXISTS bulk_account_batches (
    batch_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES site_users(user_id) ON DELETE CASCADE,
    mode TEXT NOT NULL,
    email_prefix TEXT,
    source_email TEXT,
    source_password TEXT,
    total_accounts INTEGER NOT NULL DEFAULT 500,
    price BIGINT NOT NULL DEFAULT 100000,
    charged BIGINT NOT NULL DEFAULT 0,
    state TEXT NOT NULL DEFAULT 'queued',
    created_at DOUBLE PRECISION NOT NULL,
    updated_at DOUBLE PRECISION NOT NULL,
    started_at DOUBLE PRECISION,
    completed_at DOUBLE PRECISION,
    last_message TEXT NOT NULL DEFAULT ''
);

ALTER TABLE bulk_account_batches
    ADD COLUMN IF NOT EXISTS email_prefix TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS uq_bulk_account_active_user
    ON bulk_account_batches (user_id)
    WHERE state IN ('queued', 'running');

CREATE INDEX IF NOT EXISTS idx_bulk_account_batches_user_time
    ON bulk_account_batches (user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS bulk_account_items (
    batch_id TEXT NOT NULL REFERENCES bulk_account_batches(batch_id) ON DELETE CASCADE,
    account_index INTEGER NOT NULL,
    email TEXT NOT NULL,
    password TEXT NOT NULL,
    coin_amount INTEGER NOT NULL DEFAULT 30000,
    state TEXT NOT NULL DEFAULT 'pending',
    stage TEXT NOT NULL DEFAULT 'waiting',
    last_message TEXT NOT NULL DEFAULT 'Waiting for a worker.',
    car_amount INTEGER NOT NULL DEFAULT 0,
    attempt_count INTEGER NOT NULL DEFAULT 0,
    max_attempts INTEGER NOT NULL DEFAULT 6,
    checkpoint JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at DOUBLE PRECISION NOT NULL,
    updated_at DOUBLE PRECISION NOT NULL,
    started_at DOUBLE PRECISION,
    completed_at DOUBLE PRECISION,
    last_heartbeat DOUBLE PRECISION,
    PRIMARY KEY (batch_id, account_index),
    UNIQUE (email)
);

ALTER TABLE bulk_account_items
    ADD COLUMN IF NOT EXISTS coin_amount INTEGER NOT NULL DEFAULT 30000;

CREATE INDEX IF NOT EXISTS idx_bulk_account_items_batch_state
    ON bulk_account_items (batch_id, state, account_index);

CREATE TABLE IF NOT EXISTS bulk_account_events (
    id BIGSERIAL PRIMARY KEY,
    batch_id TEXT NOT NULL REFERENCES bulk_account_batches(batch_id) ON DELETE CASCADE,
    account_index INTEGER,
    stage TEXT NOT NULL,
    message TEXT NOT NULL,
    event_time DOUBLE PRECISION NOT NULL,
    meta JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_bulk_account_events_batch_id
    ON bulk_account_events (batch_id, id DESC);

CREATE TABLE IF NOT EXISTS bulk_account_outbox (
    batch_id TEXT NOT NULL,
    account_index INTEGER NOT NULL,
    available_at DOUBLE PRECISION NOT NULL,
    dispatched_at DOUBLE PRECISION,
    attempts INTEGER NOT NULL DEFAULT 0,
    last_error TEXT,
    created_at DOUBLE PRECISION NOT NULL,
    updated_at DOUBLE PRECISION NOT NULL,
    PRIMARY KEY (batch_id, account_index),
    FOREIGN KEY (batch_id, account_index)
        REFERENCES bulk_account_items(batch_id, account_index) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_bulk_account_outbox_pending
    ON bulk_account_outbox (available_at, created_at)
    WHERE dispatched_at IS NULL;

CREATE TABLE IF NOT EXISTS car_safety_backups (
    job_id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    email TEXT NOT NULL,
    site_user_id TEXT NOT NULL DEFAULT '',
    created_at DOUBLE PRECISION NOT NULL,
    original_car_count INTEGER NOT NULL,
    original_id_counts JSONB NOT NULL DEFAULT '{}'::jsonb,
    garage_export JSONB NOT NULL DEFAULT '[]'::jsonb,
    final_car_count INTEGER,
    missing_original_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
    verified_at DOUBLE PRECISION,
    verification_state TEXT NOT NULL DEFAULT 'backup_saved'
);

CREATE INDEX IF NOT EXISTS idx_car_safety_backups_created
    ON car_safety_backups (created_at DESC);

CREATE INDEX IF NOT EXISTS idx_car_safety_backups_user_created
    ON car_safety_backups (site_user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS support_tickets (
    ticket_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    email TEXT NOT NULL,
    subject TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'general',
    status TEXT NOT NULL DEFAULT 'open',
    created_at DOUBLE PRECISION NOT NULL,
    updated_at DOUBLE PRECISION NOT NULL
);

ALTER TABLE support_tickets
    ADD COLUMN IF NOT EXISTS category TEXT NOT NULL DEFAULT 'general';

CREATE INDEX IF NOT EXISTS idx_support_tickets_category_time
    ON support_tickets (category, updated_at DESC);

CREATE INDEX IF NOT EXISTS idx_support_tickets_user_time
    ON support_tickets (user_id, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_support_tickets_status_time
    ON support_tickets (status, updated_at DESC);

CREATE TABLE IF NOT EXISTS support_ticket_messages (
    message_id TEXT PRIMARY KEY,
    ticket_id TEXT NOT NULL REFERENCES support_tickets(ticket_id) ON DELETE CASCADE,
    from_role TEXT NOT NULL,
    author TEXT NOT NULL,
    body TEXT NOT NULL,
    event_time DOUBLE PRECISION NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_support_ticket_messages_ticket_time
    ON support_ticket_messages (ticket_id, event_time ASC);

CREATE TABLE IF NOT EXISTS admin_inbox_messages (
    message_id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    user_id TEXT NOT NULL DEFAULT '',
    event_time DOUBLE PRECISION NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_admin_inbox_messages_time
    ON admin_inbox_messages (event_time DESC);

CREATE TABLE IF NOT EXISTS admin_inbox_reads (
    user_id TEXT NOT NULL REFERENCES site_users(user_id) ON DELETE CASCADE,
    message_id TEXT NOT NULL REFERENCES admin_inbox_messages(message_id) ON DELETE CASCADE,
    read_at DOUBLE PRECISION NOT NULL,
    PRIMARY KEY (user_id, message_id)
);

CREATE INDEX IF NOT EXISTS idx_admin_inbox_reads_user
    ON admin_inbox_reads (user_id, read_at DESC);

CREATE TABLE IF NOT EXISTS world_sale_health (
    singleton BOOLEAN PRIMARY KEY DEFAULT TRUE CHECK (singleton),
    state TEXT NOT NULL DEFAULT 'available',
    zero_since DOUBLE PRECISION,
    last_checked DOUBLE PRECISION NOT NULL DEFAULT 0,
    last_available DOUBLE PRECISION NOT NULL DEFAULT 0,
    slot_count INTEGER NOT NULL DEFAULT 0
);

INSERT INTO world_sale_health (singleton) VALUES (TRUE)
ON CONFLICT (singleton) DO NOTHING;

CREATE TABLE IF NOT EXISTS affected_refund_batches (
    batch_id TEXT PRIMARY KEY,
    multiplier NUMERIC(12,4) NOT NULL CHECK (multiplier > 0 AND multiplier <= 10),
    include_public BOOLEAN NOT NULL,
    include_failed BOOLEAN NOT NULL,
    start_at DOUBLE PRECISION,
    end_at DOUBLE PRECISION,
    note TEXT NOT NULL DEFAULT '',
    created_at DOUBLE PRECISION NOT NULL,
    user_count INTEGER NOT NULL DEFAULT 0,
    total_qualifying_spend BIGINT NOT NULL DEFAULT 0,
    total_refunded BIGINT NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS affected_refund_items (
    batch_id TEXT NOT NULL REFERENCES affected_refund_batches(batch_id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES site_users(user_id),
    qualifying_spend BIGINT NOT NULL,
    refund_amount BIGINT NOT NULL,
    balance_after BIGINT NOT NULL,
    sources JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at DOUBLE PRECISION NOT NULL,
    PRIMARY KEY (batch_id,user_id)
);

CREATE TABLE IF NOT EXISTS affected_refund_source_claims (
    source_type TEXT NOT NULL,
    source_id TEXT NOT NULL,
    user_id TEXT NOT NULL REFERENCES site_users(user_id),
    qualifying_spend BIGINT NOT NULL,
    batch_id TEXT NOT NULL REFERENCES affected_refund_batches(batch_id),
    created_at DOUBLE PRECISION NOT NULL,
    PRIMARY KEY (source_type,source_id)
);

CREATE INDEX IF NOT EXISTS idx_affected_refund_items_user
    ON affected_refund_items (user_id,created_at DESC);

CREATE TABLE IF NOT EXISTS shared_car_designs (
    design_id TEXT PRIMARY KEY,
    share_code TEXT NOT NULL UNIQUE,
    owner_user_id TEXT NOT NULL REFERENCES site_users(user_id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    car_id INTEGER NOT NULL,
    vinyl_count INTEGER NOT NULL,
    price_credits INTEGER NOT NULL DEFAULT 0 CHECK (price_credits BETWEEN 0 AND 10000),
    visibility TEXT NOT NULL DEFAULT 'private',
    status TEXT NOT NULL DEFAULT 'active',
    payload JSONB NOT NULL,
    photo_data BYTEA,
    photo_mime TEXT,
    created_at DOUBLE PRECISION NOT NULL,
    updated_at DOUBLE PRECISION NOT NULL,
    sales_count INTEGER NOT NULL DEFAULT 0,
    sales_limit INTEGER NOT NULL DEFAULT 1 CHECK (sales_limit BETWEEN 1 AND 10000),
    injection_count INTEGER NOT NULL DEFAULT 0
);

ALTER TABLE shared_car_designs
    ADD COLUMN IF NOT EXISTS sales_limit INTEGER NOT NULL DEFAULT 1;
ALTER TABLE shared_car_designs
    ADD COLUMN IF NOT EXISTS normalized_title TEXT NOT NULL DEFAULT '';
ALTER TABLE shared_car_designs
    ADD COLUMN IF NOT EXISTS verification_marker TEXT NOT NULL DEFAULT '';
ALTER TABLE shared_car_designs
    ADD COLUMN IF NOT EXISTS payload_fingerprint TEXT NOT NULL DEFAULT '';
ALTER TABLE shared_car_designs
    ADD COLUMN IF NOT EXISTS photo_fingerprint TEXT NOT NULL DEFAULT '';
ALTER TABLE shared_car_designs
    ADD COLUMN IF NOT EXISTS duplicate_of TEXT;
ALTER TABLE shared_car_designs
    ADD COLUMN IF NOT EXISTS moderation_note TEXT NOT NULL DEFAULT '';
ALTER TABLE shared_car_designs
    DROP CONSTRAINT IF EXISTS shared_car_designs_price_credits_check;
ALTER TABLE shared_car_designs
    ADD CONSTRAINT shared_car_designs_price_credits_check
    CHECK (price_credits BETWEEN 0 AND 10000);

CREATE INDEX IF NOT EXISTS idx_shared_designs_public
    ON shared_car_designs (visibility, status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_shared_designs_owner_fingerprints
    ON shared_car_designs (owner_user_id, visibility, status, payload_fingerprint, photo_fingerprint);

CREATE TABLE IF NOT EXISTS verified_catalog_promotions (
    promotion_id TEXT PRIMARY KEY,
    source_design_id TEXT NOT NULL UNIQUE REFERENCES shared_car_designs(design_id) ON DELETE CASCADE,
    source_share_code TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    car_id INTEGER NOT NULL,
    vinyl_count INTEGER NOT NULL DEFAULT 0,
    payload JSONB NOT NULL,
    photo_data BYTEA,
    photo_mime TEXT,
    source_owner_user_id TEXT NOT NULL REFERENCES site_users(user_id) ON DELETE CASCADE,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    created_at DOUBLE PRECISION NOT NULL,
    updated_at DOUBLE PRECISION NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_verified_catalog_promotions_source_code
    ON verified_catalog_promotions (source_share_code);
CREATE INDEX IF NOT EXISTS idx_verified_catalog_promotions_enabled
    ON verified_catalog_promotions (enabled, created_at DESC);

CREATE TABLE IF NOT EXISTS shared_design_seller_controls (
    user_id TEXT PRIMARY KEY REFERENCES site_users(user_id) ON DELETE CASCADE,
    public_selling_status TEXT NOT NULL DEFAULT 'active',
    suspended_until DOUBLE PRECISION,
    reason TEXT NOT NULL DEFAULT '',
    warning_count INTEGER NOT NULL DEFAULT 0,
    updated_at DOUBLE PRECISION NOT NULL
);

CREATE TABLE IF NOT EXISTS shared_design_moderation_events (
    event_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES site_users(user_id) ON DELETE CASCADE,
    design_id TEXT,
    event_type TEXT NOT NULL,
    reason TEXT NOT NULL DEFAULT '',
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at DOUBLE PRECISION NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_shared_design_moderation_user_time
    ON shared_design_moderation_events (user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_shared_design_moderation_type_time
    ON shared_design_moderation_events (event_type, created_at DESC);

CREATE TABLE IF NOT EXISTS marketplace_maintenance_state (
    task_key TEXT PRIMARY KEY,
    status TEXT NOT NULL,
    started_at DOUBLE PRECISION NOT NULL,
    completed_at DOUBLE PRECISION,
    summary JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS shared_design_likes (
    design_id TEXT NOT NULL REFERENCES shared_car_designs(design_id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES site_users(user_id) ON DELETE CASCADE,
    created_at DOUBLE PRECISION NOT NULL,
    PRIMARY KEY (design_id, user_id)
);

CREATE TABLE IF NOT EXISTS shared_design_comments (
    comment_id TEXT PRIMARY KEY,
    design_id TEXT NOT NULL REFERENCES shared_car_designs(design_id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES site_users(user_id) ON DELETE CASCADE,
    display_name TEXT,
    body TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'visible',
    created_at DOUBLE PRECISION NOT NULL
);

ALTER TABLE shared_design_comments
    ADD COLUMN IF NOT EXISTS display_name TEXT;

CREATE INDEX IF NOT EXISTS idx_shared_design_comments
    ON shared_design_comments (design_id, created_at ASC);

CREATE TABLE IF NOT EXISTS shared_design_reports (
    report_id TEXT PRIMARY KEY,
    design_id TEXT NOT NULL REFERENCES shared_car_designs(design_id) ON DELETE CASCADE,
    reporter_user_id TEXT NOT NULL REFERENCES site_users(user_id) ON DELETE CASCADE,
    reason TEXT NOT NULL,
    details TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'open',
    created_at DOUBLE PRECISION NOT NULL,
    resolved_at DOUBLE PRECISION,
    UNIQUE (design_id, reporter_user_id)
);

CREATE INDEX IF NOT EXISTS idx_shared_design_reports_design_time
    ON shared_design_reports (design_id, created_at DESC);

CREATE TABLE IF NOT EXISTS shared_design_report_refunds (
    refund_id TEXT PRIMARY KEY,
    report_id TEXT NOT NULL UNIQUE REFERENCES shared_design_reports(report_id) ON DELETE CASCADE,
    design_id TEXT NOT NULL REFERENCES shared_car_designs(design_id) ON DELETE CASCADE,
    reporter_user_id TEXT NOT NULL REFERENCES site_users(user_id) ON DELETE CASCADE,
    amount BIGINT NOT NULL DEFAULT 0 CHECK (amount >= 0),
    purchase_source_keys JSONB NOT NULL DEFAULT '[]'::jsonb,
    status TEXT NOT NULL DEFAULT 'no_purchase',
    created_at DOUBLE PRECISION NOT NULL,
    credited_at DOUBLE PRECISION
);

CREATE INDEX IF NOT EXISTS idx_shared_design_report_refunds_user_time
    ON shared_design_report_refunds (reporter_user_id, created_at DESC);
"""


def configured() -> bool:
    return bool(DATABASE_URL)


def get_pool():
    """Create the bounded connection pool only when PostgreSQL is configured."""
    global _POOL
    if not DATABASE_URL:
        raise RuntimeError("DATABASE_URL is required for PostgreSQL mode.")
    with _POOL_LOCK:
        if _POOL is None:
            from psycopg.rows import dict_row
            from psycopg_pool import ConnectionPool

            minimum = max(1, int(os.getenv("POSTGRES_POOL_MIN", "1")))
            maximum = max(minimum, min(20, int(os.getenv("POSTGRES_POOL_MAX", "4"))))
            _POOL = ConnectionPool(
                conninfo=DATABASE_URL,
                min_size=minimum,
                max_size=maximum,
                open=True,
                timeout=max(1.0, float(os.getenv("POSTGRES_POOL_TIMEOUT_SECONDS", "10"))),
                kwargs={"row_factory": dict_row},
            )
    return _POOL


def ensure_schema() -> None:
    global _SCHEMA_READY
    if _SCHEMA_READY:
        return
    with _POOL_LOCK:
        if _SCHEMA_READY:
            return
        with get_pool().connection() as conn:
            # Only one replica performs DDL at a time during rolling deploys.
            with conn.transaction():
                conn.execute("SELECT pg_advisory_xact_lock(784611923)")
                for statement in SCHEMA_SQL.split(";"):
                    statement = statement.strip()
                    if statement:
                        conn.execute(statement)
        _SCHEMA_READY = True


@contextmanager
def connection(*, ensure: bool = True):
    if ensure:
        ensure_schema()
    with get_pool().connection() as conn:
        yield conn


def healthcheck() -> bool:
    try:
        with connection() as conn:
            return bool(conn.execute("SELECT 1 AS ok").fetchone()["ok"])
    except Exception:
        return False
