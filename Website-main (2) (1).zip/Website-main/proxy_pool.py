#!/usr/bin/env python3
"""Rotating SOCKS5 proxy pool for the 500 Account Generator only.

Dashboard login, premium/event inject, and clone stay on direct connections.
Ten logical proxy slots (same gateway credentials) are treated as distinct
lanes for connection isolation and round-robin assignment.
"""

from __future__ import annotations

import itertools
import os
import threading
from typing import List, Optional
from urllib.parse import quote

# Gateway credentials (override via env when needed).
_PROXY_USER = os.getenv(
    "CPM_PROXY_USER",
    "vdggrosqnogvcx9-odds-5+100-country-us",
).strip()
_PROXY_PASS = os.getenv("CPM_PROXY_PASS", "zz0znqa7bynevpe").strip()
_PROXY_HOST = os.getenv("CPM_PROXY_HOST", "rp.scrapegw.com").strip()
_PROXY_PORT = int(os.getenv("CPM_PROXY_PORT", "6060") or 6060)
# socks5 for remote DNS resolution through the proxy when supported.
_PROXY_SCHEME = os.getenv("CPM_PROXY_SCHEME", "socks5").strip().lower() or "socks5"
_PROXY_SLOT_COUNT = max(1, min(32, int(os.getenv("CPM_PROXY_SLOT_COUNT", "10") or 10)))

_LOCK = threading.RLock()
_COUNTER = itertools.count(0)


def _build_proxy_url(slot: int) -> str:
    """Build an authenticated SOCKS5 URL. Slot is recorded for lane identity only."""
    user = quote(_PROXY_USER, safe="")
    password = quote(_PROXY_PASS, safe="")
    # Slot query is informational for logs; the gateway ignores it.
    return (
        f"{_PROXY_SCHEME}://{user}:{password}@{_PROXY_HOST}:{_PROXY_PORT}"
        f"#slot{slot}"
    )


def proxy_urls() -> List[str]:
    """Return all configured proxy lane URLs (default: 10 identical gateways)."""
    return [_build_proxy_url(i) for i in range(_PROXY_SLOT_COUNT)]


def proxy_count() -> int:
    return _PROXY_SLOT_COUNT


def next_proxy_url() -> str:
    """Round-robin the next logical proxy lane."""
    with _LOCK:
        idx = next(_COUNTER) % _PROXY_SLOT_COUNT
    return _build_proxy_url(idx)


def proxy_url_for_index(index: int) -> str:
    """Stable lane for a worker index / account index."""
    return _build_proxy_url(int(index) % _PROXY_SLOT_COUNT)


def proxies_enabled() -> bool:
    """Proxies are on unless explicitly disabled."""
    flag = os.getenv("CPM_PROXY_ENABLED", "1").strip().lower()
    return flag not in {"0", "false", "no", "off"}


def make_aiohttp_connector(
    *,
    proxy_url: Optional[str] = None,
    limit: int = 12,
    limit_per_host: int = 8,
    ttl_dns_cache: int = 300,
    keepalive_timeout: float = 30.0,
    ssl: bool = False,
):
    """Build an aiohttp connector that routes through the next (or given) proxy.

    Falls back to a plain TCPConnector when proxies are disabled or aiohttp-socks
    is unavailable.
    """
    import aiohttp

    use_proxy = proxies_enabled()
    url = (proxy_url or next_proxy_url()) if use_proxy else None

    if use_proxy and url:
        try:
            from aiohttp_socks import ProxyConnector

            # Strip fragment used only for local slot identity.
            clean = url.split("#", 1)[0]
            return ProxyConnector.from_url(
                clean,
                ssl=ssl,
                limit=max(2, int(limit)),
                limit_per_host=max(1, int(limit_per_host)),
                rdns=True,
            )
        except Exception:
            # Proxy package missing or URL rejected — continue direct so jobs
            # still run rather than hard-failing every injection.
            pass

    return aiohttp.TCPConnector(
        ssl=ssl,
        limit=max(2, int(limit)),
        limit_per_host=max(1, int(limit_per_host)),
        ttl_dns_cache=max(30, int(ttl_dns_cache)),
        keepalive_timeout=max(5.0, float(keepalive_timeout)),
        enable_cleanup_closed=True,
    )


def requests_proxies(proxy_url: Optional[str] = None) -> dict:
    """Dict suitable for the requests library (HTTP and HTTPS via the same lane)."""
    if not proxies_enabled():
        return {}
    raw = proxy_url or next_proxy_url()
    clean = raw.split("#", 1)[0]
    # requests understands socks5:// when PySocks is installed; also expose http.
    return {"http": clean, "https": clean}
