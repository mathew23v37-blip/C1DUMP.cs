"""Shared runtime configuration for filesystem-backed state."""

from __future__ import annotations

import os

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get("DATA_DIR", "/app/data")
os.makedirs(DATA_DIR, exist_ok=True)


def data_path(*parts: str) -> str:
    """Return an absolute path under DATA_DIR and ensure its parent exists."""
    path = os.path.abspath(os.path.join(DATA_DIR, *parts))
    data_root = os.path.abspath(DATA_DIR)
    if path != data_root and not path.startswith(data_root + os.sep):
        raise ValueError(f"Refusing to resolve path outside DATA_DIR: {path}")
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    return path


def project_path(*parts: str) -> str:
    """Return an absolute path inside the packaged project."""
    return os.path.join(PROJECT_ROOT, *parts)
