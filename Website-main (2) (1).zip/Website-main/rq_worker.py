#!/usr/bin/env python3
"""Start one JSON-serialized RQ worker for injection jobs."""

from __future__ import annotations

import logging
import os
import socket

from redis_jobs import get_redis


def main() -> None:
    from rq import Queue, Worker
    from rq.serializers import JSONSerializer

    queue_name = os.getenv("RQ_INJECTION_QUEUE", "injections").strip() or "injections"
    bulk_queue_name = os.getenv("RQ_BULK_ACCOUNT_QUEUE", "bulk-accounts").strip() or "bulk-accounts"
    configured_queues = os.getenv("RQ_WORKER_QUEUES", f"{queue_name},{bulk_queue_name}")
    queue_names = list(dict.fromkeys(name.strip() for name in configured_queues.split(",") if name.strip()))
    if not queue_names:
        queue_names = [queue_name, bulk_queue_name]
    connection = get_redis()
    queues = [Queue(name, connection=connection, serializer=JSONSerializer) for name in queue_names]
    worker_name = f"tnnr-{socket.gethostname()}-{os.getpid()}"
    worker = Worker(
        queues,
        connection=connection,
        serializer=JSONSerializer,
        name=worker_name,
    )
    worker.work(
        with_scheduler=False,
        logging_level=os.getenv("LOG_LEVEL", "INFO"),
    )


if __name__ == "__main__":
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
    main()
