# TNNR Railway Redis + RQ + PostgreSQL rollout

This build supports multiple web processes and Railway replicas without sharing
an application volume. Perform the rollout in order. Keep dashboard maintenance
enabled until the final functional checks pass.

## What is already implemented

- PostgreSQL users, password hashes, balances, credit ledger, Stripe top-up
  idempotency, shared settings, backlog history, and live counters.
- Atomic paid-job reservations. The balance debit, unique reservation, account
  lock, and durable outbox row commit in one PostgreSQL transaction.
- Redis job status, progress events, queue views, distributed admission lock,
  CPM login/session cache, player-record cache, and live-viewer heartbeats.
- A PostgreSQL outbox dispatcher and JSON-serialized RQ worker. Only a stable
  job ID enters RQ; CPM credentials remain in the PostgreSQL reservation until
  the job reaches a terminal state, then they are cleared.
- Durable paid-job recovery. PostgreSQL keeps the credit reservation, job
  credentials, attempt count, heartbeat, and successful CarID
  checkpoint. Redis mirrors live progress for the UI. A timed-out or crashed
  worker requeues the same job ID without another debit and skips checkpointed
  cars on the next attempt.
- Every resumed attempt also re-reads the destination garage. This covers the
  narrow crash window where CPM accepted a car immediately before the
  checkpoint write: already-owned CarIDs are skipped instead of duplicated.
- Automatic recovery is bounded. After `INJECTION_MAX_ATTEMPTS`, the paid
  reservation, credentials, account lock, and checkpoint stay in
  `manual_review` until an administrator resumes or refunds it.
- Idempotent administrator refunds through `distributed_admin.py`.

## Phase 1 — provision without switching the live site

1. Turn dashboard maintenance ON and create a backup of the existing Railway
   volume.
2. In the project canvas, add **PostgreSQL** and **Redis**.
3. On the existing web service add these reference variables. Use your actual
   database service names if they are not `Postgres` and `Redis`:

   ```text
   DATABASE_URL=${{Postgres.DATABASE_URL}}
   REDIS_URL=${{Redis.REDIS_URL}}
   POSTGRES_ACCOUNTS_ENABLED=0
   DISTRIBUTED_JOBS_ENABLED=0
   REDIS_RUNTIME_ENABLED=0
   WEB_WORKERS=1
   ```

4. Deploy this code while the current `/app/data` volume is still attached.
   The three `=0` flags keep the old JSON/SQLite runtime active during the
   migration.

Do not use a Railway pre-deploy command to import `/app/data`: pre-deploy
containers do not receive service volumes.

## Phase 2 — migrate and verify every stored credit

Open a Railway SSH shell into the running web service and run:

```bash
python migrate_to_postgres.py \
  --source ./site_accounts.json \
  --data-dir /app/data
```

Use the packaged `./site_accounts.json` for accounts: it is the consolidated,
credit-corrected source with 6,620 users, 6,595 10k grant entries, and 264
Stripe top-up records. The volume path remains the source for settings and
backlog history. Do not accidentally migrate an older 20k-grant copy from the
volume.

The command is idempotent and exits non-zero unless these source values exactly
match PostgreSQL:

- user count
- total stored credits for those user IDs
- Stripe Checkout Session count

It also imports settings, live counters, credentials, and action history. Save
the printed JSON verification report. If a previous partial test database has
different balances, and the site is still in maintenance with no PostgreSQL
writes occurring, rerun once with `--replace-existing`.

Never enable PostgreSQL mode when `exact_match` is `false`.

## Phase 3 — create the private worker service

Create another Railway service from the same repository and name it
`TNNR Injection Worker`.

- Set its custom Config as Code path to `/railway.worker.json`.
- Do not generate a public domain.
- Do not attach the old application volume.
- Add the same `DATABASE_URL` and `REDIS_URL` reference variables.
- Set:

  ```text
  POSTGRES_ACCOUNTS_ENABLED=1
  DISTRIBUTED_JOBS_ENABLED=1
  REDIS_RUNTIME_ENABLED=1
  RQ_INJECTION_QUEUE=injections
  OUTBOX_POLL_SECONDS=1
  INJECTION_JOB_TIMEOUT_SECONDS=3600
  INJECTION_MAX_ATTEMPTS=4
  INJECTION_QUEUE_TTL_SECONDS=21600
  WORKER_SHUTDOWN_GRACE_SECONDS=300
  CLONE_RESERVATION_TTL_SECONDS=1800
  ```

Start with one worker-service replica. One replica processes one injection at a
time. Scale this service to two replicas only after one-replica tests show the
CPM endpoints remain stable.

## Phase 4 — switch the web service

Set these variables on the web service:

```text
POSTGRES_ACCOUNTS_ENABLED=1
DISTRIBUTED_JOBS_ENABLED=1
REDIS_RUNTIME_ENABLED=1
WEB_WORKERS=2
WEB_THREADS=8
POSTGRES_POOL_MIN=1
POSTGRES_POOL_MAX=4
MAX_CONCURRENT_INJECTIONS=1
MAX_QUEUED_INJECTIONS=40
MAX_JOB_EVENTS=600
UNLIMITED_AUTO_RESTART_ENABLED=0
```

Also set one strong, permanent `FLASK_SECRET_KEY`. Every replica must receive
the same value or signed login sessions will fail when requests move between
replicas.

The web service uses `/railway.json`, starts with
`gunicorn app:app --config gunicorn.conf.py`, and checks `/health`.

## Phase 5 — verify before adding replicas

Run from a Railway SSH shell with the worker variables:

```bash
python distributed_admin.py status
```

Expected conditions:

- `postgres: true`
- `redis: true`
- at least one RQ worker
- `pending_outbox: 0` when no new job is being submitted
- no unexpected failed jobs

Then verify:

1. Register and sign in to a test site account.
2. Confirm its balance matches PostgreSQL.
3. Complete one premium injection and watch status/events update.
4. Confirm a double-click returns the same job ID and charges once.
5. Submit two different CPM accounts and confirm they queue correctly.
6. Attempt overlapping jobs for the same CPM account and confirm the second is
   rejected without a debit.
7. Complete the paid clone flow, including an incorrect target login followed
   by a corrected login; the paid reservation must remain available.
8. Complete a small Stripe test-mode top-up twice with the same session and
   confirm it credits only once.
9. While a test injection is partway through, terminate the worker service.
   After Railway restarts it, confirm the same job ID changes through
   `resume_pending`/`queued`, the completed-CarID count is retained, and the
   site balance has only one debit.

For an administrator-approved refund:

```bash
python distributed_admin.py refund JOB_ID --reason administrator_review
```

The command is idempotent; repeating it cannot credit the user twice.

To resume a held `manual_review` job from its saved checkpoint without charging
again:

```bash
python distributed_admin.py resume JOB_ID --reason administrator_resume
```

Useful recovery states:

- `running`: an RQ workhorse owns the current attempt.
- `resume_pending`: the same reservation is waiting for its next bounded
  attempt; it is not a new purchase.
- `manual_review`: the retry limit was reached. The account lock intentionally
  remains, preventing a second paid operation from overlapping it.
- `completed`, `failed`, `refunded`: terminal states; credentials are cleared.

## Phase 6 — remove the volume dependency and scale

After the checks pass:

1. Detach the application volume from the web service. Keep its backup for at
   least seven days; do not delete it during the first rollout.
2. Set the web service to two Railway replicas.
3. Keep `WEB_WORKERS=2` and `WEB_THREADS=8` initially.
4. Keep the worker service at one replica. Change
   `MAX_CONCURRENT_INJECTIONS` on the web service to match the number of worker
   replicas shown to users.
5. Watch HTTP p95/p99, CPU, memory, PostgreSQL connections, Redis memory, queue
   wait time, worker duration, and failed-job count for at least one busy cycle.
6. Increase injection-worker replicas one at a time. Do not increase web and
   worker concurrency in the same observation window.

## Rollback

If verification fails before removing the volume, set all three feature flags
back to `0`, restore `WEB_WORKERS=1`, and redeploy. The old volume data remains
unchanged. Do not run both the JSON account backend and PostgreSQL account
backend as writable production sources at the same time.

## Official references

- Railway Redis: <https://docs.railway.com/databases/redis>
- Railway PostgreSQL: <https://docs.railway.com/databases/postgresql>
- Railway service reference variables: <https://docs.railway.com/variables>
- Railway Config as Code paths: <https://docs.railway.com/config-as-code>
- Railway volume limitations: <https://docs.railway.com/volumes/reference>
- Railway pre-deploy commands: <https://docs.railway.com/deployments/pre-deploy-command>
- RQ jobs and workers: <https://python-rq.org/docs/>
