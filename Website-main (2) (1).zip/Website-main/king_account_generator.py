"""Build one durable admin king account from its saved unique-CarID collection plan."""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict

import king_account_jobs
from king_collection_planner import DEFAULT_TARGET_CAR_COUNT, collection_payload, plan_summary
from user_cpm_alts import _firebase_signup, _initialize_cpm_game_account
from car_bulk_injector import close_current_injection_http_session, verify_account_garage_count

log = logging.getLogger("tnnr-king-account")


async def build_king_account(batch_id: str, account_index: int) -> Dict[str, Any]:
    """Create/resume one account and inject its saved, unique public collection."""
    item = king_account_jobs.get_item(batch_id, int(account_index))
    if not item:
        raise RuntimeError("King-account item no longer exists.")
    email = str(item["email"])
    password = str(item["password"])
    batch = king_account_jobs.get_batch(batch_id)
    target_cars = int((batch or {}).get("target_cars") or DEFAULT_TARGET_CAR_COUNT)
    plan = list(item.get("collection_plan") or [])
    summary = plan_summary(plan)
    if summary["distinct_car_ids"] != target_cars:
        raise RuntimeError(
            f"Persisted collection plan has {summary['distinct_car_ids']} unique CarIDs; "
            f"{target_cars} are required for this batch."
        )

    def progress(stage: str, message: str, extra=None):
        king_account_jobs.record_progress(batch_id, int(account_index), stage, message, extra)

    try:
        progress("account_create", f"Creating or resuming king account {account_index}…")
        signup = await _firebase_signup(email, password)
        if not signup.get("ok"):
            # A retry can encounter an already-created Firebase identity after
            # an interrupted worker. Resume it with the same saved credentials.
            from cpm_nuker import CPMNuker
            resumed = await CPMNuker().account_login(email, password)
            if resumed.get("ok"):
                signup = resumed
                progress("account_resume", "Existing CPM identity found; resuming its saved collection plan.")
            else:
                raise RuntimeError(
                    f"Firebase account creation failed: {signup.get('message') or resumed.get('message') or 'unknown error'}"
                )

        progress("account_initialize", "Initializing CPM player record and warming Europe garage data…")
        initialized = await _initialize_cpm_game_account(
            email=email,
            password=password,
            firebase_uid=str(signup.get("firebase_uid") or ""),
            auth=str(signup.get("auth") or ""),
            refresh_token=str(signup.get("refresh_token") or ""),
        )
        if not initialized.get("ok"):
            raise RuntimeError(initialized.get("message") or "CPM account initialization failed.")

        payload = collection_payload(plan)
        progress(
            "collection_ready",
            f"Loaded {target_cars} unique public designs: {summary['catalog_designs']} catalog and {summary['marketplace_designs']} marketplace selections.",
            summary,
        )
        from car_bulk_injector import inject_public_design_collection
        result = await inject_public_design_collection(
            payload,
            email,
            password,
            progress,
            item.get("checkpoint") or {},
        )
        completed = int(result.get("injected") or 0) + int(result.get("skipped") or 0)
        if not result.get("ok") or result.get("failed_ids"):
            raise RuntimeError(result.get("message") or "Public-design collection did not finish completely.")

        progress("garage_verify_start", "Verifying the completed king garage with Europe TestGetAllCars…", {"expected_minimum": target_cars})
        verification = await verify_account_garage_count(
            email,
            password,
            progress,
            minimum_count=target_cars,
            attempts=8,
        )
        if not verification.get("ok"):
            raise RuntimeError(verification.get("message") or "Final king-account garage verification failed.")
        car_amount = int(verification.get("count") or completed)
        progress("garage_verified", f"King garage verified with {car_amount} cars.", {"verified_car_count": car_amount})
        return {
            "ok": True,
            "email": email,
            "password": password,
            "car_amount": car_amount,
            "message": f"King account {account_index} completed with {car_amount} cars.",
        }
    finally:
        try:
            await close_current_injection_http_session()
        except Exception:
            log.exception("Unable to close king-account injection HTTP session")
