"""Shared World Sale availability state and one-minute recovery monitor."""

from __future__ import annotations

import asyncio
import os
import threading
import time
from typing import Any, Dict

from persistence import atomic_write_json, load_json, seed_data_file

DELAY_SECONDS = 30
PAUSE_SECONDS = 10 * 60
CHECK_INTERVAL_SECONDS = 60
_POSTGRES = bool(os.getenv("DATABASE_URL", "").strip())
_FILE = seed_data_file("world_sale_health.json", default={
    "state": "available", "zero_since": None, "last_checked": 0.0,
    "last_available": 0.0, "slot_count": 0,
})
_LOCK = threading.RLock()
_CREDENTIALS = {
    "email": os.getenv("WORLD_SALE_MONITOR_EMAIL", "").strip(),
    "password": os.getenv("WORLD_SALE_MONITOR_PASSWORD", ""),
}
_MONITOR_STARTED = False


def _state_for(zero_since: Any, now: float | None = None) -> str:
    now = float(now or time.time())
    try:
        elapsed = max(0.0, now - float(zero_since)) if zero_since else 0.0
    except (TypeError, ValueError):
        elapsed = 0.0
    if elapsed >= PAUSE_SECONDS:
        return "paused"
    if elapsed >= DELAY_SECONDS:
        return "delayed"
    return "checking" if zero_since else "available"


def _normalize(row: Dict[str, Any] | None) -> Dict[str, Any]:
    row = dict(row or {})
    now = time.time()
    zero_since = row.get("zero_since")
    state = _state_for(zero_since, now)
    elapsed = max(0, int(now - float(zero_since))) if zero_since else 0
    return {
        "state": state,
        "paused": state == "paused",
        "delayed": state in {"delayed", "paused"},
        "zero_since": float(zero_since) if zero_since else None,
        "zero_for_seconds": elapsed,
        "last_checked": float(row.get("last_checked") or 0),
        "last_available": float(row.get("last_available") or 0),
        "slot_count": max(0, int(row.get("slot_count") or 0)),
        "next_check_seconds": CHECK_INTERVAL_SECONDS if state in {"delayed", "paused"} else 0,
    }


def get_status() -> Dict[str, Any]:
    if _POSTGRES:
        from postgres_db import connection
        with connection() as conn:
            row = conn.execute(
                "SELECT * FROM world_sale_health WHERE singleton=TRUE"
            ).fetchone()
        return _normalize(dict(row) if row else {})
    with _LOCK:
        return _normalize(load_json(_FILE, {}))


def record_slots(slot_count: int) -> Dict[str, Any]:
    """Record a real authenticated slot result and update shared state."""
    count = max(0, int(slot_count or 0))
    now = time.time()
    if _POSTGRES:
        from postgres_db import connection
        with connection() as conn, conn.transaction():
            row = conn.execute(
                "SELECT * FROM world_sale_health WHERE singleton=TRUE FOR UPDATE"
            ).fetchone()
            current = dict(row) if row else {}
            zero_since = None if count > 0 else (current.get("zero_since") or now)
            state = _state_for(zero_since, now)
            conn.execute("""INSERT INTO world_sale_health
                (singleton,state,zero_since,last_checked,last_available,slot_count)
                VALUES (TRUE,%s,%s,%s,%s,%s)
                ON CONFLICT (singleton) DO UPDATE SET
                  state=EXCLUDED.state, zero_since=EXCLUDED.zero_since,
                  last_checked=EXCLUDED.last_checked,
                  last_available=EXCLUDED.last_available, slot_count=EXCLUDED.slot_count""",
                (state, zero_since, now, now if count > 0 else current.get("last_available"), count))
        return get_status()
    with _LOCK:
        current = load_json(_FILE, {})
        zero_since = None if count > 0 else (current.get("zero_since") or now)
        current.update({
            "state": _state_for(zero_since, now), "zero_since": zero_since,
            "last_checked": now,
            "last_available": now if count > 0 else float(current.get("last_available") or 0),
            "slot_count": count,
        })
        atomic_write_json(_FILE, current)
        return _normalize(current)


async def _probe(email: str, password: str) -> None:
    try:
        from car_bulk_injector import (
            close_current_injection_http_session,
            injection_http_session,
            login_async,
            get_world_sale_slots,
        )
        async with injection_http_session() as session:
            token, _ = await login_async(session, email, password)
            if token:
                await get_world_sale_slots(session, token, blocks=20, passes=1)
    except Exception:
        # Network/authentication errors are not proof that World Sale has zero slots.
        return
    finally:
        try:
            await close_current_injection_http_session()
        except Exception:
            pass


def _monitor_loop() -> None:
    while True:
        status = get_status()
        if status.get("zero_since"):
            with _LOCK:
                email = _CREDENTIALS["email"]
                password = _CREDENTIALS["password"]
            if email and password:
                try:
                    asyncio.run(_probe(email, password))
                except Exception:
                    pass
        # Confirm the initial 30-second delay promptly, then probe every minute.
        interval = 15 if status.get("state") == "checking" else CHECK_INTERVAL_SECONDS
        time.sleep(interval)


def register_probe_credentials(email: str, password: str) -> None:
    """Keep the most recent CPM login in process memory only for recovery probes."""
    global _MONITOR_STARTED
    if email and password:
        with _LOCK:
            _CREDENTIALS.update({"email": str(email), "password": str(password)})
    with _LOCK:
        if _MONITOR_STARTED:
            return
        _MONITOR_STARTED = True
        threading.Thread(target=_monitor_loop, name="world-sale-health-monitor", daemon=True).start()


def ensure_monitor() -> None:
    register_probe_credentials("", "")
