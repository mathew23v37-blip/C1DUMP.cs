#!/usr/bin/env python3
"""Website user accounts + balance ledger for TNNR.shop."""

from __future__ import annotations

import json
import os
import threading
import time
import uuid
from typing import Any, Dict, List, Optional

from persistence import atomic_write_json, data_path, is_unlimited_currency, load_json, seed_data_file
from werkzeug.security import check_password_hash, generate_password_hash

_DIR = os.path.dirname(os.path.abspath(__file__))
ACCOUNTS_FILE = seed_data_file("site_accounts.json", default={"users": {}, "email_index": {}})
_LOCK = threading.RLock()
_ACCOUNTS_CACHE: Optional[Dict[str, Any]] = None
_ACCOUNTS_FILE_TOKEN: Optional[tuple[int, int]] = None

# ---------------------------------------------------------------------------
# Pricing (balance units). Scaled in thousands by design.
# Car unlocks most expensive → player unlocks → coin → money.
# ---------------------------------------------------------------------------
# Base prices (×4 cheaper than original thousands scale)
PRICE_MONEY = 250
PRICE_COIN = 625
PRICE_PLAYER_UNLOCK = 1_875
PRICE_CAR_PREMIUM = 6_250
PRICE_CAR_EVENT = 6_250
PRICE_CATALOG_STANDARD = 10_000
PRICE_CATALOG_RESTRICTED = 10_000
PRICE_ACCOUNT_CLONE = 10_000
PRICE_UNLOCK_ALL_CARS = 12_000
PRICE_UNLOCK_ALL_FEATURES = 9_000
PRICE_CHANGE_ID = 2_000
PRICE_BULK_ACCOUNT_GENERATOR = 100_000

# Money injections up to this amount are free
FREE_MONEY_MAX = 15_000_000

# Bundles = money+coin combined at 40% off vs buying separately
PRICE_BUNDLE = int(round((PRICE_MONEY + PRICE_COIN) * 0.6))  # 525

ACTION_PRICES: Dict[str, int] = {
    "set_money": PRICE_MONEY,  # overridden to 0 when amount <= FREE_MONEY_MAX
    "set_coin": PRICE_COIN,
    "preset_50m_30k": PRICE_BUNDLE,
    "preset_50m_50k": PRICE_BUNDLE,
    "preset_50m_100k": PRICE_BUNDLE,
    "preset_50m_500k": PRICE_BUNDLE,
    "premium_car_inject": PRICE_CAR_PREMIUM,
    "event_car_inject": PRICE_CAR_EVENT,
    "catalog_car_inject": PRICE_CATALOG_STANDARD,
    "shared_design_inject": 0,
    "account_clone": PRICE_ACCOUNT_CLONE,
    "unlock_all_cars": PRICE_UNLOCK_ALL_CARS,
    # player / account modifications
    "unlock_w16": PRICE_PLAYER_UNLOCK,
    "unlock_horns": PRICE_PLAYER_UNLOCK,
    "disable_damage": PRICE_PLAYER_UNLOCK,
    "unlimited_fuel": PRICE_PLAYER_UNLOCK,
    "unlock_smoke": PRICE_PLAYER_UNLOCK,
    "unlock_animations": PRICE_PLAYER_UNLOCK,
    "unlock_wheels": PRICE_PLAYER_UNLOCK,
    "unlock_houses": PRICE_PLAYER_UNLOCK,
    "complete_levels": PRICE_PLAYER_UNLOCK,
    "set_rank": PRICE_PLAYER_UNLOCK,
    "unlock_all_features": PRICE_UNLOCK_ALL_FEATURES,
    "fix_account": 0,  # free repair tool
    "set_player_name": 0,  # free
    "set_player_id": PRICE_CHANGE_ID,
    "set_race_wins": PRICE_PLAYER_UNLOCK,
    "set_race_loses": PRICE_PLAYER_UNLOCK,
    "bulk_account_generator": PRICE_BULK_ACCOUNT_GENERATOR,
}

# Stripe top-up packs: credits granted per successful payment.
# amount_cents is what Stripe charges, expressed in the smallest currency unit.
# All Checkout and webhook fulfillment code must use this server-side allowlist;
# never trust an amount or credit quantity supplied by the browser or Stripe metadata.
# Presentation-only balance shown while persisted Unlimited Currency is ON.
# This value must never be written to account storage or ledger entries.
UNLIMITED_DISPLAY_BALANCE = 67_999_999
# Administrative exact-balance edits use the same explicit upper bound as the
# unlimited display convention, avoiding unsafe arbitrary-sized stored credits.
MAX_STORED_BALANCE = UNLIMITED_DISPLAY_BALANCE

TOPUP_PACKS: Dict[str, Dict[str, int]] = {
    "pack_2k": {"credits": 2_000, "amount_cents": 50},       # $0.50
    "pack_5k": {"credits": 5_000, "amount_cents": 100},      # $1.00
    "pack_10k": {"credits": 10_000, "amount_cents": 199},    # $1.99
    "pack_50k": {"credits": 50_000, "amount_cents": 799},    # $7.99
    "pack_150k": {"credits": 150_000, "amount_cents": 1999}, # $19.99
    "pack_500k": {"credits": 500_000, "amount_cents": 4999}, # $49.99
}


def _accounts_file_token() -> Optional[tuple[int, int]]:
    try:
        stat = os.stat(ACCOUNTS_FILE)
        return stat.st_mtime_ns, stat.st_size
    except FileNotFoundError:
        return None


def _load() -> Dict[str, Any]:
    """Load account state once and refresh only when the backing file changes."""
    global _ACCOUNTS_CACHE, _ACCOUNTS_FILE_TOKEN
    token = _accounts_file_token()
    if _ACCOUNTS_CACHE is not None and token == _ACCOUNTS_FILE_TOKEN:
        return _ACCOUNTS_CACHE

    data = load_json(ACCOUNTS_FILE, {"users": {}, "email_index": {}})
    if isinstance(data, dict) and "users" in data:
        data.setdefault("email_index", {})
    else:
        data = {"users": {}, "email_index": {}}
    _ACCOUNTS_CACHE = data
    _ACCOUNTS_FILE_TOKEN = token
    return _ACCOUNTS_CACHE


def _save(data: Dict[str, Any]) -> None:
    global _ACCOUNTS_CACHE, _ACCOUNTS_FILE_TOKEN
    atomic_write_json(ACCOUNTS_FILE, data)
    _ACCOUNTS_CACHE = data
    _ACCOUNTS_FILE_TOKEN = _accounts_file_token()


def price_for(action: str, amount: Optional[int] = None) -> int:
    """Return credit cost for an action.

    Money 1–15M is free. Name changes are free. Bundles use discounted PRICE_BUNDLE.
    """
    if action == "set_player_name":
        return 0
    if action == "set_money":
        if amount is not None and int(amount) <= FREE_MONEY_MAX:
            return 0
        return int(ACTION_PRICES.get("set_money", PRICE_MONEY))
    if action == "catalog_car_inject":
        return PRICE_CATALOG_STANDARD
    return int(ACTION_PRICES.get(action, 0))


def is_paid_action(action: str, amount: Optional[int] = None) -> bool:
    """Return True when an action normally requires a site-balance debit.

    This helper deliberately does not consider unlimited-currency mode. It only
    answers whether the action has a configured positive price. All actual
    sufficiency checks and deductions must go through :func:`charge`, which
    consults the persisted unlimited setting on every call.
    """
    return price_for(action, amount=amount) > 0


def register(email: str, password: str) -> Dict[str, Any]:
    email = (email or "").strip().lower()
    password = password or ""
    if not email or not password:
        return {"ok": False, "message": "Email and password are required."}
    with _LOCK:
        data = _load()
        if email in data.get("email_index", {}):
            return {"ok": False, "message": "That email is already registered."}
        user_id = uuid.uuid4().hex[:12]
        # ensure uniqueness
        while user_id in data["users"]:
            user_id = uuid.uuid4().hex[:12]
        user = {
            "user_id": user_id,
            "email": email,
            "password_hash": generate_password_hash(password),
            "balance": 0,
            "created_at": time.time(),
            "updated_at": time.time(),
            "ledger": [],
        }
        data["users"][user_id] = user
        data.setdefault("email_index", {})[email] = user_id
        _save(data)
    return {"ok": True, "user_id": user_id, "email": email, "balance": 0}


def login(email: str, password: str) -> Dict[str, Any]:
    email = (email or "").strip().lower()
    password = password or ""
    with _LOCK:
        data = _load()
        user_id = data.get("email_index", {}).get(email)
        if not user_id:
            return {"ok": False, "message": "Invalid email or password."}
        user = data["users"].get(user_id)
        if not user or not check_password_hash(user.get("password_hash", ""), password):
            return {"ok": False, "message": "Invalid email or password."}
    return {
            "ok": True,
            "user_id": user["user_id"],
            "email": user["email"],
            "balance": int(user.get("balance", 0)),
    }


def reset_password_by_email(email: str, password: str) -> Dict[str, Any]:
    """Admin-only helper: replace a site's hashed password by email."""
    email = (email or "").strip().lower()
    password = password or ""
    if not email or not password:
        return {"ok": False, "message": "Email and new password are required."}
    with _LOCK:
        data = _load()
        user_id = data.get("email_index", {}).get(email)
        user = data.get("users", {}).get(user_id) if user_id else None
        if not user:
            return {"ok": False, "message": "User not found for that email."}
        user["password_hash"] = generate_password_hash(password)
        user["updated_at"] = time.time()
        _save(data)
    return {"ok": True, "email": email}


def get_user(user_id: str) -> Optional[Dict[str, Any]]:
    with _LOCK:
        data = _load()
        user = data.get("users", {}).get(user_id)
        if not user:
            return None
        return {
            "user_id": user["user_id"],
            "email": user["email"],
            "balance": int(user.get("balance", 0)),
            "created_at": user.get("created_at"),
        }


def get_balance(user_id: str) -> int:
    user = get_user(user_id)
    return int(user["balance"]) if user else 0


def set_balance(user_id: str, balance: int, reason: str = "admin_set_balance") -> Dict[str, Any]:
    """Set a site account balance to an exact stored credit value.

    This is intentionally separate from add_balance()/refund()/charge(): it is
    an administrative replacement of the stored balance, not an increment or a
    deduction. It uses the same account lock, DATA_DIR-backed JSON file, and
    atomic write helper as the rest of the account ledger.
    """
    try:
        balance = int(balance)
    except (TypeError, ValueError):
        return {"ok": False, "message": "Balance must be an integer credit amount."}
    if balance < 0:
        return {"ok": False, "message": "Balance cannot be negative."}
    if balance > MAX_STORED_BALANCE:
        return {"ok": False, "message": f"Balance cannot exceed {MAX_STORED_BALANCE:,} credits."}
    with _LOCK:
        data = _load()
        user = data.get("users", {}).get((user_id or "").strip())
        if not user:
            return {"ok": False, "message": "User not found."}
        previous = int(user.get("balance", 0))
        user["balance"] = balance
        user["updated_at"] = time.time()
        _append_ledger(user, {
            "type": "admin_set_balance",
            "previous_balance": previous,
            "target_balance": balance,
            "reason": reason,
            "balance_after": balance,
            "time": time.time(),
            "meta": {},
        })
        _save(data)
        return {"ok": True, "balance": balance, "previous_balance": previous, "user_id": user_id}


def display_balance(stored_balance: int) -> int:
    """Return the user-facing spendable balance for the current request.

    When persisted Unlimited Currency is ON, every presentation path should show
    the fixed unlimited display value. This is intentionally display-only: it
    does not mutate account storage, Stripe fulfillment, ledgers, or charge()
    deduction/bypass behavior. When the setting is OFF, the real stored balance
    is returned immediately.
    """
    if is_unlimited_currency():
        return UNLIMITED_DISPLAY_BALANCE
    return int(stored_balance or 0)


def display_balance_for_user(user: Optional[Dict[str, Any]]) -> int:
    """Return the user-facing balance for a loaded account user dict."""
    if not user:
        return 0
    return display_balance(int(user.get("balance", 0)))


def get_display_balance(user_id: str) -> int:
    """Return the user-facing balance for a user id without changing storage."""
    return display_balance(get_balance(user_id))


def with_display_balance(user: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Copy a public user dict and add display_balance for templates/API output."""
    if not user:
        return None
    enriched = dict(user)
    enriched["display_balance"] = display_balance_for_user(user)
    return enriched


def _append_ledger(user: Dict[str, Any], entry: Dict[str, Any]) -> None:
    ledger = user.setdefault("ledger", [])
    ledger.append(entry)
    if len(ledger) > 200:
        del ledger[:-200]


def add_balance_to_all_existing(amount: int, reason: str = "admin_bulk_grant") -> Dict[str, Any]:
    """Add credits to every site account that exists when this function runs.

    The user set is snapshotted under the account lock and saved atomically in a
    single write, so users registered later do not receive previous grants.
    """
    try:
        amount = int(amount)
    except (TypeError, ValueError):
        return {"ok": False, "message": "Amount must be an integer credit amount."}
    if amount <= 0:
        return {"ok": False, "message": "Amount must be greater than zero."}
    if amount > MAX_STORED_BALANCE:
        return {"ok": False, "message": f"Grant cannot exceed {MAX_STORED_BALANCE:,} credits."}

    with _LOCK:
        data = _load()
        users = data.get("users", {})
        if not users:
            return {"ok": False, "message": "There are no existing members to credit.", "updated": 0}

        now = time.time()
        updated = 0
        capped = 0
        for user_id, user in list(users.items()):
            previous = int(user.get("balance", 0))
            target = previous + amount
            if target > MAX_STORED_BALANCE:
                target = MAX_STORED_BALANCE
                capped += 1
            user["balance"] = target
            user["updated_at"] = now
            _append_ledger(user, {
                "type": "credit",
                "amount": target - previous,
                "requested_amount": amount,
                "reason": reason,
                "balance_after": target,
                "time": now,
                "meta": {"admin_bulk_grant": True},
            })
            updated += 1

        _save(data)
        return {"ok": True, "updated": updated, "amount": amount, "capped": capped}


def grant_free_and_paid_balances(
    free_amount: int = 0,
    paid_amount: int = 0,
    *,
    reason_free: str = "admin_grant_free_users",
    reason_paid: str = "admin_grant_paid_users",
) -> Dict[str, Any]:
    """Add credits on top of current balances for free and/or paid members.

    Paid = at least one fulfilled Stripe top-up. Amounts are deltas (balance + grant).
    Pass 0 to skip a tier.
    """
    try:
        free_amount = int(free_amount or 0)
        paid_amount = int(paid_amount or 0)
    except (TypeError, ValueError):
        return {"ok": False, "message": "Amounts must be whole-number credit values."}
    if free_amount < 0 or paid_amount < 0:
        return {"ok": False, "message": "Amounts cannot be negative."}
    if free_amount == 0 and paid_amount == 0:
        return {"ok": False, "message": "Enter at least one grant amount greater than zero."}
    if free_amount > MAX_STORED_BALANCE or paid_amount > MAX_STORED_BALANCE:
        return {"ok": False, "message": f"Grant cannot exceed {MAX_STORED_BALANCE:,} credits."}

    with _LOCK:
        data = _load()
        users = data.get("users", {})
        if not users:
            return {"ok": False, "message": "There are no existing members to credit.", "updated": 0}
        paid_ids = {
            str(entry.get("user_id"))
            for entry in (data.get("stripe_topups") or {}).values()
            if isinstance(entry, dict) and entry.get("user_id")
        }
        now = time.time()
        free_updated = paid_updated = capped = 0
        for user_id, user in list(users.items()):
            is_paid = user_id in paid_ids
            amount = paid_amount if is_paid else free_amount
            if amount <= 0:
                continue
            previous = int(user.get("balance", 0))
            target = previous + amount
            if target > MAX_STORED_BALANCE:
                target = MAX_STORED_BALANCE
                capped += 1
            user["balance"] = target
            user["updated_at"] = now
            _append_ledger(user, {
                "type": "credit",
                "amount": target - previous,
                "requested_amount": amount,
                "reason": reason_paid if is_paid else reason_free,
                "balance_after": target,
                "time": now,
                "meta": {"admin_bulk_grant": True, "paid_user": is_paid},
            })
            if is_paid:
                paid_updated += 1
            else:
                free_updated += 1
        _save(data)
        return {
            "ok": True,
            "free_updated": free_updated,
            "paid_updated": paid_updated,
            "updated": free_updated + paid_updated,
            "free_amount": free_amount,
            "paid_amount": paid_amount,
            "capped": capped,
        }


def has_paid_history(user_id: str) -> bool:
    """True only after at least one fulfilled Stripe top-up."""
    normalized = str(user_id or "").strip()
    if not normalized:
        return False
    with _LOCK:
        data = _load()
        return any(
            isinstance(entry, dict) and str(entry.get("user_id") or "") == normalized
            for entry in (data.get("stripe_topups") or {}).values()
        )


def wipe_free_economy(reason: str = "admin_wipe_free_economy") -> Dict[str, Any]:
    """Zero balances for never-paid accounts; every Stripe customer is excluded."""
    with _LOCK:
        data = _load()
        users = data.get("users", {})
        paid_ids = {
            str(entry.get("user_id"))
            for entry in (data.get("stripe_topups") or {}).values()
            if isinstance(entry, dict) and entry.get("user_id")
        }
        now = time.time()
        wiped = removed = 0
        for user_id, user in users.items():
            if user_id in paid_ids:
                continue
            previous = int(user.get("balance", 0) or 0)
            if previous <= 0:
                continue
            user["balance"] = 0
            user["updated_at"] = now
            _append_ledger(user, {
                "type": "debit", "amount": previous, "reason": reason,
                "balance_after": 0, "time": now,
                "meta": {"admin_free_economy_wipe": True, "paid_user": False},
            })
            wiped += 1
            removed += previous
        _save(data)
        return {"ok": True, "wiped_users": wiped, "credits_removed": removed,
                "paid_users_protected": len(paid_ids)}


def add_balance(user_id: str, amount: int, reason: str = "topup", meta: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    amount = int(amount)
    if amount <= 0:
        return {"ok": False, "message": "Amount must be positive."}
    with _LOCK:
        data = _load()
        user = data.get("users", {}).get(user_id)
        if not user:
            return {"ok": False, "message": "User not found."}
        user["balance"] = int(user.get("balance", 0)) + amount
        user["updated_at"] = time.time()
        _append_ledger(user, {
            "type": "credit",
            "amount": amount,
            "reason": reason,
            "balance_after": user["balance"],
            "time": time.time(),
            "meta": meta or {},
        })
        _save(data)
        return {"ok": True, "balance": user["balance"], "user_id": user_id}


def charge(user_id: str, action: str, reason: Optional[str] = None,
           amount: Optional[int] = None) -> Dict[str, Any]:
    """Deduct price for an action or bypass it in unlimited-currency mode.

    This is the only normal paid-action sufficiency/deduction gate. It checks
    the shared settings cache through ``is_unlimited_currency()`` for every
    paid action while holding the account lock, so an in-process admin toggle
    is observed immediately without reparsing settings.json on every request.
    Unlimited mode is behavioral: it returns
    success with ``charged == 0`` and leaves the stored balance and ledger
    unchanged; it never grants or persists an artificial balance.
    """
    cost = price_for(action, amount=amount)
    if cost <= 0:
        # free action (login etc.)
        bal = get_balance(user_id)
        return {"ok": True, "charged": 0, "balance": bal, "free": True}
    with _LOCK:
        data = _load()
        user = data.get("users", {}).get(user_id)
        if not user:
            return {"ok": False, "message": "Site account required.", "balance": 0, "cost": cost}
        bal = int(user.get("balance", 0))
        if is_unlimited_currency():
            return {
                "ok": True,
                "charged": 0,
                "balance": bal,
                "cost": cost,
                "unlimited_currency": True,
            }
        if bal < cost:
            return {
                "ok": False,
                "message": f"Not enough balance. Need {cost:,}, you have {bal:,}.",
                "balance": bal,
                "cost": cost,
            }
        user["balance"] = bal - cost
        user["updated_at"] = time.time()
        _append_ledger(user, {
            "type": "debit",
            "amount": cost,
            "reason": reason or action,
            "balance_after": user["balance"],
            "time": time.time(),
            "meta": {"action": action},
        })
        _save(data)
        return {"ok": True, "charged": cost, "balance": user["balance"], "cost": cost}


def refund(user_id: str, amount: int, reason: str = "refund") -> Dict[str, Any]:
    return add_balance(user_id, amount, reason=reason)


def pack_info(pack_id: str) -> Optional[Dict[str, int]]:
    return TOPUP_PACKS.get(pack_id)


def fulfill_stripe_topup(
    *,
    session_id: str,
    event_id: str,
    user_id: str,
    pack_id: str,
    amount_cents: int,
    currency: str,
) -> Dict[str, Any]:
    """Idempotently credit a paid Stripe Checkout top-up.

    The same JSON persistence file and lock are used so fulfillment remains
    atomic with the balance update and ledger entry. ``pack_id`` controls the
    amount credited; metadata credit quantities are deliberately ignored.
    """
    session_id = (session_id or "").strip()
    event_id = (event_id or "").strip()
    user_id = (user_id or "").strip()
    pack_id = (pack_id or "").strip()
    currency = (currency or "").strip().lower()
    pack = pack_info(pack_id)
    if not session_id:
        return {"ok": False, "message": "Missing Stripe Checkout Session ID."}
    if not event_id:
        return {"ok": False, "message": "Missing Stripe event ID."}
    if not user_id:
        return {"ok": False, "message": "Missing site user ID."}
    if not pack:
        return {"ok": False, "message": "Unknown top-up pack."}
    expected_amount = int(pack["amount_cents"])
    if int(amount_cents) != expected_amount:
        return {"ok": False, "message": "Stripe amount does not match top-up pack."}

    with _LOCK:
        data = _load()
        user = data.get("users", {}).get(user_id)
        if not user:
            return {"ok": False, "message": "User not found."}

        stripe_topups = data.setdefault("stripe_topups", {})
        existing = stripe_topups.get(session_id)
        if existing:
            return {
                "ok": True,
                "duplicate": True,
                "balance": int(user.get("balance", 0)),
                "user_id": user_id,
                "session_id": session_id,
            }

        credits = int(pack["credits"])
        user["balance"] = int(user.get("balance", 0)) + credits
        user["updated_at"] = time.time()
        ledger_entry = {
            "type": "credit",
            "amount": credits,
            "reason": "stripe_topup",
            "balance_after": user["balance"],
            "time": time.time(),
            "meta": {
                "pack_id": pack_id,
                "session_id": session_id,
                "event_id": event_id,
                "amount_cents": expected_amount,
                "currency": currency,
            },
        }
        _append_ledger(user, ledger_entry)
        stripe_topups[session_id] = {
            "event_id": event_id,
            "user_id": user_id,
            "pack_id": pack_id,
            "credits": credits,
            "amount_cents": expected_amount,
            "currency": currency,
            "fulfilled_at": time.time(),
            "balance_after": user["balance"],
        }
        _save(data)
        return {
            "ok": True,
            "duplicate": False,
            "balance": user["balance"],
            "user_id": user_id,
            "session_id": session_id,
            "credits": credits,
        }


# ---------------------------------------------------------------------------
# PostgreSQL backend
# ---------------------------------------------------------------------------
# The JSON implementation above remains the zero-configuration/local fallback.
# Railway production switches to PostgreSQL automatically when DATABASE_URL is
# present, while keeping the public accounts.py API unchanged for Flask routes.
_POSTGRES_FLAG = os.getenv("POSTGRES_ACCOUNTS_ENABLED", "auto").strip().lower()
_POSTGRES_ENABLED = bool(os.getenv("DATABASE_URL", "").strip()) and _POSTGRES_FLAG not in {
    "0", "false", "no", "off",
}


def postgres_enabled() -> bool:
    return _POSTGRES_ENABLED


if _POSTGRES_ENABLED:
    import postgres_accounts as _pg

    def register(email: str, password: str) -> Dict[str, Any]:
        return _pg.register(email, password)


    def login(email: str, password: str) -> Dict[str, Any]:
        return _pg.login(email, password)


    def reset_password_by_email(email: str, password: str) -> Dict[str, Any]:
        return _pg.reset_password_by_email(email, password)


    def get_user(user_id: str) -> Optional[Dict[str, Any]]:
        return _pg.get_user(user_id)


    def get_balance(user_id: str) -> int:
        user = _pg.get_user(user_id)
        return int(user["balance"]) if user else 0


    def set_balance(user_id: str, balance: int, reason: str = "admin_set_balance") -> Dict[str, Any]:
        return _pg.set_balance(user_id, balance, reason, MAX_STORED_BALANCE)


    def add_balance_to_all_existing(amount: int, reason: str = "admin_bulk_grant") -> Dict[str, Any]:
        return _pg.add_balance_to_all_existing(amount, reason, MAX_STORED_BALANCE)


    def grant_free_and_paid_balances(
        free_amount: int = 0,
        paid_amount: int = 0,
        *,
        reason_free: str = "admin_grant_free_users",
        reason_paid: str = "admin_grant_paid_users",
    ) -> Dict[str, Any]:
        return _pg.grant_free_and_paid_balances(
            free_amount, paid_amount, MAX_STORED_BALANCE,
            reason_free=reason_free, reason_paid=reason_paid,
        )


    def has_paid_history(user_id: str) -> bool:
        return _pg.has_paid_history(user_id)


    def wipe_free_economy(reason: str = "admin_wipe_free_economy") -> Dict[str, Any]:
        return _pg.wipe_free_economy(reason)


    def add_balance(
        user_id: str,
        amount: int,
        reason: str = "topup",
        meta: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        return _pg.add_balance(user_id, amount, reason, meta, MAX_STORED_BALANCE)


    def charge(
        user_id: str,
        action: str,
        reason: Optional[str] = None,
        amount: Optional[int] = None,
    ) -> Dict[str, Any]:
        return _pg.charge(
            user_id,
            cost=price_for(action, amount=amount),
            action=action,
            reason=reason or action,
            unlimited=is_unlimited_currency(),
        )


    def refund(user_id: str, amount: int, reason: str = "refund") -> Dict[str, Any]:
        return _pg.add_balance(user_id, amount, reason, None, MAX_STORED_BALANCE)


    def fulfill_stripe_topup(
        *,
        session_id: str,
        event_id: str,
        user_id: str,
        pack_id: str,
        amount_cents: int,
        currency: str,
    ) -> Dict[str, Any]:
        session_id = (session_id or "").strip()
        event_id = (event_id or "").strip()
        user_id = (user_id or "").strip()
        pack_id = (pack_id or "").strip()
        currency = (currency or "").strip().lower()
        pack = pack_info(pack_id)
        if not session_id:
            return {"ok": False, "message": "Missing Stripe Checkout Session ID."}
        if not event_id:
            return {"ok": False, "message": "Missing Stripe event ID."}
        if not user_id:
            return {"ok": False, "message": "Missing site user ID."}
        if not pack:
            return {"ok": False, "message": "Unknown top-up pack."}
        expected_amount = int(pack["amount_cents"])
        if int(amount_cents) != expected_amount:
            return {"ok": False, "message": "Stripe amount does not match top-up pack."}
        return _pg.fulfill_stripe_topup(
            session_id=session_id,
            event_id=event_id,
            user_id=user_id,
            pack_id=pack_id,
            credits=int(pack["credits"]),
            amount_cents=expected_amount,
            currency=currency,
            maximum=MAX_STORED_BALANCE,
        )


def reserve_injection_job(
    *,
    job_id: str,
    user_id: str,
    web_uid: Any,
    kind: str,
    action: str,
    account_keys,
    payload: Dict[str, Any],
    amount: Optional[int] = None,
    initial_state: str = "reserved",
    enqueue_now: bool = True,
) -> Dict[str, Any]:
    if not _POSTGRES_ENABLED:
        return {"ok": False, "message": "DATABASE_URL is required for distributed injection jobs."}
    return _pg.reserve_injection_job(
        job_id=job_id,
        user_id=user_id,
        web_uid=web_uid,
        kind=kind,
        action=action,
        account_keys=account_keys,
        idempotency_key=_pg.make_idempotency_key(user_id, web_uid, kind, account_keys),
        configured_cost=price_for(action, amount=amount),
        unlimited=is_unlimited_currency(),
        payload=payload,
        initial_state=initial_state,
        enqueue_now=enqueue_now,
    )


def get_job_reservation(job_id: str, *, include_payload: bool = False):
    if not _POSTGRES_ENABLED:
        return None
    return _pg.get_job_reservation(job_id, include_payload=include_payload)


def prepare_clone_job(job_id: str, *, account_keys, payload: Dict[str, Any]) -> Dict[str, Any]:
    if not _POSTGRES_ENABLED:
        return {"ok": False, "message": "DATABASE_URL is required for distributed clone jobs."}
    return _pg.prepare_clone_job(job_id, account_keys=account_keys, payload=payload)


def mark_job_started(job_id: str) -> Dict[str, Any]:
    if not _POSTGRES_ENABLED:
        raise RuntimeError("DATABASE_URL is required for distributed injection jobs.")
    return _pg.mark_job_started(job_id)


def record_job_progress(job_id: str, stage: str, message: str, extra=None) -> Dict[str, Any]:
    if not _POSTGRES_ENABLED:
        return {}
    return _pg.record_job_progress(job_id, stage, message, extra)


def touch_job(job_id: str) -> None:
    if _POSTGRES_ENABLED:
        _pg.touch_job(job_id)


def record_job_diagnostic(job_id: str, stage: str, message: str, details=None) -> None:
    if _POSTGRES_ENABLED:
        _pg.record_job_diagnostic(job_id, stage, message, details)


def recent_job_diagnostics(limit: int = 100):
    return _pg.recent_job_diagnostics(limit) if _POSTGRES_ENABLED else []


def mark_job_resumable(
    job_id: str,
    reason: str,
    *,
    failed_attempt=None,
    delay_seconds: float = 5.0,
    keep_retrying: bool = False,
) -> Dict[str, Any]:
    if not _POSTGRES_ENABLED:
        return {"ok": False, "message": "DATABASE_URL is required for durable job recovery."}
    return _pg.mark_job_resumable(
        job_id,
        reason,
        failed_attempt=failed_attempt,
        delay_seconds=delay_seconds,
        keep_retrying=keep_retrying,
    )


def resume_job_reservation(job_id: str, reason: str = "administrator_resume") -> Dict[str, Any]:
    if not _POSTGRES_ENABLED:
        return {"ok": False, "message": "DATABASE_URL is required for durable job recovery."}
    return _pg.resume_job(job_id, reason)


def finish_job_reservation(job_id: str, state: str, *, failure_message: str = "") -> None:
    if _POSTGRES_ENABLED:
        _pg.finish_job(job_id, state, failure_message=failure_message)


def refund_job_reservation(job_id: str, reason: str) -> Dict[str, Any]:
    if not _POSTGRES_ENABLED:
        return {"ok": False, "message": "DATABASE_URL is required for distributed refunds."}
    return _pg.refund_job(job_id, reason)
