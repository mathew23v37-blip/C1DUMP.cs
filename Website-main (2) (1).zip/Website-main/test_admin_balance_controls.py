import json
import os
import pathlib
import subprocess
import sys
import tempfile
import textwrap
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
PYTHON = sys.executable


def run_snippet(code: str, data_dir: str) -> str:
    env = os.environ.copy()
    env.update({
        "DATA_DIR": data_dir,
        "FLASK_SECRET_KEY": "test-flask-secret",
        "STRIPE_SECRET_KEY": "",
        "STRIPE_WEBHOOK_SECRET": "",
        "APP_BASE_URL": "https://example.test",
        "TOPUP_CURRENCY": "usd",
        "PYTHONPATH": str(ROOT),
    })
    proc = subprocess.run(
        [PYTHON, "-c", textwrap.dedent(code)],
        cwd=str(ROOT),
        env=env,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.strip()


class AdminBalanceControlsTests(unittest.TestCase):
    def test_lookup_set_validation_persistence_zero_and_no_delta_panels(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = run_snippet(
                r'''
                import json, pathlib
                import app, accounts
                app.app.config.update(TESTING=True, SECRET_KEY="test-flask-secret")
                client = app.app.test_client()
                user = accounts.register("admin-balance@example.test", "password")
                uid = user["user_id"]
                accounts.add_balance(uid, 2000, reason="test_seed")

                page = client.get("/admin-secret-panel-x9k2v1").get_data(as_text=True)
                lookup = client.post("/admin-secret-panel-x9k2v1", data={"action": "lookup_balance", "user_id": uid}).get_data(as_text=True)
                unknown = client.post("/admin-secret-panel-x9k2v1", data={"action": "lookup_balance", "user_id": "abcdef123456"}).get_data(as_text=True)
                invalid_uid = client.post("/admin-secret-panel-x9k2v1", data={"action": "lookup_balance", "user_id": "not-an-id"}).get_data(as_text=True)
                set_exact = client.post("/admin-secret-panel-x9k2v1", data={"action": "set_balance", "user_id": uid, "target_balance": "12345"}).get_data(as_text=True)
                persisted = accounts.get_balance(uid)
                raw_persisted = json.loads(pathlib.Path(accounts.ACCOUNTS_FILE).read_text())["users"][uid]["balance"]
                import importlib
                reloaded_accounts = importlib.reload(accounts)
                reloaded_persisted = reloaded_accounts.get_balance(uid)
                set_zero = client.post("/admin-secret-panel-x9k2v1", data={"action": "set_balance", "user_id": uid, "target_balance": "0"}).get_data(as_text=True)
                zero = accounts.get_balance(uid)
                invalid_amounts = {}
                for value in ["", "-1", "1.5", "abc", str(accounts.MAX_STORED_BALANCE + 1)]:
                    invalid_amounts[value] = client.post("/admin-secret-panel-x9k2v1", data={"action": "set_balance", "user_id": uid, "target_balance": value}).get_data(as_text=True)

                lowered = page.lower()
                forbidden_panels = ["add credit", "add-credit", "increment", "deduction", "remove credit", "remove-credit"]
                print(json.dumps({
                    "lookup_ok": "2,000 credits" in lookup and uid in lookup,
                    "unknown_ok": "User not found" in unknown,
                    "invalid_uid_ok": "Invalid user ID" in invalid_uid,
                    "set_exact_ok": "12,345 credits" in set_exact and persisted == 12345 and raw_persisted == 12345 and reloaded_persisted == 12345,
                    "zero_ok": "0 credits" in set_zero and zero == 0,
                    "invalid_amounts_ok": all("Invalid amount" in text or "Target credit amount" in text for text in invalid_amounts.values()),
                    "has_lookup_panel": "Balance lookup" in page,
                    "has_set_panel": "Set custom balance" in page,
                    "has_unlimited_toggle": "Unlimited Currency" in page and "unlimited mode" in page,
                    "no_delta_panels": not any(token in lowered for token in forbidden_panels),
                }))
                ''',
                tmp,
            )
            payload = json.loads(out)
            self.assertTrue(payload["lookup_ok"])
            self.assertTrue(payload["unknown_ok"])
            self.assertTrue(payload["invalid_uid_ok"])
            self.assertTrue(payload["set_exact_ok"])
            self.assertTrue(payload["zero_ok"])
            self.assertTrue(payload["invalid_amounts_ok"])
            self.assertTrue(payload["has_lookup_panel"])
            self.assertTrue(payload["has_set_panel"])
            self.assertTrue(payload["has_unlimited_toggle"])
            self.assertTrue(payload["no_delta_panels"])


if __name__ == "__main__":
    unittest.main()
