import json
import os
import pathlib
import subprocess
import sys
import tempfile
import textwrap
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
PYTHON = sys.executable


def run_snippet(code: str, data_dir: str) -> str:
    env = os.environ.copy()
    env.update({
        "DATA_DIR": data_dir,
        "FLASK_SECRET_KEY": "test-flask-secret",
        "STRIPE_SECRET_KEY": "test-stripe-secret",
        "STRIPE_WEBHOOK_SECRET": "test-webhook-secret",
        "APP_BASE_URL": "https://example.test",
        "TOPUP_CURRENCY": "usd",
        "PYTHONPATH": str(ROOT),
    })
    proc = subprocess.run(
        [PYTHON, "-c", textwrap.dedent(code)],
        cwd=str(ROOT),
        env=env,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.strip()


class RailwayPersistenceTests(unittest.TestCase):
    def test_boot_creates_data_dir_and_mutable_paths_resolve_under_it(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = run_snippet(
                r'''
                import json, os
                import app, accounts, backlog, persistence
                paths = [
                    accounts.ACCOUNTS_FILE,
                    backlog.CREDENTIALS_FILE,
                    backlog.ACTION_LOG_FILE,
                    backlog.ACTION_LOG_JSONL_FILE,
                    backlog.TRACKER_FILE,
                    backlog.LIVE_STATS_FILE,
                    persistence.SETTINGS_FILE,
                    app.nuker.db_path,
                ]
                print(json.dumps({"exists": os.path.isdir(os.environ["DATA_DIR"]), "paths": paths}))
                ''',
                tmp,
            )
            payload = json.loads(out)
            self.assertTrue(payload["exists"])
            for path in payload["paths"]:
                self.assertTrue(pathlib.Path(path).resolve().is_relative_to(pathlib.Path(tmp).resolve()), path)

    def test_atomic_json_write_survives_reload(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = run_snippet(
                r'''
                import json
                from persistence import atomic_write_json, data_path, load_json
                path = data_path("atomic.json")
                atomic_write_json(path, {"ok": True, "n": 7})
                print(json.dumps(load_json(path, {})))
                ''',
                tmp,
            )
            self.assertEqual(json.loads(out), {"ok": True, "n": 7})

    def test_account_backlog_settings_and_stripe_state_persist_under_data_dir(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = run_snippet(
                r'''
                import json, pathlib
                import accounts, backlog
                from persistence import set_unlimited_currency, load_settings
                user = accounts.register("persist@example.test", "password")
                accounts.add_balance(user["user_id"], 2000, reason="test")
                top = accounts.fulfill_stripe_topup(
                    session_id="cs_persist", event_id="evt_persist", user_id=user["user_id"],
                    pack_id="pack_2k", amount_cents=50, currency="usd")
                backlog.record_credentials("Tester", "persist@example.test", "password", web_uid=123)
                backlog.log_action("persist@example.test", "set_coin", "Set Coin", True, web_uid=123)
                settings = set_unlimited_currency(True)
                data = json.loads(pathlib.Path(accounts.ACCOUNTS_FILE).read_text())
                print(json.dumps({
                    "balance": accounts.get_balance(user["user_id"]),
                    "stripe_topup": data["stripe_topups"]["cs_persist"],
                    "creds_exists": pathlib.Path(backlog.CREDENTIALS_FILE).exists(),
                    "jsonl_exists": pathlib.Path(backlog.ACTION_LOG_JSONL_FILE).exists(),
                    "settings": load_settings(),
                    "top_ok": top["ok"],
                }))
                ''',
                tmp,
            )
            payload = json.loads(out)
            self.assertEqual(payload["balance"], 4000)
            self.assertEqual(payload["stripe_topup"]["event_id"], "evt_persist")
            self.assertTrue(payload["creds_exists"])
            self.assertTrue(payload["jsonl_exists"])
            self.assertTrue(payload["settings"]["unlimited_currency"])
            self.assertTrue(payload["top_ok"])

    def test_unlimited_mode_persists_and_bypasses_without_balance_mutation_then_off_restores(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = run_snippet(
                r'''
                import json
                import accounts
                from persistence import set_unlimited_currency, load_settings
                user = accounts.register("free@example.test", "password")
                uid = user["user_id"]
                set_unlimited_currency(True)
                bypass = accounts.charge(uid, "set_coin")
                bal_after_bypass = accounts.get_balance(uid)
                set_unlimited_currency(False)
                normal = accounts.charge(uid, "set_coin")
                print(json.dumps({
                    "settings": load_settings(),
                    "bypass": bypass,
                    "bal_after_bypass": bal_after_bypass,
                    "normal": normal,
                    "bal_final": accounts.get_balance(uid),
                }))
                ''',
                tmp,
            )
            payload = json.loads(out)
            self.assertTrue(payload["bypass"]["ok"])
            self.assertTrue(payload["bypass"]["unlimited_currency"])
            self.assertEqual(payload["bypass"]["charged"], 0)
            self.assertEqual(payload["bal_after_bypass"], 0)
            self.assertFalse(payload["normal"]["ok"])
            self.assertEqual(payload["bal_final"], 0)
            self.assertFalse(payload["settings"]["unlimited_currency"])

    def test_hidden_admin_endpoint_toggles_settings_json(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = run_snippet(
                r'''
                import json
                import app
                from persistence import load_settings
                app.app.config.update(TESTING=True, SECRET_KEY="test-flask-secret")
                client = app.app.test_client()
                before = client.get("/admin-secret-panel-x9k2v1")
                on = client.post("/admin-secret-panel-x9k2v1", data={"enabled": "1"})
                enabled = load_settings()["unlimited_currency"]
                off = client.post("/admin-secret-panel-x9k2v1", data={"enabled": "0"})
                disabled = load_settings()["unlimited_currency"]
                print(json.dumps({"before": before.status_code, "on": on.status_code, "enabled": enabled, "off": off.status_code, "disabled": disabled, "on_text": "ON" in on.get_data(as_text=True)}))
                ''',
                tmp,
            )
            payload = json.loads(out)
            self.assertEqual(payload["before"], 200)
            self.assertEqual(payload["on"], 200)
            self.assertTrue(payload["enabled"])
            self.assertTrue(payload["on_text"])
            self.assertEqual(payload["off"], 200)
            self.assertFalse(payload["disabled"])

    def test_unlimited_mode_real_action_flow_existing_user_and_new_user_transitions(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = run_snippet(
                r"""
                import json
                import app, accounts
                from persistence import load_settings

                async def ok_set_coin(uid, amount):
                    return {"ok": True, "message": f"coin set to {amount}"}

                app.app.config.update(TESTING=True, SECRET_KEY="test-flask-secret")
                app.nuker.set_coin = ok_set_coin
                client = app.app.test_client()

                existing = accounts.register("existing-flow@example.test", "password")
                uid_existing = existing["user_id"]

                def sign_in_site_and_game(uid, email):
                    with client.session_transaction() as sess:
                        sess["site_user_id"] = uid
                        sess["site_email"] = email
                        sess["site_logged_in"] = True
                        sess["logged_in"] = True
                        sess["web_uid"] = 123456
                        sess["email"] = email
                        sess["logout_confirmed"] = True

                sign_in_site_and_game(uid_existing, "existing-flow@example.test")
                off_existing = client.post("/action/set_coin", data={"amount": "999"}, headers={"Accept": "application/json"})
                bal_after_off_existing = accounts.get_balance(uid_existing)

                admin_on = client.post("/admin-secret-panel-x9k2v1", data={"enabled": "1"})
                on_existing = client.post("/action/set_coin", data={"amount": "999"}, headers={"Accept": "application/json"})
                bal_after_on_existing = accounts.get_balance(uid_existing)

                new_resp = client.post("/register", data={"email": "new-flow@example.test", "password": "password"})
                uid_new = accounts.login("new-flow@example.test", "password")["user_id"]
                sign_in_site_and_game(uid_new, "new-flow@example.test")
                on_new = client.post("/action/set_coin", data={"amount": "777"}, headers={"Accept": "application/json"})
                bal_after_on_new = accounts.get_balance(uid_new)

                admin_off = client.post("/admin-secret-panel-x9k2v1", data={"enabled": "0"})
                off_new = client.post("/action/set_coin", data={"amount": "777"}, headers={"Accept": "application/json"})
                bal_after_off_new = accounts.get_balance(uid_new)

                print(json.dumps({
                    "settings": load_settings(),
                    "admin_on_status": admin_on.status_code,
                    "admin_off_status": admin_off.status_code,
                    "register_status": new_resp.status_code,
                    "off_existing_status": off_existing.status_code,
                    "off_existing_json": off_existing.get_json(),
                    "bal_after_off_existing": bal_after_off_existing,
                    "on_existing_status": on_existing.status_code,
                    "on_existing_json": on_existing.get_json(),
                    "bal_after_on_existing": bal_after_on_existing,
                    "on_new_status": on_new.status_code,
                    "on_new_json": on_new.get_json(),
                    "bal_after_on_new": bal_after_on_new,
                    "off_new_status": off_new.status_code,
                    "off_new_json": off_new.get_json(),
                    "bal_after_off_new": bal_after_off_new,
                }))
                """,
                tmp,
            )
            payload = json.loads(out)
            self.assertEqual(payload["admin_on_status"], 200)
            self.assertEqual(payload["admin_off_status"], 200)
            self.assertEqual(payload["off_existing_status"], 402)
            self.assertFalse(payload["off_existing_json"]["ok"])
            self.assertEqual(payload["bal_after_off_existing"], 0)
            self.assertEqual(payload["on_existing_status"], 200)
            self.assertTrue(payload["on_existing_json"]["ok"])
            self.assertEqual(payload["bal_after_on_existing"], 0)
            self.assertIn(payload["register_status"], (302, 303))
            self.assertEqual(payload["on_new_status"], 200)
            self.assertTrue(payload["on_new_json"]["ok"])
            self.assertEqual(payload["bal_after_on_new"], 0)
            self.assertEqual(payload["off_new_status"], 402)
            self.assertFalse(payload["off_new_json"]["ok"])
            self.assertEqual(payload["bal_after_off_new"], 0)
            self.assertFalse(payload["settings"]["unlimited_currency"])

    def test_unlimited_mode_real_car_flows_bypass_deduction_and_off_restores_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = run_snippet(
                r"""
                import json
                import app, accounts
                from persistence import set_unlimited_currency

                app.app.config.update(TESTING=True, SECRET_KEY="test-flask-secret")
                app.nuker.get_token_data = lambda web_uid: {"email": "car@example.test", "password": "password"}
                app._try_start_queued_injections = lambda: None
                client = app.app.test_client()
                user = accounts.register("car-flow@example.test", "password")
                uid = user["user_id"]
                with client.session_transaction() as sess:
                    sess["site_user_id"] = uid
                    sess["site_email"] = "car-flow@example.test"
                    sess["site_logged_in"] = True
                    sess["logged_in"] = True
                    sess["web_uid"] = 987654
                    sess["email"] = "car@example.test"

                off_premium = client.post("/cars/bulk-inject", headers={"Accept": "application/json"})
                set_unlimited_currency(True)
                on_premium = client.post("/cars/bulk-inject", headers={"Accept": "application/json"})
                bal_after_premium = accounts.get_balance(uid)
                on_event = client.post("/cars/event-inject", headers={"Accept": "application/json"})
                bal_after_event = accounts.get_balance(uid)
                set_unlimited_currency(False)
                user2 = accounts.register("car-flow-off@example.test", "password")
                uid2 = user2["user_id"]
                with client.session_transaction() as sess:
                    sess["site_user_id"] = uid2
                    sess["site_email"] = "car-flow-off@example.test"
                    sess["site_logged_in"] = True
                    sess["logged_in"] = True
                    sess["web_uid"] = 111222
                    sess["email"] = "car2@example.test"
                off_event = client.post("/cars/event-inject", headers={"Accept": "application/json"})

                print(json.dumps({
                    "off_premium_status": off_premium.status_code,
                    "off_premium_json": off_premium.get_json(),
                    "on_premium_status": on_premium.status_code,
                    "on_premium_json": on_premium.get_json(),
                    "bal_after_premium": bal_after_premium,
                    "on_event_status": on_event.status_code,
                    "on_event_json": on_event.get_json(),
                    "bal_after_event": bal_after_event,
                    "off_event_status": off_event.status_code,
                    "off_event_json": off_event.get_json(),
                    "bal_final_user2": accounts.get_balance(uid2),
                }))
                """,
                tmp,
            )
            payload = json.loads(out)
            self.assertEqual(payload["off_premium_status"], 402)
            self.assertFalse(payload["off_premium_json"]["ok"])
            self.assertEqual(payload["on_premium_status"], 200)
            self.assertTrue(payload["on_premium_json"]["ok"])
            self.assertEqual(payload["bal_after_premium"], 0)
            self.assertEqual(payload["on_event_status"], 200)
            self.assertTrue(payload["on_event_json"]["ok"])
            self.assertEqual(payload["bal_after_event"], 0)
            self.assertEqual(payload["off_event_status"], 402)
            self.assertFalse(payload["off_event_json"]["ok"])
            self.assertEqual(payload["bal_final_user2"], 0)

    def test_unlimited_setting_reload_and_threaded_read_consistency(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = run_snippet(
                r"""
                import concurrent.futures, json, subprocess, sys, textwrap, os
                import accounts
                from persistence import set_unlimited_currency, load_settings

                user = accounts.register("threaded@example.test", "password")
                uid = user["user_id"]
                set_unlimited_currency(True)
                first_wave = [accounts.charge(uid, "set_coin") for _ in range(3)]
                balance_after_first = accounts.get_balance(uid)

                code = (
                    "import json, accounts\n"
                    "from persistence import load_settings\n"
                    f"uid = {uid!r}\n"
                    "print(json.dumps({'settings': load_settings(), 'charge': accounts.charge(uid, 'set_coin'), 'balance': accounts.get_balance(uid)}))\n"
                )
                env = os.environ.copy()
                env["PYTHONPATH"] = os.getcwd()
                restarted = subprocess.run([sys.executable, "-c", textwrap.dedent(code)], text=True, capture_output=True, check=True, env=env).stdout.strip()

                set_unlimited_currency(False)
                with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
                    off_results = list(executor.map(lambda _: accounts.charge(uid, "set_coin"), range(16)))
                final_balance = accounts.get_balance(uid)

                print(json.dumps({
                    "first_wave": first_wave,
                    "balance_after_first": balance_after_first,
                    "restarted": json.loads(restarted),
                    "settings_after_off": load_settings(),
                    "off_results": off_results,
                    "final_balance": final_balance,
                }))
                """,
                tmp,
            )
            payload = json.loads(out)
            self.assertTrue(all(item["ok"] and item.get("unlimited_currency") and item["charged"] == 0 for item in payload["first_wave"]))
            self.assertEqual(payload["balance_after_first"], 0)
            self.assertTrue(payload["restarted"]["settings"]["unlimited_currency"])
            self.assertTrue(payload["restarted"]["charge"]["ok"])
            self.assertEqual(payload["restarted"]["balance"], 0)
            self.assertFalse(payload["settings_after_off"]["unlimited_currency"])
            self.assertTrue(all(not item["ok"] for item in payload["off_results"]))
            self.assertEqual(payload["final_balance"], 0)



    def test_display_balance_existing_zero_on_off_template_and_api(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = run_snippet(
                r"""
                import json, pathlib
                import app, accounts
                from persistence import set_unlimited_currency

                app.app.config.update(TESTING=True, SECRET_KEY="test-flask-secret")
                client = app.app.test_client()
                user = accounts.register("display-zero@example.test", "password")
                uid = user["user_id"]
                with client.session_transaction() as sess:
                    sess["site_user_id"] = uid
                    sess["site_email"] = "display-zero@example.test"
                    sess["site_logged_in"] = True
                    sess["logged_in"] = True
                    sess["web_uid"] = 444555
                    sess["email"] = "display-zero@example.test"
                    sess["logout_confirmed"] = True

                set_unlimited_currency(True)
                topup_on = client.get("/topup").get_data(as_text=True)
                dashboard_on = client.get("/dashboard").get_data(as_text=True)
                api_on = client.get("/api/balance").get_json()
                raw_on = json.loads(pathlib.Path(accounts.ACCOUNTS_FILE).read_text())["users"][uid]["balance"]

                set_unlimited_currency(False)
                topup_off = client.get("/topup").get_data(as_text=True)
                dashboard_off = client.get("/dashboard").get_data(as_text=True)
                api_off = client.get("/api/balance").get_json()
                raw_off = json.loads(pathlib.Path(accounts.ACCOUNTS_FILE).read_text())["users"][uid]["balance"]

                print(json.dumps({
                    "topup_on_has_display": "67,999,999" in topup_on,
                    "dashboard_on_has_display": "67,999,999" in dashboard_on,
                    "topup_off_has_zero": ">0 <" in topup_off or "\n0 " in topup_off,
                    "dashboard_off_has_zero": ">0 <" in dashboard_off or "\n0 " in dashboard_off,
                    "api_on": api_on,
                    "api_off": api_off,
                    "raw_on": raw_on,
                    "raw_off": raw_off,
                }))
                """,
                tmp,
            )
            payload = json.loads(out)
            self.assertTrue(payload["topup_on_has_display"])
            self.assertTrue(payload["dashboard_on_has_display"])
            self.assertTrue(payload["topup_off_has_zero"])
            self.assertTrue(payload["dashboard_off_has_zero"])
            self.assertEqual(payload["api_on"]["balance"], 67999999)
            self.assertTrue(payload["api_on"]["unlimited_currency"])
            self.assertEqual(payload["api_off"]["balance"], 0)
            self.assertFalse(payload["api_off"]["unlimited_currency"])
            self.assertEqual(payload["raw_on"], 0)
            self.assertEqual(payload["raw_off"], 0)

    def test_display_balance_newly_registered_user_shows_unlimited_without_storage_mutation(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = run_snippet(
                r"""
                import json, pathlib
                import app, accounts
                from persistence import set_unlimited_currency

                app.app.config.update(TESTING=True, SECRET_KEY="test-flask-secret")
                client = app.app.test_client()
                set_unlimited_currency(True)
                resp = client.post("/register", data={"email": "new-display@example.test", "password": "password"}, follow_redirects=True)
                uid = accounts.login("new-display@example.test", "password")["user_id"]
                api = client.get("/api/balance").get_json()
                raw = json.loads(pathlib.Path(accounts.ACCOUNTS_FILE).read_text())["users"][uid]["balance"]
                print(json.dumps({
                    "status": resp.status_code,
                    "body_has_display": "67,999,999" in resp.get_data(as_text=True),
                    "api": api,
                    "raw": raw,
                }))
                """,
                tmp,
            )
            payload = json.loads(out)
            self.assertEqual(payload["status"], 200)
            self.assertTrue(payload["body_has_display"])
            self.assertEqual(payload["api"]["balance"], 67999999)
            self.assertEqual(payload["raw"], 0)

    def test_display_balance_funded_user_on_off_and_immediate_toggle(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = run_snippet(
                r"""
                import json, pathlib
                import app, accounts
                from persistence import set_unlimited_currency

                app.app.config.update(TESTING=True, SECRET_KEY="test-flask-secret")
                client = app.app.test_client()
                user = accounts.register("funded-display@example.test", "password")
                uid = user["user_id"]
                accounts.add_balance(uid, 12345, reason="test_funding")
                with client.session_transaction() as sess:
                    sess["site_user_id"] = uid
                    sess["site_email"] = "funded-display@example.test"
                    sess["site_logged_in"] = True
                    sess["logged_in"] = True
                    sess["web_uid"] = 888999
                    sess["email"] = "funded-display@example.test"
                    sess["logout_confirmed"] = True

                off_first = client.get("/api/balance").get_json()
                set_unlimited_currency(True)
                on_immediate = client.get("/api/balance").get_json()
                topup_on = client.get("/topup").get_data(as_text=True)
                set_unlimited_currency(False)
                off_immediate = client.get("/api/balance").get_json()
                topup_off = client.get("/topup").get_data(as_text=True)
                raw = json.loads(pathlib.Path(accounts.ACCOUNTS_FILE).read_text())["users"][uid]["balance"]
                print(json.dumps({
                    "off_first": off_first,
                    "on_immediate": on_immediate,
                    "off_immediate": off_immediate,
                    "topup_on_has_display": "67,999,999" in topup_on,
                    "topup_off_has_true": "12,345" in topup_off,
                    "raw": raw,
                }))
                """,
                tmp,
            )
            payload = json.loads(out)
            self.assertEqual(payload["off_first"]["balance"], 12345)
            self.assertEqual(payload["on_immediate"]["balance"], 67999999)
            self.assertEqual(payload["off_immediate"]["balance"], 12345)
            self.assertTrue(payload["topup_on_has_display"])
            self.assertTrue(payload["topup_off_has_true"])
            self.assertEqual(payload["raw"], 12345)

    def test_deployment_file_exactness_and_secret_scan(self):
        long_railway_command = "gunicorn --workers 1 --threads ${GUNICORN_THREADS:-24} --timeout ${GUNICORN_TIMEOUT:-180} --keep-alive 5 --max-requests 2000 --max-requests-jitter 200 app:app"
        short_procfile_command = "web: gunicorn --workers 1 --threads 24 --timeout 180 app:app\n"
        self.assertEqual((ROOT / "Procfile").read_text(), short_procfile_command)
        self.assertEqual((ROOT / "runtime.txt").read_text(), "python-3.11\n")
        railway = json.loads((ROOT / "railway.json").read_text())
        self.assertEqual(railway["build"]["builder"], "NIXPACKS")
        self.assertEqual(railway["deploy"]["startCommand"], long_railway_command)
        self.assertNotEqual(railway["deploy"]["startCommand"], short_procfile_command.strip().removeprefix("web: "))
        text = "\n".join(
            p.read_text(errors="ignore")
            for p in ROOT.rglob("*")
            if p.is_file() and "__pycache__" not in p.parts and p.suffix not in {".zip", ".pyc"}
        )
        forbidden = ["sk" + "_live_", "sk" + "_test_", "rk" + "_live_", "wh" + "sec_"]
        self.assertFalse([token for token in forbidden if token in text])

    def test_deployment_guide_contains_required_repair_details(self):
        guide = (ROOT / "STRIPE_RAILWAY_DEPLOYMENT.md").read_text()
        required_snippets = [
            "gunicorn --workers 1 --threads ${GUNICORN_THREADS:-24} --timeout ${GUNICORN_TIMEOUT:-180} --keep-alive 5 --max-requests 2000 --max-requests-jitter 200 app:app",
            "web: gunicorn --workers 1 --threads 24 --timeout 180 app:app",
            "## DATA_DIR persistence and path migration table",
            "site_accounts.json",
            "settings.json",
            "/admin-secret-panel-x9k2v1",
            "URL secrecy",
            "Railway Volume",
            "Full unittest suite",
            "Duplicate Stripe webhook fulfillment",
            "No real Stripe payments",
            "67,999,999",
            "display-only",
        ]
        missing = [snippet for snippet in required_snippets if snippet not in guide]
        self.assertFalse(missing, missing)



if __name__ == "__main__":
    unittest.main()
