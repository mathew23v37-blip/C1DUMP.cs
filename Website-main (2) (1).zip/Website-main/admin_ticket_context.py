#!/usr/bin/env python3
"""Aggregate per-user activity for admin support ticket views (not shown to users)."""

from __future__ import annotations

import os
import time
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple


def _day_key(ts: float) -> str:
    try:
        return datetime.fromtimestamp(float(ts), tz=timezone.utc).strftime("%Y-%m-%d")
    except Exception:
        return "unknown"


def _day_label(day: str) -> str:
    if day == "unknown":
        return "Unknown date"
    try:
        return datetime.strptime(day, "%Y-%m-%d").strftime("%a %b %d, %Y")
    except Exception:
        return day


def _postgres_ready() -> bool:
    return bool(os.getenv("DATABASE_URL", "").strip()) and os.getenv(
        "POSTGRES_ACCOUNTS_ENABLED", "auto"
    ).strip().lower() not in {"0", "false", "no", "off"}


def _stripe_topups_for_user(user_id: str) -> List[Dict[str, Any]]:
    user_id = (user_id or "").strip()
    if not user_id:
        return []
    rows: List[Dict[str, Any]] = []
    if _postgres_ready():
        try:
            from postgres_db import connection

            with connection() as conn:
                found = conn.execute(
                    """
                    SELECT session_id, user_id, credits, amount_cents, currency,
                           fulfilled_at, pack_id, balance_after
                      FROM stripe_topups
                     WHERE user_id = %s
                     ORDER BY fulfilled_at DESC
                     LIMIT 2000
                    """,
                    (user_id,),
                ).fetchall()
            for row in found:
                item = dict(row)
                rows.append({
                    "session_id": item.get("session_id"),
                    "credits": int(item.get("credits") or 0),
                    "amount_cents": int(item.get("amount_cents") or 0),
                    "currency": (item.get("currency") or "usd").upper(),
                    "time": float(item.get("fulfilled_at") or 0),
                    "pack_id": item.get("pack_id") or "",
                    "balance_after": int(item.get("balance_after") or 0),
                    "status": "paid",
                })
            return rows
        except Exception:
            pass
    try:
        import accounts

        data = accounts._load()  # type: ignore[attr-defined]
        for session_id, entry in (data.get("stripe_topups") or {}).items():
            if not isinstance(entry, dict):
                continue
            if str(entry.get("user_id") or "") != user_id:
                continue
            rows.append({
                "session_id": session_id,
                "credits": int(entry.get("credits") or entry.get("amount") or 0),
                "amount_cents": int(entry.get("amount_cents") or 0),
                "currency": (entry.get("currency") or "usd").upper(),
                "time": float(entry.get("fulfilled_at") or entry.get("created_at") or entry.get("time") or 0),
                "pack_id": entry.get("pack_id") or "",
                "balance_after": int(entry.get("balance_after") or 0),
                "status": entry.get("status") or "paid",
            })
    except Exception:
        pass
    rows.sort(key=lambda r: float(r.get("time") or 0), reverse=True)
    return rows


def _ledger_for_user(user_id: str) -> List[Dict[str, Any]]:
    user_id = (user_id or "").strip()
    if not user_id:
        return []
    rows: List[Dict[str, Any]] = []
    if _postgres_ready():
        try:
            from postgres_db import connection

            with connection() as conn:
                found = conn.execute(
                    """
                    SELECT entry_type, amount, reason, balance_after, event_time, meta
                      FROM credit_ledger
                     WHERE user_id = %s
                     ORDER BY event_time DESC
                     LIMIT 2000
                    """,
                    (user_id,),
                ).fetchall()
            for row in found:
                item = dict(row)
                rows.append({
                    "type": item.get("entry_type") or item.get("type") or "",
                    "amount": int(item.get("amount") or 0),
                    "reason": item.get("reason") or "",
                    "balance_after": int(item.get("balance_after") or 0),
                    "time": float(item.get("event_time") or 0),
                    "meta": item.get("meta") if isinstance(item.get("meta"), dict) else {},
                })
            return rows
        except Exception:
            pass
    try:
        import accounts

        user = accounts.get_user(user_id) or {}
        for entry in user.get("ledger") or []:
            if not isinstance(entry, dict):
                continue
            rows.append({
                "type": entry.get("type") or "",
                "amount": int(entry.get("amount") or 0),
                "reason": entry.get("reason") or "",
                "balance_after": int(entry.get("balance_after") or 0),
                "time": float(entry.get("time") or 0),
                "meta": entry.get("meta") if isinstance(entry.get("meta"), dict) else {},
            })
    except Exception:
        pass
    rows.sort(key=lambda r: float(r.get("time") or 0), reverse=True)
    return rows


def _saves_for_user(user_id: str) -> List[Dict[str, Any]]:
    user_id = (user_id or "").strip()
    if not user_id:
        return []
    rows: List[Dict[str, Any]] = []
    if _postgres_ready():
        try:
            from postgres_db import connection

            with connection() as conn:
                found = conn.execute(
                    """
                    SELECT job_id, kind, email, site_user_id, created_at,
                           original_car_count, final_car_count, verification_state
                      FROM car_safety_backups
                     WHERE site_user_id = %s
                     ORDER BY created_at DESC
                     LIMIT 2000
                    """,
                    (user_id,),
                ).fetchall()
            for row in found:
                item = dict(row)
                rows.append({
                    "job_id": item.get("job_id"),
                    "kind": item.get("kind") or "",
                    "email": item.get("email") or "",
                    "time": float(item.get("created_at") or 0),
                    "original_car_count": int(item.get("original_car_count") or 0),
                    "final_car_count": item.get("final_car_count"),
                    "verification_state": item.get("verification_state") or "",
                })
            return rows
        except Exception:
            pass
    try:
        from persistence import load_json, seed_data_file

        data = load_json(seed_data_file("car_safety_backups.json", default={"backups": {}}), {"backups": {}})
        for job_id, row in (data.get("backups") or {}).items():
            if not isinstance(row, dict):
                continue
            if str(row.get("site_user_id") or "") != user_id:
                continue
            rows.append({
                "job_id": job_id,
                "kind": row.get("kind") or "",
                "email": row.get("email") or "",
                "time": float(row.get("created_at") or 0),
                "original_car_count": int(row.get("original_car_count") or 0),
                "final_car_count": row.get("final_car_count"),
                "verification_state": row.get("verification_state") or "",
            })
    except Exception:
        pass
    rows.sort(key=lambda r: float(r.get("time") or 0), reverse=True)
    return rows


def _job_emails_for_user(user_id: str) -> List[str]:
    """CPM emails seen on paid injection jobs for this site account."""
    user_id = (user_id or "").strip()
    emails: set[str] = set()
    if not user_id or not _postgres_ready():
        return []
    try:
        from postgres_db import connection

        with connection() as conn:
            rows = conn.execute(
                """
                SELECT account_keys, payload
                  FROM job_reservations
                 WHERE user_id = %s
                 ORDER BY created_at DESC
                 LIMIT 100
                """,
                (user_id,),
            ).fetchall()
        for row in rows:
            keys = row.get("account_keys") or []
            if isinstance(keys, list):
                for key in keys:
                    if isinstance(key, str) and "@" in key:
                        emails.add(key.strip().lower())
            payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
            job = payload.get("job") if isinstance(payload.get("job"), dict) else {}
            for field in ("email", "source_email", "target_email"):
                val = str(job.get(field) or "").strip().lower()
                if "@" in val:
                    emails.add(val)
    except Exception:
        pass
    return sorted(emails)


def _actions_for_emails(emails: List[str], limit: int = 2000) -> List[Dict[str, Any]]:
    emails = [e.strip().lower() for e in emails if e and "@" in e]
    if not emails:
        return []
    email_set = set(emails)
    rows: List[Dict[str, Any]] = []
    try:
        import backlog

        # Prefer filtered scan when postgres backlog is active
        if hasattr(backlog, "get_all_actions"):
            for event in backlog.get_all_actions(limit=10000) or []:
                if not isinstance(event, dict):
                    continue
                if str(event.get("email") or "").strip().lower() not in email_set:
                    continue
                rows.append({
                    "email": event.get("email") or "",
                    "action": event.get("action") or "",
                    "action_title": event.get("action_title") or event.get("action") or "",
                    "success": bool(event.get("success")),
                    "message": (event.get("message") or "")[:240],
                    "time": float(event.get("timestamp") or 0),
                })
                if len(rows) >= limit:
                    break
    except Exception:
        pass
    rows.sort(key=lambda r: float(r.get("time") or 0), reverse=True)
    return rows[:limit]


def _reservations_as_actions(user_id: str) -> List[Dict[str, Any]]:
    user_id = (user_id or "").strip()
    if not user_id or not _postgres_ready():
        return []
    rows: List[Dict[str, Any]] = []
    try:
        from postgres_db import connection

        with connection() as conn:
            found = conn.execute(
                """
                SELECT job_id, kind, state, cost, attempt_count, created_at, updated_at
                  FROM job_reservations
                 WHERE user_id = %s
                 ORDER BY created_at DESC
                 LIMIT 2000
                """,
                (user_id,),
            ).fetchall()
        for row in found:
            item = dict(row)
            rows.append({
                "email": "",
                "action": f"job:{item.get('kind') or 'task'}",
                "action_title": f"{item.get('kind') or 'task'} · {item.get('state') or '?'}",
                "success": str(item.get("state") or "") in {"completed", "complete"},
                "message": f"job {item.get('job_id')} · charged {int(item.get('cost') or 0)} · attempts {int(item.get('attempt_count') or 0)}",
                "time": float(item.get("created_at") or item.get("updated_at") or 0),
            })
    except Exception:
        pass
    return rows


def build_ticket_user_context(user_id: str, site_email: str = "") -> Dict[str, Any]:
    """Return calendar-grouped activity for an admin ticket view."""
    user_id = (user_id or "").strip()
    site_email = (site_email or "").strip().lower()

    try:
        import accounts
        account = accounts.get_user(user_id) or {}
    except Exception:
        account = {}

    purchases = _stripe_topups_for_user(user_id)
    ledger = _ledger_for_user(user_id)
    saves = _saves_for_user(user_id)
    emails = _job_emails_for_user(user_id)
    emails = sorted(set(emails) | {
        str(row.get("email") or "").strip().lower()
        for row in saves if "@" in str(row.get("email") or "")
    })
    if site_email and "@" in site_email:
        emails = sorted(set(emails) | {site_email})
    actions = _actions_for_emails(emails)
    # Always include durable job reservations as site actions.
    seen_keys = {(a.get("message"), a.get("time")) for a in actions}
    for row in _reservations_as_actions(user_id):
        key = (row.get("message"), row.get("time"))
        if key not in seen_keys:
            actions.append(row)
    actions.sort(key=lambda r: float(r.get("time") or 0), reverse=True)

    days: Dict[str, Dict[str, List[Dict[str, Any]]]] = defaultdict(
        lambda: {"saves": [], "purchases": [], "actions": [], "ledger": []}
    )
    for row in saves:
        days[_day_key(row.get("time") or 0)]["saves"].append(row)
    for row in purchases:
        days[_day_key(row.get("time") or 0)]["purchases"].append(row)
    for row in actions:
        days[_day_key(row.get("time") or 0)]["actions"].append(row)
    for row in ledger:
        days[_day_key(row.get("time") or 0)]["ledger"].append(row)

    day_list = []
    for day in sorted(days.keys(), reverse=True):
        if day == "unknown" and not any(days[day].values()):
            continue
        bucket = days[day]
        day_list.append({
            "day": day,
            "label": _day_label(day),
            "saves": bucket["saves"],
            "purchases": bucket["purchases"],
            "actions": bucket["actions"],
            "ledger": bucket["ledger"],
            "counts": {
                "saves": len(bucket["saves"]),
                "purchases": len(bucket["purchases"]),
                "actions": len(bucket["actions"]),
                "ledger": len(bucket["ledger"]),
            },
        })

    return {
        "user_id": user_id,
        "site_email": site_email,
        "current_balance": int(account.get("balance") or 0),
        "related_emails": emails,
        "totals": {
            "saves": len(saves),
            "purchases": len(purchases),
            "actions": len(actions),
            "ledger": len(ledger),
        },
        "days": day_list,
        "generated_at": time.time(),
    }
