# Pre-Redeploy User and Managed-Alt Migration Checklist

**Prepared by Manus AI**

## What the supplied export contains

The supplied `user_cpm_alts.json` is ready to import. It contains **20 site-user buckets** and **29 managed alternate accounts**. There are **23 active** and **6 full** alternates, every account has the fields needed for migration, and every selected `active_id` points to an account in the same user bucket.

> **Security warning:** This data includes CPM email addresses and passwords. Keep every backup archive private, avoid pasting it into tickets or chat, and remove temporary copies after the PostgreSQL verification is complete.

## 1. Put the site into a quiet state

Before exporting, stop new writes. Enable the site’s maintenance mode or otherwise pause account creation, alt setup, and car jobs. Wait for currently running jobs to finish or record their job IDs so you can decide whether to retry them after the redeploy.

## 2. Export the current Railway volume

Add `backup_before_redeploy.py` to the deployed service, then use the Railway service shell to run the following command. It copies the user, alternate-account, credential backlog, action history, settings, counters, and other relevant JSON state into a timestamped directory. It also produces a ZIP archive and SHA-256 checksum.

```bash
cd /app
python backup_before_redeploy.py \
  --data-dir "${DATA_DIR:-/app/data}"
```

Record the printed archive path and checksum. Download the generated ZIP through your normal private Railway-volume or shell-file transfer method before replacing the service. Keep the original volume intact until the database import has been checked.

At minimum, confirm that the backup contains both files below:

| Required file | Why it is required |
|---|---|
| `site_accounts.json` | Creates the `site_users` rows and preserves site-user IDs, passwords, balances, and top-up history. |
| `user_cpm_alts.json` | Restores each user’s alt preference, active selected alt, CPM email/password, Firebase UID, status, saved car count, and action history. |

## 3. Deploy the persistent-storage code and attach PostgreSQL

Create or attach the Railway PostgreSQL service, then set the same `DATABASE_URL` on both the web and background-worker services. Enable the existing account database backend by setting:

```bash
POSTGRES_ACCOUNTS_ENABLED=1
```

Deploy the files in the migration package together. The revised `user_cpm_alts.py` automatically uses the persistent managed-alt tables whenever the PostgreSQL account backend is enabled; it remains JSON-backed only for local development with no database configured.

## 4. Import in the required order

Run both commands from the deployed service shell while the site is still quiet. **The user import must run first** because managed-alt records have a foreign key to `site_users`.

```bash
cd /app

# Import all site users and the existing JSON-backed site state.
python migrate_to_postgres.py \
  --source /app/data/predeploy-backup-YYYYMMDD-HHMMSS/site_accounts.json \
  --data-dir /app/data/predeploy-backup-YYYYMMDD-HHMMSS \
  --replace-existing

# Import preferences, selected active alts, and all managed-alt records.
python migrate_managed_alts_to_postgres.py \
  --source /app/data/predeploy-backup-YYYYMMDD-HHMMSS/user_cpm_alts.json
```

Replace `predeploy-backup-YYYYMMDD-HHMMSS` with the actual directory printed by the backup command. Both importers are idempotent: re-running them updates the same user and alternate identifiers rather than generating duplicates.

## 5. Verify before reopening the site

The first importer prints source-user and PostgreSQL-user counts plus credit totals. Its `exact_match` field must be `true`. The managed-alt importer must report the same number of source buckets as imported preferences and an account count that includes the expected imported alternates.

For the supplied file, the expected managed-alt import is:

| Check | Expected value |
|---|---:|
| Source user buckets | 20 |
| Preferences imported | 20, assuming all 20 site users were imported first |
| Managed alternate accounts upserted | 29 |
| Active selected-alt references missing | 0 |
| Source account statuses | 23 active and 6 full |

Then sign in as a test user with a known managed alt and open **My CPM Accounts**. Confirm that the same alt email, selected active alt, saved car count, and status are displayed. Submit no new car job until this check passes.

## 6. Restore service traffic and retain the backup

Once the verification succeeds, restart the web and worker services, disable maintenance mode, and make one low-risk car-tool test. Retain the encrypted/private backup archive until the service has operated normally for several days. Do not delete the Railway volume or backup copy until both user and alt records have been checked in PostgreSQL.

## Included migration files

| File | Purpose |
|---|---|
| `backup_before_redeploy.py` | Takes a local volume snapshot, writes a manifest, and creates a checksum-verified ZIP archive. |
| `migrate_to_postgres.py` | Existing user, balances, settings, counters, and backlog importer. |
| `migrate_managed_alts_to_postgres.py` | Idempotently imports preferences, active-alt selection, and managed-alt account records. |
| `user_cpm_alts.py` | Updated runtime storage layer that reads and writes persistent PostgreSQL managed-alt tables when enabled. |

The two `managed_alt_*` tables are created automatically by the importer and runtime storage layer. The JSON file is not deleted or overwritten by the migration; it remains available as a rollback source.
