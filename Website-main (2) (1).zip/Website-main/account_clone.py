#!/usr/bin/env python3
"""Paid account-clone adapter based on injectfinal.py Option 4 export/inject logic.

The source account is exported directly from TestGetAllCars into in-memory
CarBlueprint objects. Packed CPM fields are normalized exactly like the tool,
including Car170-format body vinyls, then each missing car is re-injected into
the target account through WSPurchaseCarV3.
"""

from __future__ import annotations

import asyncio
import base64
import json
import random
import struct
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional

import aiohttp
import brotli

from car_bulk_injector import injection_http_session

K = "AIzaSyBW1ZbMiUeDZHYUO2bY8Bfnf5rRgrQGPTM"
EU = "https://europe-west1-cp-multiplayer.cloudfunctions.net"
FB = "https://www.googleapis.com/identitytoolkit/v3/relyingparty"

Progress = Optional[Callable[[str, str, Optional[Dict[str, Any]]], None]]


@dataclass
class CarBlueprint:
    car_id: int
    vectors: List[dict]
    floats: List[float]
    gears: List[float]
    type_to_install: List[int]
    bought_parts: List[int]
    texts: Any
    vynils: Any
    window_vinyls: Any
    flag_id: int
    fso_data: List[int]
    installed_police_lights: List[int]
    data_version: int
    source_slot: Optional[dict] = None


def _emit(progress: Progress, stage: str, message: str, extra: Optional[Dict[str, Any]] = None) -> None:
    if progress:
        progress(stage, message, extra or {})


async def _login(session: aiohttp.ClientSession, email: str, password: str):
    try:
        async with session.post(
            f"{FB}/verifyPassword",
            params={"key": K},
            json={"email": email, "password": password, "returnSecureToken": True},
            timeout=aiohttp.ClientTimeout(total=12),
        ) as response:
            try:
                data = await response.json(content_type=None)
            except Exception:
                return None, None, "Authentication response was unreadable."
            if data.get("idToken"):
                return data["idToken"], data.get("localId"), None
            err = data.get("error", {})
            msg = err.get("message", str(data)) if isinstance(err, dict) else str(err or data)
            return None, None, msg
    except Exception as exc:
        return None, None, str(exc)


async def validate_clone_target(email: str, password: str) -> Dict[str, Any]:
    """Verify destination credentials before a paid reservation is queued."""
    async with injection_http_session() as session:
        token, uid, error = await _login(session, email, password)
        return {
            "ok": bool(token),
            "uid": uid,
            "message": "Target account verified." if token else f"Target account login failed: {error or 'unknown error'}",
        }


async def _api(session: aiohttp.ClientSession, token: str, endpoint: str, data: Any):
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}"}
    try:
        async with session.post(
            f"{EU}/{endpoint}",
            json={"data": data},
            headers=headers,
            timeout=aiohttp.ClientTimeout(total=12),
        ) as response:
            return response.status, await response.text()
    except Exception as exc:
        return 500, json.dumps({"error": str(exc)})


async def _get_garage_result(
    session: aiohttp.ClientSession,
    token: str,
) -> tuple[bool, List[dict]]:
    attempts = [
        ("TestGetAllCars", None),
    ]
    for endpoint, payload in attempts:
        _, text = await _api(session, token, endpoint, payload)
        if not text:
            continue
        try:
            response_data = json.loads(text)
            if "result" not in response_data:
                continue
            result = response_data["result"]
            cars = json.loads(result) if isinstance(result, str) else result
            if isinstance(cars, list):
                return True, cars
            if isinstance(cars, dict) and (cars.get("CarID") or cars.get("carID")):
                return True, [cars]
        except Exception:
            continue
    return False, []
async def _get_player_info(session: aiohttp.ClientSession, token: str) -> Dict[str, Any]:
    for endpoint in ("GetPlayerRecords2", "GetPlayerRecords"):
        _, text = await _api(session, token, endpoint, None)
        if not text:
            continue
        try:
            data = json.loads(text)
            result = data.get("result")
            if result is None:
                continue
            obj = json.loads(result) if isinstance(result, str) else result
            if isinstance(obj, dict):
                return {"money": obj.get("money"), "coin": obj.get("coin"), "raw": obj}
        except Exception:
            continue
    return {"money": None, "coin": None, "raw": None}


async def _world_sale_slots(session: aiohttp.ClientSession, token: str, blocks: int = 20, passes: int = 1) -> List[dict]:
    merged: List[dict] = []
    seen = set()
    for _ in range(max(1, passes)):
        _, text = await _api(session, token, "WSGetCarListV3", blocks)
        try:
            response_data = json.loads(text)
            result = response_data.get("result")
            slots = json.loads(result) if isinstance(result, str) else result
            if not isinstance(slots, list):
                continue
            for slot in slots:
                sid = slot.get("carID") or slot.get("CarID")
                if sid is None or sid in seen:
                    continue
                seen.add(sid)
                merged.append(slot)
        except Exception:
            continue
    return merged


def _unpack_blob(value: Any) -> Optional[bytes]:
    if not isinstance(value, str) or not value:
        return None
    try:
        return brotli.decompress(base64.b64decode(value, validate=True))
    except Exception:
        return None


def _unpack_counted_floats(value: Any) -> Optional[List[float]]:
    raw = _unpack_blob(value)
    if raw is None or len(raw) < 4:
        return None
    try:
        count = struct.unpack_from("<I", raw, 0)[0]
        if count > 4096 or len(raw) != 4 + count * 4:
            return None
        return list(struct.unpack_from("<" + "f" * count, raw, 4))
    except Exception:
        return None


def _unpack_counted_ints(value: Any) -> Optional[List[int]]:
    raw = _unpack_blob(value)
    if raw is None or len(raw) < 4:
        return None
    try:
        count = struct.unpack_from("<I", raw, 0)[0]
        if count > 4096 or len(raw) != 4 + count * 4:
            return None
        return list(struct.unpack_from("<" + "i" * count, raw, 4))
    except Exception:
        return None


def _unpack_vectors(value: Any) -> Optional[List[dict]]:
    raw = _unpack_blob(value)
    if raw is None or len(raw) < 4:
        return None
    try:
        count = struct.unpack_from("<I", raw, 0)[0]
        if count > 1024 or len(raw) != 4 + count * 12:
            return None
        values = struct.unpack_from("<" + "f" * (count * 3), raw, 4)
        return [
            {"x": values[i * 3], "y": values[i * 3 + 1], "z": values[i * 3 + 2]}
            for i in range(count)
        ]
    except Exception:
        return None


def _read_utf8_chars(buf: bytes, pos: int, count: int):
    if count < 0 or count > 10000:
        return None
    start = pos
    chars = 0
    while chars < count:
        if pos >= len(buf):
            return None
        byte = buf[pos]
        if byte < 0x80:
            size = 1
        elif (byte & 0xE0) == 0xC0:
            size = 2
        elif (byte & 0xF0) == 0xE0:
            size = 3
        elif (byte & 0xF8) == 0xF0:
            size = 4
        else:
            return None
        if pos + size > len(buf):
            return None
        try:
            buf[pos:pos + size].decode("utf-8")
        except UnicodeDecodeError:
            return None
        pos += size
        chars += 1
    return buf[start:pos].decode("utf-8"), pos


def _decode_vynils_car170(value: Any, expected_car_id: Optional[int] = None) -> Optional[dict]:
    """Decode packed CPM1 body vinyls to the same six-field schema as CarID 170."""
    raw = _unpack_blob(value)
    if raw is None or len(raw) < 9:
        return None
    try:
        count = struct.unpack_from("<I", raw, 1)[0]
        end = len(raw) - 4
        embedded_car_id = struct.unpack_from("<i", raw, end)[0]
    except Exception:
        return None
    if count > 10000:
        return None
    if expected_car_id is not None and embedded_car_id != int(expected_car_id):
        return None

    def valid_start(pos: int, idx: int) -> bool:
        if idx == count:
            return pos == end
        if pos + 41 > end or raw[pos] != 6:
            return False
        try:
            vals = struct.unpack_from("<9f", raw, pos + 1)
        except Exception:
            return False
        return all(v == v and abs(v) < 1e7 for v in vals)

    memo: Dict[Any, Any] = {}

    def walk(idx: int, pos: int):
        key = (idx, pos)
        if key in memo:
            return memo[key]
        if idx == count:
            result = [] if pos == end else None
            memo[key] = result
            return result
        if not valid_start(pos, idx):
            memo[key] = None
            return None

        p = pos + 1
        vals = struct.unpack_from("<9f", raw, p)
        p += 36
        discriminator = struct.unpack_from("<i", raw, p)[0]
        p += 4
        candidates = []

        if p + 12 <= end:
            color = struct.unpack_from("<I", raw, p)[0]
            packed_data = struct.unpack_from("<I", raw, p + 4)[0]
            next_pos = p + 12
            if valid_start(next_pos, idx + 1):
                candidates.append((next_pos, "", color, packed_data))

        if p + 4 <= end:
            char_count = struct.unpack_from("<i", raw, p)[0]
            decoded = _read_utf8_chars(raw, p + 4, char_count)
            if decoded is not None:
                text_value, q = decoded
                if q + 12 <= end:
                    color = struct.unpack_from("<I", raw, q)[0]
                    packed_data = struct.unpack_from("<I", raw, q + 4)[0]
                    next_pos = q + 12
                    if valid_start(next_pos, idx + 1):
                        candidates.append((next_pos, text_value, color, packed_data))

        candidates.sort(
            key=lambda item: 0 if (
                (discriminator == 0 and item[1] == "") or
                (discriminator != 0 and item[1] != "")
            ) else 1
        )
        for next_pos, text_value, color, packed_data in candidates:
            tail = walk(idx + 1, next_pos)
            if tail is None:
                continue
            record = {
                "position": {"x": vals[0], "y": vals[1], "z": vals[2]},
                "scaleRotation": {"x": vals[3], "y": vals[4], "z": vals[5]},
                "iconPosition": {"x": vals[6], "y": vals[7], "z": vals[8]},
                "text": text_value,
                "color": int(color),
                "packedData": int(packed_data),
            }
            result = [record] + tail
            memo[key] = result
            return result
        memo[key] = None
        return None

    records = walk(0, 5)
    if records is None or len(records) != count:
        return None
    return {"CarID": int(embedded_car_id), "allVynils": records}


def _runtime_vynils(value: Any, car_id: int) -> dict:
    if isinstance(value, dict):
        result = json.loads(json.dumps(value))
        result["CarID"] = int(car_id)
        result.setdefault("allVynils", [])
        return result
    if isinstance(value, str):
        decoded = _decode_vynils_car170(value, int(car_id))
        if decoded is not None:
            return decoded
    return {"CarID": int(car_id), "allVynils": []}


def _normalize_export_car(car: dict) -> dict:
    """Option 4 normalization: packed/expanded TestGetAllCars -> reusable runtime JSON."""
    out = json.loads(json.dumps(car))
    cid = int(out.get("CarID", out.get("carID", 0)) or 0)

    vectors = _unpack_vectors(out.get("vectors"))
    if vectors is not None:
        out["vectors"] = vectors
    floats = _unpack_counted_floats(out.get("floats"))
    if floats is not None:
        out["floats"] = floats
    gears = _unpack_counted_floats(out.get("gears"))
    if gears is not None:
        out["gears"] = gears
    type_to_install = _unpack_counted_ints(out.get("typeToInstall"))
    if type_to_install is not None:
        out["typeToInstall"] = type_to_install
    bought_parts = _unpack_counted_ints(out.get("BoughtParts"))
    if bought_parts is not None:
        out["BoughtParts"] = bought_parts
    fso = _unpack_counted_ints(out.get("fsoData"))
    if fso is not None:
        out["fsoData"] = fso
    police = _unpack_counted_ints(out.get("installedPoliceLights"))
    if police is not None:
        out["installedPoliceLights"] = police
    if cid:
        out["Vynils"] = _runtime_vynils(out.get("Vynils"), cid)
    return out


def _to_blueprint(car: dict) -> Optional[CarBlueprint]:
    try:
        cid = int(car.get("CarID", car.get("carID", 0)) or 0)
        if cid <= 0:
            return None
        raw = json.loads(json.dumps(car))
        normalized = _normalize_export_car(car)
        return CarBlueprint(
            car_id=cid,
            vectors=normalized.get("vectors") if isinstance(normalized.get("vectors"), list) else [{"x": 2, "y": 2, "z": 2} for _ in range(28)],
            floats=normalized.get("floats") if isinstance(normalized.get("floats"), list) else [0] * 54,
            gears=normalized.get("gears") if isinstance(normalized.get("gears"), list) else [-10] * 8,
            type_to_install=normalized.get("typeToInstall") if isinstance(normalized.get("typeToInstall"), list) else [-2, 0, 0, 0, 0, -2, -2, 0],
            bought_parts=normalized.get("BoughtParts") if isinstance(normalized.get("BoughtParts"), list) else [-1] + [0] * 70,
            texts=normalized.get("texts", ["", "", "", ""]),
            vynils=_runtime_vynils(normalized.get("Vynils"), cid),
            window_vinyls=normalized.get("WindowVinyls", {}),
            flag_id=normalized.get("flagID", -1),
            fso_data=normalized.get("fsoData", [-1, 0, 255, 255, 255, 255, 255, 255]),
            installed_police_lights=normalized.get("installedPoliceLights", [8, 2, 0, 0, -1]),
            data_version=normalized.get("dataVersion", 3),
            source_slot={"one_car": raw},
        )
    except Exception:
        return None


def _blueprint_runtime_car(blueprint: CarBlueprint, uid: str = "") -> dict:
    cid = int(blueprint.car_id)
    raw = None
    if isinstance(blueprint.source_slot, dict):
        raw = blueprint.source_slot.get("one_car")
    if isinstance(raw, dict):
        car = _normalize_export_car(raw)
    else:
        car = {
            "vectors": json.loads(json.dumps(blueprint.vectors)),
            "floats": json.loads(json.dumps(blueprint.floats)),
            "gears": json.loads(json.dumps(blueprint.gears)),
            "typeToInstall": json.loads(json.dumps(blueprint.type_to_install)),
            "BoughtParts": json.loads(json.dumps(blueprint.bought_parts)),
            "texts": json.loads(json.dumps(blueprint.texts)),
            "Vynils": json.loads(json.dumps(blueprint.vynils)),
            "WindowVinyls": json.loads(json.dumps(blueprint.window_vinyls)),
            "flagID": blueprint.flag_id,
            "fsoData": json.loads(json.dumps(blueprint.fso_data)),
            "installedPoliceLights": json.loads(json.dumps(blueprint.installed_police_lights)),
            "dataVersion": int(blueprint.data_version or 3),
        }
    car["CarID"] = cid
    car["Vynils"] = _runtime_vynils(car.get("Vynils"), cid)
    if car.get("WindowVinyls") is None:
        car["WindowVinyls"] = {}
    if "dataVersion" not in car:
        car["dataVersion"] = int(blueprint.data_version or 3)

    texts = car.get("texts")
    if isinstance(texts, list):
        while len(texts) < 4:
            texts.append("")
        if not texts[2]:
            texts[2] = f"{(uid or 'UNKNOWN')[:8].upper()}_{cid}_HZ"
        car["texts"] = texts
    return car


async def _buy_car(session: aiohttp.ClientSession, token: str, slot: dict, car: dict) -> bool:
    cid = int(car.get("CarID", car.get("carID", 0)) or 0)
    vinyl_payload = _runtime_vynils(car.get("Vynils"), cid)
    car["Vynils"] = vinyl_payload
    payload = {
        "ownerID": slot.get("ownerID", ""),
        "ownerName": slot.get("ownerName", ""),
        "description": slot.get("description", ""),
        "CarID": slot.get("carID", 0),
        "carGeneratedID": slot.get("carGeneratedID", ""),
        "ownerAccountID": slot.get("ownerAccountID", ""),
        "oneCar": car,
        "vynilOneCar": vinyl_payload,
        "loadedLocalCar": {"instanceID": random.randint(-999999, -100000)},
        "price": slot.get("price", 100),
        "SellingCar": {},
        "willReject": False,
        "dislike": 1,
        "like": 0,
        "liked": False,
        "disliked": False,
        "mode": 1,
    }
    _, text = await _api(session, token, "WSPurchaseCarV3", json.dumps(payload))
    try:
        return json.loads(text).get("result") == 1
    except Exception:
        return False


async def clone_account(
    source_email: str,
    source_password: str,
    target_email: str,
    target_password: str,
    progress: Progress = None,
    resume_checkpoint: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Export every unique source garage car and inject each missing one into target."""
    async with injection_http_session() as session:
        _emit(progress, "source_login", "Logging into the source account…")
        source_token, source_uid, source_error = await _login(session, source_email, source_password)
        if not source_token:
            return {"ok": False, "message": f"Source account login failed: {source_error or 'unknown error'}", "exported": 0, "injected": 0, "failed_ids": []}

        _emit(progress, "source_garage", "Reading every car from the source garage with TestGetAllCars…")
        source_garage_readable, garage = await _get_garage_result(session, source_token)
        if not source_garage_readable or not garage:
            return {"ok": False, "message": "Source garage is empty or TestGetAllCars could not be read.", "exported": 0, "injected": 0, "failed_ids": []}

        _emit(progress, "export", f"Found {len(garage)} garage entries — preserving car data, vinyls, tuning, gearbox and install kits…", {"garage_count": len(garage)})

        blueprints: List[CarBlueprint] = []
        seen_ids = set()
        vinyl_layers = 0
        for index, raw_car in enumerate(garage, 1):
            bp = _to_blueprint(raw_car)
            if not bp or bp.car_id in seen_ids:
                continue
            seen_ids.add(bp.car_id)
            blueprints.append(bp)
            if isinstance(bp.vynils, dict) and isinstance(bp.vynils.get("allVynils"), list):
                vinyl_layers += len(bp.vynils["allVynils"])
            _emit(progress, "export_car", f"Prepared source car #{bp.car_id} ({len(blueprints)} ready)", {"current": index, "total": len(garage), "car_id": bp.car_id})

        if not blueprints:
            return {"ok": False, "message": "No inject-ready cars could be prepared from the source garage.", "exported": 0, "injected": 0, "failed_ids": []}

        _emit(progress, "export_ready", f"Export complete — {len(blueprints)} unique cars and {vinyl_layers:,} body-vinyl layers are ready for injection.", {"exported": len(blueprints), "vinyl_layers": vinyl_layers})

        _emit(progress, "target_login", "Logging into the destination account…")
        target_token, target_uid, target_error = await _login(session, target_email, target_password)
        if not target_token:
            return {"ok": False, "message": f"Target account login failed: {target_error or 'unknown error'}", "exported": len(blueprints), "injected": 0, "failed_ids": []}

        _emit(progress, "target_garage", "Reading the destination garage so existing cars are not overwritten…")
        target_garage_readable, target_garage = await _get_garage_result(session, target_token)
        owned = {
            int(c.get("CarID") or c.get("carID") or 0)
            for c in target_garage
            if isinstance(c, dict)
        }
        owned.discard(0)
        checkpoint_ids = {
            int(value) for value in (resume_checkpoint or {}).get("completed_car_ids", [])
            if str(value).lstrip("-").isdigit() and int(value) > 0
        }
        # A readable live garage is authoritative. Use checkpoint IDs only if
        # Get Cars is temporarily unavailable, so retries can repair a car that
        # was acknowledged by World Sale but never persisted.
        checkpoint_only = set() if target_garage_readable else checkpoint_ids
        targets = [
            bp for bp in blueprints
            if bp.car_id not in owned and bp.car_id not in checkpoint_only
        ]
        skipped = len(blueprints) - len(targets)
        _emit(
            progress,
            "compare",
            f"Destination has {len(owned)} cars — {len(targets)} need cloning and {skipped} are already owned or checkpointed.",
            {
                "targets": len(targets),
                "skipped": skipped,
                "checkpointed": len(checkpoint_only.intersection(seen_ids)),
            },
        )

        if not targets:
            return {
                "ok": True,
                "message": "Clone complete — the destination already has every source car.",
                "exported": len(blueprints),
                "injected": 0,
                "skipped_owned": skipped,
                "failed_ids": [],
                "vinyl_layers": vinyl_layers,
            }

        info = await _get_player_info(session, target_token)
        if info.get("money") is not None:
            _emit(progress, "target_balance", f"Destination balance checked — money {int(info.get('money') or 0):,}, coins {int(info.get('coin') or 0):,}.")

        _emit(progress, "worldsale", "Scanning World Sale slots for clone injection…")
        warm = await _world_sale_slots(session, target_token, blocks=20, passes=2)
        _emit(progress, "worldsale", f"World Sale scan returned {len(warm)} available slots.")

        used_slots = set()
        injected = 0
        failed_ids: List[int] = []
        money = info.get("money")

        for index, blueprint in enumerate(targets, 1):
            cid = int(blueprint.car_id)
            _emit(progress, "inject_car", f"[{index}/{len(targets)}] Preparing car #{cid} with original vinyls and setup…", {"current": index, "total": len(targets), "car_id": cid})
            success = False
            for attempt in range(1, 5):
                slots = await _world_sale_slots(session, target_token, blocks=20, passes=1)
                candidates = []
                for slot in slots:
                    sid = slot.get("carID") or slot.get("CarID")
                    if sid is None or sid in used_slots:
                        continue
                    slot_price = slot.get("price", 0) or 0
                    if money is not None and slot_price > money:
                        continue
                    candidates.append((slot_price, slot))
                if not candidates:
                    _emit(progress, "slot_wait", f"[{index}/{len(targets)}] No usable slot for #{cid} yet — retry {attempt}/4…")
                    await asyncio.sleep(0.6)
                    continue
                candidates.sort(key=lambda pair: pair[0])
                _, slot = candidates[0]
                sid = slot.get("carID") or slot.get("CarID")
                used_slots.add(sid)
                one_car = _blueprint_runtime_car(blueprint, target_uid or "")
                success = await _buy_car(session, target_token, slot, one_car)
                if success:
                    break
                _emit(progress, "retry", f"[{index}/{len(targets)}] World Sale rejected #{cid} — retry {attempt}/4…")
                await asyncio.sleep(0.8)

            if success:
                injected += 1
                _emit(progress, "injected", f"[{index}/{len(targets)}] Car #{cid} cloned successfully ({injected}/{len(targets)}).", {"injected": injected, "total": len(targets), "car_id": cid})
            else:
                failed_ids.append(cid)
                _emit(progress, "failed", f"[{index}/{len(targets)}] Car #{cid} could not be injected after retries.", {"car_id": cid})
            await asyncio.sleep(0.8)

        ok = injected > 0 or not failed_ids
        message = f"Clone finished — {injected}/{len(targets)} missing cars injected."
        if failed_ids:
            message += f" {len(failed_ids)} cars still failed and can be retried."
        return {
            "ok": ok,
            "message": message,
            "exported": len(blueprints),
            "injected": injected,
            "skipped_owned": skipped,
            "failed_ids": failed_ids,
            "vinyl_layers": vinyl_layers,
        }
