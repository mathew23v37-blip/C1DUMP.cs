#!/usr/bin/env python3
"""Queue diagnostics plus explicit resume/refund controls for paid reservations."""

from __future__ import annotations

import argparse
import json


def status() -> dict:
    from postgres_db import connection, healthcheck
    from redis_jobs import get_job_store, get_redis
    from rq import Queue, Worker

    store = get_job_store()
    queue = Queue("injections", connection=get_redis())
    with connection() as conn:
        reservations = conn.execute(
            "SELECT state, COUNT(*)::bigint AS count FROM job_reservations GROUP BY state"
        ).fetchall()
        outbox = conn.execute(
            "SELECT COUNT(*)::bigint AS count FROM injection_outbox WHERE dispatched_at IS NULL"
        ).fetchone()["count"]
    workers = Worker.all(connection=get_redis())
    return {
        "postgres": healthcheck(),
        "redis": store.ping(),
        "redis_job_states": store.states(),
        "rq_queue_length": len(queue),
        "rq_failed": len(queue.failed_job_registry),
        "rq_workers": [{"name": worker.name, "state": worker.state} for worker in workers],
        "postgres_reservations": {row["state"]: int(row["count"]) for row in reservations},
        "pending_outbox": int(outbox),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("status")
    refund = sub.add_parser("refund")
    refund.add_argument("job_id")
    refund.add_argument("--reason", default="administrator_refund")
    resume = sub.add_parser("resume")
    resume.add_argument("job_id")
    resume.add_argument("--reason", default="administrator_resume")
    sub.add_parser("dispatch")
    args = parser.parse_args()
    if args.command == "status":
        result = status()
    elif args.command == "refund":
        import accounts
        from redis_jobs import get_job_store

        result = accounts.refund_job_reservation(args.job_id, args.reason)
        if result.get("ok"):
            get_job_store().finish(args.job_id, "refunded", result)
    elif args.command == "resume":
        import accounts
        from redis_jobs import get_job_store

        result = accounts.resume_job_reservation(args.job_id, args.reason)
        if result.get("requeued"):
            checkpoint = result.get("checkpoint") or {}
            get_job_store().update(
                args.job_id,
                status="resume_pending",
                result=None,
                checkpoint=checkpoint,
            )
            get_job_store().append_event(
                args.job_id,
                "resume_pending",
                "Administrator resumed this paid job from its saved checkpoint; no credits were charged.",
            )
    else:
        from outbox_dispatcher import dispatch_pending_once

        result = {"dispatched": dispatch_pending_once(100)}
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if not isinstance(result, dict) or result.get("ok", True) else 1


if __name__ == "__main__":
    raise SystemExit(main())
