import asyncio
import json
import os
import sys
from copy import deepcopy
from pathlib import Path

PROJECT_DIR = Path('/home/ubuntu/work_getallcars/source/Website-main')
os.environ.setdefault('DATA_DIR', '/home/ubuntu/work_getallcars/testdata')
sys.path.insert(0, str(PROJECT_DIR))

import car_bulk_injector as injector


async def test_collection_wrapper():
    base = json.loads((PROJECT_DIR / 'alt_bootstrap_car.json').read_text(encoding='utf-8'))['car']
    cars = []
    for car_id in range(1, 101):
        car = deepcopy(base)
        car['CarID'] = car_id
        car['Vynils']['CarID'] = car_id
        cars.append(car)
    captured = {}
    original = injector._inject_car_ids_from_template

    async def fake_inject(ids, template, email, password, progress=None, **kwargs):
        captured['ids'] = ids
        captured['template'] = template
        captured['kwargs'] = kwargs
        return {'ok': True, 'injected': 100, 'skipped': 0, 'failed_ids': []}

    try:
        injector._inject_car_ids_from_template = fake_inject
        result = await injector.inject_public_design_collection({'cars': cars}, 'test@example.test', 'password')
        assert result['ok'] is True
        assert captured['ids'] == list(range(1, 101))
        assert captured['kwargs']['replace_owned'] is True
        assert captured['kwargs']['lossless_individual'] is True
        assert captured['kwargs']['payload_mode'] == 'verified_full'
    finally:
        injector._inject_car_ids_from_template = original


async def main_async():
    await test_collection_wrapper()


if __name__ == '__main__':
    asyncio.run(main_async())
    source = (PROJECT_DIR / 'worker_tasks.py').read_text(encoding='utf-8')
    assert 'worker pool under the batch concurrency cap' in source
    assert 'worker_lane_slot("king"' not in source
    source = (PROJECT_DIR / 'king_account_jobs.py').read_text(encoding='utf-8')
    assert 'i.car_amount DESC' in source
    assert 'max_concurrency' in source
    worker_source = (PROJECT_DIR / 'worker_tasks.py').read_text(encoding='utf-8')
    assert 'maximum concurrency is full' in worker_source
    print('PASS: king collection wrapper, concurrent worker path, maximum-concurrency gate, and completion-priority query are present.')
