#!/usr/bin/env python3
"""PostgreSQL implementation of site accounts and injection reservations."""

from __future__ import annotations

import hashlib
import json
import os
import time
import uuid
from typing import Any, Dict, Iterable, Optional

from werkzeug.security import check_password_hash, generate_password_hash

from postgres_db import connection, ensure_schema


def _jsonb(value):
    from psycopg.types.json import Jsonb

    return Jsonb(value)


def _public_user(row) -> Optional[Dict[str, Any]]:
    if not row:
        return None
    return {
        "user_id": row["user_id"],
        "email": row["email"],
        "balance": int(row["balance"]),
        "created_at": row.get("created_at"),
    }


def _ledger(
    cursor,
    *,
    user_id: str,
    entry_type: str,
    amount: int,
    reason: str,
    balance_after: int,
    event_time: Optional[float] = None,
    meta: Optional[Dict[str, Any]] = None,
    previous_balance: Optional[int] = None,
    target_balance: Optional[int] = None,
    source_key: Optional[str] = None,
) -> None:
    cursor.execute(
        """
        INSERT INTO credit_ledger
            (user_id, entry_type, amount, previous_balance, target_balance,
             reason, balance_after, event_time, meta, source_key)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (source_key) DO NOTHING
        """,
        (
            user_id,
            entry_type,
            int(amount),
            previous_balance,
            target_balance,
            reason,
            int(balance_after),
            float(event_time or time.time()),
            _jsonb(meta or {}),
            source_key,
        ),
    )


def register(email: str, password: str) -> Dict[str, Any]:
    email = (email or "").strip().lower()
    password = password or ""
    if not email or not password:
        return {"ok": False, "message": "Email and password are required."}
    now = time.time()
    for _ in range(4):
        user_id = uuid.uuid4().hex[:12]
        try:
            with connection() as conn, conn.transaction():
                row = conn.execute(
                    """
                    INSERT INTO site_users
                        (user_id, email, password_hash, balance, created_at, updated_at)
                    VALUES (%s, %s, %s, 0, %s, %s)
                    ON CONFLICT (email) DO NOTHING
                    RETURNING user_id, email, balance
                    """,
                    (user_id, email, generate_password_hash(password), now, now),
                ).fetchone()
                if row:
                    return {"ok": True, "user_id": row["user_id"], "email": row["email"], "balance": 0}
                existing = conn.execute(
                    "SELECT user_id FROM site_users WHERE email = %s", (email,)
                ).fetchone()
                if existing:
                    return {"ok": False, "message": "That email is already registered."}
        except Exception as exc:
            if "site_users_pkey" not in str(exc):
                raise
    return {"ok": False, "message": "Unable to allocate a unique user ID. Please retry."}


def login(email: str, password: str) -> Dict[str, Any]:
    email = (email or "").strip().lower()
    with connection() as conn:
        row = conn.execute(
            "SELECT user_id, email, password_hash, balance FROM site_users WHERE email = %s",
            (email,),
        ).fetchone()
    if not row or not check_password_hash(row["password_hash"], password or ""):
        return {"ok": False, "message": "Invalid email or password."}
    return {
        "ok": True,
        "user_id": row["user_id"],
        "email": row["email"],
        "balance": int(row["balance"]),
    }


def reset_password_by_email(email: str, password: str) -> Dict[str, Any]:
    """Admin-only helper: replace a site's hashed password by email."""
    email = (email or "").strip().lower()
    password = password or ""
    if not email or not password:
        return {"ok": False, "message": "Email and new password are required."}
    with connection() as conn, conn.transaction():
        row = conn.execute(
            "SELECT user_id FROM site_users WHERE email = %s FOR UPDATE", (email,)
        ).fetchone()
        if not row:
            return {"ok": False, "message": "User not found for that email."}
        conn.execute(
            "UPDATE site_users SET password_hash = %s, updated_at = %s WHERE user_id = %s",
            (generate_password_hash(password), time.time(), row["user_id"]),
        )
    return {"ok": True, "email": email}


def get_user(user_id: str) -> Optional[Dict[str, Any]]:
    with connection() as conn:
        row = conn.execute(
            "SELECT user_id, email, balance, created_at FROM site_users WHERE user_id = %s",
            ((user_id or "").strip(),),
        ).fetchone()
    return _public_user(row)


def set_balance(user_id: str, balance: int, reason: str, maximum: int) -> Dict[str, Any]:
    try:
        balance = int(balance)
    except (TypeError, ValueError):
        return {"ok": False, "message": "Balance must be an integer credit amount."}
    if balance < 0:
        return {"ok": False, "message": "Balance cannot be negative."}
    if balance > maximum:
        return {"ok": False, "message": f"Balance cannot exceed {maximum:,} credits."}
    now = time.time()
    with connection() as conn, conn.transaction():
        row = conn.execute(
            "SELECT balance FROM site_users WHERE user_id = %s FOR UPDATE", (user_id,)
        ).fetchone()
        if not row:
            return {"ok": False, "message": "User not found."}
        previous = int(row["balance"])
        conn.execute(
            "UPDATE site_users SET balance = %s, updated_at = %s WHERE user_id = %s",
            (balance, now, user_id),
        )
        _ledger(
            conn,
            user_id=user_id,
            entry_type="admin_set_balance",
            amount=balance - previous,
            previous_balance=previous,
            target_balance=balance,
            reason=reason,
            balance_after=balance,
            event_time=now,
        )
    return {"ok": True, "balance": balance, "previous_balance": previous, "user_id": user_id}


def add_balance(user_id: str, amount: int, reason: str, meta: Optional[Dict[str, Any]], maximum: int) -> Dict[str, Any]:
    amount = int(amount)
    if amount <= 0:
        return {"ok": False, "message": "Amount must be positive."}
    now = time.time()
    with connection() as conn, conn.transaction():
        row = conn.execute(
            """
            UPDATE site_users
               SET balance = balance + %s, updated_at = %s
             WHERE user_id = %s
         RETURNING balance
            """,
            (amount, now, user_id),
        ).fetchone()
        if not row:
            return {"ok": False, "message": "User not found."}
        balance = int(row["balance"])
        _ledger(
            conn,
            user_id=user_id,
            entry_type="credit",
            amount=amount,
            reason=reason,
            balance_after=balance,
            event_time=now,
            meta=meta,
        )
    return {"ok": True, "balance": balance, "user_id": user_id}


def add_balance_to_all_existing(amount: int, reason: str, maximum: int) -> Dict[str, Any]:
    try:
        amount = int(amount)
    except (TypeError, ValueError):
        return {"ok": False, "message": "Amount must be an integer credit amount."}
    if amount <= 0:
        return {"ok": False, "message": "Amount must be greater than zero."}
    if amount > maximum:
        return {"ok": False, "message": f"Grant cannot exceed {maximum:,} credits."}
    now = time.time()
    with connection() as conn, conn.transaction():
        rows = conn.execute(
            "SELECT user_id, balance FROM site_users ORDER BY user_id FOR UPDATE"
        ).fetchall()
        if not rows:
            return {"ok": False, "message": "There are no existing members to credit.", "updated": 0}
        capped = 0
        for row in rows:
            previous = int(row["balance"])
            target = min(maximum, previous + amount)
            capped += int(target == maximum and previous + amount > maximum)
            conn.execute(
                "UPDATE site_users SET balance = %s, updated_at = %s WHERE user_id = %s",
                (target, now, row["user_id"]),
            )
            _ledger(
                conn,
                user_id=row["user_id"],
                entry_type="credit",
                amount=target - previous,
                reason=reason,
                balance_after=target,
                event_time=now,
                meta={"admin_bulk_grant": True, "requested_amount": amount},
            )
    return {"ok": True, "updated": len(rows), "amount": amount, "capped": capped}


def grant_free_and_paid_balances(
    free_amount: int, paid_amount: int, maximum: int, *,
    reason_free: str = "admin_grant_free_users",
    reason_paid: str = "admin_grant_paid_users",
) -> Dict[str, Any]:
    free_amount, paid_amount = int(free_amount or 0), int(paid_amount or 0)
    if min(free_amount, paid_amount) < 0 or max(free_amount, paid_amount) > maximum:
        return {"ok": False, "message": "Grant amounts are outside the allowed range."}
    if not free_amount and not paid_amount:
        return {"ok": False, "message": "Enter at least one grant amount greater than zero."}
    now = time.time()
    free_updated = paid_updated = capped = 0
    with connection() as conn, conn.transaction():
        rows = conn.execute(
            """SELECT u.user_id, u.balance,
                      EXISTS(SELECT 1 FROM stripe_topups s WHERE s.user_id=u.user_id) AS is_paid
                 FROM site_users u ORDER BY u.user_id FOR UPDATE OF u"""
        ).fetchall()
        for row in rows:
            paid = bool(row["is_paid"])
            amount = paid_amount if paid else free_amount
            if amount <= 0:
                continue
            previous = int(row["balance"] or 0)
            target = min(maximum, previous + amount)
            capped += int(target < previous + amount)
            conn.execute("UPDATE site_users SET balance=%s, updated_at=%s WHERE user_id=%s",
                         (target, now, row["user_id"]))
            _ledger(conn, user_id=row["user_id"], entry_type="credit",
                    amount=target-previous, reason=reason_paid if paid else reason_free,
                    balance_after=target, event_time=now,
                    meta={"admin_bulk_grant": True, "paid_user": paid})
            if paid: paid_updated += 1
            else: free_updated += 1
    return {"ok": True, "free_updated": free_updated, "paid_updated": paid_updated,
            "updated": free_updated + paid_updated, "capped": capped}


def has_paid_history(user_id: str) -> bool:
    normalized = str(user_id or "").strip()
    if not normalized:
        return False
    with connection() as conn:
        row = conn.execute(
            "SELECT 1 FROM stripe_topups WHERE user_id = %s LIMIT 1", (normalized,)
        ).fetchone()
    return bool(row)


def wipe_free_economy(reason: str = "admin_wipe_free_economy") -> Dict[str, Any]:
    """Atomically zero never-paid balances while protecting all Stripe customers."""
    now = time.time()
    with connection() as conn, conn.transaction():
        paid_count = conn.execute(
            "SELECT COUNT(DISTINCT user_id)::bigint AS n FROM stripe_topups"
        ).fetchone()["n"]
        rows = conn.execute(
            """
            SELECT u.user_id, u.balance
              FROM site_users u
             WHERE u.balance > 0
               AND NOT EXISTS (
                   SELECT 1 FROM stripe_topups s WHERE s.user_id = u.user_id
               )
             ORDER BY u.user_id
             FOR UPDATE OF u
            """
        ).fetchall()
        removed = 0
        wipe_id = uuid.uuid4().hex
        for row in rows:
            previous = int(row["balance"] or 0)
            conn.execute(
                "UPDATE site_users SET balance = 0, updated_at = %s WHERE user_id = %s",
                (now, row["user_id"]),
            )
            _ledger(
                conn, user_id=row["user_id"], entry_type="debit", amount=previous,
                reason=reason, balance_after=0, event_time=now,
                previous_balance=previous, target_balance=0,
                meta={"admin_free_economy_wipe": True, "paid_user": False},
                source_key=f"free-wipe:{wipe_id}:{row['user_id']}",
            )
            removed += previous
    return {"ok": True, "wiped_users": len(rows), "credits_removed": removed,
            "paid_users_protected": int(paid_count or 0)}


def charge(
    user_id: str,
    *,
    cost: int,
    action: str,
    reason: str,
    unlimited: bool,
) -> Dict[str, Any]:
    cost = int(cost)
    with connection() as conn, conn.transaction():
        row = conn.execute(
            "SELECT balance FROM site_users WHERE user_id = %s FOR UPDATE", (user_id,)
        ).fetchone()
        if not row:
            return {"ok": False, "message": "Site account required.", "balance": 0, "cost": cost}
        balance = int(row["balance"])
        if cost <= 0:
            return {"ok": True, "charged": 0, "balance": balance, "free": True}
        if unlimited:
            return {"ok": True, "charged": 0, "balance": balance, "cost": cost, "unlimited_currency": True}
        if balance < cost:
            return {
                "ok": False,
                "message": f"Not enough balance. Need {cost:,}, you have {balance:,}.",
                "balance": balance,
                "cost": cost,
            }
        after = balance - cost
        now = time.time()
        conn.execute(
            "UPDATE site_users SET balance = %s, updated_at = %s WHERE user_id = %s",
            (after, now, user_id),
        )
        _ledger(
            conn,
            user_id=user_id,
            entry_type="debit",
            amount=cost,
            reason=reason or action,
            balance_after=after,
            event_time=now,
            meta={"action": action},
        )
    return {"ok": True, "charged": cost, "balance": after, "cost": cost}


def fulfill_stripe_topup(
    *,
    session_id: str,
    event_id: str,
    user_id: str,
    pack_id: str,
    credits: int,
    amount_cents: int,
    currency: str,
    maximum: int,
) -> Dict[str, Any]:
    now = time.time()
    with connection() as conn, conn.transaction():
        conn.execute(
            "SELECT pg_advisory_xact_lock(hashtextextended(%s, 0))",
            (f"stripe-session:{session_id}",),
        )
        existing = conn.execute(
            "SELECT balance_after FROM stripe_topups WHERE session_id = %s", (session_id,)
        ).fetchone()
        if existing:
            return {
                "ok": True,
                "duplicate": True,
                "balance": int(existing["balance_after"]),
                "user_id": user_id,
                "session_id": session_id,
            }
        row = conn.execute(
            "SELECT balance FROM site_users WHERE user_id = %s FOR UPDATE", (user_id,)
        ).fetchone()
        if not row:
            return {"ok": False, "message": "User not found."}
        after = int(row["balance"]) + int(credits)
        conn.execute(
            "UPDATE site_users SET balance = %s, updated_at = %s WHERE user_id = %s",
            (after, now, user_id),
        )
        conn.execute(
            """
            INSERT INTO stripe_topups
                (session_id, event_id, user_id, pack_id, credits, amount_cents,
                 currency, fulfilled_at, balance_after)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (session_id, event_id, user_id, pack_id, credits, amount_cents, currency, now, after),
        )
        _ledger(
            conn,
            user_id=user_id,
            entry_type="credit",
            amount=int(credits),
            reason="stripe_topup",
            balance_after=after,
            event_time=now,
            meta={
                "pack_id": pack_id,
                "session_id": session_id,
                "event_id": event_id,
                "amount_cents": amount_cents,
                "currency": currency,
            },
            source_key=f"stripe:{session_id}",
        )
    return {
        "ok": True,
        "duplicate": False,
        "balance": after,
        "user_id": user_id,
        "session_id": session_id,
        "credits": int(credits),
    }


def make_idempotency_key(user_id: str, web_uid: Any, kind: str, account_keys: Iterable[str]) -> str:
    normalized = ",".join(sorted({str(k).strip().lower() for k in account_keys if k}))
    raw = f"{user_id}|{web_uid}|{kind}|{normalized}".encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def reserve_injection_job(
    *,
    job_id: str,
    user_id: str,
    web_uid: Any,
    kind: str,
    action: str,
    account_keys: Iterable[str],
    idempotency_key: str,
    configured_cost: int,
    unlimited: bool,
    payload: Dict[str, Any],
    initial_state: str = "reserved",
    enqueue_now: bool = True,
) -> Dict[str, Any]:
    """Atomically reserve credits and create the durable job/outbox record."""
    now = time.time()
    keys = sorted({str(key).strip().lower() for key in account_keys if key})
    with connection() as conn, conn.transaction():
        stale_cutoff = now - max(300, int(os.getenv("CAR_JOB_STALE_LOCK_SECONDS", "900")))
        stale_rows = conn.execute(
            """
            UPDATE job_reservations
               SET state = 'manual_review', updated_at = %s,
                   failure_message = COALESCE(NULLIF(failure_message, ''),
                       'Job heartbeat expired; saved for administrator review.')
             WHERE state = 'running'
               AND COALESCE(last_heartbeat, updated_at) < %s
         RETURNING job_id
            """,
            (now, stale_cutoff),
        ).fetchall()
        for stale_row in stale_rows:
            conn.execute("DELETE FROM injection_outbox WHERE job_id = %s", (stale_row["job_id"],))
        # Repair locks left by completed/held jobs from earlier deployments.
        # Without this cleanup an account can say "still injecting" forever.
        conn.execute(
            """
            DELETE FROM injection_account_locks l
             USING job_reservations r
             WHERE l.job_id = r.job_id
               AND r.state IN ('completed', 'failed', 'refunded', 'manual_review')
            """
        )
        conn.execute("SELECT pg_advisory_xact_lock(hashtextextended(%s, 0))", (idempotency_key,))
        existing = conn.execute(
            """
            SELECT r.*, u.balance
              FROM job_reservations r
              JOIN site_users u ON u.user_id = r.user_id
             WHERE r.idempotency_key = %s
               AND r.state IN (
                   'reserved', 'awaiting_target', 'queued', 'running',
                   'resume_pending', 'manual_review'
               )
             ORDER BY r.created_at DESC
             LIMIT 1
            """,
            (idempotency_key,),
        ).fetchone()
        if existing:
            return {
                "ok": True,
                "duplicate": True,
                "job_id": existing["job_id"],
                "state": existing["state"],
                "charged": int(existing["cost"]),
                "balance": int(existing["balance"]),
            }

        if enqueue_now:
            for account_key in keys:
                conn.execute(
                    "SELECT pg_advisory_xact_lock(hashtextextended(%s, 0))",
                    (f"injection-account:{account_key}",),
                )
            conflict = conn.execute(
                "SELECT account_key, job_id FROM injection_account_locks WHERE account_key = ANY(%s) LIMIT 1",
                (keys,),
            ).fetchone() if keys else None
            if conflict:
                return {
                    "ok": False,
                    "message": "Another car operation is already queued or running for this CPM account.",
                    "conflict_job_id": conflict["job_id"],
                }

        user = conn.execute(
            "SELECT balance FROM site_users WHERE user_id = %s FOR UPDATE", (user_id,)
        ).fetchone()
        if not user:
            return {"ok": False, "message": "Site account required.", "balance": 0, "cost": configured_cost}
        balance = int(user["balance"])
        charged = 0 if unlimited else int(configured_cost)
        if charged > balance:
            return {
                "ok": False,
                "message": f"Not enough balance. Need {configured_cost:,}, you have {balance:,}.",
                "balance": balance,
                "cost": int(configured_cost),
            }
        after = balance - charged
        if charged:
            conn.execute(
                "UPDATE site_users SET balance = %s, updated_at = %s WHERE user_id = %s",
                (after, now, user_id),
            )
            _ledger(
                conn,
                user_id=user_id,
                entry_type="debit",
                amount=charged,
                reason=action,
                balance_after=after,
                event_time=now,
                meta={"action": action, "job_id": job_id, "kind": kind},
                source_key=f"job-debit:{job_id}",
            )
        conn.execute(
            """
            INSERT INTO job_reservations
                (job_id, user_id, web_uid, kind, action, idempotency_key,
                 account_keys, cost, state, payload, max_attempts,
                 created_at, updated_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                job_id,
                user_id,
                str(web_uid),
                kind,
                action,
                idempotency_key,
                _jsonb(keys),
                charged,
                initial_state,
                _jsonb(payload),
                # Unlock All keeps its remaining JSON cars in the durable queue
                # for repeated safe rescans instead of cancelling early.
                20 if kind == "unlock_all" else max(1, min(20, int(os.getenv("INJECTION_MAX_ATTEMPTS", "4")))),
                now,
                now,
            ),
        )
        if enqueue_now:
            for account_key in keys:
                conn.execute(
                    "INSERT INTO injection_account_locks (account_key, job_id, created_at) VALUES (%s, %s, %s)",
                    (account_key, job_id, now),
                )
            conn.execute(
                """
                INSERT INTO injection_outbox
                    (job_id, payload, available_at, created_at, updated_at)
                VALUES (%s, %s, %s, %s, %s)
                """,
                (job_id, _jsonb(payload), now, now, now),
            )
    return {
        "ok": True,
        "duplicate": False,
        "job_id": job_id,
        "state": initial_state,
        "charged": charged,
        "balance": after,
        "cost": int(configured_cost),
        "unlimited_currency": bool(unlimited),
    }


def get_job_reservation(job_id: str, *, include_payload: bool = False) -> Optional[Dict[str, Any]]:
    columns = "r.*" if include_payload else "r.job_id, r.user_id, r.web_uid, r.kind, r.action, r.account_keys, r.cost, r.state, r.created_at, r.updated_at, r.failure_message, r.checkpoint, r.attempt_count, r.max_attempts, r.last_heartbeat"
    with connection() as conn:
        row = conn.execute(f"SELECT {columns} FROM job_reservations r WHERE job_id = %s", (job_id,)).fetchone()
    return dict(row) if row else None


def prepare_clone_job(job_id: str, *, account_keys: Iterable[str], payload: Dict[str, Any]) -> Dict[str, Any]:
    now = time.time()
    keys = sorted({str(key).strip().lower() for key in account_keys if key})
    with connection() as conn, conn.transaction():
        row = conn.execute(
            "SELECT state FROM job_reservations WHERE job_id = %s FOR UPDATE", (job_id,)
        ).fetchone()
        if not row:
            return {"ok": False, "message": "Paid clone reservation was not found."}
        if row["state"] in ("queued", "running", "resume_pending", "manual_review"):
            return {"ok": True, "already_running": True, "state": row["state"]}
        if row["state"] != "awaiting_target":
            return {"ok": False, "message": "This paid clone reservation is no longer available."}
        for account_key in keys:
            conn.execute(
                "SELECT pg_advisory_xact_lock(hashtextextended(%s, 0))",
                (f"injection-account:{account_key}",),
            )
        conflict = conn.execute(
            """
            SELECT account_key, job_id FROM injection_account_locks
             WHERE account_key = ANY(%s) AND job_id <> %s
             LIMIT 1
            """,
            (keys, job_id),
        ).fetchone() if keys else None
        if conflict:
            return {
                "ok": False,
                "message": "A car operation is already queued or running for the source or destination CPM account. Your paid clone reservation is still saved; retry shortly.",
                "conflict_job_id": conflict["job_id"],
            }
        conn.execute(
            """
            UPDATE job_reservations
               SET account_keys = %s, payload = %s, state = 'reserved', updated_at = %s
             WHERE job_id = %s
            """,
            (_jsonb(keys), _jsonb(payload), now, job_id),
        )
        conn.execute("DELETE FROM injection_account_locks WHERE job_id = %s", (job_id,))
        for account_key in keys:
            conn.execute(
                "INSERT INTO injection_account_locks (account_key, job_id, created_at) VALUES (%s, %s, %s)",
                (account_key, job_id, now),
            )
        conn.execute(
            """
            INSERT INTO injection_outbox
                (job_id, payload, available_at, created_at, updated_at)
            VALUES (%s, %s, %s, %s, %s)
            ON CONFLICT (job_id) DO UPDATE SET
                payload = EXCLUDED.payload,
                available_at = EXCLUDED.available_at,
                dispatched_at = NULL,
                last_error = NULL,
                updated_at = EXCLUDED.updated_at
            """,
            (job_id, _jsonb(payload), now, now, now),
        )
    return {"ok": True, "already_running": False, "state": "reserved"}


def claim_outbox_batch(limit: int = 10) -> list[Dict[str, Any]]:
    now = time.time()
    lease_until = now + 30.0
    with connection() as conn, conn.transaction():
        rows = conn.execute(
            """
            SELECT o.job_id, o.payload, o.attempts,
                   r.user_id, r.web_uid, r.kind, r.action, r.account_keys,
                   r.cost, r.state, r.created_at, r.updated_at,
                   r.attempt_count, r.max_attempts, r.checkpoint
              FROM injection_outbox o
              JOIN job_reservations r ON r.job_id = o.job_id
             WHERE o.dispatched_at IS NULL
               AND o.available_at <= %s
               AND r.state IN ('reserved', 'queued', 'resume_pending')
             ORDER BY o.created_at
             FOR UPDATE OF o SKIP LOCKED
             LIMIT %s
            """,
            (now, max(1, min(100, int(limit)))),
        ).fetchall()
        for row in rows:
            conn.execute(
                """
                UPDATE injection_outbox
                   SET attempts = attempts + 1, available_at = %s, updated_at = %s
                 WHERE job_id = %s
                """,
                (lease_until, now, row["job_id"]),
            )
    return [dict(row) for row in rows]


def mark_outbox_dispatched(job_id: str) -> None:
    now = time.time()
    with connection() as conn, conn.transaction():
        conn.execute(
            "UPDATE injection_outbox SET dispatched_at = %s, updated_at = %s WHERE job_id = %s",
            (now, now, job_id),
        )
        conn.execute(
            """
            UPDATE job_reservations
               SET state = CASE
                       WHEN state IN ('reserved', 'resume_pending') THEN 'queued'
                       ELSE state
                   END,
                   updated_at = %s
             WHERE job_id = %s
            """,
            (now, job_id),
        )


def mark_outbox_error(job_id: str, error: str, attempts: int) -> None:
    now = time.time()
    backoff = min(300.0, max(5.0, 2.0 ** min(8, max(1, int(attempts)))))
    with connection() as conn, conn.transaction():
        conn.execute(
            """
            UPDATE injection_outbox
               SET last_error = %s, available_at = %s, updated_at = %s
             WHERE job_id = %s AND dispatched_at IS NULL
            """,
            ((error or "")[:1000], now + backoff, now, job_id),
        )


def mark_job_started(job_id: str) -> Dict[str, Any]:
    now = time.time()
    with connection() as conn, conn.transaction():
        row = conn.execute(
            """
            UPDATE job_reservations
               SET state = 'running', started_at = COALESCE(started_at, %s),
                   attempt_count = attempt_count + 1,
                   last_heartbeat = %s, updated_at = %s
             WHERE job_id = %s AND state IN ('reserved', 'queued', 'resume_pending')
         RETURNING payload, user_id, web_uid, kind, action, account_keys, cost,
                   checkpoint, attempt_count, max_attempts, last_heartbeat
            """,
            (now, now, now, job_id),
        ).fetchone()
        if not row:
            raise RuntimeError(f"Runnable reservation {job_id} was not found.")
    return dict(row)


_CHECKPOINT_SUCCESS_STAGES = {"car_success", "retry_success", "verified", "injected"}


def record_job_progress(job_id: str, stage: str, message: str, extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Persist a compact, durable checkpoint after observable worker progress."""
    now = time.time()
    details = dict(extra) if isinstance(extra, dict) else {}
    with connection() as conn, conn.transaction():
        row = conn.execute(
            "SELECT checkpoint, state, attempt_count FROM job_reservations WHERE job_id = %s FOR UPDATE",
            (job_id,),
        ).fetchone()
        if not row:
            raise RuntimeError(f"Job reservation {job_id} was not found.")
        checkpoint = dict(row.get("checkpoint") or {})
        completed = {
            int(value) for value in checkpoint.get("completed_car_ids", [])
            if str(value).lstrip("-").isdigit() and int(value) > 0
        }
        car_id = details.get("car_id")
        if stage in _CHECKPOINT_SUCCESS_STAGES and car_id is not None:
            try:
                car_id = int(car_id)
            except (TypeError, ValueError):
                car_id = 0
            if car_id > 0:
                completed.add(car_id)
        checkpoint.update({
            "completed_car_ids": sorted(completed),
            "completed_count": len(completed),
            "last_stage": str(stage or "working")[:80],
            "last_message": str(message or "")[:500],
            "last_extra": details,
            "last_event_at": now,
            "attempt_count": int(row.get("attempt_count") or 0),
        })
        if details.get("cleanup_started"):
            checkpoint["cleanup_started"] = True
        if details.get("public_complete"):
            checkpoint["public_complete"] = True
            checkpoint["public_completed_at"] = now
        try:
            countdown_deadline = float(details.get("countdown_deadline") or 0)
        except (TypeError, ValueError):
            countdown_deadline = 0
        if countdown_deadline > 0:
            checkpoint["countdown_deadline"] = countdown_deadline
        conn.execute(
            """
            UPDATE job_reservations
               SET checkpoint = %s, last_heartbeat = %s, updated_at = %s
             WHERE job_id = %s AND state = 'running'
            """,
            (_jsonb(checkpoint), now, now, job_id),
        )
    return checkpoint


def touch_job(job_id: str) -> None:
    now = time.time()
    with connection() as conn:
        conn.execute(
            """
            UPDATE job_reservations
               SET last_heartbeat = %s, updated_at = %s
             WHERE job_id = %s AND state = 'running'
            """,
            (now, now, job_id),
        )


def record_job_diagnostic(job_id: str, stage: str, message: str, details=None) -> None:
    """Persist internal-only car recovery details for the admin panel."""
    now = time.time()
    with connection() as conn:
        conn.execute(
            """
            INSERT INTO car_job_diagnostics
                (job_id,user_id,kind,stage,message,details,event_time)
            SELECT job_id,user_id,kind,%s,%s,%s,%s
              FROM job_reservations WHERE job_id=%s
            """,
            (str(stage or "working")[:80], str(message or "")[:2000],
             _jsonb(details if isinstance(details, dict) else {}), now, job_id),
        )


def recent_job_diagnostics(limit: int = 100) -> list[Dict[str, Any]]:
    with connection() as conn:
        rows = conn.execute(
            """SELECT d.*,u.email
                 FROM car_job_diagnostics d
                 LEFT JOIN site_users u ON u.user_id=d.user_id
                ORDER BY d.event_time DESC LIMIT %s""",
            (max(1, min(500, int(limit))),),
        ).fetchall()
    return [dict(row) for row in rows]


def mark_job_resumable(
    job_id: str,
    reason: str,
    *,
    failed_attempt: Optional[int] = None,
    delay_seconds: float = 5.0,
    keep_retrying: bool = False,
) -> Dict[str, Any]:
    """Requeue the same paid reservation, retaining credentials and checkpoint."""
    now = time.time()
    with connection() as conn, conn.transaction():
        row = conn.execute(
            """
            SELECT state, attempt_count, max_attempts, payload, checkpoint
              FROM job_reservations WHERE job_id = %s FOR UPDATE
            """,
            (job_id,),
        ).fetchone()
        if not row:
            return {"ok": False, "message": "Job reservation not found."}
        state = str(row["state"])
        attempt_count = int(row.get("attempt_count") or 0)
        max_attempts = int(row.get("max_attempts") or 1)
        if state in {"completed", "failed", "refunded"}:
            return {"ok": False, "terminal": True, "state": state}
        if failed_attempt is not None and int(failed_attempt) != attempt_count:
            return {"ok": True, "stale": True, "state": state, "attempt_count": attempt_count}
        if state == "resume_pending":
            return {"ok": True, "duplicate": True, "requeued": True, "state": state, "attempt_count": attempt_count}
        # Never extend a paid car job forever. Once its saved retry budget is
        # exhausted, close the customer-facing task, release the account lock,
        # and retain diagnostics/checkpoint data for admin review.
        if attempt_count >= max_attempts:
            conn.execute(
                """
                UPDATE job_reservations
                   SET state = 'manual_review', failure_message = %s,
                       last_heartbeat = %s, updated_at = %s
                 WHERE job_id = %s
                """,
                ((reason or "Worker recovery limit reached.")[:2000], now, now, job_id),
            )
            conn.execute("DELETE FROM injection_outbox WHERE job_id = %s", (job_id,))
            conn.execute("DELETE FROM injection_account_locks WHERE job_id = %s", (job_id,))
            return {
                "ok": True,
                "requeued": False,
                "manual_review": True,
                "state": "manual_review",
                "attempt_count": attempt_count,
                "max_attempts": max_attempts,
                "checkpoint": dict(row.get("checkpoint") or {}),
            }
        available_at = now + max(0.0, min(900.0, float(delay_seconds)))
        conn.execute(
            """
            UPDATE job_reservations
               SET state = 'resume_pending', failure_message = %s,
                   max_attempts = GREATEST(max_attempts, %s),
                   last_heartbeat = %s, updated_at = %s
             WHERE job_id = %s
            """,
            ((reason or "Worker stopped unexpectedly.")[:2000], max_attempts, now, now, job_id),
        )
        conn.execute(
            """
            INSERT INTO injection_outbox
                (job_id, payload, available_at, dispatched_at, attempts,
                 last_error, created_at, updated_at)
            VALUES (%s, %s, %s, NULL, 0, %s, %s, %s)
            ON CONFLICT (job_id) DO UPDATE SET
                payload = EXCLUDED.payload,
                available_at = EXCLUDED.available_at,
                dispatched_at = NULL,
                attempts = 0,
                last_error = EXCLUDED.last_error,
                updated_at = EXCLUDED.updated_at
            """,
            (job_id, _jsonb(row.get("payload") or {}), available_at, (reason or "")[:1000], now, now),
        )
    return {
        "ok": True,
        "requeued": True,
        "state": "resume_pending",
        "attempt_count": attempt_count,
        "next_attempt": attempt_count + 1,
        "max_attempts": max_attempts,
        "checkpoint": dict(row.get("checkpoint") or {}),
    }


def resume_job(job_id: str, reason: str = "administrator_resume") -> Dict[str, Any]:
    """Allow an administrator to continue a held paid job without charging again."""
    with connection() as conn, conn.transaction():
        row = conn.execute(
            "SELECT state, attempt_count, max_attempts FROM job_reservations WHERE job_id = %s FOR UPDATE",
            (job_id,),
        ).fetchone()
        if not row:
            return {"ok": False, "message": "Job reservation not found."}
        if row["state"] in {"completed", "failed", "refunded"}:
            return {"ok": False, "message": f"Job is already {row['state']}."}
        conn.execute(
            "UPDATE job_reservations SET max_attempts = GREATEST(max_attempts, attempt_count + 1) WHERE job_id = %s",
            (job_id,),
        )
    return mark_job_resumable(job_id, reason, delay_seconds=0)


def finish_job(job_id: str, state: str, *, failure_message: str = "") -> None:
    if state not in {"completed", "failed", "manual_review"}:
        raise ValueError(f"Invalid terminal reservation state: {state}")
    now = time.time()
    with connection() as conn, conn.transaction():
        if state == "manual_review":
            conn.execute(
                """
                UPDATE job_reservations
                   SET state = 'manual_review', updated_at = %s,
                       failure_message = %s
                 WHERE job_id = %s
                """,
                (now, (failure_message or "")[:2000], job_id),
            )
            conn.execute("DELETE FROM injection_outbox WHERE job_id = %s", (job_id,))
            conn.execute("DELETE FROM injection_account_locks WHERE job_id = %s", (job_id,))
            return
        conn.execute(
            """
            UPDATE job_reservations
               SET state = %s, completed_at = %s, updated_at = %s,
                   failure_message = %s, payload = '{}'::jsonb
             WHERE job_id = %s
            """,
            (state, now, now, (failure_message or "")[:2000], job_id),
        )
        conn.execute("DELETE FROM injection_outbox WHERE job_id = %s", (job_id,))
        conn.execute("DELETE FROM injection_account_locks WHERE job_id = %s", (job_id,))


def refund_job(job_id: str, reason: str) -> Dict[str, Any]:
    now = time.time()
    with connection() as conn, conn.transaction():
        reservation = conn.execute(
            "SELECT user_id, cost, state FROM job_reservations WHERE job_id = %s FOR UPDATE",
            (job_id,),
        ).fetchone()
        if not reservation:
            return {"ok": False, "message": "Job reservation not found."}
        if reservation["state"] == "refunded":
            user = conn.execute(
                "SELECT balance FROM site_users WHERE user_id = %s", (reservation["user_id"],)
            ).fetchone()
            return {"ok": True, "duplicate": True, "balance": int(user["balance"]) if user else 0}
        user = conn.execute(
            "SELECT balance FROM site_users WHERE user_id = %s FOR UPDATE", (reservation["user_id"],)
        ).fetchone()
        amount = int(reservation["cost"])
        after = int(user["balance"]) + amount
        if amount:
            conn.execute(
                "UPDATE site_users SET balance = %s, updated_at = %s WHERE user_id = %s",
                (after, now, reservation["user_id"]),
            )
            _ledger(
                conn,
                user_id=reservation["user_id"],
                entry_type="credit",
                amount=amount,
                reason=reason,
                balance_after=after,
                event_time=now,
                meta={"job_id": job_id, "refund": True},
                source_key=f"job-refund:{job_id}",
            )
        conn.execute(
            """
            UPDATE job_reservations
               SET state = 'refunded', refunded_at = %s, updated_at = %s,
                   failure_message = %s, payload = '{}'::jsonb
             WHERE job_id = %s
            """,
            (now, now, reason, job_id),
        )
        conn.execute("DELETE FROM injection_outbox WHERE job_id = %s", (job_id,))
        conn.execute("DELETE FROM injection_account_locks WHERE job_id = %s", (job_id,))
    return {"ok": True, "duplicate": False, "refunded": amount, "balance": after}


def expire_abandoned_clone_reservations(max_age_seconds: int = 1800) -> int:
    cutoff = time.time() - max(300, int(max_age_seconds))
    with connection() as conn:
        rows = conn.execute(
            """
            SELECT job_id FROM job_reservations
             WHERE state = 'awaiting_target' AND updated_at < %s
             LIMIT 100
            """,
            (cutoff,),
        ).fetchall()
    refunded = 0
    for row in rows:
        result = refund_job(row["job_id"], "expired_clone_reservation")
        refunded += int(bool(result.get("ok") and not result.get("duplicate")))
    return refunded


def load_settings(defaults: Dict[str, Any]) -> Dict[str, Any]:
    ensure_schema()
    with connection() as conn:
        rows = conn.execute("SELECT setting_key, setting_value FROM site_settings").fetchall()
    merged = dict(defaults)
    for row in rows:
        merged[row["setting_key"]] = row["setting_value"]
    return merged


def save_settings(settings: Dict[str, Any]) -> Dict[str, Any]:
    now = time.time()
    with connection() as conn, conn.transaction():
        for key, value in settings.items():
            conn.execute(
                """
                INSERT INTO site_settings (setting_key, setting_value, updated_at)
                VALUES (%s, %s, %s)
                ON CONFLICT (setting_key) DO UPDATE SET
                    setting_value = EXCLUDED.setting_value,
                    updated_at = EXCLUDED.updated_at
                """,
                (key, _jsonb(value), now),
            )
    return dict(settings)


def migrate_json_accounts(data: Dict[str, Any], *, replace_existing: bool = False) -> Dict[str, int]:
    """Idempotently import the legacy site_accounts.json structure."""
    users = data.get("users", {}) if isinstance(data, dict) else {}
    topups = data.get("stripe_topups", {}) if isinstance(data, dict) else {}
    inserted_users = inserted_ledger = inserted_topups = 0
    with connection() as conn, conn.transaction():
        conn.execute("SELECT pg_advisory_xact_lock(784611924)")
        for user_id, raw in users.items():
            user = raw if isinstance(raw, dict) else {}
            params = (
                str(user.get("user_id") or user_id),
                str(user.get("email") or "").strip().lower(),
                str(user.get("password_hash") or ""),
                max(0, int(user.get("balance") or 0)),
                float(user.get("created_at") or time.time()),
                float(user.get("updated_at") or user.get("created_at") or time.time()),
            )
            if not params[1] or not params[2]:
                continue
            if replace_existing:
                row = conn.execute(
                    """
                    INSERT INTO site_users
                        (user_id, email, password_hash, balance, created_at, updated_at)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    ON CONFLICT (user_id) DO UPDATE SET
                        email = EXCLUDED.email,
                        password_hash = EXCLUDED.password_hash,
                        balance = EXCLUDED.balance,
                        created_at = EXCLUDED.created_at,
                        updated_at = EXCLUDED.updated_at
                    RETURNING user_id
                    """,
                    params,
                ).fetchone()
            else:
                row = conn.execute(
                    """
                    INSERT INTO site_users
                        (user_id, email, password_hash, balance, created_at, updated_at)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    ON CONFLICT DO NOTHING
                    RETURNING user_id
                    """,
                    params,
                ).fetchone()
            inserted_users += int(bool(row))
            for index, entry in enumerate(user.get("ledger", [])):
                if not isinstance(entry, dict):
                    continue
                source = "legacy:" + hashlib.sha256(
                    f"{user_id}:{index}:{json.dumps(entry, sort_keys=True)}".encode("utf-8")
                ).hexdigest()
                before = conn.execute("SELECT 1 FROM credit_ledger WHERE source_key = %s", (source,)).fetchone()
                if before:
                    continue
                _ledger(
                    conn,
                    user_id=str(user.get("user_id") or user_id),
                    entry_type=str(entry.get("type") or "legacy"),
                    amount=int(entry.get("amount") or 0),
                    previous_balance=entry.get("previous_balance"),
                    target_balance=entry.get("target_balance"),
                    reason=str(entry.get("reason") or "legacy_import"),
                    balance_after=int(entry.get("balance_after") or 0),
                    event_time=float(entry.get("time") or time.time()),
                    meta=entry.get("meta") if isinstance(entry.get("meta"), dict) else {},
                    source_key=source,
                )
                inserted_ledger += 1
        for session_id, raw in topups.items():
            if not isinstance(raw, dict) or not raw.get("user_id"):
                continue
            row = conn.execute(
                """
                INSERT INTO stripe_topups
                    (session_id, event_id, user_id, pack_id, credits, amount_cents,
                     currency, fulfilled_at, balance_after)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (session_id) DO NOTHING
                RETURNING session_id
                """,
                (
                    session_id,
                    str(raw.get("event_id") or "legacy"),
                    str(raw["user_id"]),
                    str(raw.get("pack_id") or "legacy"),
                    int(raw.get("credits") or 0),
                    int(raw.get("amount_cents") or 0),
                    str(raw.get("currency") or "usd"),
                    float(raw.get("fulfilled_at") or time.time()),
                    int(raw.get("balance_after") or 0),
                ),
            ).fetchone()
            inserted_topups += int(bool(row))
    with connection() as conn:
        totals = conn.execute(
            """
            SELECT COUNT(*)::bigint AS users, COALESCE(SUM(balance), 0)::bigint AS credits
              FROM site_users
            """
        ).fetchone()
        stripe_count = conn.execute("SELECT COUNT(*)::bigint AS n FROM stripe_topups").fetchone()["n"]
    return {
        "inserted_users": inserted_users,
        "inserted_ledger_entries": inserted_ledger,
        "inserted_stripe_topups": inserted_topups,
        "database_users": int(totals["users"]),
        "database_credits": int(totals["credits"]),
        "database_stripe_topups": int(stripe_count),
    }
