"""Plan varied public-design collections for admin-generated CPM accounts."""

from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
import hashlib
import random
from typing import Any, Dict, Iterable, List

import catalog_repository
import design_marketplace
from car_bulk_injector import CarBlueprint, _blueprints_from_payload

DEFAULT_TARGET_CAR_COUNT = 100


class CollectionPoolError(ValueError):
    """Raised when public sources cannot produce the requested distinct collection."""


def _one_blueprint_payload(blueprint: CarBlueprint) -> Dict[str, Any]:
    """Preserve the source slot while constraining a candidate to one CarID."""
    return {"cars": [asdict(blueprint)]}


def _select_blueprint(payload: Any, car_id: int) -> CarBlueprint | None:
    try:
        expected = int(car_id)
    except (TypeError, ValueError):
        return None
    for blueprint in _blueprints_from_payload(payload):
        if int(blueprint.car_id or 0) == expected:
            return blueprint
    return None


def _candidate(*, source_key: str, source_kind: str, car_id: int, payload: Dict[str, Any], title: str = "") -> Dict[str, Any]:
    return {
        "source_key": str(source_key),
        "source_kind": str(source_kind),
        "title": str(title or "")[:160],
        "car_id": int(car_id),
        "payload": deepcopy(payload),
    }


def verified_public_pool() -> Dict[int, List[Dict[str, Any]]]:
    """Return active public designs grouped by CarID, excluding malformed entries.

    The static catalog is treated as a verified public source. Marketplace
    candidates use only active public listings and retain their full payloads.
    """
    grouped: Dict[int, List[Dict[str, Any]]] = {}

    for catalog_car in catalog_repository.get_catalog_cars(include_hidden=False):
        car_id = int(catalog_car.get("car_id") or 0)
        payload = catalog_repository.load_catalog_payload(str(catalog_car.get("slug") or ""))
        blueprint = _select_blueprint(payload, car_id) if payload else None
        if blueprint is None:
            continue
        grouped.setdefault(car_id, []).append(_candidate(
            source_key=f"catalog:{catalog_car.get('slug')}",
            source_kind="catalog",
            car_id=car_id,
            payload=_one_blueprint_payload(blueprint),
            title=str(catalog_car.get("name") or catalog_car.get("slug") or "Catalog design"),
        ))

    for listing in design_marketplace.list_active_public_payloads(limit=2000):
        car_id = int(listing.get("car_id") or 0)
        payload = listing.get("payload")
        blueprint = _select_blueprint(payload, car_id) if isinstance(payload, dict) else None
        if blueprint is None:
            continue
        grouped.setdefault(car_id, []).append(_candidate(
            source_key=f"market:{listing.get('design_id')}",
            source_kind="marketplace",
            car_id=car_id,
            payload=_one_blueprint_payload(blueprint),
            title=str(listing.get("title") or listing.get("share_code") or "Public design"),
        ))

    # Stable ordering makes a persisted batch snapshot deterministic and auditable.
    for candidates in grouped.values():
        candidates.sort(key=lambda item: (item["source_kind"], item["source_key"]))
    return dict(sorted(grouped.items()))


def pool_summary(pool: Dict[int, List[Dict[str, Any]]]) -> Dict[str, int]:
    candidates = [candidate for choices in pool.values() for candidate in choices]
    return {
        "distinct_car_ids": len(pool),
        "design_candidates": len(candidates),
        "catalog_candidates": sum(1 for item in candidates if item["source_kind"] == "catalog"),
        "marketplace_candidates": sum(1 for item in candidates if item["source_kind"] == "marketplace"),
    }


def require_capacity(pool: Dict[int, List[Dict[str, Any]]], target_count: int = DEFAULT_TARGET_CAR_COUNT) -> None:
    target_count = max(1, int(target_count))
    if len(pool) < target_count:
        summary = pool_summary(pool)
        raise CollectionPoolError(
            f"Only {summary['distinct_car_ids']} distinct eligible CarIDs are available; "
            f"{target_count} are required for a king collection."
        )


def _seed(batch_id: str, account_index: int) -> int:
    digest = hashlib.sha256(f"{batch_id}:{int(account_index)}:king-collection-v1".encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big")


def make_collection_plan(
    pool: Dict[int, List[Dict[str, Any]]],
    *,
    batch_id: str,
    account_index: int,
    target_count: int = DEFAULT_TARGET_CAR_COUNT,
) -> List[Dict[str, Any]]:
    """Select one candidate per unique CarID with deterministic per-account variety."""
    require_capacity(pool, target_count)
    rng = random.Random(_seed(batch_id, account_index))
    selected_ids = rng.sample(sorted(pool), int(target_count))
    plan: List[Dict[str, Any]] = []
    for car_id in selected_ids:
        choices = pool[car_id]
        # Multiple popular designs for one CarID are deliberately varied per account.
        plan.append(deepcopy(choices[rng.randrange(len(choices))]))
    return plan


def collection_payload(plan: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    """Combine one already-validated payload per CarID for the shared injector."""
    cars: List[Dict[str, Any]] = []
    seen: set[int] = set()
    for item in plan:
        try:
            car_id = int(item.get("car_id") or 0)
        except (AttributeError, TypeError, ValueError):
            continue
        if car_id <= 0 or car_id in seen:
            continue
        payload = item.get("payload") if isinstance(item, dict) else None
        source_cars = payload.get("cars") if isinstance(payload, dict) else None
        if not isinstance(source_cars, list) or len(source_cars) != 1 or not isinstance(source_cars[0], dict):
            continue
        seen.add(car_id)
        cars.append(deepcopy(source_cars[0]))
    return {"cars": cars}


def plan_summary(plan: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    rows = list(plan)
    return {
        "target_count": len(rows),
        "distinct_car_ids": len({int(item.get("car_id") or 0) for item in rows if isinstance(item, dict)} - {0}),
        "catalog_designs": sum(1 for item in rows if item.get("source_kind") == "catalog"),
        "marketplace_designs": sum(1 for item in rows if item.get("source_kind") == "marketplace"),
        "car_ids": [int(item.get("car_id") or 0) for item in rows if isinstance(item, dict)],
    }
