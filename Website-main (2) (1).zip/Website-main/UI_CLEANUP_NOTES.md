# CPM1 Webtool UI Cleanup Notes

This update keeps the existing dark premium frontend scheme and preserves the existing modifier functionality.

## Changes made

- Removed the large warning block from the login page.
- Removed the dashboard warning/info block about logging out before running actions.
- Removed visible Malik/source-code wording from the dashboard UI.
- Replaced the footer messaging with neutral webtool branding.
- Added an in-page confirmation popup after successful login. The user must confirm they have logged out of the game account before the dashboard is usable.
- Tightened page width, overflow, and large-screen spacing rules to reduce extra empty space when fully zoomed out.

## Functionality preservation

- Existing forms, buttons, modifier controls, and action routes were preserved.
- Existing modifier/game logic files were not changed.
- A small session route (`/confirm-logout`) was added only to support the requested in-page confirmation popup.

## Local run

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

On Windows:

```bat
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Then open `http://127.0.0.1:8080`.
