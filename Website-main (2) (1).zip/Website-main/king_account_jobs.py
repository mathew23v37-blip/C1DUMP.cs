"""Durable admin batches for varied 100-car king-account generation."""

from __future__ import annotations

import os
import re
import secrets
import time
import uuid
from typing import Any, Dict, Optional

from postgres_db import connection
from king_collection_planner import (
    DEFAULT_TARGET_CAR_COUNT,
    CollectionPoolError,
    collection_payload,
    make_collection_plan,
    plan_summary,
    pool_summary,
    require_capacity,
    verified_public_pool,
)

EMAIL_DOMAIN = os.getenv("KING_ACCOUNT_EMAIL_DOMAIN", "proton.me").strip() or "proton.me"
MAX_ACCOUNTS_PER_BATCH = max(1, min(250, int(os.getenv("KING_ACCOUNT_MAX_BATCH", "100"))))
MAX_ATTEMPTS = max(1, min(10, int(os.getenv("KING_ACCOUNT_MAX_ATTEMPTS", "4"))))
MAX_TARGET_CARS = max(1, min(2000, int(os.getenv("KING_ACCOUNT_MAX_TARGET_CARS", "2000"))))
MAX_CONCURRENCY = max(1, min(32, int(os.getenv("KING_ACCOUNT_MAX_CONCURRENCY", os.getenv("RQ_WORKER_PROCESSES", "4")))))
PREFIX_RE = re.compile(r"^[a-z0-9](?:[a-z0-9._-]{0,30}[a-z0-9])?$")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS king_account_batches (
    batch_id TEXT PRIMARY KEY,
    email_prefix TEXT NOT NULL,
    total_accounts INTEGER NOT NULL,
    target_cars INTEGER NOT NULL DEFAULT 100,
    state TEXT NOT NULL DEFAULT 'queued',
    pool_summary JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at DOUBLE PRECISION NOT NULL,
    updated_at DOUBLE PRECISION NOT NULL,
    started_at DOUBLE PRECISION,
    completed_at DOUBLE PRECISION,
    last_message TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_king_account_batches_state_time
    ON king_account_batches (state, created_at DESC);

CREATE TABLE IF NOT EXISTS king_account_items (
    batch_id TEXT NOT NULL REFERENCES king_account_batches(batch_id) ON DELETE CASCADE,
    account_index INTEGER NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    state TEXT NOT NULL DEFAULT 'queued',
    stage TEXT NOT NULL DEFAULT 'waiting',
    last_message TEXT NOT NULL DEFAULT 'Waiting for the single generator lane.',
    car_amount INTEGER NOT NULL DEFAULT 0,
    attempt_count INTEGER NOT NULL DEFAULT 0,
    max_attempts INTEGER NOT NULL DEFAULT 4,
    collection_plan JSONB NOT NULL DEFAULT '[]'::jsonb,
    checkpoint JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at DOUBLE PRECISION NOT NULL,
    updated_at DOUBLE PRECISION NOT NULL,
    started_at DOUBLE PRECISION,
    completed_at DOUBLE PRECISION,
    last_heartbeat DOUBLE PRECISION,
    PRIMARY KEY (batch_id, account_index)
);
CREATE INDEX IF NOT EXISTS idx_king_account_items_retry
    ON king_account_items (batch_id, state, attempt_count DESC, car_amount DESC, account_index);

CREATE TABLE IF NOT EXISTS king_account_events (
    id BIGSERIAL PRIMARY KEY,
    batch_id TEXT NOT NULL REFERENCES king_account_batches(batch_id) ON DELETE CASCADE,
    account_index INTEGER,
    stage TEXT NOT NULL,
    message TEXT NOT NULL,
    event_time DOUBLE PRECISION NOT NULL,
    meta JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS idx_king_account_events_batch
    ON king_account_events (batch_id, id DESC);

CREATE TABLE IF NOT EXISTS king_account_outbox (
    batch_id TEXT NOT NULL,
    account_index INTEGER NOT NULL,
    available_at DOUBLE PRECISION NOT NULL,
    dispatched_at DOUBLE PRECISION,
    attempts INTEGER NOT NULL DEFAULT 0,
    last_error TEXT,
    created_at DOUBLE PRECISION NOT NULL,
    updated_at DOUBLE PRECISION NOT NULL,
    PRIMARY KEY (batch_id, account_index),
    FOREIGN KEY (batch_id, account_index)
        REFERENCES king_account_items(batch_id, account_index) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_king_account_outbox_pending
    ON king_account_outbox (available_at, created_at)
    WHERE dispatched_at IS NULL;
    """

# Existing deployments need this additive migration when the table already exists.
_SCHEMA_MIGRATIONS = """
ALTER TABLE king_account_batches ADD COLUMN IF NOT EXISTS max_concurrency INTEGER NOT NULL DEFAULT 4;
"""


def _jsonb(value: Any):
    from psycopg.types.json import Jsonb
    return Jsonb(value if isinstance(value, (dict, list)) else {})


def configured() -> bool:
    return bool(os.getenv("DATABASE_URL", "").strip() and os.getenv("REDIS_URL", "").strip())


def ensure_schema() -> None:
    with connection() as conn:
        conn.execute(_SCHEMA)
        conn.execute(_SCHEMA_MIGRATIONS)


def _event(conn, batch_id: str, account_index: Optional[int], stage: str, message: str, meta: Optional[dict] = None) -> int:
    row = conn.execute("""INSERT INTO king_account_events
        (batch_id,account_index,stage,message,event_time,meta)
        VALUES (%s,%s,%s,%s,%s,%s) RETURNING id""", (
        batch_id, account_index, str(stage or "working")[:80], str(message or "")[:2000],
        time.time(), _jsonb(meta or {}),
    )).fetchone()
    return int(row["id"])


def _password() -> str:
    # An account-generator password is independent from any admin/site password.
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"
    return "".join(secrets.choice(alphabet) for _ in range(14))


def _email(prefix: str, batch_id: str, account_index: int) -> str:
    return f"{prefix}{batch_id[:6]}{int(account_index):03d}@{EMAIL_DOMAIN}"


def create_batch(*, email_prefix: str, account_count: Any, target_cars: Any = DEFAULT_TARGET_CAR_COUNT, password: Any = "", max_concurrency: Any = MAX_CONCURRENCY) -> Dict[str, Any]:
    """Snapshot the verified public pool and atomically queue a selected batch size."""
    if not configured():
        return {"ok": False, "message": "Database and Redis must be configured before starting the generator."}
    prefix = str(email_prefix or "").strip().lower()
    if not PREFIX_RE.fullmatch(prefix):
        return {"ok": False, "message": "Use 1–32 lowercase letters, numbers, dots, dashes, or underscores for the email prefix."}
    try:
        total = int(account_count)
    except (TypeError, ValueError):
        return {"ok": False, "message": "Enter a whole-number account count."}
    if not 1 <= total <= MAX_ACCOUNTS_PER_BATCH:
        return {"ok": False, "message": f"Account count must be between 1 and {MAX_ACCOUNTS_PER_BATCH}."}
    try:
        target = int(target_cars)
    except (TypeError, ValueError):
        return {"ok": False, "message": "Enter a whole-number unique CarID target for each account."}
    if not 1 <= target <= MAX_TARGET_CARS:
        return {"ok": False, "message": f"Unique CarIDs per account must be between 1 and {MAX_TARGET_CARS}."}
    account_password = str(password or "")
    if len(account_password) < 8 or len(account_password) > 128:
        return {"ok": False, "message": "The generated-account password must be 8–128 characters."}
    if account_password != account_password.strip():
        return {"ok": False, "message": "The generated-account password cannot start or end with whitespace."}
    try:
        concurrency = int(max_concurrency)
    except (TypeError, ValueError):
        return {"ok": False, "message": "Enter a whole-number maximum concurrency."}
    if not 1 <= concurrency <= MAX_CONCURRENCY:
        return {"ok": False, "message": f"Maximum concurrency must be between 1 and {MAX_CONCURRENCY}."}

    try:
        pool = verified_public_pool()
        require_capacity(pool, target)
    except CollectionPoolError as exc:
        return {"ok": False, "message": str(exc), "pool": pool_summary(pool) if 'pool' in locals() else {}}
    except Exception as exc:
        return {"ok": False, "message": f"Unable to load the verified public design pool: {exc}"}

    now = time.time()
    batch_id = uuid.uuid4().hex
    plans = [make_collection_plan(pool, batch_id=batch_id, account_index=index, target_count=target)
             for index in range(1, total + 1)]
    emails = [_email(prefix, batch_id, index) for index in range(1, total + 1)]
    summary = {
        **pool_summary(pool),
        "target_cars": target,
        "max_concurrency": concurrency,
        "password_configured": True,
    }

    ensure_schema()
    with connection() as conn, conn.transaction():
        existing = conn.execute("""SELECT batch_id FROM king_account_batches
            WHERE state IN ('queued','running') ORDER BY created_at DESC LIMIT 1 FOR UPDATE""").fetchone()
        if existing:
            return {"ok": False, "message": "A king-account batch is already active. Complete or cancel it before starting another.", "batch_id": existing["batch_id"]}
        conflict = conn.execute("SELECT email FROM king_account_items WHERE email = ANY(%s) LIMIT 1", (emails,)).fetchone()
        if conflict:
            return {"ok": False, "message": f"Generated email already exists ({conflict['email']}); use a different prefix."}
        conn.execute("""INSERT INTO king_account_batches
            (batch_id,email_prefix,total_accounts,target_cars,max_concurrency,state,pool_summary,created_at,updated_at,last_message)
            VALUES (%s,%s,%s,%s,%s,'queued',%s,%s,%s,%s)""", (
            batch_id, prefix, total, target, concurrency, _jsonb(summary), now, now,
            f"Queued {total} king-account target(s) with {target} unique CarIDs each at maximum concurrency {concurrency}.",
        ))
        for index, plan in enumerate(plans, start=1):
            item_summary = plan_summary(plan)
            conn.execute("""INSERT INTO king_account_items
                (batch_id,account_index,email,password,state,stage,last_message,car_amount,attempt_count,max_attempts,
                 collection_plan,checkpoint,created_at,updated_at)
                VALUES (%s,%s,%s,%s,'queued','waiting','Waiting for the single generator lane.',0,0,%s,%s,%s,%s,%s)""", (
                batch_id, index, emails[index - 1], account_password, MAX_ATTEMPTS,
                _jsonb(plan), _jsonb({"plan_summary": item_summary}), now, now,
            ))
            conn.execute("""INSERT INTO king_account_outbox
                (batch_id,account_index,available_at,created_at,updated_at)
                VALUES (%s,%s,%s,%s,%s)""", (
                batch_id, index, now, now, now,
            ))
        _event(conn, batch_id, None, "queued", f"King-account batch queued with {target} unique CarIDs per account at maximum concurrency {concurrency}.", summary)
    return {"ok": True, "batch_id": batch_id, "total_accounts": total, "pool": summary}


def claim_next_outbox() -> Optional[Dict[str, Any]]:
    """Claim only one account at a time; retries prefer the most complete account."""
    ensure_schema()
    now = time.time()
    with connection() as conn, conn.transaction():
        row = conn.execute("""SELECT o.batch_id,o.account_index,o.attempts,i.attempt_count,i.car_amount
            FROM king_account_outbox o JOIN king_account_items i
              ON i.batch_id=o.batch_id AND i.account_index=o.account_index
            JOIN king_account_batches b ON b.batch_id=o.batch_id
            WHERE o.dispatched_at IS NULL AND o.available_at<=%s
              AND b.state IN ('queued','running') AND i.state='queued'
              AND (SELECT count(*) FROM king_account_outbox po
                   JOIN king_account_items pi ON pi.batch_id=po.batch_id AND pi.account_index=po.account_index
                   WHERE po.batch_id=o.batch_id AND po.dispatched_at IS NOT NULL
                     AND pi.state IN ('queued','running')) < b.max_concurrency
            ORDER BY (i.attempt_count>0) DESC,i.car_amount DESC,o.available_at ASC,i.account_index ASC
            LIMIT 1 FOR UPDATE SKIP LOCKED""", (now,)).fetchone()
        if not row:
            return None
        conn.execute("UPDATE king_account_outbox SET dispatched_at=%s,attempts=attempts+1,updated_at=%s WHERE batch_id=%s AND account_index=%s", (now, now, row["batch_id"], row["account_index"]))
        conn.execute("UPDATE king_account_batches SET state='running',started_at=COALESCE(started_at,%s),updated_at=%s WHERE batch_id=%s", (now, now, row["batch_id"]))
        return dict(row)


def mark_outbox_error(batch_id: str, account_index: int, error: str) -> None:
    now = time.time()
    with connection() as conn:
        conn.execute("UPDATE king_account_outbox SET dispatched_at=NULL,last_error=%s,updated_at=%s WHERE batch_id=%s AND account_index=%s", (str(error)[:1000], now, batch_id, int(account_index)))


def start_item(batch_id: str, account_index: int) -> Dict[str, Any]:
    now = time.time()
    with connection() as conn, conn.transaction():
        row = conn.execute("SELECT * FROM king_account_items WHERE batch_id=%s AND account_index=%s FOR UPDATE", (batch_id, int(account_index))).fetchone()
        if not row:
            raise RuntimeError("King-account item was not found.")
        item = dict(row)
        if item["state"] == "complete":
            return {**item, "already_complete": True}
        if item["state"] == "cancelled":
            return {**item, "cancelled": True}
        if item["state"] == "force_stopped":
            return {**item, "cancelled": True, "force_stopped": True}
        batch = conn.execute("SELECT max_concurrency,state FROM king_account_batches WHERE batch_id=%s FOR UPDATE", (batch_id,)).fetchone()
        if not batch or batch.get("state") in {"cancelled", "force_stopped"}:
            return {**item, "cancelled": True, "force_stopped": bool(batch and batch.get("state") == "force_stopped")}
        concurrency = max(1, int(batch.get("max_concurrency") or MAX_CONCURRENCY))
        running = conn.execute("""SELECT count(*) AS count FROM king_account_items
            WHERE batch_id=%s AND state='running'""", (batch_id,)).fetchone()
        if int((running or {}).get("count") or 0) >= concurrency:
            retry_at = now + 1.0
            conn.execute("""UPDATE king_account_outbox SET dispatched_at=NULL,available_at=%s,updated_at=%s
                WHERE batch_id=%s AND account_index=%s""", (retry_at, now, batch_id, int(account_index)))
            return {**item, "deferred": True, "next_allowed_at": retry_at, "reason": "maximum concurrency reached"}
        attempt = int(item.get("attempt_count") or 0) + 1
        conn.execute("""UPDATE king_account_items SET state='running',stage='starting',attempt_count=%s,
            started_at=COALESCE(started_at,%s),last_heartbeat=%s,updated_at=%s,last_message=%s
            WHERE batch_id=%s AND account_index=%s""", (attempt, now, now, now, "Starting king-account build.", batch_id, int(account_index)))
        _event(conn, batch_id, int(account_index), "starting", f"Starting account {account_index}; attempt {attempt}.", {"attempt": attempt})
        item.update(state="running", attempt_count=attempt)
        return item


def get_item(batch_id: str, account_index: int) -> Optional[Dict[str, Any]]:
    ensure_schema()
    with connection() as conn:
        row = conn.execute("SELECT * FROM king_account_items WHERE batch_id=%s AND account_index=%s", (batch_id, int(account_index))).fetchone()
    return dict(row) if row else None


def record_progress(batch_id: str, account_index: int, stage: str, message: str, extra: Optional[dict] = None) -> None:
    now = time.time()
    extra = extra if isinstance(extra, dict) else {}
    with connection() as conn, conn.transaction():
        row = conn.execute("""SELECT i.checkpoint,i.car_amount,b.state AS batch_state
            FROM king_account_items i JOIN king_account_batches b ON b.batch_id=i.batch_id
            WHERE i.batch_id=%s AND i.account_index=%s FOR UPDATE""", (batch_id, int(account_index))).fetchone()
        if not row or row.get("batch_state") in {"cancelled", "force_stopped"}:
            return
        checkpoint = dict(row.get("checkpoint") or {})
        checkpoint["last_stage"] = str(stage)
        checkpoint["last_extra"] = extra
        completed = extra.get("completed_count")
        if completed is not None:
            try:
                checkpoint["completed_count"] = max(int(checkpoint.get("completed_count") or 0), int(completed))
            except (TypeError, ValueError):
                pass
        car_amount = int(row.get("car_amount") or 0)
        for key in ("verified_car_count", "completed_count", "injected"):
            try:
                car_amount = max(car_amount, int(extra.get(key) or 0))
            except (TypeError, ValueError):
                pass
        conn.execute("""UPDATE king_account_items SET stage=%s,last_message=%s,checkpoint=%s,car_amount=%s,
            last_heartbeat=%s,updated_at=%s WHERE batch_id=%s AND account_index=%s""", (str(stage)[:80], str(message)[:2000], _jsonb(checkpoint), car_amount, now, now, batch_id, int(account_index)))
        _event(conn, batch_id, int(account_index), stage, message, extra)


def finish_item(batch_id: str, account_index: int, car_amount: int, message: str) -> None:
    now = time.time()
    with connection() as conn, conn.transaction():
        batch = conn.execute("SELECT state FROM king_account_batches WHERE batch_id=%s FOR UPDATE", (batch_id,)).fetchone()
        if not batch or batch.get("state") in {"cancelled", "force_stopped"}:
            return
        conn.execute("""UPDATE king_account_items SET state='complete',stage='complete',car_amount=%s,last_message=%s,
            completed_at=%s,updated_at=%s WHERE batch_id=%s AND account_index=%s""", (max(0, int(car_amount)), str(message)[:2000], now, now, batch_id, int(account_index)))
        conn.execute("DELETE FROM king_account_outbox WHERE batch_id=%s AND account_index=%s", (batch_id, int(account_index)))
        _event(conn, batch_id, int(account_index), "complete", message, {"car_amount": int(car_amount)})
        _refresh_batch(conn, batch_id)


def fail_or_retry_item(batch_id: str, account_index: int, reason: str, car_amount: int = 0) -> Dict[str, Any]:
    now = time.time()
    with connection() as conn, conn.transaction():
        batch = conn.execute("SELECT state FROM king_account_batches WHERE batch_id=%s FOR UPDATE", (batch_id,)).fetchone()
        if not batch:
            return {"state": "missing"}
        if batch.get("state") in {"cancelled", "force_stopped"}:
            return {"state": batch.get("state"), "requeued": False}
        row = conn.execute("SELECT attempt_count,max_attempts,car_amount FROM king_account_items WHERE batch_id=%s AND account_index=%s FOR UPDATE", (batch_id, int(account_index))).fetchone()
        if not row:
            return {"state": "missing"}
        attempts = int(row["attempt_count"] or 0)
        best_count = max(int(row["car_amount"] or 0), max(0, int(car_amount)))
        if attempts < int(row["max_attempts"] or MAX_ATTEMPTS):
            cooldown = min(300.0, 15.0 * (2 ** max(0, attempts - 1)))
            conn.execute("""UPDATE king_account_items SET state='queued',stage='retry_pending',car_amount=%s,last_message=%s,
                updated_at=%s WHERE batch_id=%s AND account_index=%s""", (best_count, str(reason)[:2000], now, batch_id, int(account_index)))
            conn.execute("""INSERT INTO king_account_outbox (batch_id,account_index,available_at,created_at,updated_at)
                VALUES (%s,%s,%s,%s,%s)
                ON CONFLICT (batch_id,account_index) DO UPDATE SET dispatched_at=NULL,available_at=EXCLUDED.available_at,
                    updated_at=EXCLUDED.updated_at,last_error=EXCLUDED.last_error""", (batch_id, int(account_index), now + cooldown, now, now))
            _event(conn, batch_id, int(account_index), "retry_pending", f"Retry queued after: {reason}", {"attempt": attempts, "car_amount": best_count, "cooldown": cooldown})
            _refresh_batch(conn, batch_id)
            return {"state": "queued", "requeued": True, "car_amount": best_count}
        conn.execute("""UPDATE king_account_items SET state='failed',stage='failed',car_amount=%s,last_message=%s,
            completed_at=%s,updated_at=%s WHERE batch_id=%s AND account_index=%s""", (best_count, str(reason)[:2000], now, now, batch_id, int(account_index)))
        conn.execute("DELETE FROM king_account_outbox WHERE batch_id=%s AND account_index=%s", (batch_id, int(account_index)))
        _event(conn, batch_id, int(account_index), "failed", reason, {"attempt": attempts, "car_amount": best_count})
        _refresh_batch(conn, batch_id)
        return {"state": "failed", "requeued": False, "car_amount": best_count}


def _refresh_batch(conn, batch_id: str) -> None:
    row = conn.execute("""SELECT count(*) FILTER (WHERE state='complete') AS complete,
        count(*) FILTER (WHERE state='failed') AS failed,count(*) FILTER (WHERE state IN ('queued','running')) AS active,
        count(*) AS total FROM king_account_items WHERE batch_id=%s""", (batch_id,)).fetchone()
    now = time.time()
    state = "running" if int(row["active"] or 0) else "complete"
    message = f"{int(row['complete'] or 0)}/{int(row['total'] or 0)} complete; {int(row['failed'] or 0)} failed."
    conn.execute("UPDATE king_account_batches SET state=%s,last_message=%s,updated_at=%s,completed_at=CASE WHEN %s='complete' THEN %s ELSE completed_at END WHERE batch_id=%s", (state, message, now, state, now, batch_id))


def get_batch(batch_id: str) -> Optional[Dict[str, Any]]:
    ensure_schema()
    with connection() as conn:
        batch = conn.execute("SELECT * FROM king_account_batches WHERE batch_id=%s", (batch_id,)).fetchone()
        if not batch:
            return None
        items = conn.execute("SELECT * FROM king_account_items WHERE batch_id=%s ORDER BY account_index", (batch_id,)).fetchall()
        events = conn.execute("SELECT * FROM king_account_events WHERE batch_id=%s ORDER BY id DESC LIMIT 200", (batch_id,)).fetchall()
    result = dict(batch)
    result["items"] = [dict(row) for row in items]
    result["events"] = [dict(row) for row in reversed(events)]
    return result


def cancel_batch(batch_id: str) -> Dict[str, Any]:
    now = time.time()
    with connection() as conn, conn.transaction():
        row = conn.execute("SELECT state FROM king_account_batches WHERE batch_id=%s FOR UPDATE", (batch_id,)).fetchone()
        if not row:
            return {"ok": False, "message": "Batch not found."}
        conn.execute("UPDATE king_account_batches SET state='cancelled',last_message='Cancelled by administrator.',updated_at=%s,completed_at=%s WHERE batch_id=%s", (now, now, batch_id))
        conn.execute("UPDATE king_account_items SET state='cancelled',stage='cancelled',last_message='Cancelled by administrator.',updated_at=%s,completed_at=%s WHERE batch_id=%s AND state='queued'", (now, now, batch_id))
        conn.execute("DELETE FROM king_account_outbox WHERE batch_id=%s", (batch_id,))
        _event(conn, batch_id, None, "cancelled", "Batch cancelled by administrator.")
    return {"ok": True, "message": "Batch cancelled."}


def force_stop_batch(batch_id: str) -> Dict[str, Any]:
    """Immediately invalidate a batch; late worker results cannot complete or retry it."""
    now = time.time()
    with connection() as conn, conn.transaction():
        row = conn.execute("SELECT state FROM king_account_batches WHERE batch_id=%s FOR UPDATE", (batch_id,)).fetchone()
        if not row:
            return {"ok": False, "message": "Batch not found."}
        if row.get("state") == "force_stopped":
            return {"ok": True, "message": "Batch was already force-stopped."}
        conn.execute("""UPDATE king_account_batches SET state='force_stopped',
            last_message='Force-stopped by administrator.',updated_at=%s,completed_at=%s WHERE batch_id=%s""", (now, now, batch_id))
        conn.execute("""UPDATE king_account_items SET state='force_stopped',stage='force_stopped',
            last_message='Force-stopped by administrator.',updated_at=%s,completed_at=COALESCE(completed_at,%s)
            WHERE batch_id=%s AND state IN ('queued','running','retry_pending')""", (now, now, batch_id))
        conn.execute("DELETE FROM king_account_outbox WHERE batch_id=%s", (batch_id,))
        _event(conn, batch_id, None, "force_stopped", "Batch force-stopped by administrator; queued work was released and late results will be ignored.")
    return {"ok": True, "message": "Batch force-stopped. You can start a new batch now."}
