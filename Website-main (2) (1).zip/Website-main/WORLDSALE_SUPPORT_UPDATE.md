# World Sale and Support Update

This bundle adds categorized support operations and World Sale report handling.

## Admin support queues

Open the admin panel’s **Support Desk**. Tickets are separated into **Free Support**, **Paid Support**, and **World Sale Support**. Paid Support means the account has at least one fulfilled Stripe top-up. Users now select a support area when opening a ticket.

## World Sale reports

Open **World Sale Support — listings, reports & moderation**. The page shows total/open reports, refunded reports, refunded credits, auto-disabled listings, report counts per listing, reporter details, and refund status. Staff can resolve or dismiss reports and can temporarily disable, restore, or permanently remove listings.

A listing is automatically set to `hidden` after more than five unique user reports. The threshold can be changed with `SHARED_DESIGN_REPORT_AUTO_DISABLE_THRESHOLD`; the default is `5`.

## Automatic report refunds

When a signed-in user reports a listing, the system finds that user’s paid ledger purchases for the specific listing and credits the total back once. The refund is recorded with a unique report/refund row and ledger source key, so refreshes or repeated submissions cannot double-credit. The user receives an Inbox confirmation when credits were refunded.

## Cars page and catalog ordering

The Cars page is ordered top to bottom as **Verified Cars Injection Catalog**, **Public Sale Cars Injection Catalog**, **Event Cars Injections**, and **Premium Cars Injections**. Recovery, unlock, and free-service links remain below those four primary catalog sections.

The public catalog now tells users to open the individual listing and use **Report Design** rather than opening a general support ticket. World Sale reports continue to route to the World Sale Support queue, with automatic site-credit refunds and Inbox confirmations for eligible purchases.

## Promoting public-sale designs to Verified

In the `/backlog` admin panel, open the **Car Catalog** tab and use **Copy to Verified** beside an active public-sale listing. Promotion creates a separate snapshot of its full saved payload and photo in PostgreSQL. The original public listing, share code, owner, sales history, and marketplace availability remain unchanged. Repeating the action is idempotent and reports the design as already verified.

## Deployment

No manual SQL command is required when the application starts normally: `postgres_db.ensure_schema()` adds the support category column, report indexes, report-refund table, and verified-promotion table through additive migrations. Keep the existing `DATABASE_URL` and Stripe configuration unchanged. Deploy the bundle with the existing Railway start command, then open `/cars`, `/designed-cars`, `/shared-designs`, and the admin `/backlog` page to verify the sections and promotion queue.
