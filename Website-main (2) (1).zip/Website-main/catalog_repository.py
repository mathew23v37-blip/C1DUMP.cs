"""Persistent catalog metadata for the supplied designed-car payloads.

The catalog manifest is intentionally kept separate from account balances,
garage backups, premium/event databases, and action logs.  Admin changes only
toggle catalog visibility; they never rewrite source payload JSON or user data.
"""

from __future__ import annotations

import json
import threading
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List, Optional

from persistence import atomic_write_json, data_path, seed_data_file


_ROOT = Path(__file__).resolve().parent
_SEED_FILE = _ROOT / "catalog_cars_database.json"
_RUNTIME_FILE = Path(seed_data_file("catalog_cars_database.json", default={"cars": []}))
_LOCK = threading.RLock()


def _load() -> Dict[str, Any]:
    with _LOCK:
        try:
            data = json.loads(_RUNTIME_FILE.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            data = {}
        if not isinstance(data, dict):
            data = {}
        needs_seed = not data.get("cars") or int(data.get("schema_version") or 0) < 4
        if needs_seed and _SEED_FILE.is_file():
            data = json.loads(_SEED_FILE.read_text(encoding="utf-8"))
            atomic_write_json(str(_RUNTIME_FILE), data)
        data.setdefault("cars", [])
        pricing = data.get("pricing") if isinstance(data.get("pricing"), dict) else {}
        pricing.setdefault("standard_credits", pricing.get("catalog_credits", 8000))
        pricing.setdefault("restricted_credits", 12000)
        data["pricing"] = pricing
        return data


def _save(data: Dict[str, Any]) -> None:
    with _LOCK:
        atomic_write_json(str(_RUNTIME_FILE), data)


def get_catalog_cars(*, include_hidden: bool = False) -> List[Dict[str, Any]]:
    data = _load()
    cars = []
    for raw in data.get("cars", []):
        if not isinstance(raw, dict):
            continue
        car = deepcopy(raw)
        car.setdefault("enabled", True)
        car.setdefault("source_groups", ["verified"])
        car.setdefault("catalog_kind", "verified")
        if str(car.get("slug") or "").lower() == "w124":
            car["name"] = "Event Badged Mercedes W124"
        if include_hidden or car["enabled"]:
            cars.append(car)
    return cars


def _promotion_to_car(promotion: Dict[str, Any]) -> Dict[str, Any]:
    promotion_id = str(promotion.get("promotion_id") or "")
    return {
        "slug": f"verified-promotion-{promotion_id}",
        "name": promotion.get("title") or "Verified public-sale design",
        "description": promotion.get("description") or "",
        "car_id": int(promotion.get("car_id") or 0),
        "payload_path": "",
        "photos": [],
        "price_credits": int(promotion.get("verified_price_credits") or 10000),
        "enabled": bool(promotion.get("enabled", True)),
        "source_groups": ["verified", "public_sale"],
        "catalog_kind": "verified_public_sale",
        "is_verified_promotion": True,
        "promotion_id": promotion_id,
        "source_design_id": promotion.get("source_design_id") or "",
        "source_share_code": promotion.get("source_share_code") or "",
        "source_owner_user_id": promotion.get("source_owner_user_id") or "",
        "vinyl_count": int(promotion.get("vinyl_count") or 0),
    }


def get_promoted_catalog_cars(*, include_disabled: bool = False) -> List[Dict[str, Any]]:
    """Load admin-promoted public designs as verified catalog cards."""
    try:
        from design_marketplace import list_verified_promotions
        return [_promotion_to_car(row) for row in list_verified_promotions(include_disabled=include_disabled)]
    except Exception:
        # The static verified catalog must remain available if PostgreSQL is down.
        return []


def get_catalog_car(slug: str, *, include_hidden: bool = False) -> Optional[Dict[str, Any]]:
    slug = str(slug or "").strip().lower()
    for car in get_catalog_cars(include_hidden=include_hidden):
        if str(car.get("slug") or "").lower() == slug:
            return car
    for car in get_promoted_catalog_cars(include_disabled=include_hidden):
        if str(car.get("slug") or "").lower() == slug:
            return car
    return None


def catalog_summary() -> Dict[str, Any]:
    cars = get_catalog_cars(include_hidden=True)
    promoted = get_promoted_catalog_cars(include_disabled=True)
    all_cars = cars + promoted
    return {
        "total": len(all_cars),
        "visible": sum(1 for car in all_cars if car.get("enabled", True)),
        "restricted": sum(1 for car in all_cars if int(car.get("price_credits") or 0) == 12000),
        "standard": sum(1 for car in all_cars if int(car.get("price_credits") or 0) == 8000),
        "photos": sum(len(car.get("photos") or []) for car in all_cars),
        "premium": sum(1 for car in all_cars if "premium" in (car.get("source_groups") or [])),
        "event": sum(1 for car in all_cars if "event" in (car.get("source_groups") or [])),
        "crown": sum(1 for car in all_cars if bool(car.get("crown"))),
        "verified_promoted": len(promoted),
        "pricing": deepcopy(_load().get("pricing") or {}),
    }


def set_catalog_visibility(slug: str, enabled: bool) -> Dict[str, Any]:
    """Persist an admin visibility change without touching car payloads."""
    slug = str(slug or "").strip().lower()
    data = _load()
    for car in data.get("cars", []):
        if str(car.get("slug") or "").lower() == slug:
            car["enabled"] = bool(enabled)
            _save(data)
            return {"ok": True, "car": deepcopy(car)}
    return {"ok": False, "message": "Catalog car not found."}


def load_catalog_payload(slug: str) -> Optional[Dict[str, Any]]:
    # A hidden listing is intentionally unavailable to public purchase routes,
    # but its source payload must remain intact for admin restoration and audit.
    car = get_catalog_car(slug, include_hidden=True)
    if not car:
        return None
    if car.get("is_verified_promotion"):
        try:
            from design_marketplace import get_verified_promotion
            promotion = get_verified_promotion(car.get("promotion_id"), include_disabled=True)
            payload = promotion.get("payload") if promotion else None
            return payload if isinstance(payload, dict) else None
        except Exception:
            return None
    payload_path = get_catalog_asset_path(car.get("payload_path"))
    if not payload_path:
        return None
    try:
        payload = json.loads(payload_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def get_catalog_asset_path(filename: Any) -> Optional[Path]:
    """Resolve only approved, flat root-level catalog files."""
    filename = str(filename or "").strip()
    if not filename or Path(filename).name != filename:
        return None
    approved = set()
    for car in get_catalog_cars(include_hidden=True):
        approved.add(str(car.get("payload_path") or ""))
        approved.update(str(item) for item in (car.get("photos") or []))
    if filename not in approved:
        return None
    candidate = _ROOT / filename
    return candidate if candidate.is_file() else None
