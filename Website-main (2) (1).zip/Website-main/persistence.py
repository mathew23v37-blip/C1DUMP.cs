"""Thread-safe persistence helpers for DATA_DIR-backed mutable state."""

from __future__ import annotations

import json
import os
import shutil
import tempfile
import threading
import time
from typing import Any, Dict

from config import DATA_DIR, PROJECT_ROOT, data_path, project_path

_LOCKS: Dict[str, threading.RLock] = {}
_LOCKS_GUARD = threading.RLock()


def get_lock(path: str) -> threading.RLock:
    resolved = os.path.abspath(path)
    with _LOCKS_GUARD:
        lock = _LOCKS.get(resolved)
        if lock is None:
            lock = threading.RLock()
            _LOCKS[resolved] = lock
        return lock


def ensure_data_dir() -> str:
    os.makedirs(DATA_DIR, exist_ok=True)
    return DATA_DIR


def ensure_parent(path: str) -> None:
    parent = os.path.dirname(os.path.abspath(path))
    if parent:
        os.makedirs(parent, exist_ok=True)


def seed_data_file(filename: str, *, packaged_name: str | None = None, default: Any = None) -> str:
    """Create DATA_DIR/filename on first run from packaged file or default data."""
    ensure_data_dir()
    target = data_path(filename)
    if os.path.exists(target):
        return target
    source = project_path(packaged_name or filename)
    ensure_parent(target)
    lock = get_lock(target)
    with lock:
        if os.path.exists(target):
            return target
        if os.path.exists(source) and os.path.abspath(source) != os.path.abspath(target):
            shutil.copy2(source, target)
        elif default is not None:
            atomic_write_json(target, default)
        else:
            # Touch the file only for callers that explicitly supplied a default.
            pass
    return target


def load_json(path: str, default: Any) -> Any:
    lock = get_lock(path)
    with lock:
        try:
            with open(path, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except (FileNotFoundError, json.JSONDecodeError):
            return default


def atomic_write_json(path: str, data: Any, *, pretty: bool = False) -> None:
    ensure_parent(path)
    lock = get_lock(path)
    tmp_name = None
    with lock:
        fd, tmp_name = tempfile.mkstemp(
            prefix=os.path.basename(path) + ".",
            suffix=".tmp",
            dir=os.path.dirname(os.path.abspath(path)) or ".",
            text=True,
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                if pretty:
                    json.dump(data, fh, indent=2, ensure_ascii=False)
                else:
                    json.dump(data, fh, ensure_ascii=False, separators=(",", ":"))
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(tmp_name, path)
            tmp_name = None
            try:
                dir_fd = os.open(os.path.dirname(os.path.abspath(path)) or ".", os.O_RDONLY)
                try:
                    os.fsync(dir_fd)
                finally:
                    os.close(dir_fd)
            except OSError:
                pass
        finally:
            if tmp_name:
                try:
                    os.unlink(tmp_name)
                except FileNotFoundError:
                    pass


def append_jsonl(path: str, event: Dict[str, Any]) -> None:
    ensure_parent(path)
    lock = get_lock(path)
    with lock:
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(event, ensure_ascii=False, separators=(",", ":")) + "\n")
            fh.flush()
            os.fsync(fh.fileno())


DEFAULT_SETTINGS: Dict[str, Any] = {
    "unlimited_currency": False,
    # Maintenance mode is intentionally ON by default. Existing deployments
    # whose settings.json predates this option inherit the safe default until
    # an administrator explicitly turns the dashboard back on.
    "dashboard_maintenance": True,
    "maintenance_mode": "unlimited",
    "maintenance_enabled_sections": [
        "money", "coins", "currency_presets", "player_modifications",
        "player_unlocks", "account_repair", "public_listings",
    ],
    "hourly_access_schedule_enabled": True,
    "maintenance_bypass_user_ids": [],
}
SETTINGS_FILE = seed_data_file("settings.json", default=DEFAULT_SETTINGS)
_POSTGRES_SETTINGS_ENABLED = bool(os.getenv("DATABASE_URL", "").strip()) and os.getenv(
    "POSTGRES_ACCOUNTS_ENABLED", "auto"
).strip().lower() not in {"0", "false", "no", "off"}
_SETTINGS_CACHE: Dict[str, Any] | None = None
_SETTINGS_CACHE_MTIME_NS: int | None = None
_SETTINGS_CACHE_CHECKED_AT = 0.0
try:
    _SETTINGS_CACHE_TTL_SECONDS = max(
        0.1, float(os.getenv("SETTINGS_CACHE_TTL_SECONDS", "1.0"))
    )
except (TypeError, ValueError):
    _SETTINGS_CACHE_TTL_SECONDS = 1.0


def _settings_mtime_ns() -> int | None:
    try:
        return os.stat(SETTINGS_FILE).st_mtime_ns
    except FileNotFoundError:
        return None


def load_settings() -> Dict[str, Any]:
    global _SETTINGS_CACHE, _SETTINGS_CACHE_MTIME_NS, _SETTINGS_CACHE_CHECKED_AT
    if _POSTGRES_SETTINGS_ENABLED:
        # PostgreSQL is the shared source of truth once horizontal scaling is
        # enabled. A short process cache keeps template rendering inexpensive.
        now = time.monotonic()
        lock = get_lock(SETTINGS_FILE)
        with lock:
            if (
                _SETTINGS_CACHE is not None
                and (now - _SETTINGS_CACHE_CHECKED_AT) < _SETTINGS_CACHE_TTL_SECONDS
            ):
                return dict(_SETTINGS_CACHE)
            from postgres_accounts import load_settings as pg_load_settings

            merged = pg_load_settings(DEFAULT_SETTINGS)
            _SETTINGS_CACHE = dict(merged)
            _SETTINGS_CACHE_CHECKED_AT = now
            return dict(merged)
    now = time.monotonic()
    lock = get_lock(SETTINGS_FILE)
    with lock:
        if (
            _SETTINGS_CACHE is not None
            and (now - _SETTINGS_CACHE_CHECKED_AT) < _SETTINGS_CACHE_TTL_SECONDS
        ):
            return dict(_SETTINGS_CACHE)

        mtime_ns = _settings_mtime_ns()
        _SETTINGS_CACHE_CHECKED_AT = now
        if _SETTINGS_CACHE is not None and mtime_ns == _SETTINGS_CACHE_MTIME_NS:
            return dict(_SETTINGS_CACHE)

        data = load_json(SETTINGS_FILE, dict(DEFAULT_SETTINGS))
        if not isinstance(data, dict):
            data = dict(DEFAULT_SETTINGS)
        merged = dict(DEFAULT_SETTINGS)
        merged.update(data)
        _SETTINGS_CACHE = merged
        _SETTINGS_CACHE_MTIME_NS = mtime_ns
        return dict(merged)


def save_settings(settings: Dict[str, Any]) -> Dict[str, Any]:
    global _SETTINGS_CACHE, _SETTINGS_CACHE_MTIME_NS, _SETTINGS_CACHE_CHECKED_AT
    merged = dict(DEFAULT_SETTINGS)
    if isinstance(settings, dict):
        merged.update(settings)
    merged["unlimited_currency"] = bool(merged.get("unlimited_currency"))
    merged["dashboard_maintenance"] = bool(merged.get("dashboard_maintenance"))
    mode = str(merged.get("maintenance_mode") or "off").strip().lower()
    if not merged["dashboard_maintenance"]:
        mode = "off"
    elif mode not in {"unlimited", "paid"}:
        mode = "unlimited"
    merged["maintenance_mode"] = mode
    merged["dashboard_maintenance"] = mode != "off"
    merged["hourly_access_schedule_enabled"] = bool(merged.get("hourly_access_schedule_enabled", True))
    merged["maintenance_enabled_sections"] = sorted({
        str(value).strip().lower()
        for value in (merged.get("maintenance_enabled_sections") or [])
        if str(value).strip()
    })
    merged["maintenance_bypass_user_ids"] = sorted({
        str(value).strip().lower()
        for value in (merged.get("maintenance_bypass_user_ids") or [])
        if str(value).strip()
    })
    if _POSTGRES_SETTINGS_ENABLED:
        from postgres_accounts import save_settings as pg_save_settings

        saved = pg_save_settings(merged)
        lock = get_lock(SETTINGS_FILE)
        with lock:
            _SETTINGS_CACHE = dict(saved)
            _SETTINGS_CACHE_MTIME_NS = None
            _SETTINGS_CACHE_CHECKED_AT = time.monotonic()
        return dict(saved)
    lock = get_lock(SETTINGS_FILE)
    with lock:
        atomic_write_json(SETTINGS_FILE, merged, pretty=True)
        _SETTINGS_CACHE = dict(merged)
        _SETTINGS_CACHE_MTIME_NS = _settings_mtime_ns()
        _SETTINGS_CACHE_CHECKED_AT = time.monotonic()
    return dict(merged)


def is_unlimited_currency() -> bool:
    return bool(load_settings().get("unlimited_currency"))


def set_unlimited_currency(enabled: bool) -> Dict[str, Any]:
    settings = load_settings()
    settings["unlimited_currency"] = bool(enabled)
    return save_settings(settings)


def is_dashboard_maintenance() -> bool:
    return bool(load_settings().get("dashboard_maintenance", True))


def set_dashboard_maintenance(enabled: bool) -> Dict[str, Any]:
    settings = load_settings()
    settings["dashboard_maintenance"] = bool(enabled)
    settings["maintenance_mode"] = "unlimited" if enabled else "off"
    return save_settings(settings)


def set_maintenance_controls(mode: str, enabled_sections: list[str], schedule_enabled: bool = True) -> Dict[str, Any]:
    mode = str(mode or "off").strip().lower()
    if mode not in {"off", "unlimited", "paid"}:
        raise ValueError("Maintenance mode must be off, unlimited, or paid.")
    settings = load_settings()
    settings["maintenance_mode"] = mode
    settings["dashboard_maintenance"] = mode != "off"
    settings["maintenance_enabled_sections"] = list(enabled_sections or [])
    settings["hourly_access_schedule_enabled"] = bool(schedule_enabled)
    return save_settings(settings)


def maintenance_bypass_user_ids() -> list[str]:
    """Return site User IDs allowed through maintenance across all replicas."""
    return sorted({
        str(value).strip().lower()
        for value in (load_settings().get("maintenance_bypass_user_ids") or [])
        if str(value).strip()
    })


def is_maintenance_bypass(user_id: Any) -> bool:
    normalized = str(user_id or "").strip().lower()
    return bool(normalized and normalized in set(maintenance_bypass_user_ids()))


def set_maintenance_bypass(user_id: Any, enabled: bool) -> Dict[str, Any]:
    normalized = str(user_id or "").strip().lower()
    if not normalized:
        raise ValueError("Enter a site User ID.")
    settings = load_settings()
    allowed = {
        str(value).strip().lower()
        for value in (settings.get("maintenance_bypass_user_ids") or [])
        if str(value).strip()
    }
    if enabled:
        allowed.add(normalized)
    else:
        allowed.discard(normalized)
    settings["maintenance_bypass_user_ids"] = sorted(allowed)
    return save_settings(settings)
