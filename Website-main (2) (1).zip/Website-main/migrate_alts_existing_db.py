#!/usr/bin/env python3
"""One-command managed-alt import into an already-populated PostgreSQL database."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path


def load_source(path: Path) -> dict:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Cannot read managed-alt export: {exc}") from exc
    if not isinstance(data, dict) or not isinstance(data.get("users"), dict):
        raise RuntimeError("Expected a user_cpm_alts.json file containing a users map.")
    return data


def main() -> int:
    parser = argparse.ArgumentParser(description="Import managed alts into the existing PostgreSQL database.")
    parser.add_argument("--source", default=os.path.join(os.getenv("DATA_DIR", "/app/data"), "user_cpm_alts.json"))
    parser.add_argument("--dry-run", action="store_true", help="Check database ownership and email conflicts without writing data.")
    args = parser.parse_args()

    if not os.getenv("DATABASE_URL", "").strip():
        print("ERROR: DATABASE_URL is not set in this service.", file=sys.stderr)
        return 2
    source = Path(args.source).resolve()
    try:
        data = load_source(source)
    except RuntimeError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    users = data["users"]
    owner_ids = [str(user_id).strip() for user_id, bucket in users.items() if str(user_id).strip() and isinstance(bucket, dict)]
    rows = [row for bucket in users.values() if isinstance(bucket, dict) for row in (bucket.get("accounts") or []) if isinstance(row, dict)]
    account_ids = [str(row.get("id") or "").strip() for row in rows if str(row.get("id") or "").strip()]
    emails = [str(row.get("email") or "").strip().lower() for row in rows if str(row.get("email") or "").strip()]
    invalid = len(rows) - len(account_ids) or len(rows) - len(emails)
    if invalid:
        print("ERROR: source contains alternate accounts missing an id or email; no data was written.", file=sys.stderr)
        return 2

    from postgres_db import connection
    with connection() as conn:
        found_rows = conn.execute("SELECT user_id FROM site_users WHERE user_id = ANY(%s)", (owner_ids,)).fetchall()
        existing_users = {str(row["user_id"]) for row in found_rows}
        missing_users = sorted(set(owner_ids) - existing_users)
        try:
            conflicts = conn.execute("""SELECT account_id,email FROM managed_alt_accounts
                WHERE email = ANY(%s)""", (emails,)).fetchall() if emails else []
        except Exception as exc:
            # First migration: the managed-alt tables do not exist until the
            # delegated importer creates them. Other database failures still
            # surface in the actual import before any source row is committed.
            if "managed_alt_accounts" not in str(exc):
                raise
            conflicts = []
    expected_by_email = {str(row.get("email") or "").lower(): str(row.get("id") or "") for row in rows}
    conflicts = [dict(row) for row in conflicts if expected_by_email.get(str(row["email"]).lower()) not in {str(row["account_id"]), ""}]

    preflight = {
        "source": str(source),
        "source_user_buckets": len(owner_ids),
        "source_managed_alts": len(rows),
        "site_users_found": len(existing_users),
        "missing_site_users": len(missing_users),
        "conflicting_existing_alt_emails": len(conflicts),
        "dry_run": bool(args.dry_run),
    }
    if missing_users or conflicts:
        preflight["status"] = "blocked"
        preflight["message"] = "No data was written. Import the missing site users first or resolve the listed existing-alt email conflict."
        if missing_users:
            preflight["missing_site_user_ids"] = missing_users[:20]
        if conflicts:
            preflight["conflicts"] = [{"account_id": row["account_id"], "email": row["email"]} for row in conflicts[:20]]
        print(json.dumps(preflight, indent=2, sort_keys=True))
        return 1
    if args.dry_run:
        preflight["status"] = "ready"
        preflight["message"] = "All managed-alt owners exist in the current database; the import can run safely."
        print(json.dumps(preflight, indent=2, sort_keys=True))
        return 0

    importer = Path(__file__).with_name("migrate_managed_alts_to_postgres.py")
    command = [sys.executable, str(importer), "--source", str(source)]
    result = subprocess.run(command, text=True, capture_output=True)
    if result.stdout:
        print(result.stdout.strip())
    if result.returncode:
        if result.stderr:
            print(result.stderr.strip(), file=sys.stderr)
        return result.returncode

    with connection() as conn:
        persisted = conn.execute("SELECT count(*) AS n FROM managed_alt_accounts WHERE account_id = ANY(%s)", (account_ids,)).fetchone()["n"] if account_ids else 0
        preferences = conn.execute("SELECT count(*) AS n FROM managed_alt_preferences WHERE site_user_id = ANY(%s)", (owner_ids,)).fetchone()["n"] if owner_ids else 0
    print(json.dumps({
        **preflight,
        "status": "complete",
        "persisted_managed_alts_from_source": int(persisted),
        "persisted_preferences_from_source": int(preferences),
        "exact_match": int(persisted) == len(account_ids) and int(preferences) == len(owner_ids),
    }, indent=2, sort_keys=True))
    return 0 if int(persisted) == len(account_ids) and int(preferences) == len(owner_ids) else 1


if __name__ == "__main__":
    raise SystemExit(main())
