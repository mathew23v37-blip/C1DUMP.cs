#!/usr/bin/env python3
"""Create and fully build one durable account from a 500-account batch."""

from __future__ import annotations

import asyncio
import hashlib
import logging
from typing import Any, Dict

import aiohttp

import backlog
import bulk_account_jobs
from account_clone import clone_account
from car_bulk_injector import (
    close_current_injection_http_session,
    inject_premium_and_event_cars,
    verify_account_garage_count,
)
from cpm_nuker import CPMNuker, firebase_key


log = logging.getLogger("tnnr-bulk-account")


def _worker_uid(batch_id: str, account_index: int) -> int:
    digest = hashlib.sha256(f"{batch_id}:{account_index}".encode("utf-8")).hexdigest()
    return int(digest[:14], 16) % 900_000_000_000 + 100_000_000_000


async def _create_or_resume_firebase_account(nuker: CPMNuker, email: str, password: str) -> Dict[str, Any]:
    """Create a new Firebase identity, or log back into the identity after a retry.

    Uses the SOCKS5 proxy pool (account-gen only). Site login and other tools
    stay on direct connections.
    """
    import proxy_pool

    key = firebase_key()
    url = f"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={key}"
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "UnityPlayer/2022.3.62f2 (UnityWebRequest/1.0, libcurl/8.10.1-DEV)",
        "X-Unity-Version": "2022.3.62f2",
    }
    # Tight timeout so a slow proxy lane fails over quickly instead of hanging.
    timeout = aiohttp.ClientTimeout(total=18, connect=8)
    connector = proxy_pool.make_aiohttp_connector(
        proxy_url=proxy_pool.next_proxy_url(),
        limit=8,
        limit_per_host=4,
        ssl=False,
    )
    async with aiohttp.ClientSession(timeout=timeout, connector=connector) as session:
        async with session.post(
            url,
            headers=headers,
            json={"email": email, "password": password, "returnSecureToken": True},
        ) as response:
            payload = await response.json(content_type=None)
    if payload.get("idToken"):
        return {
            "ok": True,
            "created": True,
            "auth": payload["idToken"],
            "refresh_token": payload.get("refreshToken", ""),
            "firebase_uid": payload.get("localId", ""),
        }
    error = str((payload.get("error") or {}).get("message") or payload)
    if "EMAIL_EXISTS" in error.upper():
        login = await nuker.account_login(email, password)
        if login.get("ok"):
            return {"ok": True, "created": False, **login}
    return {"ok": False, "message": f"Fresh account creation failed: {error[:300]}"}


def _fresh_player_record(firebase_uid: str, account_index: int) -> Dict[str, Any]:
    """Minimal complete CPM record used when Firebase signup has no game save."""
    player_id = (str(firebase_uid or "")[:8] or f"TNNR{account_index:04d}").upper()
    return {
        "localID": player_id,
        "money": 0,
        "coin": 0,
        "boughtFsos": [],
        "boughtPoliceLights": [],
        "boughtPoliceSirens": [],
        "FriendsID": [],
        "LevelsDoneTime": [0.0] * 110,
        "floats": [0.0] * 54,
        "integers": [0] * 120,
        "fcar": [],
        "favouriteWheels": [],
        "favouriteVinyls": [],
        "favouriteEmojis": [],
        "emojiPacks": [],
        "flags": {},
        "animations": [],
        "wheels": [],
    }


async def _initialize_fresh_player_record(
    *,
    nuker: CPMNuker,
    web_uid: int,
    firebase_uid: str,
    batch_id: str,
    account_index: int,
) -> bool:
    """Fallback-save a base record, then verify the game can load it."""
    record = _fresh_player_record(firebase_uid, account_index)
    forced_fields = set(record)
    for save_attempt in range(1, 4):
        bulk_account_jobs.record_progress(
            batch_id,
            account_index,
            "record_initialize",
            f"CPM player record is missing — creating the base game save ({save_attempt}/3)…",
            {"attempt": save_attempt, "fallback": True},
        )
        result = await nuker._save(web_uid, record, force_fields=forced_fields)
        if result.get("ok"):
            bulk_account_jobs.record_progress(
                batch_id,
                account_index,
                "record_initialize_sent",
                "Base CPM player save accepted. Waiting for it to become readable…",
                {"attempt": save_attempt, "fallback": True},
            )
            for load_attempt in range(1, 7):
                await asyncio.sleep(min(10.0, 1.5 * load_attempt))
                if await nuker.load_account(web_uid, force=True):
                    bulk_account_jobs.record_progress(
                        batch_id,
                        account_index,
                        "record_ready",
                        "Fresh CPM player record initialized and verified.",
                        {"save_attempt": save_attempt, "load_attempt": load_attempt},
                    )
                    return True
        await asyncio.sleep(2.0 * save_attempt)
    return False


async def _require_step(
    *,
    batch_id: str,
    account_index: int,
    completed_steps: set[str],
    step: str,
    label: str,
    operation,
) -> None:
    if step in completed_steps:
        return
    bulk_account_jobs.record_progress(batch_id, account_index, step, f"Applying {label}…", {"step": step})
    result = await operation()
    if not isinstance(result, dict) or not result.get("ok"):
        detail = result.get("message", "Unknown response") if isinstance(result, dict) else str(result)
        raise RuntimeError(f"{label} failed: {detail}")
    completed_steps.add(step)
    bulk_account_jobs.record_progress(
        batch_id,
        account_index,
        "step_complete",
        f"{label} applied successfully.",
        {"step": step},
    )


async def build_bulk_account(batch_id: str, account_index: int) -> Dict[str, Any]:
    """Resume one generated account from its saved PostgreSQL checkpoint."""
    item = bulk_account_jobs.get_item(batch_id, account_index)
    if not item:
        raise RuntimeError("Bulk account record no longer exists.")
    email = str(item["email"])
    password = str(item["password"])
    coin_amount = max(1, min(500_000, int(item.get("coin_amount") or 30_000)))
    mode = str(item["mode"])
    checkpoint = dict(item.get("checkpoint") or {})
    completed_steps = set(checkpoint.get("completed_steps") or [])
    web_uid = _worker_uid(batch_id, account_index)
    nuker = CPMNuker()

    def progress(stage: str, message: str, extra=None):
        bulk_account_jobs.record_progress(batch_id, account_index, stage, message, extra)

    try:
        progress("account_create", f"Creating fresh account {account_index}/500…")
        auth = await _create_or_resume_firebase_account(nuker, email, password)
        if not auth.get("ok"):
            raise RuntimeError(auth.get("message", "Fresh account creation failed."))
        nuker.save_token(
            web_uid,
            auth["auth"],
            email,
            password,
            auth.get("refresh_token", ""),
            auth.get("firebase_uid", ""),
        )
        if "account_created" not in completed_steps:
            completed_steps.add("account_created")
            progress(
                "step_complete",
                "Fresh CPM identity created and credentials saved.",
                {"step": "account_created", "email": email, "resumed": not bool(auth.get("created"))},
            )

        loaded = False
        for attempt in range(1, 4):
            progress("account_load", f"Loading the fresh player record (attempt {attempt}/3)…")
            loaded = await nuker.load_account(web_uid, force=True)
            if loaded:
                break
            await asyncio.sleep(min(8.0, 1.5 * attempt))
        if not loaded:
            loaded = await _initialize_fresh_player_record(
                nuker=nuker,
                web_uid=web_uid,
                firebase_uid=str(auth.get("firebase_uid") or ""),
                batch_id=batch_id,
                account_index=account_index,
            )
        if not loaded:
            raise RuntimeError("Fresh account exists, but CPM rejected every player-record initialization fallback.")

        await _require_step(
            batch_id=batch_id,
            account_index=account_index,
            completed_steps=completed_steps,
            step="money_50m",
            label="50,000,000 cash",
            operation=lambda: nuker.set_money(web_uid, 50_000_000),
        )
        await _require_step(
            batch_id=batch_id,
            account_index=account_index,
            completed_steps=completed_steps,
            step="coins_selected",
            label=f"{coin_amount:,} coins",
            operation=lambda: nuker.set_coin(web_uid, coin_amount),
        )
        await _require_step(
            batch_id=batch_id,
            account_index=account_index,
            completed_steps=completed_steps,
            step="race_wins",
            label="670,000 race wins",
            operation=lambda: nuker.set_race_wins(web_uid, 670_000),
        )
        await _require_step(
            batch_id=batch_id,
            account_index=account_index,
            completed_steps=completed_steps,
            step="race_losses",
            label="clean race-loss record",
            operation=lambda: nuker.set_race_loses(web_uid, 0),
        )
        await _require_step(
            batch_id=batch_id,
            account_index=account_index,
            completed_steps=completed_steps,
            step="all_features",
            label="all player unlocks, King Rank, W16, horns, no damage, unlimited fuel, smoke, animations, wheels, houses and levels",
            operation=lambda: nuker.unlock_all_features(web_uid),
        )
        checkpoint = bulk_account_jobs.get_item(batch_id, account_index).get("checkpoint") or {}
        if mode == "clone":
            progress("cars", "Cloning the selected source garage into this fresh account…")
            car_result = await clone_account(
                str(item.get("source_email") or ""),
                str(item.get("source_password") or ""),
                email,
                password,
                progress,
                checkpoint,
            )
            car_amount = int(car_result.get("exported") or 0) - len(car_result.get("failed_ids") or [])
        else:
            progress("cars", "Injecting every configured premium and event car into this fresh account…")
            car_result = await inject_premium_and_event_cars(email, password, progress, checkpoint)
            car_amount = int(car_result.get("total") or 0) - len(car_result.get("failed_ids") or [])
        if not car_result.get("ok") or car_result.get("failed_ids"):
            raise RuntimeError(car_result.get("message", "Car injection did not finish completely."))

        progress(
            "garage_verify_start",
            "Reloading the completed garage with Get Cars before saving the final car amount…",
            {"expected_minimum": max(0, car_amount)},
        )
        garage_verification = await verify_account_garage_count(
            email,
            password,
            progress,
            minimum_count=max(0, car_amount),
            attempts=6,
        )
        if not garage_verification.get("ok"):
            raise RuntimeError(
                "Final Get Cars verification failed: "
                + str(garage_verification.get("message") or "garage count was not confirmed")
            )
        car_amount = int(garage_verification.get("count") or 0)
        progress(
            "garage_verified",
            f"Final Get Cars verification confirmed {car_amount} saved cars.",
            {"verified_car_count": car_amount},
        )

        final_record = nuker.get_user_template(web_uid, email) or {}
        player_name = str(final_record.get("Name") or "Generated Account")
        backlog.record_credentials(
            player_name,
            email,
            password,
            web_uid=f"bulk:{batch_id}:{account_index}",
        )
        backlog.log_action(
            email,
            "bulk_account_generated",
            "500 Account Generator",
            True,
            message=f"Generated account {account_index}/500 with {car_amount} cars using {mode} mode.",
            web_uid=f"bulk:{batch_id}:{account_index}",
            player_name=player_name,
            extra={
                "batch_id": batch_id,
                "account_index": account_index,
                "coin_amount": coin_amount,
                "car_amount": car_amount,
                "mode": mode,
            },
        )
        return {
            "ok": True,
            "email": email,
            "password": password,
            "car_amount": max(0, car_amount),
            "message": f"Account {account_index}/500 fully generated with {max(0, car_amount)} cars.",
        }
    finally:
        try:
            await nuker.close_current_loop_network_client()
        except Exception:
            log.exception("Unable to close bulk account modifier HTTP session")
        try:
            await close_current_injection_http_session()
        except Exception:
            log.exception("Unable to close bulk account injection HTTP session")
