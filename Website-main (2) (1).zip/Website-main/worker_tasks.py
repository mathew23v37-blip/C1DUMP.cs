#!/usr/bin/env python3
"""RQ task implementations for long-running CPM car operations."""

from __future__ import annotations

import asyncio
import logging
import random
import time
from typing import Any, Dict

import accounts
import backlog
import bulk_account_jobs
import king_account_jobs
import catalog_repository
import design_marketplace
from bulk_account_generator import build_bulk_account
from king_account_generator import build_king_account
from account_clone import clone_account
from car_bulk_injector import (
    close_current_injection_http_session,
    inject_all_cars,
    inject_event_cars,
    inject_saved_cars,
    inject_with_garage_protection,
)
from redis_jobs import get_job_store, worker_lane_slot


log = logging.getLogger("tnnr-worker")
CAR_JOB_KINDS = {
    "premium", "event", "unlock_all", "catalog", "shared_design",
    "garage_recovery",
}


def _recovery_delay(attempt: int) -> float:
    """Capped exponential backoff with jitter for whole-job recovery cycles."""
    base = min(600.0, 10.0 * (2 ** min(6, max(0, int(attempt) - 1))))
    return base * random.uniform(0.8, 1.2)


def process_bulk_account_item(batch_id: str, account_index: int) -> Dict[str, Any]:
    """Build one child account; retries reuse its saved credentials/checkpoint."""
    item = bulk_account_jobs.start_item(batch_id, int(account_index))
    if item.get("already_complete"):
        return {
            "ok": True,
            "duplicate": True,
            "email": item.get("email"),
            "car_amount": int(item.get("car_amount") or 0),
        }
    if item.get("cancelled"):
        return {
            "ok": True,
            "cancelled": True,
            "message": "Batch was cancelled before this account started.",
        }
    attempt = int(item.get("attempt_count") or 1)
    try:
        with worker_lane_slot("bulk", wait_seconds=900.0):
            result = asyncio.run(build_bulk_account(batch_id, int(account_index)))
        if not isinstance(result, dict) or not result.get("ok"):
            raise RuntimeError(
                result.get("message", "Bulk account worker returned an invalid result.")
                if isinstance(result, dict)
                else "Bulk account worker returned an invalid result."
            )
        saved = bulk_account_jobs.finish_item(
            batch_id,
            int(account_index),
            car_amount=int(result.get("car_amount") or 0),
            message=str(result.get("message") or f"Account {account_index}/500 complete."),
        )
        if not saved:
            return {"ok": True, "cancelled": True, "message": "Batch was cancelled before completion was saved."}
        return result
    except Exception as exc:
        log.exception("Bulk account %s/%s attempt %s failed", batch_id, account_index, attempt)
        recovery = bulk_account_jobs.fail_or_retry_item(
            batch_id,
            int(account_index),
            str(exc),
            failed_attempt=attempt,
        )
        return {
            "ok": False,
            "message": str(exc),
            "requeued": bool(recovery.get("requeued")),
            "state": recovery.get("state"),
            "attempt": attempt,
        }


def process_king_account_item(batch_id: str, account_index: int) -> Dict[str, Any]:
    """Build one king account in the RQ worker pool under the batch concurrency cap."""
    item = king_account_jobs.start_item(batch_id, int(account_index))
    if item.get("already_complete"):
        return {"ok": True, "duplicate": True, "email": item.get("email"), "car_amount": int(item.get("car_amount") or 0)}
    if item.get("deferred"):
        return {"ok": True, "deferred": True, "message": "King-account start deferred because the selected maximum concurrency is full."}
    if item.get("cancelled"):
        return {"ok": True, "cancelled": True, "message": "Batch was cancelled before this account started."}
    try:
        result = asyncio.run(build_king_account(batch_id, int(account_index)))
        if not isinstance(result, dict) or not result.get("ok"):
            raise RuntimeError(result.get("message", "King-account worker returned an invalid result.") if isinstance(result, dict) else "King-account worker returned an invalid result.")
        king_account_jobs.finish_item(
            batch_id,
            int(account_index),
            car_amount=int(result.get("car_amount") or 0),
            message=str(result.get("message") or f"King account {account_index} complete."),
        )
        return result
    except Exception as exc:
        log.exception("King account %s/%s failed", batch_id, account_index)
        latest_item = king_account_jobs.get_item(batch_id, int(account_index)) or item
        recovery = king_account_jobs.fail_or_retry_item(
            batch_id,
            int(account_index),
            str(exc),
            car_amount=int(latest_item.get("car_amount") or 0),
        )
        return {"ok": False, "message": str(exc), "requeued": bool(recovery.get("requeued")), "state": recovery.get("state")}


async def _execute(kind: str, credentials: Dict[str, Any], progress, checkpoint, job_id: str = "", site_user_id: str = ""):
    if kind in {"premium", "event", "unlock_all"}:
        return await inject_with_garage_protection(
            job_id, kind, credentials["email"], credentials["password"], progress, checkpoint, site_user_id
        )
    if kind == "catalog":
        car = catalog_repository.get_catalog_car(credentials.get("catalog_slug"), include_hidden=True)
        payload = catalog_repository.load_catalog_payload(credentials.get("catalog_slug"))
        if not car or not payload:
            raise RuntimeError("The selected designed-car payload is unavailable.")
        return await inject_with_garage_protection(
            job_id, "catalog", credentials["email"], credentials["password"],
            progress, checkpoint, site_user_id, payload, int(car.get("car_id") or 0),
        )
    if kind == "shared_design":
        design = design_marketplace.get_design(design_id=credentials.get("design_id"), include_payload=True)
        if not design or design.get("status") != "active":
            raise RuntimeError("The shared design is unavailable.")
        progress(
            "template",
            f"Public Car selected: {design.get('title') or 'Shared Design'} "
            f"(CarID #{int(design.get('car_id') or 0)}). Applying exactly 1 car…",
            {"car_id": int(design.get("car_id") or 0), "total": 1},
        )
        result = await inject_with_garage_protection(
            job_id, "shared_design", credentials["email"], credentials["password"],
            progress, checkpoint, site_user_id, custom_payload=design.get("payload") or {},
        )
        if result.get("ok"):
            design_marketplace.note_injection(design["design_id"])
            progress(
                "verified",
                f"Public Car CarID #{int(design.get('car_id') or 0)} injected and verified successfully.",
                {"car_id": int(design.get("car_id") or 0), "completed": 1, "total": 1},
            )
        return result
    if kind == "garage_recovery":
        payload = credentials.get("custom_payload")
        if not isinstance(payload, dict) or not isinstance(payload.get("cars"), list):
            raise RuntimeError("The selected garage recovery save is unavailable.")
        # Enforce max target garage size (same policy as the recovery page).
        from car_bulk_injector import verify_account_garage_count
        GARAGE_RECOVERY_MAX_TARGET_CARS = 5
        count_result = await verify_account_garage_count(
            credentials["email"], credentials["password"], progress, minimum_count=0, attempts=3,
        )
        target_count = int((count_result or {}).get("count") or 0)
        if target_count > GARAGE_RECOVERY_MAX_TARGET_CARS:
            raise RuntimeError(
                f"Recovery declined: target account already has {target_count} cars "
                f"(limit is {GARAGE_RECOVERY_MAX_TARGET_CARS}). Use an alternate with 5 or fewer cars."
            )
        progress(
            "restore_loaded",
            f"Loaded {len(payload['cars'])} cars from your private garage save.",
            {"total": len(payload["cars"]), "source_job_id": credentials.get("source_job_id", "")},
        )
        return await inject_with_garage_protection(
            job_id, "custom_safe_file", credentials["email"], credentials["password"],
            progress, checkpoint, site_user_id, custom_payload=payload,
        )
    if kind == "clone":
        return await clone_account(
            credentials["source_email"],
            credentials["source_password"],
            credentials["target_email"],
            credentials["target_password"],
            progress,
            checkpoint,
        )
    raise RuntimeError(f"Unsupported injection job kind: {kind}")


async def _execute_and_close(kind: str, credentials: Dict[str, Any], progress, checkpoint, job_id: str = "", site_user_id: str = ""):
    try:
        return await _execute(kind, credentials, progress, checkpoint, job_id, site_user_id)
    finally:
        await close_current_injection_http_session()


def _log_result(kind: str, credentials: Dict[str, Any], public_job: Dict[str, Any], result: Dict[str, Any]) -> None:
    email = credentials.get("source_email") if kind == "clone" else credentials.get("email")
    email = email or "unknown"
    injected = int(result.get("injected") or 0)
    success = bool(result.get("ok")) or injected > 0
    if kind == "premium":
        action, title = "premium_car_inject", "Premium Cars Injection"
    elif kind == "event":
        action, title = "event_car_inject", "Event Cars Injection"
    elif kind == "unlock_all":
        action, title = "unlock_all_cars", "Unlock All Cars 1-270"
    elif kind == "catalog":
        action, title = "catalog_car_inject", "Designed Car Injection"
    elif kind == "shared_design":
        action, title = "shared_design_inject", "Shared Design Injection"
    elif kind == "garage_recovery":
        action, title = "self_garage_recovery", "Self Garage Recovery"
    else:
        action, title = "account_clone", "Clone Account"
    extra = {
        "injected": injected,
        "failed_ids": result.get("failed_ids", []),
    }
    if kind == "garage_recovery":
        extra["source_job_id"] = credentials.get("source_job_id", "")
    for key in (
        "exported", "skipped", "skipped_owned", "vinyl_layers", "donor_car_id",
        "payload_profile", "payload_profiles",
    ):
        if key in result:
            extra[key] = result[key]
    backlog.log_action(
        email,
        action,
        title,
        success,
        message=result.get("message", ""),
        web_uid=public_job.get("web_uid"),
        extra=extra,
    )
    if injected > 1:
        backlog.record_live_action(action, True, amount=injected - 1)


def process_injection_job(job_id: str) -> Dict[str, Any]:
    """Run one attempt of a durable paid reservation with checkpointed recovery."""
    store = get_job_store()
    reservation = accounts.mark_job_started(job_id)
    payload = reservation.get("payload") if isinstance(reservation.get("payload"), dict) else {}
    public_job = payload.get("job") if isinstance(payload.get("job"), dict) else {}
    credentials = payload.get("credentials") if isinstance(payload.get("credentials"), dict) else {}
    kind = str(reservation.get("kind") or public_job.get("kind") or "")
    attempt = int(reservation.get("attempt_count") or 1)
    checkpoint = dict(reservation.get("checkpoint") or {})

    if not store.get(job_id):
        store.create(job_id, public_job)
    store.update(job_id, status="running", attempt_count=attempt, checkpoint=checkpoint)
    if attempt > 1:
        completed = int(checkpoint.get("completed_count") or 0)
        store.append_event(
            job_id,
            "resuming",
            f"Worker recovered — resuming paid job from its saved checkpoint ({completed} cars already completed).",
            {"attempt": attempt, "completed": completed},
        )
    else:
        store.append_event(job_id, "starting", "Your turn — starting injection now…", {"attempt": attempt})

    last_durable_write = 0.0
    diagnostic_stages_seen = set()

    def progress(stage: str, message: str, extra=None):
        nonlocal last_durable_write
        store.append_event(job_id, stage, message, extra)
        should_record_diagnostic = stage in {
            "slot_retry", "car_failed", "retry_failed", "garage_verify_retry",
            "protection_check", "finishing", "error",
        }
        # The protection loop emits an updated ETA/heartbeat throughout the
        # cleanup window. Log its public phase once; repeated timestamps belong
        # in the durable checkpoint, not Railway logs or the user console.
        if stage == "finishing" and stage in diagnostic_stages_seen:
            should_record_diagnostic = False
        if should_record_diagnostic:
            diagnostic_stages_seen.add(stage)
            log.warning(
                "job=%s kind=%s stage=%s internal_message=%s extra=%s",
                job_id, kind, stage, message, extra or {},
            )
            try:
                accounts.record_job_diagnostic(job_id, stage, message, extra)
            except Exception:
                log.exception("Unable to persist internal diagnostic for job %s", job_id)
        now = time.monotonic()
        must_checkpoint = stage in {
            "car_success", "retry_success", "verified", "injected",
            "finishing", "public_success",
        }
        if must_checkpoint or now - last_durable_write >= 15.0:
            saved = accounts.record_job_progress(job_id, stage, message, extra)
            store.update(job_id, checkpoint=saved, attempt_count=attempt)
            last_durable_write = now

    result: Dict[str, Any]
    try:
        # This Redis lease is shared by every worker replica. It prevents six
        # Railway replicas from each applying their full local worker count to
        # World Sale at once while still allowing the queue to remain durable.
        with worker_lane_slot("other", wait_seconds=900.0):
            result = asyncio.run(_execute_and_close(
                kind, credentials, progress, checkpoint, job_id,
                str(reservation.get("user_id") or ""),
            ))
        if not isinstance(result, dict):
            result = {"ok": False, "message": "Worker returned an invalid result.", "failed_ids": []}
        result["attempt_count"] = attempt
        result["checkpointed_car_ids"] = int(
            (accounts.record_job_progress(job_id, "complete", str(result.get("message") or "Completed."), result)
             or {}).get("completed_count") or 0
        )
        if kind in CAR_JOB_KINDS and (not result.get("ok") or result.get("failed_ids")):
            internal_reason = str(result.get("message") or "Car verification is not complete.")
            log.warning(
                "job=%s kind=%s cycle=%s incomplete failed_ids=%s reason=%s",
                job_id, kind, attempt, result.get("failed_ids", []), internal_reason,
            )
            try:
                accounts.record_job_diagnostic(job_id, "cycle_incomplete", internal_reason, {
                    "cycle": attempt,
                    "failed_ids": result.get("failed_ids", []),
                    "safety_verification": result.get("safety_verification", {}),
                })
            except Exception:
                log.exception("Unable to persist incomplete-cycle diagnostic for job %s", job_id)
            cycle_delay = _recovery_delay(attempt)
            recovery = accounts.mark_job_resumable(
                job_id,
                internal_reason,
                failed_attempt=attempt,
                delay_seconds=cycle_delay,
                keep_retrying=True,
            )
            if recovery.get("requeued"):
                eta_seconds = int(cycle_delay) + 90
                public_message = (
                    f"Finishing Up and Cleaning Out Errors · Estimated time left: about {eta_seconds} seconds"
                )
                result.update({
                    "ok": True,
                    "resuming": True,
                    "message": public_message,
                    "failed_ids": [],
                    "eta_seconds": eta_seconds,
                })
                store.update(job_id, status="resume_pending", result=None, checkpoint=recovery.get("checkpoint") or {})
                store.append_event(job_id, "finishing", public_message, {"eta_seconds": eta_seconds})
                return result
        if kind in {"unlock_all", "clone"}:
            display_status = "done" if result.get("ok") else "error"
        else:
            display_status = "complete" if result.get("ok") else "finished_with_errors"
        store.finish(job_id, display_status, result)
        accounts.finish_job_reservation(
            job_id,
            "completed" if result.get("ok") else "failed",
            failure_message="" if result.get("ok") else str(result.get("message") or "Injection reported errors."),
        )
        try:
            _log_result(kind, credentials, public_job, result)
        except Exception:
            log.exception("Unable to record worker result for job %s", job_id)
        return result
    except Exception as exc:
        log.exception("Injection job %s failed", job_id)
        try:
            accounts.record_job_diagnostic(job_id, "worker_exception", str(exc), {"cycle": attempt})
        except Exception:
            log.exception("Unable to persist worker exception diagnostic for job %s", job_id)
        cycle_delay = _recovery_delay(attempt)
        recovery = accounts.mark_job_resumable(
            job_id,
            str(exc),
            failed_attempt=attempt,
            delay_seconds=cycle_delay,
            keep_retrying=kind in CAR_JOB_KINDS,
        )
        if recovery.get("requeued"):
            completed = int((recovery.get("checkpoint") or {}).get("completed_count") or 0)
            eta_seconds = int(cycle_delay) + 90
            message = f"Finishing Up and Cleaning Out Errors · Estimated time left: about {eta_seconds} seconds"
            result = {
                "ok": True,
                "resuming": True,
                "message": message,
                "failed_ids": [],
                "attempt_count": attempt,
                "eta_seconds": eta_seconds,
            }
            store.update(job_id, status="resume_pending", result=None, checkpoint=recovery.get("checkpoint") or {})
            store.append_event(job_id, "finishing", message, {"eta_seconds": eta_seconds})
        else:
            message = (
                "Automatic recovery reached its safety limit. Your paid reservation and checkpoint "
                "are still saved for an administrator to resume; you will not be charged again."
            )
            result = {"ok": False, "message": message, "failed_ids": [], "attempt_count": attempt}
            store.append_event(job_id, "manual_review", message)
            store.finish(job_id, "error", result)
        return result
