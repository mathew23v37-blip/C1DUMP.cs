# CPM1 Webtool Frontend Redesign Notes

This package contains a frontend-only visual redesign of the CPM1 webtool.

## What changed

- Redesigned the login page (`templates/index.html`) with a dark premium gaming style.
- Redesigned the main tool dashboard (`templates/dashboard.html`) with polished cards, buttons, sections, spacing, hover states, soft glows, and responsive mobile behavior.
- Updated the shared template styling (`templates/base.html`) for the dark glassmorphism theme, navigation, flash messages, inputs, buttons, typography, and page shell.
- Updated the included stylesheet (`style.ccs`) to match the approved dark futuristic palette.

## Palette

The redesigned UI uses the requested color families only:

- Deep electric purple
- Neon cyan/teal
- Soft gold
- Cool blue
- Deep dark base background around `#0a0a0f`

No pink, magenta, or rose accent palette was intentionally used.

## Functionality preservation

No Python backend files were intentionally changed. The existing routes, form actions, submitted field names, modifier buttons, and backend-connected template expressions were preserved.

## Local run

Use the same local run process as before:

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

On Windows:

```bat
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Then open:

```text
http://127.0.0.1:8080
```
