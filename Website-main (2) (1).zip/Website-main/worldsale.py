import aiohttp
import asyncio
import json
import sys
import time
import random
import os
import glob
from config import data_path
sys.stdout.reconfigure(encoding='utf-8')
from colorama import Fore, Style, init as ca_init
ca_init(autoreset=True)

CPM_WORLDSALE_FIREBASE_KEY_ENV = 'CPM_WORLDSALE_FIREBASE_KEY'
EU = 'https://europe-west1-cp-multiplayer.cloudfunctions.net'
FB = 'https://www.googleapis.com/identitytoolkit/v3/relyingparty'
ALL_CARS_DIR = os.getenv('ALL_CARS_DIR') or data_path('all-cars')
DEBUG = False


def firebase_key():
    key = os.getenv(CPM_WORLDSALE_FIREBASE_KEY_ENV, '').strip()
    if not key:
        raise RuntimeError(f'Missing required environment variable {CPM_WORLDSALE_FIREBASE_KEY_ENV} for worldsale/car injector authentication.')
    return key


C = Fore
B = Style.BRIGHT
D = Style.DIM
N = Style.RESET_ALL
G = C.LIGHTBLACK_EX
W = C.LIGHTWHITE_EX
R = C.RED
Y = C.YELLOW
M = C.MAGENTA
CY = C.CYAN
GR = C.GREEN

def cls():
    os.system('cls' if os.name == 'nt' else 'clear')

def debug_log(msg, data=None):
    if DEBUG:
        if data:
            print(f'    {Y}[DEBUG]{N} {G}{msg}:{N} {D}{str(data)[:200]}{N}')
        else:
            print(f'    {Y}[DEBUG]{N} {G}{msg}{N}')

def line(char='─', n=48, c=G):
    print(f'  {c}{B}{char * n}{N}')

def spin(msg, sec=1.0):
    f = '⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
    end = time.time() + sec
    i = 0
    while time.time() < end:
        sys.stdout.write(f'\r    {CY}{f[i % 10]}{N} {G}{msg}{N} ')
        sys.stdout.flush()
        time.sleep(0.06)
        i += 1
    sys.stdout.write('\r' + ' ' * 60 + '\r')

async def spin_async(msg, sec=1.0):
    f = '⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
    end = time.time() + sec
    i = 0
    while time.time() < end:
        sys.stdout.write(f'\r    {CY}{f[i % 10]}{N} {G}{msg}{N} ')
        sys.stdout.flush()
        await asyncio.sleep(0.06)
        i += 1
    sys.stdout.write('\r' + ' ' * 60 + '\r')

def load_all_cars():
    cars = []
    if not os.path.exists(ALL_CARS_DIR):
        os.makedirs(ALL_CARS_DIR)
        return cars
    
    for filepath in sorted(glob.glob(f'{ALL_CARS_DIR}/*.json')):
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                car = json.load(f)
                cars.append(car)
        except:
            pass
    
    return cars

async def login_async(session, e, p):
    key = firebase_key()
    for url in [f'{FB}/verifyPassword', f'{FB}/signupNewUser']:
        try:
            async with session.post(url, params={'key': key}, json={
                'email': e, 'password': p, 'returnSecureToken': True
            }, timeout=aiohttp.ClientTimeout(total=12)) as r:
                d = await r.json()
                if d.get('idToken'):
                    return d['idToken'], d['localId']
        except:
            continue
    return None, None

async def api_async(session, tok, ep, data):
    h = {'Content-Type': 'application/json', 'Authorization': f'Bearer {tok}'}
    try:
        async with session.post(f'{EU}/{ep}', json={'data': data}, headers=h,
                               timeout=aiohttp.ClientTimeout(total=10)) as r:
            text = await r.text()
            return r.status, text
    except:
        return 500, ''

async def get_world_sale_slots(session, tok):
    _, t = await api_async(session, tok, 'WSGetCarListV3', 20)
    try:
        response_data = json.loads(t)
        if 'result' in response_data:
            lst = json.loads(response_data['result'])
            if lst:
                return lst
    except:
        pass
    return []

async def buy_car_from_slot(session, tok, slot, car):
    payload = {
        "ownerID": slot.get('ownerID', ''),
        "ownerName": slot.get('ownerName', ''),
        "description": slot.get('description', ''),
        "CarID": slot.get('carID', 0),
        "carGeneratedID": slot.get('carGeneratedID', ''),
        "ownerAccountID": slot.get('ownerAccountID', ''),
        "oneCar": car,
        "vynilOneCar": car.get('Vynils', {}),
        "loadedLocalCar": {"instanceID": random.randint(-999999, -100000)},
        "price": slot.get('price', 100),
        "SellingCar": {},
        "willReject": False,
        "dislike": 1,
        "like": 0,
        "liked": False,
        "disliked": False,
        "mode": 1,
    }
    _, t = await api_async(session, tok, 'WSPurchaseCarV3', json.dumps(payload))
    try:
        return json.loads(t).get('result') == 1
    except:
        return False

async def unlock_all_cars_async(email, pwd):
    all_cars = load_all_cars()
    
    if not all_cars:
        print(f'\n    {R}✗{N} {G}No cars found in {ALL_CARS_DIR}/ folder{N}')
        print(f'    {G}Add .json files with car metadata to continue{N}')
        return 0
    
    min_price = 0
    max_price = 10000
    total_cars = len(all_cars)
    
    print(f'\n  {M}{B}═══ UNLOCK ALL CARS MODE ═══{N}\n')
    print(f'    {G}Cars to unlock{N} {D}→{N} {W}{total_cars}{N}')
    print(f'    {G}Price range{N}   {D}→{N} {W}${min_price}-${max_price}{N}')
    
    connector = aiohttp.TCPConnector(limit=50, limit_per_host=50)
    async with aiohttp.ClientSession(connector=connector) as session:
        await spin_async('Authenticating…')
        try:
            tok, uid = await login_async(session, email, pwd)
        except RuntimeError as exc:
            print(f'    {R}✗{N} {G}{exc}{N}')
            return 0
        if not tok:
            print(f'    {R}✗{N} {G}Auth failed{N}')
            return 0
        print(f'    {GR}✓{N} {G}Logged in as {W}{uid[:8]}…{N}')
        
        total_unlocked = 0
        total_spent = 0
        car_index = 0
        unlocked_ids = set()
        
        while total_unlocked < total_cars:
            sys.stdout.write(f'\r    {CY}⏳{N} {G}Fetching world sale…{N} ')
            sys.stdout.flush()
            
            slots = await get_world_sale_slots(session, tok)
            
            if not slots:
                sys.stdout.write(f'\r    {Y}⏳{N} {G}Waiting for slots…{N} ')
                sys.stdout.flush()
                await asyncio.sleep(0.5)
                continue
            
            valid_slots = []
            for slot in slots:
                slot_id = slot.get('carID', 0)
                slot_price = slot.get('price', 0)
                
                if slot_id in unlocked_ids:
                    continue
                
                if slot_price < min_price or slot_price > max_price:
                    continue
                
                valid_slots.append(slot)
            
            if not valid_slots:
                sys.stdout.write(f'\r    {Y}⏳{N} {G}No new slots in range…{N} ')
                sys.stdout.flush()
                await asyncio.sleep(0.5)
                continue
            
            remaining = total_cars - total_unlocked
            slots_to_buy = valid_slots[:remaining]
            
            sys.stdout.write(f'\r    {CY}⚡{N} {G}Buying {len(slots_to_buy)} slots…{N} ')
            sys.stdout.flush()
            
            tasks = []
            for slot in slots_to_buy:
                car = all_cars[car_index % total_cars]
                car_index += 1
                
                new_car = json.loads(json.dumps(car))
                slot_id = slot.get('carID', 0)
                new_car['CarID'] = slot_id
                
                if 'texts' in new_car:
                    texts = new_car['texts']
                    if isinstance(texts, str):
                        texts = [texts, '', '']
                    while len(texts) <= 2:
                        texts.append('')
                    texts[2] = f'{uid[:8].upper()}_{slot_id}_HZ'
                    new_car['texts'] = texts
                
                if 'Vynils' in new_car and isinstance(new_car['Vynils'], dict):
                    new_car['Vynils']['CarID'] = slot_id
                
                tasks.append(buy_car_from_slot(session, tok, slot, new_car))
            
            if not tasks:
                break
            
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            batch_unlocked = 0
            batch_spent = 0
            
            for i, result in enumerate(results):
                if result is True:
                    batch_unlocked += 1
                    batch_spent += slots_to_buy[i].get('price', 0)
                    unlocked_ids.add(slots_to_buy[i].get('carID', 0))
            
            total_unlocked += batch_unlocked
            total_spent += batch_spent
            
            print(f'\r    {GR}✓{N} {G}Bought {batch_unlocked}/{len(slots_to_buy)} | {total_unlocked}/{total_cars} cars | ${total_spent:,}{N}     ')
            
            if total_unlocked >= total_cars:
                break
            
            await asyncio.sleep(0.3)
        
        print(f'\n  {M}{B}═══ UNLOCK COMPLETE ═══{N}')
        print(f'  {GR}Unlocked:{N} {W}{total_unlocked}/{total_cars}{N}  {GR}Spent:{N} {W}${total_spent:,}{N}')
        return total_unlocked

async def auto_hunt_async(email, pwd, max_cars=10, min_price=0, max_price=100000, delay=1.0, batch_size=5):
    print(f'\n  {CY}{B}═══ AUTO HUNT MODE ═══{N}\n')
    
    connector = aiohttp.TCPConnector(limit=50, limit_per_host=50)
    async with aiohttp.ClientSession(connector=connector) as session:
        await spin_async('Authenticating…')
        try:
            tok, uid = await login_async(session, email, pwd)
        except RuntimeError as exc:
            print(f'    {R}✗{N} {G}{exc}{N}')
            return 0
        if not tok:
            print(f'    {R}✗{N} {G}Auth failed{N}')
            return 0
        print(f'    {GR}✓{N} {G}Logged in as {W}{uid[:8]}…{N}')
        
        total_bought = 0
        total_spent = 0
        bought_ids = set()
        failed_attempts = 0
        max_failures = 30
        
        garage = await get_garage_cars(session, tok)
        if not garage:
            print(f'    {R}✗{N} {G}Cannot access garage{N}')
            return 0
        
        base_car = max(garage, key=lambda c: c.get('CarID', 0))
        base_id = base_car.get('CarID', 0)
        print(f'    {G}Blueprint{N} {D}→{N} {W}#{base_id}{N}')
        print(f'    {G}Garage{N}   {D}→{N} {W}{len(garage)} cars{N}')
        print(f'    {G}Target{N}   {D}→{N} {W}{max_cars} cars | ${min_price}-${max_price}{N}')
        print()
        
        while total_bought < max_cars and failed_attempts < max_failures:
            slots = await get_world_sale_slots(session, tok)
            
            if not slots:
                failed_attempts += 1
                sys.stdout.write(f'\r    {Y}⏳{N} {G}Waiting for slots… {failed_attempts}/{max_failures}{N} ')
                sys.stdout.flush()
                await asyncio.sleep(delay)
                continue
            
            valid_slots = []
            for slot in slots:
                slot_id = slot.get('carID', 0)
                slot_price = slot.get('price', 0)
                
                if slot_id in bought_ids:
                    continue
                
                if slot_price < min_price or slot_price > max_price:
                    continue
                
                valid_slots.append(slot)
            
            if not valid_slots:
                failed_attempts += 1
                sys.stdout.write(f'\r    {Y}⏳{N} {G}No valid slots… {failed_attempts}/{max_failures}{N} ')
                sys.stdout.flush()
                await asyncio.sleep(delay)
                continue
            
            remaining = max_cars - total_bought
            batch = min(batch_size, remaining, len(valid_slots))
            batch_slots = valid_slots[:batch]
            
            tasks = []
            for slot in batch_slots:
                new_car = json.loads(json.dumps(base_car))
                slot_id = slot.get('carID', 0)
                new_car['CarID'] = slot_id
                
                if 'texts' in new_car:
                    texts = new_car['texts']
                    if isinstance(texts, str):
                        texts = [texts, '', '']
                    while len(texts) <= 2:
                        texts.append('')
                    texts[2] = f'{uid[:8].upper()}_{slot_id}_HZ'
                    new_car['texts'] = texts
                
                if 'Vynils' in new_car and isinstance(new_car['Vynils'], dict):
                    new_car['Vynils']['CarID'] = slot_id
                
                tasks.append(buy_car_from_slot(session, tok, slot, new_car))
            
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            batch_bought = 0
            for i, result in enumerate(results):
                if result is True:
                    slot = batch_slots[i]
                    total_bought += 1
                    total_spent += slot.get('price', 0)
                    bought_ids.add(slot.get('carID'))
                    batch_bought += 1
            
            if batch_bought > 0:
                print(f'\r    {GR}✓{N} {G}Bought {batch_bought} cars | {total_bought}/{max_cars} | ${total_spent:,}{N}     ')
                failed_attempts = 0
            else:
                print(f'\r    {R}✗{N} {G}Batch failed{N}     ')
                failed_attempts += 1
            
            await asyncio.sleep(delay)
        
        print(f'\n  {CY}{B}═══ HUNT COMPLETE ═══{N}')
        print(f'  {GR}Bought:{N} {W}{total_bought}{N}  {GR}Spent:{N} {W}${total_spent:,}{N}')
        return total_bought

async def get_garage_cars(session, tok):
    _, t = await api_async(session, tok, 'TestGetAllCars', None)
    try:
        response_data = json.loads(t)
        if 'result' in response_data:
            return json.loads(response_data['result'])
    except:
        pass
    return []

async def inject_async(email, pwd, cid):
    connector = aiohttp.TCPConnector(limit=10)
    async with aiohttp.ClientSession(connector=connector) as session:
        spin('Connecting…')
        try:
            tok, uid = await login_async(session, email, pwd)
        except RuntimeError as exc:
            print(f'    {R}✗{N} {G}{exc}{N}')
            return False
        if not tok:
            print(f'    {R}✗{N} {G}Auth failed{N}')
            return False
        print(f'    {GR}✓{N} {G}Authenticated{N}  {D}[{uid[:8]}…]{N}')
        
        spin('Blueprint…')
        _, t = await api_async(session, tok, 'TestGetAllCars', None)
        try:
            response_data = json.loads(t)
            if 'result' not in response_data:
                print(f'    {R}✗{N} {G}Cannot get cars{N}')
                return False
            cars = json.loads(response_data['result'])
        except:
            print(f'    {R}✗{N} {G}Parse error{N}')
            return False
        
        if not cars:
            print(f'    {R}✗{N} {G}No cars available{N}')
            return False
        
        tpl = max(cars, key=lambda c: c.get('CarID', 0))
        print(f'    {GR}✓{N} {G}Blueprint{N}     {D}base #{tpl.get("CarID")}{N}')
        
        spin('Assembling…')
        car = json.loads(json.dumps(tpl))
        if 'CarID' not in car:
            print(f'    {R}✗{N} {G}Invalid car structure{N}')
            return False
        
        car['CarID'] = cid
        
        try:
            if 'texts' in car:
                texts = car['texts']
                if isinstance(texts, str):
                    car['texts'] = [texts, '', '']
                    texts = car['texts']
                elif not isinstance(texts, list):
                    pass
                else:
                    while len(texts) <= 2:
                        texts.append('')
                    car['texts'][2] = f'{uid[:8].upper()}_{cid}_HZ'
        except:
            pass
        
        try:
            if 'Vynils' in car and isinstance(car['Vynils'], dict):
                car['Vynils']['CarID'] = cid
        except:
            pass
        
        print(f'    {GR}✓{N} {G}Assembled{N}    {D}CarID #{cid}{N}')
        
        spin('Slot…')
        slots = await get_world_sale_slots(session, tok)
        if not slots:
            print(f'    {R}✗{N} {G}No slots{N}')
            return False
        
        w = slots[0]
        print(f'    {GR}✓{N} {G}Slot{N}         {D}#{w.get("carID")}{N}')
        
        spin('Injecting…', 1.8)
        success = await buy_car_from_slot(session, tok, w, car)
        
        if not success:
            print(f'    {R}✗{N} {G}Rejected{N}')
            return False
        
        await asyncio.sleep(1.5)
        _, t = await api_async(session, tok, 'TestGetAllCars', None)
        try:
            final = json.loads(json.loads(t)['result'])
            print(f'    {GR}✓{N} {G}Injected{N}     {D}garage: {len(final)} cars{N}')
        except:
            print(f'    {GR}✓{N} {G}Injected{N}')
        return True

def inject(email, pwd, cid):
    return asyncio.run(inject_async(email, pwd, cid))

def auto_hunt(email, pwd, max_cars=10, min_price=0, max_price=100000, delay=1.0, batch_size=5):
    return asyncio.run(auto_hunt_async(email, pwd, max_cars, min_price, max_price, delay, batch_size))

def unlock_all_cars(email, pwd):
    return asyncio.run(unlock_all_cars_async(email, pwd))

def main():
    cls()
    print(f'  {G}{B}CPM1 CAR INJECTOR {D}v3.0{N}')
    print(f'  {G}{D}async • aiohttp • unlock all{N}')
    line()
    print(f'  {W}{B}OPTIONS{N}')
    print()
    print(f'    {G}[1]{N} {W}Inject car{N}')
    print(f'    {G}[2]{N} {W}Auto hunt & buy{N}')
    print(f'    {G}[3]{N} {W}Unlock all cars (all-cars/){N}')
    print(f'    {G}[4]{N} {W}Exit{N}')
    print()
    
    mode = input(f'    {G}Choice{N} {D}›{N} ').strip()
    
    if mode == '4':
        sys.exit(0)
    
    print()
    email = input(f'    {G}Email{N}  {D}›{N} ').strip()
    pwd = input(f'    {G}Pass{N}   {D}›{N} ').strip()
    
    if not email or not pwd:
        print(f'\n    {R}All fields required{N}\n')
        input(f'  {G}Enter to exit…{N}')
        sys.exit(1)
    
    if mode == '1':
        cid_s = input(f'    {G}Car ID{N} {D}›{N} ').strip()
        try:
            cid = int(cid_s)
            if cid <= 0:
                raise ValueError
        except:
            print(f'\n    {R}Invalid Car ID{N}\n')
            input(f'  {G}Enter to exit…{N}')
            sys.exit(1)
        
        print()
        line()
        print(f'  {G}Target{N} {D}→{N} {W}{email}{N}')
        print(f'  {G}Car{N}    {D}→{N} {W}#{cid}{N}')
        line()
        print()
        
        ok = inject(email, pwd, cid)
        
        print()
        line('═')
        if ok:
            print(f'  {GR}{B}  ✓  INJECTION COMPLETE{N}')
            print(f'  {G}  Car {W}#{cid}{G} → {W}{email}{N}')
        else:
            print(f'  {R}{B}  ✗  INJECTION FAILED{N}')
            print(f'  {G}  Check credentials and retry{N}')
        line('═')
    
    elif mode == '2':
        print()
        max_cars_s = input(f'    {G}Max cars{N} {D}›{N} ').strip()
        min_price_s = input(f'    {G}Min price{N} {D}›{N} ').strip()
        max_price_s = input(f'    {G}Max price{N} {D}›{N} ').strip()
        batch_s = input(f'    {G}Batch size{N} {D}›{N} ').strip()
        
        try:
            max_cars = int(max_cars_s) if max_cars_s else 10
            min_price = int(min_price_s) if min_price_s else 0
            max_price = int(max_price_s) if max_price_s else 100000
            batch_size = int(batch_s) if batch_s else 5
        except:
            max_cars, min_price, max_price, batch_size = 10, 0, 100000, 5
        
        print()
        line()
        auto_hunt(email, pwd, max_cars, min_price, max_price, 0.5, batch_size)
        line()
    
    elif mode == '3':
        print()
        line()
        unlock_all_cars(email, pwd)
        line()
    
    print(f'\n  {G}Enter to exit…{N}', end='')
    input()

if __name__ == '__main__':
    main()