"""Auditable multiplier refunds for users affected by car-injection issues."""

from __future__ import annotations

import time
import uuid
from collections import defaultdict
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Any, Dict, Iterable, List, Optional

from postgres_db import connection

CAR_JOB_KINDS = (
    "premium", "event", "catalog", "unlock_all", "shared_design", "custom_safe_file"
)
FAILED_STATES = ("failed", "manual_review")


def _source_rows(
    conn,
    *,
    include_public: bool,
    include_failed: bool,
    start_at: Optional[float],
    end_at: Optional[float],
    user_ids: Optional[Iterable[str]] = None,
) -> List[dict]:
    parts = []
    params: List[Any] = []
    if include_public:
        clauses = [
            "l.entry_type='debit'",
            "l.amount>0",
            # psycopg treats percent signs as parameter markers, so a SQL
            # wildcard must be doubled. The reason fallback also discovers
            # legacy marketplace charges created before source keys existed.
            "(l.source_key LIKE 'design-inject-buy:%%' OR l.reason='Shared design purchase')",
        ]
        if start_at is not None:
            clauses.append("l.event_time >= %s"); params.append(float(start_at))
        if end_at is not None:
            clauses.append("l.event_time < %s"); params.append(float(end_at))
        parts.append(f"""SELECT 'public_design_purchase'::text AS source_type,
            COALESCE(l.source_key,'legacy-ledger:' || l.id::text) AS source_id,
            l.user_id,l.amount::bigint AS spend,l.event_time
            FROM credit_ledger l WHERE {' AND '.join(clauses)}""")
    if include_failed:
        clauses = [
            "r.cost>0",
            "r.kind=ANY(%s)",
            "(r.state=ANY(%s) OR EXISTS ("
            "SELECT 1 FROM car_safety_backups b WHERE b.job_id=r.job_id "
            "AND b.verification_state='protection_failed'"
            ") OR EXISTS ("
            "SELECT 1 FROM car_job_diagnostics d WHERE d.job_id=r.job_id "
            "AND d.stage IN ('cycle_incomplete','worker_exception','manual_review','protection_failed')"
            "))",
        ]
        params.extend([list(CAR_JOB_KINDS), list(FAILED_STATES)])
        if start_at is not None:
            clauses.append("r.created_at >= %s"); params.append(float(start_at))
        if end_at is not None:
            clauses.append("r.created_at < %s"); params.append(float(end_at))
        parts.append(f"""SELECT 'failed_car_job'::text AS source_type,
            r.job_id AS source_id,r.user_id,r.cost::bigint AS spend,r.created_at AS event_time
            FROM job_reservations r WHERE {' AND '.join(clauses)}""")
    if not parts:
        return []
    query = " UNION ALL ".join(parts)
    outer = ["c.source_id IS NULL"]
    selected = sorted({str(value).strip() for value in (user_ids or []) if value})
    if selected:
        outer.append("s.user_id=ANY(%s)"); params.append(selected)
    rows = conn.execute(f"""SELECT s.*,u.email,u.balance
        FROM ({query}) s
        JOIN site_users u ON u.user_id=s.user_id
        LEFT JOIN affected_refund_source_claims c
          ON c.source_type=s.source_type AND c.source_id=s.source_id
        WHERE {' AND '.join(outer)}
        ORDER BY s.event_time ASC""", tuple(params)).fetchall()
    return [dict(row) for row in rows]


def candidates(
    *,
    include_public: bool = True,
    include_failed: bool = True,
    start_at: Optional[float] = None,
    end_at: Optional[float] = None,
) -> List[Dict[str, Any]]:
    with connection() as conn:
        rows = _source_rows(
            conn, include_public=include_public, include_failed=include_failed,
            start_at=start_at, end_at=end_at,
        )
    grouped: Dict[str, Dict[str, Any]] = {}
    for row in rows:
        user_id = str(row["user_id"])
        item = grouped.setdefault(user_id, {
            "user_id": user_id, "email": row["email"], "balance": int(row["balance"]),
            "public_spend": 0, "failed_spend": 0, "public_count": 0,
            "failed_count": 0, "qualifying_spend": 0,
        })
        spend = int(row["spend"] or 0)
        if row["source_type"] == "public_design_purchase":
            item["public_spend"] += spend; item["public_count"] += 1
        else:
            item["failed_spend"] += spend; item["failed_count"] += 1
        item["qualifying_spend"] += spend
    return sorted(grouped.values(), key=lambda item: (-item["qualifying_spend"], item["email"]))


def apply_multiplier(
    *,
    user_ids: Iterable[str],
    multiplier: Any,
    include_public: bool,
    include_failed: bool,
    start_at: Optional[float] = None,
    end_at: Optional[float] = None,
    note: str = "Car injection issue compensation",
) -> Dict[str, Any]:
    selected = sorted({str(value).strip() for value in user_ids if str(value).strip()})
    if not selected:
        return {"ok": False, "message": "Select at least one affected user."}
    try:
        rate = Decimal(str(multiplier))
    except (InvalidOperation, TypeError, ValueError):
        return {"ok": False, "message": "Enter a valid refund multiplier."}
    if rate < Decimal("0.01") or rate > Decimal("10"):
        return {"ok": False, "message": "Multiplier must be between 0.01 and 10."}
    if not include_public and not include_failed:
        return {"ok": False, "message": "Choose at least one affected-spend category."}

    batch_id = uuid.uuid4().hex
    now = time.time()
    note = (note or "Car injection issue compensation").strip()[:1000]
    with connection() as conn, conn.transaction():
        conn.execute("SELECT pg_advisory_xact_lock(hashtextextended(%s,0))", ("affected-car-refunds",))
        rows = _source_rows(
            conn, include_public=include_public, include_failed=include_failed,
            start_at=start_at, end_at=end_at, user_ids=selected,
        )
        grouped = defaultdict(list)
        for row in rows:
            grouped[str(row["user_id"])].append(row)
        if not grouped:
            return {"ok": False, "message": "No unrefunded qualifying charges remain for the selected users."}

        from psycopg.types.json import Jsonb
        conn.execute("""INSERT INTO affected_refund_batches
            (batch_id,multiplier,include_public,include_failed,start_at,end_at,note,
             created_at,user_count,total_qualifying_spend,total_refunded)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,0,0,0)""",
            (batch_id, rate, include_public, include_failed, start_at, end_at, note, now))

        total_spend = total_refund = 0
        processed = []
        for user_id, sources in grouped.items():
            qualifying = sum(int(row["spend"] or 0) for row in sources)
            refund = max(1, int((Decimal(qualifying) * rate).quantize(Decimal("1"), rounding=ROUND_HALF_UP)))
            user = conn.execute(
                "SELECT email,balance FROM site_users WHERE user_id=%s FOR UPDATE", (user_id,)
            ).fetchone()
            if not user or refund <= 0:
                continue
            after = int(user["balance"]) + refund
            conn.execute(
                "UPDATE site_users SET balance=%s,updated_at=%s WHERE user_id=%s",
                (after, now, user_id),
            )
            conn.execute("""INSERT INTO credit_ledger
                (user_id,entry_type,amount,reason,balance_after,event_time,meta,source_key)
                VALUES (%s,'credit',%s,%s,%s,%s,%s,%s)""",
                (user_id, refund, note, after, now,
                 Jsonb({"affected_refund": True, "batch_id": batch_id,
                        "multiplier": str(rate), "qualifying_spend": qualifying}),
                 f"affected-refund:{batch_id}:{user_id}"))
            source_summary = [{
                "type": row["source_type"], "id": row["source_id"],
                "spend": int(row["spend"]), "time": float(row["event_time"]),
            } for row in sources]
            conn.execute("""INSERT INTO affected_refund_items
                (batch_id,user_id,qualifying_spend,refund_amount,balance_after,sources,created_at)
                VALUES (%s,%s,%s,%s,%s,%s,%s)""",
                (batch_id, user_id, qualifying, refund, after, Jsonb(source_summary), now))
            for row in sources:
                conn.execute("""INSERT INTO affected_refund_source_claims
                    (source_type,source_id,user_id,qualifying_spend,batch_id,created_at)
                    VALUES (%s,%s,%s,%s,%s,%s)""",
                    (row["source_type"], row["source_id"], user_id,
                     int(row["spend"]), batch_id, now))
            total_spend += qualifying
            total_refund += refund
            processed.append({"user_id": user_id, "email": user["email"],
                              "qualifying_spend": qualifying, "refund": refund, "balance": after})

        conn.execute("""UPDATE affected_refund_batches SET user_count=%s,
            total_qualifying_spend=%s,total_refunded=%s WHERE batch_id=%s""",
            (len(processed), total_spend, total_refund, batch_id))
    return {"ok": True, "batch_id": batch_id, "users": processed,
            "user_count": len(processed), "qualifying_spend": total_spend,
            "refunded": total_refund, "multiplier": str(rate)}


def recent_batches(limit: int = 20) -> List[Dict[str, Any]]:
    with connection() as conn:
        rows = conn.execute("""SELECT * FROM affected_refund_batches
            ORDER BY created_at DESC LIMIT %s""", (max(1, min(100, int(limit))),)).fetchall()
    return [dict(row) for row in rows]
