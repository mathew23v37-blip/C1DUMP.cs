# Login Redirect Flow Update

## Summary

This package updates the CPM1 webtool routing so the public root page is the login page and successful login redirects to the dashboard.

Production flow:

1. `https://tnnr.shop/` shows the login page.
2. Existing logged-in sessions are cleared when visiting `/`, so the main domain does not jump straight to the dashboard.
3. After a successful login, the app redirects to `/dashboard` (`https://tnnr.shop/dashboard`).
4. `/dashboard` remains protected and redirects unauthenticated users back to `/`.
5. The existing dashboard logout-confirmation popup still appears after successful login.

## Preserved

- Existing modifier controls and action routes
- Existing action please-wait popup and success popup
- Existing post-login logout confirmation popup
- Existing dark premium UI styling
- Existing modifier/game logic in `cpm_nuker.py` and `cpm_nuker_web.py`

## Local run steps

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

On Windows:

```bat
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Then open:

```text
http://127.0.0.1:8080
```

## Manual QA checklist

- Open `/` and confirm the login page appears.
- Try `/dashboard` before logging in and confirm it redirects to `/`.
- Log in with valid CPM credentials and confirm the browser redirects to `/dashboard`.
- Confirm the logout confirmation popup appears on the dashboard after login.
- Confirm modifier buttons still show the please-wait popup and successful actions still show the success popup.
