from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

PROJECT = Path('/home/ubuntu/work_getallcars/source/Website-main')
sys.path.insert(0, str(PROJECT))
import export_public_sale_designs as exporter


def car(car_id: int, vinyls: int) -> dict:
    return {'CarID': car_id, 'Vynils': [{'CarID': car_id, 'vinyls': vinyls}]}


def main() -> None:
    rows = [
        {'design_id': 'd1', 'share_code': 'TNNR-A', 'title': 'First', 'car_id': 10,
         'payload': {'cars': [car(10, 31)]}, 'visibility': 'public', 'status': 'active', 'sales_count': 0, 'sales_limit': 2, 'created_at': 1, 'updated_at': 1},
        {'design_id': 'd2', 'share_code': 'TNNR-B', 'title': 'Second', 'car_id': 10,
         'payload': {'cars': [car(10, 42)]}, 'visibility': 'private', 'status': 'inactive', 'sales_count': 1, 'sales_limit': 1, 'created_at': 2, 'updated_at': 2},
        {'design_id': 'd3', 'share_code': 'TNNR-C', 'title': 'Third', 'car_id': 11,
         'payload': {'cars': [car(11, 55)]}, 'visibility': 'private', 'status': 'removed', 'sales_count': 0, 'sales_limit': 1, 'created_at': 3, 'updated_at': 3},
    ]
    original = exporter._load_all_marketplace_rows
    try:
        exporter._load_all_marketplace_rows = lambda: rows
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            manifest = exporter.export_designs(output)
            files = sorted(output.glob('car_*__*.json'))
            assert len(files) == 3
            assert manifest['exported_design_files'] == 3
            assert manifest['distinct_car_ids'] == 2
            assert json.loads(files[0].read_text())['cars'][0]['CarID'] in {10, 11}
            rerun = exporter.export_designs(output)
            rerun_files = sorted(output.glob('car_*__*.json'))
            assert len(rerun_files) == 3
            assert rerun['exported_design_files'] == 3
            metadata = {item['share_code']: item for item in rerun['files']}
            assert metadata['TNNR-B']['visibility'] == 'private'
            assert metadata['TNNR-B']['status'] == 'inactive'
            assert metadata['TNNR-C']['status'] == 'removed'
            assert (output / 'manifest.json').exists()
    finally:
        exporter._load_all_marketplace_rows = original
    print('PASS: public sale exporter writes one ready-to-inject JSON per listing including private/inactive records, preserves same-CarID variants, and reruns safely.')


if __name__ == '__main__':
    main()

