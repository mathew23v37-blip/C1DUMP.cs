import contextlib
import unittest

import design_marketplace as marketplace


class FakeWorldSaleDB:
    def __init__(self):
        self.design = {"design_id": "d1", "owner_user_id": "seller", "status": "active"}
        self.reports = {}
        self.refunds = {}
        self.ledger = []
        self.balance = 10
        self.purchases = [{"source_key": "design-inject-buy:d1:purchase-1", "amount": 125}]

    def __call__(self):
        return self

    def __enter__(self):
        return self

    def __exit__(self, *_):
        return False

    @contextlib.contextmanager
    def transaction(self):
        yield self

    def execute(self, sql, params=()):
        text = " ".join(str(sql).split())
        if text.startswith("SELECT * FROM shared_car_designs"):
            return _Result(self.design)
        if text.startswith("INSERT INTO shared_design_reports"):
            key = (params[1], params[2])
            report_id = self.reports.setdefault(key, f"report-{len(self.reports) + 1}")
            return _Result({"report_id": report_id})
        if text.startswith("SELECT count(*) AS n FROM shared_design_reports"):
            return _Result({"n": len(self.reports)})
        if text.startswith("SELECT source_key, amount"):
            return _Result(self.purchases)
        if text.startswith("SELECT refund_id,amount,status"):
            return _Result(self.refunds.get(params[0]))
        if text.startswith("SELECT balance FROM site_users"):
            return _Result({"balance": self.balance})
        if text.startswith("UPDATE site_users"):
            self.balance = params[0]
            return _Result(None)
        if text.startswith("INSERT INTO credit_ledger"):
            self.ledger.append(params)
            return _Result(None)
        if text.startswith("INSERT INTO shared_design_report_refunds"):
            report_id = params[1]
            status = "refunded" if "'refunded'" in text else "no_purchase"
            amount = int(params[4]) if status == "refunded" else 0
            self.refunds[report_id] = {"refund_id": params[0], "amount": amount, "status": status}
            return _Result(None)
        if text.startswith("UPDATE shared_car_designs"):
            self.design["status"] = "hidden"
            return _Result(None)
        if text.startswith("INSERT INTO shared_design_moderation_events"):
            return _Result(None)
        raise AssertionError(f"Unhandled SQL: {text}")


class _Result:
    def __init__(self, value):
        self.value = value

    def fetchone(self):
        return self.value if isinstance(self.value, dict) or self.value is None else self.value[0]

    def fetchall(self):
        return self.value if isinstance(self.value, list) else ([] if self.value is None else [self.value])


class WorldSaleSupportTests(unittest.TestCase):
    def setUp(self):
        self.db = FakeWorldSaleDB()
        self.original_connection = marketplace.connection
        marketplace.connection = self.db

    def tearDown(self):
        marketplace.connection = self.original_connection

    def test_report_refunds_paid_purchase_once(self):
        first = marketplace.report("d1", "buyer", "photo_mismatch", "wrong photo")
        second = marketplace.report("d1", "buyer", "photo_mismatch", "still wrong")
        self.assertTrue(first["ok"])
        self.assertEqual(first["refund_amount"], 125)
        self.assertEqual(second["refund_amount"], 125)
        self.assertEqual(self.db.balance, 135)
        self.assertEqual(len(self.db.ledger), 1)
        self.assertEqual(len(self.db.refunds), 1)

    def test_sixth_unique_report_temporarily_disables_listing(self):
        for index in range(1, 7):
            self.db.purchases = []
            result = marketplace.report("d1", f"reporter-{index}", "other", "review")
        self.assertEqual(result["report_count"], 6)
        self.assertTrue(result["temporarily_disabled"])
        self.assertEqual(self.db.design["status"], "hidden")


if __name__ == "__main__":
    unittest.main()
