#!/usr/bin/env python3
"""CPM giveaway system: queueing, spinner, prize pool, inbox delivery."""

from __future__ import annotations

import json
import random
import re
import time
import uuid
from typing import Any, Dict, List, Optional

import postgres_db

try:
    import accounts
except Exception:  # pragma: no cover
    accounts = None  # type: ignore

try:
    import community
except Exception:  # pragma: no cover
    community = None  # type: ignore


_SCHEMA_READY = False

_SCHEMA = """
CREATE TABLE IF NOT EXISTS giveaway_settings (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    enabled BOOLEAN NOT NULL DEFAULT FALSE,
    updated_at DOUBLE PRECISION NOT NULL
);
INSERT INTO giveaway_settings (id, enabled, updated_at)
VALUES (1, FALSE, EXTRACT(EPOCH FROM NOW()))
ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS giveaways (
    giveaway_id TEXT PRIMARY KEY,
    title TEXT NOT NULL DEFAULT 'Giveaway!',
    status TEXT NOT NULL DEFAULT 'setup',
    prize_pool_json TEXT NOT NULL DEFAULT '[]',
    winner_user_id TEXT,
    winner_username TEXT,
    winner_prize_json TEXT,
    spin_seed TEXT,
    message TEXT NOT NULL DEFAULT '',
    created_at DOUBLE PRECISION NOT NULL,
    updated_at DOUBLE PRECISION NOT NULL,
    finished_at DOUBLE PRECISION
);
CREATE INDEX IF NOT EXISTS idx_giveaways_status_time
    ON giveaways (status, created_at DESC);

CREATE TABLE IF NOT EXISTS giveaway_entries (
    giveaway_id TEXT NOT NULL,
    site_user_id TEXT NOT NULL,
    username TEXT NOT NULL,
    created_at DOUBLE PRECISION NOT NULL,
    PRIMARY KEY (giveaway_id, site_user_id)
);
CREATE INDEX IF NOT EXISTS idx_giveaway_entries_gid
    ON giveaway_entries (giveaway_id);

CREATE TABLE IF NOT EXISTS giveaway_history (
    id BIGSERIAL PRIMARY KEY,
    giveaway_id TEXT NOT NULL,
    winner_user_id TEXT,
    winner_username TEXT,
    prize_json TEXT,
    created_at DOUBLE PRECISION NOT NULL
);

CREATE TABLE IF NOT EXISTS tnnr_site_inbox (
    id BIGSERIAL PRIMARY KEY,
    user_id TEXT NOT NULL,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    source TEXT NOT NULL DEFAULT 'giveaway',
    created_at DOUBLE PRECISION NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tnnr_site_inbox_user
    ON tnnr_site_inbox (user_id, is_read, created_at DESC);
"""


def _ensure_schema() -> None:
    global _SCHEMA_READY
    if _SCHEMA_READY:
        return
    if not postgres_db.configured():
        raise RuntimeError("PostgreSQL is not configured.")
    with postgres_db.connection() as conn:
        conn.execute(_SCHEMA)
    _SCHEMA_READY = True


def is_enabled() -> bool:
    try:
        _ensure_schema()
        with postgres_db.connection() as conn:
            row = conn.execute(
                "SELECT enabled FROM giveaway_settings WHERE id=1"
            ).fetchone()
        return bool(row and row["enabled"])
    except Exception:
        return False


def set_enabled(enabled: bool) -> Dict[str, Any]:
    _ensure_schema()
    now = time.time()
    with postgres_db.connection() as conn:
        conn.execute(
            """INSERT INTO giveaway_settings (id, enabled, updated_at)
               VALUES (1, %s, %s)
               ON CONFLICT (id) DO UPDATE
               SET enabled=EXCLUDED.enabled, updated_at=EXCLUDED.updated_at""",
            (bool(enabled), now),
        )
    return {"ok": True, "enabled": bool(enabled)}


def _parse_prize_pool(raw: str) -> List[Dict[str, Any]]:
    try:
        data = json.loads(raw or "[]")
    except json.JSONDecodeError:
        return []
    if not isinstance(data, list):
        return []
    out: List[Dict[str, Any]] = []
    for item in data:
        if not isinstance(item, dict):
            continue
        kind = str(item.get("kind") or "").lower()
        if kind == "credits":
            try:
                amount = int(item.get("amount") or 0)
            except (TypeError, ValueError):
                continue
            if amount <= 0:
                continue
            out.append({
                "kind": "credits",
                "amount": amount,
                "label": f"{amount:,} Credits",
            })
        elif kind in {"cpm1", "cpm2", "cpm1_account", "cpm2_account"}:
            line = str(item.get("line") or item.get("account") or "").strip()
            if not line or ":" not in line:
                continue
            norm = "cpm1" if kind.startswith("cpm1") else "cpm2"
            out.append({
                "kind": norm,
                "line": line,
                "label": f"{norm.upper()} Account",
            })
    return out


def current_giveaway() -> Optional[Dict[str, Any]]:
    _ensure_schema()
    with postgres_db.connection() as conn:
        row = conn.execute(
            """SELECT * FROM giveaways
               ORDER BY created_at DESC LIMIT 1"""
        ).fetchone()
    if not row:
        return None
    return _public_giveaway(row)


def _public_giveaway(row: Any) -> Dict[str, Any]:
    pool = _parse_prize_pool(row["prize_pool_json"])
    winner_prize = None
    if row["winner_prize_json"]:
        try:
            winner_prize = json.loads(row["winner_prize_json"])
        except json.JSONDecodeError:
            winner_prize = None
    entries = list_entries(row["giveaway_id"])
    winners = _winners_for(row["giveaway_id"])
    return {
        "giveaway_id": row["giveaway_id"],
        "title": row["title"] or "Giveaway!",
        "status": row["status"],
        "prize_count": len(pool),
        "prizes": [
            {"kind": p["kind"], "label": p["label"], "amount": p.get("amount")}
            for p in pool
        ],
        "entry_count": len(entries),
        "entries": entries,
        "winners": winners,
        "winner_user_id": row["winner_user_id"],
        "winner_username": row["winner_username"],
        "winner_prize": winner_prize,
        "message": row["message"] or "",
        "finished": row["status"] == "finished",
        "created_at": float(row["created_at"] or 0),
        "updated_at": float(row["updated_at"] or 0),
        "finished_at": float(row["finished_at"] or 0) if row["finished_at"] else None,
    }


def list_entries(giveaway_id: str) -> List[Dict[str, str]]:
    with postgres_db.connection() as conn:
        rows = conn.execute(
            """SELECT site_user_id, username, created_at
               FROM giveaway_entries WHERE giveaway_id=%s
               ORDER BY created_at ASC""",
            (giveaway_id,),
        ).fetchall()
    return [
        {
            "site_user_id": r["site_user_id"],
            "username": r["username"],
            "created_at": float(r["created_at"] or 0),
        }
        for r in rows
    ]


def create_or_update_setup(
    title: str,
    credit_amounts: List[int],
    cpm1_lines: List[str],
    cpm2_lines: List[str],
) -> Dict[str, Any]:
    """Create a new giveaway in setup (or replace unfinished setup)."""
    _ensure_schema()
    title = (title or "Giveaway!").strip()[:80] or "Giveaway!"
    pool: List[Dict[str, Any]] = []
    for amount in credit_amounts:
        try:
            n = int(amount)
        except (TypeError, ValueError):
            continue
        if n > 0:
            pool.append({
                "kind": "credits",
                "amount": n,
                "label": f"{n:,} Credits",
            })
    for line in cpm1_lines:
        line = line.strip()
        if line and ":" in line:
            pool.append({"kind": "cpm1", "line": line, "label": "CPM1 Account"})
    for line in cpm2_lines:
        line = line.strip()
        if line and ":" in line:
            pool.append({"kind": "cpm2", "line": line, "label": "CPM2 Account"})
    if not pool:
        return {"ok": False, "message": "Add at least one prize (credits or account line)."}

    now = time.time()
    giveaway_id = uuid.uuid4().hex
    with postgres_db.connection() as conn:
        with conn.transaction():
            # Close any prior non-finished giveaway so the new one is current.
            conn.execute(
                """UPDATE giveaways SET status='finished',
                   message=COALESCE(NULLIF(message,''), 'Superseded by a new giveaway setup.'),
                   updated_at=%s, finished_at=COALESCE(finished_at, %s)
                   WHERE status IN ('setup', 'queueing', 'spinning')""",
                (now, now),
            )
            conn.execute(
                """INSERT INTO giveaways
                   (giveaway_id, title, status, prize_pool_json, message,
                    created_at, updated_at)
                   VALUES (%s, %s, 'setup', %s, %s, %s, %s)""",
                (
                    giveaway_id,
                    title,
                    json.dumps(pool),
                    f"Setup ready · {len(pool)} prize(s)",
                    now,
                    now,
                ),
            )
    return {
        "ok": True,
        "giveaway_id": giveaway_id,
        "prize_count": len(pool),
        "message": f"Giveaway setup saved with {len(pool)} prize(s).",
    }


def start_queueing() -> Dict[str, Any]:
    _ensure_schema()
    g = current_giveaway()
    if not g:
        return {"ok": False, "message": "Create a giveaway setup first."}
    if g["status"] not in {"setup", "queueing"}:
        return {
            "ok": False,
            "message": "Current giveaway already finished. Create a new setup first.",
        }
    now = time.time()
    with postgres_db.connection() as conn:
        conn.execute(
            """UPDATE giveaways SET status='queueing',
               message='Queueing open — enter your username to join.',
               updated_at=%s WHERE giveaway_id=%s""",
            (now, g["giveaway_id"]),
        )
    return {"ok": True, "message": "Queueing is now open."}


def join(
    site_user_id: str,
    username: str,
) -> Dict[str, Any]:
    """Register an entrant. site_user_id must come from the authenticated session."""
    _ensure_schema()
    site_user_id = str(site_user_id or "").strip()
    username = re.sub(r"\s+", " ", (username or "").strip())[:40]
    if not site_user_id:
        return {"ok": False, "message": "Sign in with your site account to join."}
    if len(username) < 1:
        username = "Player"
    g = current_giveaway()
    if not g or g["status"] != "queueing":
        return {"ok": False, "message": "Queueing is not open right now."}
    now = time.time()
    try:
        with postgres_db.connection() as conn:
            conn.execute(
                """INSERT INTO giveaway_entries
                   (giveaway_id, site_user_id, username, created_at)
                   VALUES (%s, %s, %s, %s)
                   ON CONFLICT (giveaway_id, site_user_id) DO UPDATE
                   SET username=EXCLUDED.username""",
                (g["giveaway_id"], site_user_id, username, now),
            )
            conn.execute(
                "UPDATE giveaways SET updated_at=%s WHERE giveaway_id=%s",
                (now, g["giveaway_id"]),
            )
    except Exception as exc:
        return {"ok": False, "message": f"Unable to join: {exc}"}
    return {
        "ok": True,
        "message": f"You're in as {username}!",
        "site_user_id": site_user_id,
        "username": username,
    }


def _deliver_prize(user_id: str, username: str, prize: Dict[str, Any]) -> str:
    """Grant credits / deliver account details via inbox. Returns delivery note."""
    notes: List[str] = []
    kind = prize.get("kind")

    if kind == "credits":
        amount = int(prize.get("amount") or 0)
        if amount > 0 and accounts is not None:
            try:
                user = accounts.get_user(user_id) or {}
                current = int(user.get("balance") or user.get("credits") or 0)
                target = current + amount
                result = accounts.set_balance(user_id, target)
                if isinstance(result, dict) and result.get("ok") is False:
                    notes.append(str(result.get("message") or "Credit grant failed"))
                else:
                    notes.append(f"Added {amount:,} credits (balance → {target:,})")
            except Exception as exc:
                notes.append(f"Credit grant error: {exc}")
        else:
            notes.append(f"{amount:,} credits (manual review — accounts module unavailable)")

    # Always send inbox message with prize details
    title = "🎁 Giveaway prize!"
    if kind == "credits":
        body = (
            f"Congratulations {username}!\n\n"
            f"You won {int(prize.get('amount') or 0):,} site credits from the Giveaway spinner.\n"
            f"Credits have been added to your account balance."
        )
    elif kind in {"cpm1", "cpm2"}:
        label = kind.upper()
        line = str(prize.get("line") or "")
        body = (
            f"Congratulations {username}!\n\n"
            f"You won a {label} account from the Giveaway spinner.\n\n"
            f"Account credentials:\n{line}\n\n"
            f"Keep this message private. Change the password after login if possible."
        )
    else:
        body = f"Congratulations {username}! You won: {prize.get('label') or 'a prize'}."

    delivered = _send_inbox(user_id, title, body)
    notes.append("Inbox: " + ("sent" if delivered else "queued/unavailable"))
    return "; ".join(notes)



def _try_community_inbox(user_id: str, title: str, body: str) -> bool:
    """Probe community module for any single-user inbox helper."""
    if community is None:
        return False
    uid = str(user_id)
    candidates = (
        "send_inbox",
        "inbox_send",
        "inbox_add",
        "inbox_create",
        "inbox_notify",
        "send_message",
        "send_user_message",
        "notify_user",
        "admin_send_inbox",
        "admin_inbox_send",
        "create_inbox_message",
        "post_inbox",
    )
    kw_variants = (
        {"user_id": uid, "title": title, "body": body},
        {"site_user_id": uid, "title": title, "body": body},
        {"to_user_id": uid, "title": title, "body": body},
        {"user_id": uid, "subject": title, "message": body},
        {"user_id": uid, "subject": title, "body": body},
        {"uid": uid, "title": title, "body": body},
        {"user_id": uid, "title": title, "content": body},
        {"user_id": uid, "title": title, "text": body},
    )
    for name in candidates:
        fn = getattr(community, name, None)
        if not callable(fn):
            continue
        for args in ((uid, title, body), (title, body, uid), (uid, body)):
            try:
                result = fn(*args)
                if result is False:
                    continue
                return True
            except TypeError:
                continue
            except Exception:
                continue
        for kwargs in kw_variants:
            try:
                result = fn(**kwargs)
                if result is False:
                    continue
                return True
            except TypeError:
                continue
            except Exception:
                continue
    return False


def _discover_inbox_tables(conn) -> List[str]:
    rows = conn.execute(
        """SELECT table_name FROM information_schema.tables
           WHERE table_schema='public'
             AND (
               table_name ILIKE '%inbox%'
               OR table_name ILIKE '%notification%'
               OR table_name ILIKE '%site_message%'
               OR table_name ILIKE '%user_message%'
             )"""
    ).fetchall()
    return [str(r["table_name"] if isinstance(r, dict) else r[0]) for r in rows]


def _table_columns(conn, table: str) -> List[str]:
    rows = conn.execute(
        """SELECT column_name FROM information_schema.columns
           WHERE table_schema='public' AND table_name=%s""",
        (table,),
    ).fetchall()
    return [str(r["column_name"] if isinstance(r, dict) else r[0]) for r in rows]


def _sql_inbox_insert(user_id: str, title: str, body: str) -> bool:
    """Insert into whatever inbox-like table exists in Postgres."""
    now = time.time()
    uid = str(user_id)
    try:
        with postgres_db.connection() as conn:
            tables = _discover_inbox_tables(conn)
            preferred = [
                "inbox_messages",
                "community_inbox",
                "site_inbox",
                "user_inbox",
                "inbox",
                "notifications",
                "site_messages",
                "user_messages",
            ]
            ordered = [t for t in preferred if t in tables] + [
                t for t in tables if t not in preferred
            ]
            for table in ordered:
                cols = {c.lower(): c for c in _table_columns(conn, table)}
                user_col = None
                for key in (
                    "user_id", "site_user_id", "to_user_id", "recipient_id",
                    "owner_id", "uid",
                ):
                    if key in cols:
                        user_col = cols[key]
                        break
                title_col = None
                for key in ("title", "subject", "heading"):
                    if key in cols:
                        title_col = cols[key]
                        break
                body_col = None
                for key in ("body", "message", "content", "text", "detail"):
                    if key in cols:
                        body_col = cols[key]
                        break
                if not user_col or not body_col:
                    continue
                insert_cols = [user_col]
                values: List[Any] = [uid]
                if title_col:
                    insert_cols.append(title_col)
                    values.append(title)
                insert_cols.append(body_col)
                values.append(body)
                for key, val in (
                    ("created_at", now),
                    ("updated_at", now),
                    ("sent_at", now),
                ):
                    if key in cols:
                        insert_cols.append(cols[key])
                        values.append(val)
                for key, val in (
                    ("is_read", False),
                    ("read", False),
                    ("unread", True),
                    ("seen", False),
                ):
                    if key in cols:
                        insert_cols.append(cols[key])
                        values.append(val)
                for key, val in (
                    ("from_user_id", "system"),
                    ("sender", "system"),
                    ("kind", "giveaway"),
                    ("type", "giveaway"),
                    ("source", "giveaway"),
                ):
                    if key in cols:
                        insert_cols.append(cols[key])
                        values.append(val)
                placeholders = ", ".join(["%s"] * len(values))
                col_sql = ", ".join(insert_cols)
                try:
                    conn.execute(
                        f"INSERT INTO {table} ({col_sql}) VALUES ({placeholders})",
                        tuple(values),
                    )
                    return True
                except Exception:
                    continue
    except Exception:
        return False
    return False


def _send_inbox(user_id: str, title: str, body: str) -> bool:
    """Deliver a private inbox message.

    Always writes to tnnr_site_inbox (merged into the public Inbox page).
    Also tries community APIs / discovered tables when available.
    """
    _ensure_schema()
    uid = str(user_id)
    title = (title or "Message")[:120]
    body = (body or "")[:4000]
    wrote = False
    try:
        with postgres_db.connection() as conn:
            conn.execute(
                """INSERT INTO tnnr_site_inbox
                   (user_id, title, body, is_read, source, created_at)
                   VALUES (%s, %s, %s, FALSE, 'giveaway', %s)""",
                (uid, title, body, time.time()),
            )
        wrote = True
    except Exception:
        wrote = False
    # Best-effort mirrors into community / other tables
    try:
        _try_community_inbox(uid, title, body)
    except Exception:
        pass
    try:
        _sql_inbox_insert(uid, title, body)
    except Exception:
        pass
    return wrote


def list_site_inbox(user_id: str, limit: int = 100) -> List[Dict[str, Any]]:
    """Messages from the guaranteed giveaway/system inbox table."""
    _ensure_schema()
    uid = str(user_id or "")
    if not uid:
        return []
    with postgres_db.connection() as conn:
        rows = conn.execute(
            """SELECT id, user_id, title, body, is_read, source, created_at
               FROM tnnr_site_inbox
               WHERE user_id=%s
               ORDER BY created_at DESC
               LIMIT %s""",
            (uid, max(1, min(500, int(limit)))),
        ).fetchall()
    out = []
    for r in rows:
        out.append({
            "id": f"tnnr-{r['id']}",
            "user_id": r["user_id"],
            "title": r["title"],
            "subject": r["title"],
            "body": r["body"],
            "message": r["body"],
            "content": r["body"],
            "is_read": bool(r["is_read"]),
            "read": bool(r["is_read"]),
            "unread": not bool(r["is_read"]),
            "source": r["source"] or "giveaway",
            "created_at": float(r["created_at"] or 0),
            "timestamp": float(r["created_at"] or 0),
        })
    return out


def site_inbox_unread_count(user_id: str) -> int:
    _ensure_schema()
    uid = str(user_id or "")
    if not uid:
        return 0
    with postgres_db.connection() as conn:
        row = conn.execute(
            """SELECT COUNT(*) AS n FROM tnnr_site_inbox
               WHERE user_id=%s AND is_read=FALSE""",
            (uid,),
        ).fetchone()
    return int((row["n"] if row else 0) or 0)


def site_inbox_mark_all_read(user_id: str) -> None:
    _ensure_schema()
    uid = str(user_id or "")
    if not uid:
        return
    with postgres_db.connection() as conn:
        conn.execute(
            """UPDATE tnnr_site_inbox SET is_read=TRUE
               WHERE user_id=%s AND is_read=FALSE""",
            (uid,),
        )


def resolve_user(username_or_id: str) -> Optional[Dict[str, str]]:
    """Resolve giveaway username or site user id → {site_user_id, username}."""
    _ensure_schema()
    raw = (username_or_id or "").strip()
    if not raw:
        return None
    with postgres_db.connection() as conn:
        row = conn.execute(
            """SELECT site_user_id, username FROM giveaway_entries
               WHERE site_user_id=%s
               ORDER BY created_at DESC LIMIT 1""",
            (raw,),
        ).fetchone()
        if row:
            return {"site_user_id": row["site_user_id"], "username": row["username"]}
        row = conn.execute(
            """SELECT site_user_id, username FROM giveaway_entries
               WHERE LOWER(username)=LOWER(%s)
               ORDER BY created_at DESC LIMIT 1""",
            (raw,),
        ).fetchone()
        if row:
            return {"site_user_id": row["site_user_id"], "username": row["username"]}
        row = conn.execute(
            """SELECT winner_user_id AS site_user_id, winner_username AS username
               FROM giveaway_history
               WHERE winner_user_id=%s OR LOWER(winner_username)=LOWER(%s)
               ORDER BY id DESC LIMIT 1""",
            (raw, raw),
        ).fetchone()
        if row:
            return {"site_user_id": row["site_user_id"], "username": row["username"]}
    if accounts is not None:
        try:
            user = accounts.get_user(raw)
            if user:
                return {
                    "site_user_id": str(user.get("user_id") or raw),
                    "username": str(
                        user.get("username")
                        or user.get("display_name")
                        or user.get("email")
                        or raw
                    ),
                }
        except Exception:
            pass
    return None


def admin_send_inbox(
    username_or_id: str,
    title: str,
    body: str,
) -> Dict[str, Any]:
    """Manual inbox send from admin panel (username or site user id)."""
    _ensure_schema()
    title = (title or "").strip()[:120]
    body = (body or "").strip()[:4000]
    if not title or not body:
        return {"ok": False, "message": "Title and body are required."}
    resolved = resolve_user(username_or_id)
    if not resolved:
        if re.fullmatch(r"[a-zA-Z0-9_-]{6,64}", (username_or_id or "").strip()):
            resolved = {
                "site_user_id": username_or_id.strip(),
                "username": username_or_id.strip(),
            }
        else:
            return {
                "ok": False,
                "message": "Could not resolve that username or site user ID.",
            }
    ok = _send_inbox(resolved["site_user_id"], title, body)
    if not ok:
        return {
            "ok": False,
            "message": (
                f"Resolved {resolved['username']} → {resolved['site_user_id']} "
                "but inbox delivery failed (no compatible inbox table/API)."
            ),
            "site_user_id": resolved["site_user_id"],
            "username": resolved["username"],
        }
    return {
        "ok": True,
        "message": (
            f"Inbox message sent to {resolved['username']} "
            f"({resolved['site_user_id']})."
        ),
        "site_user_id": resolved["site_user_id"],
        "username": resolved["username"],
    }


def resend_prize_to_winner(username_or_id: str) -> Dict[str, Any]:
    """Re-send the latest giveaway prize text for a winner via inbox."""
    _ensure_schema()
    resolved = resolve_user(username_or_id)
    if not resolved:
        return {"ok": False, "message": "Could not resolve username or site user ID."}
    with postgres_db.connection() as conn:
        row = conn.execute(
            """SELECT prize_json, winner_username FROM giveaway_history
               WHERE winner_user_id=%s OR LOWER(winner_username)=LOWER(%s)
               ORDER BY id DESC LIMIT 1""",
            (resolved["site_user_id"], resolved["username"]),
        ).fetchone()
    if not row:
        return {"ok": False, "message": "No giveaway prize history for that user."}
    try:
        prize = json.loads(row["prize_json"] or "{}")
    except json.JSONDecodeError:
        prize = {}
    note = _deliver_prize(
        resolved["site_user_id"],
        resolved["username"] or row["winner_username"],
        prize,
    )
    return {
        "ok": True,
        "message": f"Re-sent prize to {resolved['username']}: {note}",
        "site_user_id": resolved["site_user_id"],
        "username": resolved["username"],
        "delivery": note,
    }



def _winners_for(giveaway_id: str) -> List[Dict[str, Any]]:
    """Public winner list for one giveaway (no account passwords)."""
    with postgres_db.connection() as conn:
        rows = conn.execute(
            """SELECT winner_user_id, winner_username, prize_json, created_at
               FROM giveaway_history
               WHERE giveaway_id=%s
               ORDER BY id ASC""",
            (giveaway_id,),
        ).fetchall()
    out: List[Dict[str, Any]] = []
    for r in rows:
        try:
            prize = json.loads(r["prize_json"] or "{}")
        except json.JSONDecodeError:
            prize = {}
        public_prize = {
            "kind": prize.get("kind"),
            "label": prize.get("label") or prize.get("kind") or "Prize",
        }
        if prize.get("kind") == "credits" and prize.get("amount") is not None:
            public_prize["amount"] = prize.get("amount")
        out.append({
            "winner_user_id": r["winner_user_id"],
            "winner_username": r["winner_username"],
            "prize": public_prize,
            "created_at": float(r["created_at"] or 0),
        })
    return out


def start_spinner() -> Dict[str, Any]:
    """Award every remaining prize to unique random entrants (sequential winners).

    Keeps spinning through the full prize pool in one admin action. Each winner
    is removed from the eligible pool so they cannot win twice. Prizes are
    delivered privately via the website inbox.
    """
    _ensure_schema()
    g = current_giveaway()
    if not g:
        return {"ok": False, "message": "No giveaway found."}
    if g["status"] not in {"queueing", "spinning"}:
        return {
            "ok": False,
            "message": "Open queueing first, then start the spinner.",
        }
    entries = list(g["entries"])
    if not entries:
        return {"ok": False, "message": "No one has joined the queue yet."}

    with postgres_db.connection() as conn:
        row = conn.execute(
            "SELECT prize_pool_json FROM giveaways WHERE giveaway_id=%s",
            (g["giveaway_id"],),
        ).fetchone()
    pool = _parse_prize_pool(row["prize_pool_json"] if row else "[]")
    if not pool:
        return {"ok": False, "message": "Prize pool is empty."}

    # Already-won users on this giveaway stay out of the pool
    already = {w["winner_user_id"] for w in _winners_for(g["giveaway_id"])}
    eligible = [e for e in entries if e["site_user_id"] not in already]
    if not eligible:
        return {"ok": False, "message": "Every entrant has already won a prize."}

    now = time.time()
    spin_seed = uuid.uuid4().hex
    awarded: List[Dict[str, Any]] = []
    deliveries: List[str] = []
    remaining_pool = list(pool)
    remaining_eligible = list(eligible)

    # One unique winner per prize, until prizes or entrants run out
    while remaining_pool and remaining_eligible:
        prize = remaining_pool.pop(0)  # preserve admin prize order
        winner = random.choice(remaining_eligible)
        remaining_eligible = [
            e for e in remaining_eligible
            if e["site_user_id"] != winner["site_user_id"]
        ]
        delivery = _deliver_prize(
            winner["site_user_id"], winner["username"], prize
        )
        deliveries.append(delivery)
        public_prize = {
            "kind": prize["kind"],
            "label": prize.get("label") or prize["kind"],
        }
        if prize["kind"] == "credits":
            public_prize["amount"] = prize.get("amount")
        awarded.append({
            "winner_user_id": winner["site_user_id"],
            "winner_username": winner["username"],
            "prize": public_prize,
        })
        with postgres_db.connection() as conn:
            conn.execute(
                """INSERT INTO giveaway_history
                   (giveaway_id, winner_user_id, winner_username, prize_json, created_at)
                   VALUES (%s, %s, %s, %s, %s)""",
                (
                    g["giveaway_id"],
                    winner["site_user_id"],
                    winner["username"],
                    json.dumps(prize),
                    now,
                ),
            )

    last = awarded[-1] if awarded else None
    names = ", ".join(a["winner_username"] for a in awarded)
    with postgres_db.connection() as conn:
        conn.execute(
            """UPDATE giveaways SET
               status='finished',
               winner_user_id=%s,
               winner_username=%s,
               winner_prize_json=%s,
               prize_pool_json=%s,
               spin_seed=%s,
               message=%s,
               updated_at=%s,
               finished_at=%s
               WHERE giveaway_id=%s""",
            (
                (last or {}).get("winner_user_id"),
                (last or {}).get("winner_username"),
                json.dumps((last or {}).get("prize") or {}),
                json.dumps(remaining_pool),
                spin_seed,
                f"{len(awarded)} winner(s): {names}",
                now,
                now,
                g["giveaway_id"],
            ),
        )

    return {
        "ok": True,
        "giveaway_id": g["giveaway_id"],
        "winners": awarded,
        # backward-compatible single-winner fields = last award
        "winner_user_id": (last or {}).get("winner_user_id"),
        "winner_username": (last or {}).get("winner_username"),
        "prize": (last or {}).get("prize"),
        "entry_count": len(entries),
        "entries": entries,
        "spin_seed": spin_seed,
        "delivery": " | ".join(deliveries),
        "message": f"Awarded {len(awarded)} prize(s): {names}",
    }


def list_giveaway_batches(limit: int = 10) -> List[Dict[str, Any]]:
    """Recent giveaways with full winner rows (for admin resend UI)."""
    _ensure_schema()
    with postgres_db.connection() as conn:
        batches = conn.execute(
            """SELECT giveaway_id, title, status, message, created_at, finished_at
               FROM giveaways
               ORDER BY created_at DESC
               LIMIT %s""",
            (max(1, min(50, int(limit))),),
        ).fetchall()
        out: List[Dict[str, Any]] = []
        for b in batches:
            gid = b["giveaway_id"]
            winners = conn.execute(
                """SELECT id, winner_user_id, winner_username, prize_json, created_at
                   FROM giveaway_history
                   WHERE giveaway_id=%s
                   ORDER BY id ASC""",
                (gid,),
            ).fetchall()
            winner_rows = []
            for w in winners:
                try:
                    prize = json.loads(w["prize_json"] or "{}")
                except json.JSONDecodeError:
                    prize = {}
                winner_rows.append({
                    "history_id": int(w["id"]),
                    "winner_user_id": w["winner_user_id"],
                    "winner_username": w["winner_username"],
                    "prize_label": prize.get("label") or prize.get("kind") or "Prize",
                    "prize_kind": prize.get("kind"),
                    "created_at": float(w["created_at"] or 0),
                })
            out.append({
                "giveaway_id": gid,
                "title": b["title"] or "Giveaway!",
                "status": b["status"],
                "message": b["message"] or "",
                "created_at": float(b["created_at"] or 0),
                "finished_at": float(b["finished_at"] or 0) if b["finished_at"] else None,
                "winner_count": len(winner_rows),
                "winners": winner_rows,
            })
    return out


def resend_all_prizes_for_giveaway(giveaway_id: str) -> Dict[str, Any]:
    """Re-send inbox prize messages for every winner on a giveaway."""
    _ensure_schema()
    gid = (giveaway_id or "").strip()
    if not re.fullmatch(r"[a-f0-9]{32}", gid):
        return {"ok": False, "message": "Invalid giveaway id."}
    with postgres_db.connection() as conn:
        rows = conn.execute(
            """SELECT winner_user_id, winner_username, prize_json
               FROM giveaway_history
               WHERE giveaway_id=%s
               ORDER BY id ASC""",
            (gid,),
        ).fetchall()
    if not rows:
        return {"ok": False, "message": "No winners stored for that giveaway."}

    ok_n = 0
    fail_n = 0
    details: List[str] = []
    for r in rows:
        try:
            prize = json.loads(r["prize_json"] or "{}")
        except json.JSONDecodeError:
            prize = {}
        username = r["winner_username"] or "?"
        uid = r["winner_user_id"]
        try:
            note = _deliver_prize(uid, username, prize)
            # treat explicit inbox failure in note
            if "Inbox: sent" in note or "balance →" in note or "credits" in note.lower():
                if "Inbox: sent" in note or "Inbox: queued" not in note:
                    ok_n += 1
                else:
                    # still count if credits applied even if inbox weak
                    ok_n += 1
            else:
                if "Inbox: sent" in note:
                    ok_n += 1
                else:
                    # delivery attempted; mark ok if _deliver_prize returned without raise
                    if "unavailable" in note.lower() or "failed" in note.lower():
                        fail_n += 1
                    else:
                        ok_n += 1
            details.append(f"{username}: {note}")
        except Exception as exc:
            fail_n += 1
            details.append(f"{username}: ERROR {exc}")

    return {
        "ok": True,
        "message": (
            f"Resend finished for giveaway {gid[:8]}… · "
            f"attempted={len(rows)} ok≈{ok_n} fail≈{fail_n}"
        ),
        "attempted": len(rows),
        "ok_count": ok_n,
        "fail_count": fail_n,
        "details": details[:50],
    }


def resend_prize_by_history_id(history_id: int) -> Dict[str, Any]:
    """Re-send one prize row from giveaway_history by id."""
    _ensure_schema()
    try:
        hid = int(history_id)
    except (TypeError, ValueError):
        return {"ok": False, "message": "Invalid history id."}
    with postgres_db.connection() as conn:
        row = conn.execute(
            """SELECT winner_user_id, winner_username, prize_json
               FROM giveaway_history WHERE id=%s""",
            (hid,),
        ).fetchone()
    if not row:
        return {"ok": False, "message": "Prize history row not found."}
    try:
        prize = json.loads(row["prize_json"] or "{}")
    except json.JSONDecodeError:
        prize = {}
    note = _deliver_prize(
        row["winner_user_id"], row["winner_username"] or "winner", prize
    )
    return {
        "ok": True,
        "message": f"Re-sent to {row['winner_username']}: {note}",
        "delivery": note,
        "username": row["winner_username"],
        "site_user_id": row["winner_user_id"],
    }


def admin_snapshot() -> Dict[str, Any]:
    _ensure_schema()
    enabled = is_enabled()
    g = current_giveaway()
    batches = list_giveaway_batches(8)
    history: List[Dict[str, Any]] = []
    for batch in batches:
        for w in batch.get("winners") or []:
            history.append({
                "giveaway_id": batch["giveaway_id"],
                "winner_username": w["winner_username"],
                "prize_label": w["prize_label"],
                "created_at": w["created_at"],
            })
    return {
        "enabled": enabled,
        "current": g,
        "history": history[:40],
        "batches": batches,
    }
