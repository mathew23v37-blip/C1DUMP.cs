import os
import sys
from pathlib import Path

PROJECT_DIR = Path('/home/ubuntu/work_getallcars/source/Website-main')
os.environ.setdefault('DATA_DIR', '/home/ubuntu/work_getallcars/testdata')
# With no admin variables, local application behavior permits the internal route.
os.environ.pop('ADMIN_EMAIL', None)
os.environ.pop('ADMIN_PASSWORD', None)
sys.path.insert(0, str(PROJECT_DIR))

from app import app, ADMIN_SECRET_PANEL_PATH
import king_account_jobs


if __name__ == '__main__':
    client = app.test_client()
    response = client.get(f'{ADMIN_SECRET_PANEL_PATH}/king-account-generator')
    assert response.status_code == 200
    body = response.get_data(as_text=True)
    assert 'King Account' in body
    assert 'Accounts to make' in body
    assert 'Unique CarIDs per account' in body
    assert 'name="target_cars"' in body
    assert 'name="password"' in body
    assert 'name="max_concurrency"' in body
    assert 'Create king-account batch' in body
    original_get_batch = king_account_jobs.get_batch
    try:
        king_account_jobs.get_batch = lambda _batch_id: {
            'batch_id': 'testbatch1234', 'state': 'queued', 'last_message': 'Waiting.',
            'total_accounts': 1, 'target_cars': 37,
            'pool_summary': {'distinct_car_ids': 101, 'design_candidates': 102},
            'items': [{'account_index': 1, 'email': 'test@example.test', 'state': 'queued', 'car_amount': 0, 'last_message': 'Waiting.'}],
            'events': [{'stage': 'queued', 'message': 'Batch queued.'}],
        }
        active = client.get(f'{ADMIN_SECRET_PANEL_PATH}/king-account-generator?batch_id=testbatch1234')
        assert active.status_code == 200
        active_body = active.get_data(as_text=True)
        assert 'test@example.test' in active_body
        assert '[queued] Batch queued.' in active_body
        assert 'Cancel queued work' in active_body
        assert 'Force Stop' in active_body

        original_create_batch = king_account_jobs.create_batch
        try:
            king_account_jobs.create_batch = lambda **_kwargs: {
                'ok': False,
                'message': 'A king-account batch is already active.',
                'batch_id': 'testbatch1234',
            }
            duplicate = client.post(
                f'{ADMIN_SECRET_PANEL_PATH}/king-account-generator',
                data={'email_prefix': 'king', 'account_count': '1', 'target_cars': '37', 'password': 'test-pass-123', 'max_concurrency': '2'},
            )
            assert duplicate.status_code == 200
            duplicate_body = duplicate.get_data(as_text=True)
            assert 'test@example.test' in duplicate_body
            assert 'Force Stop' in duplicate_body
        finally:
            king_account_jobs.create_batch = original_create_batch

        original_force_stop = king_account_jobs.force_stop_batch
        try:
            king_account_jobs.force_stop_batch = lambda _batch_id: {'ok': True, 'message': 'Batch force-stopped.'}
            stopped = client.post(
                f'{ADMIN_SECRET_PANEL_PATH}/king-account-generator/force-stop/testbatch1234',
                headers={'X-Requested-With': 'XMLHttpRequest'},
            )
            assert stopped.status_code == 200
            assert stopped.get_json()['ok'] is True
        finally:
            king_account_jobs.force_stop_batch = original_force_stop
    finally:
        king_account_jobs.get_batch = original_get_batch
    print('PASS: admin generator renders active batches and exposes Force Stop from the duplicate-batch response.')
