import aiohttp
import asyncio
import base64
import hashlib
import json
import logging
import os
import sqlite3
import struct
import time
import threading
import zlib
from copy import deepcopy
from typing import Any, Dict, List, Optional, Tuple

from config import data_path

try:
    import brotli
    HAS_BROTLI = True
except ImportError:  # pragma: no cover - optional dependency path
    HAS_BROTLI = False

try:
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import unpad
    HAS_CRYPTO = True
except ImportError:  # pragma: no cover - optional dependency path
    HAS_CRYPTO = False

logging.basicConfig(level=logging.INFO, format="%(asctime)s │ %(levelname)s │ %(message)s")
log = logging.getLogger("CPM-Web")

# Malik source constants, with environment-variable overrides for deployments.
CPM_FIREBASE_KEY_ENV = "CPM_FIREBASE_KEY"
# Endpoint order verified by the TNNR endpoint scanner. Environment overrides
# remain first so Railway configuration can still pin a specific route.
_DEFAULT_LOAD_URLS = [
    "https://europe-west1-cp-multiplayer.cloudfunctions.net/GetPlayerRecords4",
    "https://europe-west1-cp-multiplayer.cloudfunctions.net/GetPlayerRecords3",
]
_DEFAULT_SAVE_URLS = [
    "https://europe-west1-cp-multiplayer.cloudfunctions.net/SavePlayerRecordsPartially8",
    "https://europe-west1-cp-multiplayer.cloudfunctions.net/SavePlayerRecordsPartially7",
]
_DEFAULT_RANK_URLS = [
    "https://europe-west1-cp-multiplayer.cloudfunctions.net/SetUserRating6",
    "https://europe-west1-cp-multiplayer.cloudfunctions.net/SetUserRating5",
    "https://europe-west1-cp-multiplayer.cloudfunctions.net/SetUserRating2",
    "https://europe-west1-cp-multiplayer.cloudfunctions.net/SetUserRating1",
]

def _endpoint_urls(env_name: str, defaults: List[str]) -> List[str]:
    override = os.getenv(env_name, "").strip()
    # An older Railway variable may still point at the retired US region. Do
    # not let that stale configuration override the verified Europe endpoints.
    if "us-central1-cp-multiplayer.cloudfunctions.net" in override:
        log.warning("Ignoring stale US-region override for %s; using Europe endpoints.", env_name)
        override = ""
    urls = ([override] if override else []) + list(defaults)
    # Preserve order while removing duplicates.
    return list(dict.fromkeys(urls))

LOAD_URLS = _endpoint_urls("CPM_LOAD_URL", _DEFAULT_LOAD_URLS)
SAVE_URLS = _endpoint_urls("CPM_SAVE_URL", _DEFAULT_SAVE_URLS)
RANK_URLS = _endpoint_urls("CPM_RANK_URL", _DEFAULT_RANK_URLS)
# Compatibility constants for code/imports that still reference the singular names.
LOAD_URL = LOAD_URLS[0]
SAVE_URL = SAVE_URLS[0]
RANK_URL = RANK_URLS[0]
MAX_MONEY = 50_000_000
MAX_COIN = 500_000

def firebase_key() -> str:
    key = os.getenv(CPM_FIREBASE_KEY_ENV, "").strip()
    if not key:
        raise RuntimeError(f"Missing required environment variable {CPM_FIREBASE_KEY_ENV} for CPM nuker Firebase authentication.")
    return key


GAME_HEADERS = {
    "Accept": "*/*",
    "Accept-Encoding": "gzip",
    "Content-Type": "application/json",
    "User-Agent": "UnityPlayer/2022.3.62f2 (UnityWebRequest/1.0, libcurl/8.10.1-DEV)",
    "X-Unity-Version": "2022.3.62f2",
}


def _env_int(name: str, default: int) -> int:
    try:
        return max(1, int(os.getenv(name, str(default))))
    except (TypeError, ValueError):
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return max(0.1, float(os.getenv(name, str(default))))
    except (TypeError, ValueError):
        return default


class _LoopSessionPool:
    """Persistent aiohttp clients scoped to the currently running event loop.

    aiohttp ClientSession instances are bound to the loop that created them,
    so this pool intentionally keeps one reusable session per live loop/thread
    instead of creating a connector for every request.
    """

    def __init__(self):
        self._sessions: Dict[int, aiohttp.ClientSession] = {}
        self._lock = threading.RLock()

    async def get(self) -> aiohttp.ClientSession:
        # Direct connection — site login / modifiers are not proxied.
        # Bulk account gen uses its own proxied session for Firebase signup only.
        loop = asyncio.get_running_loop()
        key = id(loop)
        session = self._sessions.get(key)
        if session is not None and not session.closed:
            return session

        connector = aiohttp.TCPConnector(
            ssl=False,
            limit=_env_int("CPM_HTTP_CONNECTION_LIMIT", 64),
            limit_per_host=_env_int("CPM_HTTP_CONNECTION_LIMIT_PER_HOST", 24),
            ttl_dns_cache=_env_int("CPM_HTTP_DNS_CACHE_SECONDS", 300),
            keepalive_timeout=_env_float("CPM_HTTP_KEEPALIVE_SECONDS", 30.0),
            enable_cleanup_closed=True,
        )
        timeout = aiohttp.ClientTimeout(
            total=_env_float("CPM_HTTP_TIMEOUT_TOTAL", 30.0),
            connect=_env_float("CPM_HTTP_TIMEOUT_CONNECT", 10.0),
            sock_connect=_env_float("CPM_HTTP_TIMEOUT_SOCK_CONNECT", 10.0),
            sock_read=_env_float("CPM_HTTP_TIMEOUT_SOCK_READ", 30.0),
        )
        session = aiohttp.ClientSession(timeout=timeout, connector=connector)
        with self._lock:
            old = self._sessions.get(key)
            if old is not None and old is not session and not old.closed:
                await old.close()
            self._sessions[key] = session
        return session

    async def close_current_loop(self) -> None:
        loop = asyncio.get_running_loop()
        key = id(loop)
        with self._lock:
            session = self._sessions.pop(key, None)
        if session is not None and not session.closed:
            await session.close()

    async def close_all_reachable(self) -> None:
        # Safe for shutdown of the current process/thread loop; sessions bound
        # to already-closed loops are dropped from the registry.
        with self._lock:
            sessions = list(self._sessions.items())
            self._sessions.clear()
        for _, session in sessions:
            if not session.closed:
                try:
                    await session.close()
                except Exception:
                    log.debug("Ignoring aiohttp session close failure", exc_info=True)


def make_xor_key(uid: str) -> bytes:
    chars = list(str(uid or ""))
    if len(chars) >= 9:
        chars[1], chars[8] = chars[8], chars[1]
    if len(chars) >= 3:
        chars.pop(2)
    if len(chars) >= 5:
        chars.append(chars[4])
    key = "".join(chars).encode("utf-8")
    return key or b"0"


def xor_bytes(data: bytes, key: bytes) -> bytes:
    return bytes(data[i] ^ key[i % len(key)] for i in range(len(data)))


def decompress(data: bytes) -> Optional[bytes]:
    if HAS_BROTLI:
        try:
            return brotli.decompress(data)
        except Exception:
            pass
    for args in ((zlib.MAX_WBITS | 16,), tuple()):
        try:
            return zlib.decompress(data, *args)
        except Exception:
            pass
    return None


def decrypt_aes(data: bytes, key: bytes) -> Optional[bytes]:
    if not HAS_CRYPTO:
        return None
    try:
        cipher = AES.new(key[:16], AES.MODE_CBC, b"\x00" * 16)
        return unpad(cipher.decrypt(data), 16)
    except Exception:
        return None


def _md5(text: str) -> bytes:
    return hashlib.md5(str(text).encode()).digest()


def _sha1(text: str) -> bytes:
    return hashlib.sha1(str(text).encode()).digest()[:16]


def build_aes_keys(uid: str, password: Optional[str] = None, email: Optional[str] = None) -> List[bytes]:
    keys = [_md5("olzhas_carparking")]
    if password:
        keys.extend([_md5(password), _sha1(password)])
    if uid:
        keys.extend([_md5(uid), _sha1(uid)])
    if email:
        keys.append(_md5(email))
    return keys


class Reader:
    def __init__(self, data: bytes):
        self.buf = data
        self.pos = 0

    def has_bytes(self, n: int) -> bool:
        return self.pos + n <= len(self.buf)

    def read_byte(self) -> int:
        if not self.has_bytes(1):
            return 0
        value = self.buf[self.pos]
        self.pos += 1
        return value

    def read_int(self) -> int:
        if not self.has_bytes(4):
            self.pos = len(self.buf)
            return 0
        value = struct.unpack_from("<i", self.buf, self.pos)[0]
        self.pos += 4
        return value

    def read_float(self) -> float:
        if not self.has_bytes(4):
            self.pos = len(self.buf)
            return 0.0
        value = struct.unpack_from("<f", self.buf, self.pos)[0]
        self.pos += 4
        return value

    def read_string(self) -> str:
        marker = self.read_int()
        if marker in (0, -1):
            return ""
        length = (-marker) - 1 if marker < -1 else marker
        if marker < -1:
            self.read_int()
        length = max(0, min(length, 1_000_000))
        if not self.has_bytes(length):
            return ""
        text = self.buf[self.pos:self.pos + length].decode("utf-8", errors="replace")
        self.pos += length
        return text.replace("\x00", "").strip()

    def read_list(self, item_fn):
        count = self.read_int()
        if count <= 0 or count > 1_000_000:
            return []
        result = []
        for _ in range(count):
            if self.pos >= len(self.buf):
                break
            value = item_fn()
            if value is not None:
                result.append(value)
        return result

    def read_dict(self) -> Dict[int, int]:
        count = self.read_int()
        if count <= 0 or count > 1_000_000:
            return {}
        result = {}
        for _ in range(count):
            if self.pos >= len(self.buf):
                break
            result[self.read_int()] = self.read_int()
        return result

    def read_equipment(self) -> Optional[Dict[str, Any]]:
        if self.read_byte() == 0:
            return None
        return {
            "hair": self.read_list(self.read_int),
            "face": self.read_list(self.read_int),
            "beard": self.read_list(self.read_int),
            "cap": self.read_list(self.read_int),
            "mask": self.read_list(self.read_int),
            "top": self.read_list(self.read_int),
            "gloves": self.read_list(self.read_int),
            "bag": self.read_list(self.read_int),
            "pants": self.read_list(self.read_int),
            "shoes": self.read_list(self.read_int),
            "glasses": self.read_list(self.read_int),
            "SelectedEquipments": self.read_list(self.read_int),
            "Gender": self.read_int(),
        }


def parse_player(buf: bytes) -> Optional[Dict[str, Any]]:
    r = Reader(buf)
    if r.read_byte() == 0:
        return None
    player: Dict[str, Any] = {}
    player["Name"] = r.read_string()
    player["money"] = r.read_int()
    player["coin"] = r.read_int()
    player["localID"] = r.read_string()
    player["boughtFsos"] = r.read_list(r.read_int)

    def read_friend():
        r.read_byte()
        return {"id": r.read_string(), "Name": r.read_string(), "accountID": r.read_string()}

    player["FriendsID"] = r.read_list(read_friend)
    player["LevelsDoneTime"] = r.read_list(r.read_float)
    player["floats"] = r.read_list(r.read_float)
    player["integers"] = r.read_list(r.read_int)
    player["fcar"] = r.read_list(r.read_int)
    player["favouriteWheels"] = r.read_list(r.read_int)
    player["favouriteVinyls"] = r.read_list(r.read_int)
    player["favouriteEmojis"] = r.read_list(r.read_int)
    player["personEquipmentsMale"] = r.read_equipment()
    player["personEquipmentsFemale"] = r.read_equipment()

    if r.read_byte() == 0:
        player["platesData"] = None
    else:
        def read_vinyl():
            r.read_byte()
            def rv():
                return {"x": r.read_float(), "y": r.read_float(), "z": r.read_float()}
            return {"vectors": r.read_list(rv), "v": r.read_list(r.read_string),
                    "floats": r.read_list(r.read_float), "text": r.read_string()}
        def read_plate():
            r.read_byte()
            return {"plateId": r.read_int(), "frontCarId": r.read_int(),
                    "rearCarId": r.read_int(), "vinyls": r.read_list(read_vinyl)}
        player["platesData"] = {"allPlates": r.read_list(read_plate)}

    if r.read_byte() == 0:
        player["carIDnStatus"] = None
    else:
        player["carIDnStatus"] = {
            "carGeneratedIDs": r.read_list(r.read_string),
            "carStatus": r.read_list(r.read_int),
        }
    player["allData"] = r.read_string()
    player["flags"] = r.read_dict()
    player["animations"] = r.read_list(r.read_int)
    player["emojiPacks"] = r.read_list(r.read_int)
    player["wheels"] = r.read_list(r.read_int)
    player["boughtPoliceLights"] = r.read_list(r.read_int)
    player["boughtPoliceSirens"] = r.read_list(r.read_int)
    return player


def try_parse(buf: bytes) -> Optional[Dict[str, Any]]:
    candidates = [buf]
    first = decompress(buf)
    if first:
        candidates.append(first)
        second = decompress(first)
        if second:
            candidates.append(second)
    for candidate in candidates:
        if not candidate:
            continue
        if candidate[0] in (17, 23, 24):
            try:
                parsed = parse_player(candidate)
                if parsed and parsed.get("Name") is not None:
                    return parsed
            except Exception:
                pass
        try:
            clean = candidate[3:] if len(candidate) >= 3 and candidate[:2] == b"\xef\xbb" else candidate
            if clean and clean[0] == 123:
                return json.loads(clean.decode("utf-8"))
        except Exception:
            pass
    return None


def decrypt_player_record(base64_text: str, uid: str, password: Optional[str] = None, email: Optional[str] = None) -> Dict[str, Any]:
    try:
        buf = base64.b64decode(base64_text)
    except Exception:
        return {"success": False, "message": "Bad base64"}
    if len(buf) < 10:
        return {"success": False, "message": "Too small"}

    direct = try_parse(buf)
    if direct:
        return {"success": True, "record": direct}

    if uid:
        try:
            decoded = decompress(xor_bytes(buf, make_xor_key(uid)))
            if decoded:
                parsed = try_parse(decoded)
                if parsed:
                    return {"success": True, "record": parsed}
        except Exception:
            pass

    for key in build_aes_keys(uid or "", password, email):
        plain = decrypt_aes(buf, key)
        if not plain:
            continue
        parsed = try_parse(plain)
        if parsed:
            return {"success": True, "record": parsed}
    return {"success": False, "message": "Could not decrypt"}


class Writer:
    def __init__(self):
        self._p: List[bytes] = []

    def write_byte(self, v):
        self._p.append(bytes([int(v or 0) & 0xFF]))

    def write_int(self, v):
        self._p.append(struct.pack("<i", int(v or 0)))

    def write_float(self, v):
        self._p.append(struct.pack("<f", float(v or 0.0)))

    def write_string(self, s):
        if s is None:
            self._p.append(struct.pack("<i", -1))
            return
        s = str(s)
        if s == "":
            self._p.append(struct.pack("<i", 0))
            return
        enc = s.encode("utf-8")
        self._p.append(struct.pack("<ii", -(len(enc)) - 1, len(s)) + enc)

    def write_list(self, lst, fn):
        if lst is None:
            self._p.append(struct.pack("<i", -1))
            return
        self._p.append(struct.pack("<i", len(lst)))
        for item in lst:
            fn(item)

    def write_equipment(self, data):
        if not data:
            self.write_byte(0)
            return
        self.write_byte(13)
        for key in ["hair", "face", "beard", "cap", "mask", "top", "gloves", "bag", "pants", "shoes", "glasses", "SelectedEquipments"]:
            self.write_list(data.get(key, []), self.write_int)
        self.write_int(data.get("Gender", 0))

    def write_plates(self, data):
        if not data:
            self.write_byte(0)
            return
        self.write_byte(1)
        plates = data.get("allPlates", [])
        self._p.append(struct.pack("<i", len(plates)))
        for plate in plates:
            self.write_byte(4)
            self.write_int(plate.get("plateId", 0))
            self.write_int(plate.get("frontCarId", 0))
            self.write_int(plate.get("rearCarId", 0))
            vinyls = plate.get("vinyls", [])
            self._p.append(struct.pack("<i", len(vinyls)))
            for vinyl in vinyls:
                self.write_byte(4)
                vecs = vinyl.get("vectors", [])
                self._p.append(struct.pack("<i", len(vecs)))
                for vec in vecs:
                    self._p.append(struct.pack("<fff", vec.get("x", 0), vec.get("y", 0), vec.get("z", 0)))
                self.write_list(vinyl.get("v", []), self.write_string)
                self.write_list(vinyl.get("floats", []), self.write_float)
                self.write_string(vinyl.get("text", ""))

    def write_car_id_status(self, data):
        if not data:
            self.write_byte(0)
            return
        self.write_byte(2)
        self.write_list(data.get("carGeneratedIDs", []), self.write_string)
        self.write_list(data.get("carStatus", []), self.write_int)

    def to_bytes(self):
        return b"".join(self._p)


FIELD_MAPPING = [
    (1, "localID"), (2, "money"), (3, "Name"), (4, "coin"), (5, "allData"),
    (6, "boughtFsos"), (7, "boughtPoliceLights"), (8, "boughtPoliceSirens"),
    (9, "FriendsID"), (10, "LevelsDoneTime"), (11, "floats"), (12, "integers"),
    (13, "fcar"), (14, "favouriteWheels"), (15, "favouriteVinyls"),
    (16, "favouriteEmojis"), (18, "emojiPacks"),
    (41, "personEquipmentsMale"), (42, "personEquipmentsFemale"),
    (43, "platesData"), (44, "carIDnStatus"), (45, "flags"),
    (46, "animations"), (48, "wheels"),
]
INT_LIST_FIELDS = {6, 7, 8, 12, 13, 14, 15, 16, 18, 46, 48}
FLOAT_LIST_FIELDS = {10, 11}
ALWAYS_SEND = {"allData"}


def _field_modified(new_value, old_value) -> bool:
    if new_value is None and old_value is None:
        return False
    if new_value is None or old_value is None:
        return True
    if type(new_value) != type(old_value):
        return True
    if isinstance(new_value, (dict, list)):
        return json.dumps(new_value, sort_keys=True) != json.dumps(old_value, sort_keys=True)
    return new_value != old_value


def serialize_field(fid: int, value: Any) -> Optional[bytes]:
    w = Writer()
    if fid in (1, 3, 5):
        w.write_string(value)
        return w.to_bytes()
    if fid in (2, 4):
        w.write_int(value or 0)
        return w.to_bytes()
    if fid == 9:
        friends = value or []
        w._p.append(struct.pack("<i", len(friends)))
        for friend in friends:
            friend = friend or {}
            w.write_byte(3)
            w.write_string(friend.get("id", ""))
            w.write_string(friend.get("Name", ""))
            w.write_string(friend.get("accountID", ""))
        return w.to_bytes()
    if fid in INT_LIST_FIELDS:
        w.write_list(value or [], w.write_int)
        return w.to_bytes()
    if fid in FLOAT_LIST_FIELDS:
        w.write_list(value or [], w.write_float)
        return w.to_bytes()
    if fid in (41, 42):
        w.write_equipment(value)
        return w.to_bytes()
    if fid == 43:
        w.write_plates(value)
        return w.to_bytes()
    if fid == 44:
        w.write_car_id_status(value)
        return w.to_bytes()
    if fid == 45:
        flags = value or {}
        w._p.append(struct.pack("<i", len(flags)))
        for key, val in flags.items():
            w.write_int(int(key))
            w.write_int(int(val))
        return w.to_bytes()
    return None


def build_payload(record: Dict[str, Any], uid: str, original: Optional[Dict[str, Any]] = None,
                  force_fields: Optional[set] = None) -> str:
    force_fields = set(force_fields or [])
    fields = []
    for fid, key in FIELD_MAPPING:
        value = record.get(key)
        if value is None:
            continue
        if key in ALWAYS_SEND:
            should_send = isinstance(value, str) and len(value) > 0
        elif key in force_fields:
            should_send = True
        elif original is not None:
            should_send = _field_modified(value, original.get(key))
        else:
            should_send = True
        if not should_send:
            continue
        raw = serialize_field(fid, value)
        if raw is not None:
            fields.append((fid, raw))

    parts = [struct.pack("<i", len(fields))]
    for fid, raw in fields:
        parts.append(struct.pack("<hi", fid, len(raw)))
        parts.append(raw)
    combined = b"".join(parts)
    compressed = brotli.compress(combined) if HAS_BROTLI else zlib.compress(combined)
    encrypted = xor_bytes(compressed, make_xor_key(uid))
    return base64.b64encode(encrypted).decode("ascii")


class CPMNuker:
    def __init__(self, db_path: str | None = None):
        self.db_path = db_path or data_path("cpm_tokens.db")
        self.cache: Dict[str, Dict[str, Any]] = {}
        self._cache_lock = threading.RLock()
        self._http = _LoopSessionPool()
        self._redis = None
        self._redis_namespace = os.getenv("REDIS_NAMESPACE", "tnnr").strip() or "tnnr"
        self._redis_ttl = max(1800, int(os.getenv("CPM_REDIS_SESSION_TTL_SECONDS", "7200")))
        redis_runtime_flag = os.getenv("REDIS_RUNTIME_ENABLED", "auto").strip().lower()
        if os.getenv("REDIS_URL", "").strip() and redis_runtime_flag not in {"0", "false", "no", "off"}:
            from redis_jobs import get_redis

            self._redis = get_redis()
        else:
            self._init_db()

    def _redis_token_key(self, uid: int) -> str:
        return f"{self._redis_namespace}:cpm:token:{uid}"

    def _redis_record_key(self, cache_key: str) -> str:
        return f"{self._redis_namespace}:cpm:record:{cache_key}"

    def _redis_record_index_key(self, uid: int) -> str:
        return f"{self._redis_namespace}:cpm:record-index:{uid}"

    def _redis_backup_key(self, uid: int) -> str:
        return f"{self._redis_namespace}:cpm:backups:{uid}"

    def _connect(self):
        connection = sqlite3.connect(
            self.db_path,
            timeout=_env_float("CPM_SQLITE_BUSY_TIMEOUT_SECONDS", 10.0),
        )
        connection.execute(
            f"PRAGMA busy_timeout={int(_env_float('CPM_SQLITE_BUSY_TIMEOUT_SECONDS', 10.0) * 1000)}"
        )
        return connection

    def _init_db(self):
        with self._connect() as c:
            c.execute("PRAGMA journal_mode=WAL")
            c.execute("PRAGMA synchronous=NORMAL")
            c.execute("""CREATE TABLE IF NOT EXISTS tokens (
                user_id INTEGER PRIMARY KEY,
                auth_token TEXT,
                email TEXT,
                password TEXT,
                refresh_token TEXT,
                firebase_uid TEXT,
                token_expires_at REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )""")
            c.execute("""CREATE TABLE IF NOT EXISTS user_data (
                cache_key TEXT PRIMARY KEY,
                email TEXT,
                data_json TEXT,
                saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )""")
            c.execute("""CREATE TABLE IF NOT EXISTS backups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                label TEXT,
                data_json TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )""")
            for stmt in (
                "ALTER TABLE tokens ADD COLUMN firebase_uid TEXT",
                "ALTER TABLE tokens ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
                "ALTER TABLE user_data ADD COLUMN saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
            ):
                try:
                    c.execute(stmt)
                except Exception:
                    pass
            c.commit()

    def _ck(self, uid: int, email: Optional[str] = None) -> str:
        if email:
            return f"{uid}_{email}"
        td = self.get_token_data(uid)
        return f"{uid}_{td['email']}" if td and td.get("email") else str(uid)

    def save_token(self, uid: int, auth: str, email: str, pw: Optional[str] = None,
                   rt: Optional[str] = None, fuid: Optional[str] = None):
        if self._redis is not None:
            payload = {
                "auth_token": auth,
                "email": email,
                "password": pw,
                "refresh_token": rt,
                "firebase_uid": fuid,
                "token_expires_at": time.time() + 3600,
            }
            self._redis.set(
                self._redis_token_key(uid),
                json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
                ex=self._redis_ttl,
            )
            return
        with self._connect() as c:
            c.execute("""INSERT OR REPLACE INTO tokens
                (user_id, auth_token, email, password, refresh_token, firebase_uid, token_expires_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (uid, auth, email, pw, rt, fuid, time.time() + 3600))
            c.commit()

    def get_token_data(self, uid: int) -> Optional[Dict[str, Any]]:
        if self._redis is not None:
            raw = self._redis.get(self._redis_token_key(uid))
            if not raw:
                return None
            try:
                if isinstance(raw, bytes):
                    raw = raw.decode("utf-8")
                value = json.loads(raw)
                return value if isinstance(value, dict) else None
            except (TypeError, ValueError, json.JSONDecodeError):
                return None
        with self._connect() as c:
            row = c.execute("""SELECT auth_token, email, password, refresh_token, firebase_uid, token_expires_at
                               FROM tokens WHERE user_id=?""", (uid,)).fetchone()
        if not row:
            return None
        return {
            "auth_token": row[0], "email": row[1], "password": row[2],
            "refresh_token": row[3], "firebase_uid": row[4], "token_expires_at": row[5]
        }

    def get_token(self, uid: int) -> Optional[Dict[str, str]]:
        td = self.get_token_data(uid)
        return {"auth_token": td["auth_token"], "email": td["email"]} if td else None

    def update_token(self, uid: int, auth: str, rt: Optional[str] = None):
        if self._redis is not None:
            payload = self.get_token_data(uid)
            if not payload:
                return
            payload["auth_token"] = auth
            payload["token_expires_at"] = time.time() + 3600
            if rt:
                payload["refresh_token"] = rt
            self._redis.set(
                self._redis_token_key(uid),
                json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
                ex=self._redis_ttl,
            )
            return
        with self._connect() as c:
            if rt:
                c.execute("UPDATE tokens SET auth_token=?, refresh_token=?, token_expires_at=? WHERE user_id=?",
                          (auth, rt, time.time() + 3600, uid))
            else:
                c.execute("UPDATE tokens SET auth_token=?, token_expires_at=? WHERE user_id=?",
                          (auth, time.time() + 3600, uid))
            c.commit()

    def delete_token(self, uid: int):
        if self._redis is not None:
            index_key = self._redis_record_index_key(uid)
            record_keys = list(self._redis.smembers(index_key))
            with self._redis.pipeline() as pipe:
                pipe.delete(self._redis_token_key(uid), index_key, self._redis_backup_key(uid))
                if record_keys:
                    pipe.delete(*record_keys)
                pipe.execute()
            with self._cache_lock:
                for key in [k for k in self.cache if k.startswith(str(uid))]:
                    del self.cache[key]
            return
        with self._connect() as c:
            c.execute("DELETE FROM tokens WHERE user_id=?", (uid,))
            c.commit()
        with self._cache_lock:
            for key in [k for k in self.cache if k.startswith(str(uid))]:
                del self.cache[key]

    def is_expired(self, uid: int) -> bool:
        td = self.get_token_data(uid)
        return not td or not td.get("token_expires_at") or td["token_expires_at"] < time.time()

    def get_record(self, uid: int, email: Optional[str] = None) -> Dict[str, Any]:
        ck = self._ck(uid, email)
        if self._redis is not None:
            raw = self._redis.get(self._redis_record_key(ck))
            if not raw:
                return {}
            try:
                if isinstance(raw, bytes):
                    raw = raw.decode("utf-8")
                value = json.loads(raw)
                return value if isinstance(value, dict) else {}
            except (TypeError, ValueError, json.JSONDecodeError):
                return {}
        with self._cache_lock:
            cached = self.cache.get(ck)
        if cached is None:
            with self._connect() as c:
                row = c.execute("SELECT data_json FROM user_data WHERE cache_key=?", (ck,)).fetchone()
            if row:
                try:
                    cached = json.loads(row[0])
                    with self._cache_lock:
                        self.cache[ck] = cached
                except Exception:
                    pass
        with self._cache_lock:
            return self.cache.get(ck, {})

    def set_record(self, uid: int, data: Dict[str, Any], email: Optional[str] = None):
        ck = self._ck(uid, email)
        if self._redis is not None:
            record_key = self._redis_record_key(ck)
            with self._redis.pipeline() as pipe:
                pipe.set(
                    record_key,
                    json.dumps(data, ensure_ascii=False, separators=(",", ":")),
                    ex=self._redis_ttl,
                )
                pipe.sadd(self._redis_record_index_key(uid), record_key)
                pipe.expire(self._redis_record_index_key(uid), self._redis_ttl)
                pipe.execute()
            return
        with self._cache_lock:
            self.cache[ck] = data
        with self._connect() as c:
            c.execute("INSERT OR REPLACE INTO user_data (cache_key, email, data_json) VALUES (?, ?, ?)",
                      (ck, email, json.dumps(data)))
            c.commit()

    # Website compatibility aliases.
    def get_user_template(self, uid: int, email: Optional[str] = None) -> Dict[str, Any]:
        return self.get_record(uid, email)

    def save_user_template(self, uid: int, data: Dict[str, Any], email: Optional[str] = None):
        self.set_record(uid, data, email)

    def save_backup(self, uid: int, label: str, data: Dict[str, Any]):
        if self._redis is not None:
            payload = json.dumps(
                {"id": str(time.time_ns()), "label": label, "time": time.time(), "data": data},
                ensure_ascii=False,
                separators=(",", ":"),
            )
            key = self._redis_backup_key(uid)
            with self._redis.pipeline() as pipe:
                pipe.lpush(key, payload)
                pipe.ltrim(key, 0, 4)
                pipe.expire(key, self._redis_ttl)
                pipe.execute()
            return
        with self._connect() as c:
            c.execute("INSERT INTO backups (user_id, label, data_json) VALUES (?, ?, ?)",
                      (uid, label, json.dumps(data)))
            c.commit()

    def get_backups(self, uid: int) -> List[Dict[str, Any]]:
        if self._redis is not None:
            result = []
            for raw in self._redis.lrange(self._redis_backup_key(uid), 0, 4):
                try:
                    if isinstance(raw, bytes):
                        raw = raw.decode("utf-8")
                    item = json.loads(raw)
                    result.append({"id": item.get("id"), "label": item.get("label"), "time": item.get("time")})
                except (TypeError, ValueError, json.JSONDecodeError):
                    continue
            return result
        with self._connect() as c:
            rows = c.execute("SELECT id, label, created_at FROM backups WHERE user_id=? ORDER BY created_at DESC LIMIT 5",
                             (uid,)).fetchall()
        return [{"id": r[0], "label": r[1], "time": r[2]} for r in rows]

    async def _post(self, url: str, payload: Dict[str, Any], headers: Dict[str, str]) -> Optional[Dict[str, Any]]:
        try:
            clean_headers = {k: v for k, v in headers.items() if k.lower() != "host"}
            session = await self._http.get()
            async with session.post(url, json=payload, headers=clean_headers) as resp:
                text = await resp.text()
                try:
                    return json.loads(text)
                except Exception:
                    return {"raw": text, "status": resp.status}
        except Exception as exc:
            log.error("HTTP error: %s", exc)
            return None

    async def close_current_loop_network_client(self) -> None:
        await self._http.close_current_loop()

    async def close_network_clients(self) -> None:
        await self._http.close_all_reachable()

    async def login(self, email: str, password: str) -> Dict[str, Any]:
        try:
            key = firebase_key()
        except RuntimeError as exc:
            return {"ok": False, "message": str(exc)}
        url = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={key}"
        headers = {
            "Accept": "*/*",
            "Accept-Encoding": "gzip",
            "Content-Type": "application/json",
            "User-Agent": "UnityPlayer/2022.3.62f2 (UnityWebRequest/1.0, libcurl/8.10.1-DEV)",
            "X-Unity-Version": "2022.3.62f2",
        }
        payload = {"email": email, "password": password, "returnSecureToken": True, "clientType": "CLIENT_TYPE_ANDROID"}
        result = await self._post(url, payload, headers)
        if not result:
            return {"ok": False, "message": "NETWORK_ERROR"}
        if "idToken" in result:
            return {
                "ok": True,
                "message": "OK",
                "auth": result["idToken"],
                "refresh_token": result.get("refreshToken", ""),
                "firebase_uid": result.get("localId", ""),
            }
        err = str(result.get("error", {}).get("message", "")).upper()
        for key in ["EMAIL_NOT_FOUND", "INVALID_PASSWORD", "INVALID_LOGIN_CREDENTIALS", "TOO_MANY_ATTEMPTS", "USER_DISABLED", "INVALID_EMAIL"]:
            if key in err:
                return {"ok": False, "message": key}
        return {"ok": False, "message": f"LOGIN_FAILED: {err[:80]}"}

    async def account_login(self, email: str, password: str) -> Dict[str, Any]:
        return await self.login(email, password)

    async def _refresh(self, uid: int) -> Tuple[bool, str]:
        td = self.get_token_data(uid)
        if not td:
            return False, "NO_TOKEN"
        rt, em, pw = td.get("refresh_token"), td.get("email"), td.get("password")
        if rt:
            try:
                key = firebase_key()
            except RuntimeError as exc:
                return False, str(exc)
            try:
                result = await self._post(
                    f"https://securetoken.googleapis.com/v1/token?key={key}",
                    {"grant_type": "refresh_token", "refresh_token": rt},
                    {"Content-Type": "application/json"},
                )
                if result and result.get("id_token"):
                    self.update_token(uid, result["id_token"], result.get("refresh_token", rt))
                    return True, "OK"
            except Exception:
                pass
        if em and pw:
            result = await self.login(em, pw)
            if result.get("ok"):
                self.save_token(uid, result["auth"], em, pw, result.get("refresh_token", ""), result.get("firebase_uid", ""))
                return True, "OK"
        return False, "REFRESH_FAILED"

    async def get_auth(self, uid: int) -> Tuple[bool, str, str]:
        if self.is_expired(uid):
            ok, msg = await self._refresh(uid)
            if not ok:
                return False, msg, ""
        td = self.get_token_data(uid)
        if td and td.get("auth_token"):
            return True, "OK", td["auth_token"]
        return False, "NO_TOKEN", ""

    async def load(self, uid: int, force: bool = False) -> bool:
        td = self.get_token_data(uid)
        if not td:
            return False
        ck = self._ck(uid)
        if self._redis is not None and not force and self._redis.exists(self._redis_record_key(ck)):
            return True
        if not force and ck in self.cache:
            return True
        ok, msg, auth = await self.get_auth(uid)
        if not ok:
            log.warning("load: no valid token for %s: %s", uid, msg)
            return False
        headers = {**GAME_HEADERS, "Authorization": f"Bearer {auth}"}
        diagnostics = []
        for load_url in LOAD_URLS:
            endpoint = load_url.rsplit("/", 1)[-1]
            result = await self._post(load_url, {"data": None}, headers)
            if not result or not result.get("result"):
                diagnostics.append(f"{endpoint}=empty:{str(result)[:100]}")
                continue
            decoded = decrypt_player_record(
                result["result"],
                td.get("firebase_uid", ""),
                td.get("password", ""),
                td.get("email", ""),
            )
            if decoded.get("success") and decoded.get("record"):
                self.set_record(uid, decoded["record"], td.get("email", ""))
                log.info("Loaded %s via %s: %s", uid, endpoint, decoded["record"].get("Name"))
                return True
            diagnostics.append(f"{endpoint}=decrypt:{decoded.get('message')}")
        log.warning("load: all confirmed endpoints failed for %s: %s", uid, " | ".join(diagnostics))
        return False

    async def load_account(self, uid: int, force: bool = False) -> bool:
        return await self.load(uid, force)

    def _ok(self, value: Any) -> bool:
        if value in (1, True):
            return True
        if value in (0, False, None):
            return False
        if isinstance(value, str):
            text = value.strip()
            lowered = text.lower()
            if text == "1" or lowered in {"ok", "true", "success", "successful"}:
                return True
            if text == "0" or lowered in {"false", "failed", "error"}:
                return False
            try:
                return self._ok(json.loads(text))
            except Exception:
                return False
        if isinstance(value, dict):
            # Firebase callable responses commonly wrap the actual result under
            # `result`. Some endpoints return `ok` / `success`; non-JSON 200
            # bodies are normalized by _post as {"raw": text, "status": code}.
            for key in ("result", "ok", "success"):
                if key in value:
                    return self._ok(value[key])
            if int(value.get("status", 0) or 0) == 200 and "raw" in value:
                return self._ok(value.get("raw"))
        return False

    async def _send(self, auth: str, record: Dict[str, Any], fuid: str,
                    original: Optional[Dict[str, Any]] = None,
                    force_fields: Optional[set] = None) -> Tuple[bool, str]:
        if not fuid:
            return False, "NO_FIREBASE_UID"
        try:
            payload = build_payload(record, fuid, original, force_fields=force_fields)
            headers = {
                **GAME_HEADERS,
                "Authorization": f"Bearer {auth}",
                "Connection": "Keep-Alive",
                "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 12; Pixel 6 Build/SD1A.210817.036)",
            }
            save_body = {"data": {"data": payload, "deviceId": fuid[:8]}}
            diagnostics = []
            for save_url in SAVE_URLS:
                endpoint = save_url.rsplit("/", 1)[-1]
                result = await self._post(save_url, save_body, headers)
                if result and self._ok(result):
                    log.info("Save succeeded via %s", endpoint)
                    return True, f"OK:{endpoint}"
                diagnostics.append(f"{endpoint}={str(result)[:120]}")
                log.warning("Save attempt failed via %s: %s", endpoint, str(result)[:180])
            return False, "SAVE_FAILED: " + " | ".join(diagnostics)
        except Exception as exc:
            return False, str(exc)

    async def _save(self, uid: int, data: Dict[str, Any], force_fields: Optional[set] = None) -> Dict[str, Any]:
        ok, msg, auth = await self.get_auth(uid)
        if not ok:
            return {"ok": False, "message": msg}
        td = self.get_token_data(uid)
        fuid = td.get("firebase_uid", "") if td else ""
        email = td.get("email", "") if td else ""
        original = self.get_record(uid, email) or None
        ok2, msg2 = await self._send(auth, data, fuid, original, force_fields=force_fields)
        if ok2:
            self.set_record(uid, data, email)
            return {"ok": True, "message": "OK"}
        return {"ok": False, "message": msg2}

    async def _modify(self, uid: int, mods: Dict[str, Any], force_fields: Optional[set] = None) -> Dict[str, Any]:
        await self.load(uid)
        td = self.get_token_data(uid)
        email = td.get("email") if td else None
        data = deepcopy(self.get_record(uid, email))
        if not data or data.get("Name") is None:
            return {"ok": False, "message": "Could not load account data. Try logging in again or refreshing first."}
        for key, value in mods.items():
            if key == "money":
                value = min(int(value), MAX_MONEY)
            if key == "coin":
                value = min(int(value), MAX_COIN)
            data[key] = value
        forced = set(force_fields or mods.keys())
        return await self._save(uid, data, force_fields=forced)

    async def _set_floats(self, uid: int, indices_values: List[Tuple[int, float]]) -> Dict[str, Any]:
        await self.load(uid)
        td = self.get_token_data(uid)
        email = td.get("email") if td else None
        data = deepcopy(self.get_record(uid, email))
        if not data or data.get("Name") is None:
            return {"ok": False, "message": "Could not load account data. Try logging in again or refreshing first."}
        floats = data.get("floats", [])
        max_idx = max(idx for idx, _ in indices_values)
        while len(floats) <= max_idx:
            floats.append(0.0)
        for idx, value in indices_values:
            floats[idx] = float(value)
        data["floats"] = floats
        return await self._save(uid, data)

    async def _set_integers(self, uid: int, indices_values: List[Tuple[int, int]]) -> Dict[str, Any]:
        await self.load(uid)
        td = self.get_token_data(uid)
        email = td.get("email") if td else None
        data = deepcopy(self.get_record(uid, email))
        if not data or data.get("Name") is None:
            return {"ok": False, "message": "Could not load account data. Try logging in again or refreshing first."}
        integers = data.get("integers", [])
        max_idx = max(idx for idx, _ in indices_values)
        while len(integers) <= max_idx:
            integers.append(0)
        for idx, value in indices_values:
            integers[idx] = int(value)
        data["integers"] = integers
        return await self._save(uid, data)

    async def set_money(self, uid: int, amount: int) -> Dict[str, Any]:
        return await self._modify(uid, {"money": min(int(amount), MAX_MONEY)})

    async def set_coin(self, uid: int, amount: int) -> Dict[str, Any]:
        return await self._modify(uid, {"coin": min(int(amount), MAX_COIN)})

    async def set_player_name(self, uid: int, name: str) -> Dict[str, Any]:
        # Force identity fields into the partial-save payload so the account
        # identity is written even if cached data already contains the value.
        return await self._modify(uid, {"Name": str(name)}, force_fields={"Name"})

    async def change_player_id(self, uid: int, new_id: str) -> Dict[str, Any]:
        """Change player ID using a fresh server record and a forced localID save."""
        await self.load(uid, force=True)
        td = self.get_token_data(uid)
        email = td.get("email") if td else None
        data = deepcopy(self.get_record(uid, email))
        if not data or data.get("Name") is None:
            return {
                "ok": False,
                "message": "Could not load account data. Please login again or refresh first.",
            }

        new_id_upper = str(new_id or "").strip().upper()
        if not new_id_upper:
            return {"ok": False, "message": "ID cannot be empty."}

        data["localID"] = new_id_upper
        result = await self._save(uid, data, force_fields={"localID"})
        if result.get("ok"):
            return {
                "ok": True,
                "message": f"ID changed successfully to: {new_id_upper}",
                "new_id": new_id_upper,
            }
        return {
            "ok": False,
            "message": result.get("message", "Save failed"),
        }

    async def set_player_id(self, uid: int, pid: str) -> Dict[str, Any]:
        # Website compatibility name; use the fresh-record Change ID flow.
        return await self.change_player_id(uid, pid)

    async def set_race_wins(self, uid: int, amount: int) -> Dict[str, Any]:
        return await self._set_floats(uid, [(8, float(amount))])

    async def set_race_loses(self, uid: int, amount: int) -> Dict[str, Any]:
        return await self._set_floats(uid, [(9, float(amount))])

    async def unlock_w16(self, uid: int) -> Dict[str, Any]:
        return await self._set_floats(uid, [(32, 1.0)])

    async def unlock_horns(self, uid: int) -> Dict[str, Any]:
        return await self._set_floats(uid, [(27, 1.0), (28, 1.0), (29, 1.0), (30, 1.0), (31, 1.0)])

    async def disable_damage(self, uid: int) -> Dict[str, Any]:
        return await self._set_floats(uid, [(34, 1.0)])

    async def unlimited_fuel(self, uid: int) -> Dict[str, Any]:
        return await self._set_floats(uid, [(3, 1.0)])

    async def unlock_smoke(self, uid: int) -> Dict[str, Any]:
        return await self._set_floats(uid, [(33, 1.0)])

    async def unlock_animations(self, uid: int) -> Dict[str, Any]:
        await self.load(uid)
        td = self.get_token_data(uid)
        email = td.get("email") if td else None
        data = deepcopy(self.get_record(uid, email))
        if not data or data.get("Name") is None:
            return {"ok": False, "message": "Could not load account data."}
        data["animations"] = sorted(set(data.get("animations", []) + list(range(301))))
        return await self._save(uid, data)

    async def unlock_wheels(self, uid: int) -> Dict[str, Any]:
        await self.load(uid)
        td = self.get_token_data(uid)
        email = td.get("email") if td else None
        data = deepcopy(self.get_record(uid, email))
        if not data or data.get("Name") is None:
            return {"ok": False, "message": "Could not load account data."}
        data["wheels"] = sorted(set(data.get("wheels", []) + list(range(73, 221))))
        integers = data.get("integers", [])
        while len(integers) < 113:
            integers.append(0)
        for idx in [0, 1, 2, 3, 4, 5, 110, 111, 112]:
            integers[idx] = 1
        data["integers"] = integers
        return await self._save(uid, data)

    async def unlock_houses(self, uid: int) -> Dict[str, Any]:
        return await self._set_integers(uid, [(8, 1), (110, 1), (111, 1), (112, 1)])

    async def complete_all_levels(self, uid: int) -> Dict[str, Any]:
        levels = [0] + [120 if i == 43 else 1 for i in range(1, 110)]
        return await self._modify(uid, {"LevelsDoneTime": levels})

    async def set_rank(self, uid: int) -> Dict[str, Any]:
        await self.load(uid)
        ok, msg, auth = await self.get_auth(uid)
        if not ok:
            return {"ok": False, "message": msg}

        # Confirmed SetUserRating endpoints can return a null callback/data response even when the
        # request has been accepted for delayed CPM account sync. Keep the real
        # endpoint call, classify that known response as "sync pending" for
        # users, and log sanitized raw diagnostics for the site owner.
        king_rank_sync_message = 'King Rank request was sent. King Rank can populate faster on new accounts; older accounts with existing data may take longer to sync. Open the game, check the Achievements menu (most achievements should be maxed out), and give Car Parking Multiplayer time to sync the rank.'
        rank_values = {
            "time": 999999999,
            "cars": 999999999,
            "car_fix": 999999999,
            "car_collided": 999999999,
            "car_exchange": 999999999,
            "car_trade": 999999999,
            "car_wash": 999999999,
            "slicer_cut": 999999999,
            "drift_max": 999999999,
            "drift": 999999999,
            "cargo": 999999999,
            "delivery": 999999999,
            "race_win": 999999999,
            "taxi": 999999999,
            "levels": 999999999,
            "gifts": 999999999,
            "fuel": 999999999,
            "offroad": 999999999,
            "speed_banner": 999999999,
            "reactions": 999999999,
            "run": 999999999,
            "real_estate": 999999999,
            "t_distance": 999999999,
            "treasure": 999999999,
            "block_post": 999999999,
            "push_ups": 999999999,
            "burnt_tire": 999999999,
            "passanger_distance": 999999999,
        }
        rating_body = {"RatingData": rank_values}
        headers = {**GAME_HEADERS, "Authorization": f"Bearer {auth}"}

        def _safe_response(value: Any) -> str:
            try:
                return json.dumps(value, ensure_ascii=False, sort_keys=True)[:700]
            except Exception:
                return str(value)[:700]

        def _parse_result_payload(value: Any) -> Any:
            if isinstance(value, dict) and "result" in value:
                value = value.get("result")
            if isinstance(value, str):
                try:
                    return json.loads(value)
                except Exception:
                    return value
            return value

        def _classify_rank_response(value: Any) -> Tuple[str, str]:
            if value is None:
                return "failure", "no response"
            if isinstance(value, dict) and value.get("result") == 0:
                return "known-sync", "callable object returned result=0"
            parsed = _parse_result_payload(value)
            if isinstance(parsed, dict):
                callback = parsed.get("callback")
                data = parsed.get("data")
                battlepass = parsed.get("battlepass")
                if isinstance(callback, dict) and callback:
                    return "success", "non-empty callback returned"
                if self._ok(parsed):
                    return "success", "endpoint returned ok/success"
                if data is None and callback is None and isinstance(battlepass, dict):
                    daily = battlepass.get("daily") if isinstance(battlepass.get("daily"), dict) else {}
                    if daily.get("finished") == []:
                        return "known-sync", "null callback/data with empty daily battlepass response"
            if self._ok(value):
                return "success", "endpoint returned ok/success"
            return "failure", _safe_response(value)

        # JSON-string first is the observed compatible SetUserRating format;
        # object form is retained as a diagnostic/compatibility fallback.
        attempts = [
            ("legacy-json-string", {"data": json.dumps(rating_body, separators=(",", ":"))}),
            ("callable-object", {"data": rating_body}),
        ]
        diagnostics = []
        saw_known_sync = False
        for rank_url in RANK_URLS:
            endpoint = rank_url.rsplit("/", 1)[-1]
            for label, payload in attempts:
                result = await self._post(rank_url, payload, headers)
                status, detail = _classify_rank_response(result)
                diagnostics.append(f"{endpoint}/{label}={status}: {detail}")
                log.info(
                    "King Rank %s attempt uid=%s label=%s status=%s detail=%s raw=%s",
                    endpoint, uid, label, status, detail, _safe_response(result)
                )
                if status == "success":
                    return {
                        "ok": True,
                        "message": "OK",
                        "rank_endpoint": endpoint,
                        "rank_diagnostics": diagnostics,
                    }
                if status == "known-sync":
                    saw_known_sync = True

        if saw_known_sync:
            log.warning("King Rank sync-pending response classified as user-facing success uid=%s diagnostics=%s", uid, " | ".join(diagnostics))
            return {
                "ok": True,
                "message": king_rank_sync_message,
                "rank_sync_pending": True,
                "rank_diagnostics": diagnostics,
            }
        return {"ok": False, "message": "RANK_FAILED: " + " | ".join(diagnostics)}

    def _normalize_equipment(self, equipment: Dict[str, Any], gender: int) -> Dict[str, Any]:
        list_fields = [
            "hair", "face", "beard", "cap", "mask", "top", "gloves",
            "bag", "pants", "shoes", "glasses", "SelectedEquipments",
        ]
        normalized = {}
        for key in list_fields:
            values = equipment.get(key, []) if isinstance(equipment, dict) else []
            normalized[key] = [int(v) for v in values]
        normalized["Gender"] = int(gender)
        return normalized

    async def _save_equipment(self, uid: int, field: str, equipment: Dict[str, Any]) -> Dict[str, Any]:
        await self.load(uid, force=True)
        td = self.get_token_data(uid)
        email = td.get("email") if td else None
        data = deepcopy(self.get_record(uid, email))
        if not data or data.get("Name") is None:
            return {"ok": False, "message": "Could not load account data. Try logging in again or refreshing first."}

        gender = 0 if field == "personEquipmentsMale" else 1
        data[field] = self._normalize_equipment(equipment, gender)

        # Save both equipment slots when possible. Sending both fields prevents
        # one gender slot from being dropped by partial-save edge cases, while
        # preserving any existing opposite-gender equipment data.
        force_fields = {field}
        other_field = "personEquipmentsFemale" if field == "personEquipmentsMale" else "personEquipmentsMale"
        other_gender = 1 if other_field == "personEquipmentsFemale" else 0
        if data.get(other_field):
            data[other_field] = self._normalize_equipment(data[other_field], data[other_field].get("Gender", other_gender))
            force_fields.add(other_field)

        return await self._save(uid, data, force_fields=force_fields)

    async def unlock_equipments_male(self, uid: int) -> Dict[str, Any]:
        equipment = {
            "Gender": 0,
            "bag": list(range(101)),
            "beard": list(range(6, 21)) + [100],
            "cap": list(range(3, 64)),
            "face": [0, 1, 2, 100],
            "glasses": list(range(10)) + [100],
            "gloves": list(range(6)) + [100],
            "hair": list(range(3, 20)) + [100],
            "mask": list(range(3, 9)) + [100],
            "pants": list(range(26)),
            "shoes": list(range(31)),
            "top": list(range(2, 109)),
            "SelectedEquipments": [-1, 10, 19, 41, 100, 4, 20, 9, 22, 21, 74],
        }
        return await self._save_equipment(uid, "personEquipmentsMale", equipment)

    async def unlock_equipments_female(self, uid: int) -> Dict[str, Any]:
        equipment = {
            "Gender": 1,
            "bag": list(range(6)),
            "beard": [],
            "cap": list(range(3, 41)),
            "face": [0],
            "glasses": list(range(10)),
            "gloves": [1],
            "hair": [0, 7, 8, 9, 10],
            "mask": list(range(3, 8)),
            "pants": list(range(12)),
            "shoes": list(range(3, 15)),
            "top": list(range(5, 80)),
            "SelectedEquipments": [0, 0, -1, -1, -1, -1, -1, -1, 0, -1, -1],
        }
        return await self._save_equipment(uid, "personEquipmentsFemale", equipment)

    async def fix_account(self, uid: int) -> Dict[str, Any]:
        await self.load(uid)
        td = self.get_token_data(uid)
        email = td.get("email") if td else None
        data = deepcopy(self.get_record(uid, email))
        if not data or data.get("Name") is None:
            return {"ok": False, "message": "Could not load account data."}
        bugs = 0
        floats = data.get("floats", [])[:54]
        while len(floats) < 54:
            floats.append(0.0)
        fixed_floats = []
        for value in floats:
            if value in (1, 1.0):
                fixed_floats.append(1.0)
            elif isinstance(value, (int, float)) and value > 1:
                bugs += 1
                fixed_floats.append(0.0)
            else:
                fixed_floats.append(float(value) if value else 0.0)
        integers = data.get("integers", [])[:120]
        while len(integers) < 120:
            integers.append(0)
        fixed_integers = []
        for value in integers:
            if value == 1:
                fixed_integers.append(1)
            elif isinstance(value, (int, float)) and value > 1:
                bugs += 1
                fixed_integers.append(0)
            else:
                fixed_integers.append(int(value) if value else 0)
        data["floats"] = fixed_floats
        data["integers"] = fixed_integers
        result = await self._save(uid, data)
        return {"ok": True, "bugs_fixed": bugs, "message": f"{bugs} bugs fixed"} if result.get("ok") else {"ok": False, "message": "FIX_FAILED"}

    async def fix_account_data(self, uid: int) -> Dict[str, Any]:
        return await self.fix_account(uid)

    async def unlock_all_features(self, uid: int) -> Dict[str, Any]:
        feature_calls = [
            ("W16 Engine", self.unlock_w16),
            ("Horns", self.unlock_horns),
            ("No Damage", self.disable_damage),
            ("Unlimited Fuel", self.unlimited_fuel),
            ("Smoke", self.unlock_smoke),
            ("Animations", self.unlock_animations),
            ("Wheels", self.unlock_wheels),
            ("Houses", self.unlock_houses),
            ("All Levels", self.complete_all_levels),
            ("Max Rank", self.set_rank),
        ]
        results = []
        failed = []
        await self.load(uid, force=True)
        for name, fn in feature_calls:
            result = await fn(uid)
            if result.get("ok"):
                results.append(name)
                if result.get("rank_sync_pending"):
                    # Keep Unlock All user-friendly for the known CPM King Rank sync-delay response.
                    # The real SetUserRating7 call still ran; detailed endpoint diagnostics are logged.
                    results.append("King Rank sync notice")
            else:
                failed.append(f"{name}: {result.get('message', 'Failed')}")
        sync_notice = ""
        if "King Rank sync notice" in results:
            results = [item for item in results if item != "King Rank sync notice"]
            sync_notice = " King Rank request was sent; on new accounts it may appear faster, while older accounts may need more time. Check the Achievements menu and give Car Parking Multiplayer time to sync."
        return {
            "ok": not failed,
            "message": f"Unlocked {len(results)}/{len(feature_calls)} features" + sync_notice + ("; " + "; ".join(failed) if failed else ""),
            "results": results,
            "failed": failed,
        }
