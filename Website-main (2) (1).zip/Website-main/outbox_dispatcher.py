#!/usr/bin/env python3
"""Reliably relay committed PostgreSQL injection reservations into RQ."""

from __future__ import annotations

import logging
import os
import random
import re
import signal
import time

import postgres_accounts
import bulk_account_jobs
import king_account_jobs
from redis_jobs import JOB_RETENTION_SECONDS, get_job_store, get_redis


log = logging.getLogger("tnnr-outbox")
QUEUE_NAME = os.getenv("RQ_INJECTION_QUEUE", "injections").strip() or "injections"
JOB_TIMEOUT_SECONDS = max(1800, int(os.getenv("INJECTION_JOB_TIMEOUT_SECONDS", "7200")))
QUEUE_TTL_SECONDS = max(JOB_TIMEOUT_SECONDS, int(os.getenv("INJECTION_QUEUE_TTL_SECONDS", "21600")))
FAILURE_TTL_SECONDS = max(3600, int(os.getenv("INJECTION_FAILURE_TTL_SECONDS", "86400")))
_RQ_JOB_ID = re.compile(r"^inject-(?P<job_id>.+)-a(?P<attempt>\d+)$")
_BULK_RQ_JOB_ID = re.compile(
    r"^bulk-(?P<batch_id>[a-f0-9]{32})-(?P<account_index>\d+)-a(?P<attempt>\d+)$"
)
BULK_QUEUE_NAME = os.getenv("RQ_BULK_ACCOUNT_QUEUE", "bulk-accounts").strip() or "bulk-accounts"
BULK_JOB_TIMEOUT_SECONDS = max(1800, int(os.getenv("BULK_ACCOUNT_JOB_TIMEOUT_SECONDS", "7200")))
BULK_QUEUE_TTL_SECONDS = max(BULK_JOB_TIMEOUT_SECONDS, int(os.getenv("BULK_ACCOUNT_QUEUE_TTL_SECONDS", "86400")))
KING_JOB_TIMEOUT_SECONDS = max(1800, int(os.getenv("KING_ACCOUNT_JOB_TIMEOUT_SECONDS", "14400")))
KING_QUEUE_TTL_SECONDS = max(KING_JOB_TIMEOUT_SECONDS, int(os.getenv("KING_ACCOUNT_QUEUE_TTL_SECONDS", "86400")))


def _queue():
    from rq import Queue
    from rq.serializers import JSONSerializer

    return Queue(QUEUE_NAME, connection=get_redis(), serializer=JSONSerializer)


def _bulk_queue():
    from rq import Queue
    from rq.serializers import JSONSerializer

    return Queue(BULK_QUEUE_NAME, connection=get_redis(), serializer=JSONSerializer)


def _ensure_bulk_rq_job(queue, rq_job_id: str, batch_id: str, account_index: int) -> None:
    """Enqueue a bulk RQ job, replacing any dead Redis key that would block unique ids."""
    from rq.job import Job
    from rq.job import JobStatus

    if Job.exists(rq_job_id, connection=queue.connection):
        try:
            existing = Job.fetch(rq_job_id, connection=queue.connection)
            status = existing.get_status(refresh=True)
            # Live or still-queued work must not be duplicated.
            if status in {
                JobStatus.QUEUED,
                JobStatus.STARTED,
                JobStatus.DEFERRED,
                JobStatus.SCHEDULED,
            }:
                return
            # Finished / failed / stopped keys still make Job.exists True and
            # previously caused mark_outbox_dispatched with no runnable worker.
            try:
                existing.delete()
            except Exception:
                log.exception("Unable to delete stale bulk RQ job %s", rq_job_id)
        except Exception:
            log.exception("Unable to inspect existing bulk RQ job %s", rq_job_id)

    queue.enqueue(
        "worker_tasks.process_bulk_account_item",
        batch_id,
        account_index,
        job_id=rq_job_id,
        job_timeout=BULK_JOB_TIMEOUT_SECONDS,
        ttl=BULK_QUEUE_TTL_SECONDS,
        result_ttl=JOB_RETENTION_SECONDS,
        failure_ttl=FAILURE_TTL_SECONDS,
        description=f"TNNR generated account {account_index}/500 ({batch_id[:8]})",
    )


def dispatch_bulk_pending_once(limit: int = 25) -> int:
    queue = _bulk_queue()
    rows = bulk_account_jobs.claim_outbox_batch(limit)
    dispatched = 0
    for row in rows:
        batch_id = row["batch_id"]
        account_index = int(row["account_index"])
        next_attempt = int(row.get("attempt_count") or 0) + 1
        rq_job_id = f"bulk-{batch_id}-{account_index}-a{next_attempt}"
        try:
            _ensure_bulk_rq_job(queue, rq_job_id, batch_id, account_index)
            bulk_account_jobs.mark_outbox_dispatched(batch_id, account_index)
            dispatched += 1
        except Exception as exc:
            log.exception("Unable to dispatch bulk account %s/%s", batch_id, account_index)
            bulk_account_jobs.mark_outbox_error(
                batch_id,
                account_index,
                str(exc),
                int(row.get("attempts") or 0) + 1,
            )
    return dispatched



def _ensure_king_rq_job(queue, rq_job_id: str, batch_id: str, account_index: int) -> None:
    """Queue one durable king-account build; stale completed IDs are replaced."""
    from rq.job import Job, JobStatus
    if Job.exists(rq_job_id, connection=queue.connection):
        existing = Job.fetch(rq_job_id, connection=queue.connection)
        if existing.get_status(refresh=True) in {JobStatus.QUEUED, JobStatus.STARTED, JobStatus.DEFERRED, JobStatus.SCHEDULED}:
            return
        existing.delete()
    queue.enqueue(
        "worker_tasks.process_king_account_item",
        batch_id,
        account_index,
        job_id=rq_job_id,
        job_timeout=KING_JOB_TIMEOUT_SECONDS,
        ttl=KING_QUEUE_TTL_SECONDS,
        result_ttl=JOB_RETENTION_SECONDS,
        failure_ttl=FAILURE_TTL_SECONDS,
        description=f"TNNR king account {account_index} ({batch_id[:8]})",
    )


def dispatch_king_pending_once(limit: int | None = None) -> int:
    """Fill available king-account concurrency slots without an account-rate cap."""
    if limit is None:
        limit = max(1, min(32, int(os.getenv("KING_OUTBOX_BATCH_SIZE", "32"))))
    dispatched = 0
    for _ in range(max(1, int(limit))):
        row = king_account_jobs.claim_next_outbox()
        if not row:
            break
        batch_id = str(row["batch_id"])
        account_index = int(row["account_index"])
        attempt = int(row.get("attempt_count") or 0) + 1
        try:
            _ensure_king_rq_job(_bulk_queue(), f"king-{batch_id}-{account_index}-a{attempt}", batch_id, account_index)
            dispatched += 1
        except Exception as exc:
            log.exception("Unable to dispatch king account %s/%s", batch_id, account_index)
            king_account_jobs.mark_outbox_error(batch_id, account_index, str(exc))
    return dispatched


def cancel_pending_bulk_jobs(batch_id: str) -> int:
    """Remove queued (not running) RQ jobs for a permanently cancelled batch."""
    from rq.job import Job

    queue = _bulk_queue()
    prefix = f"bulk-{batch_id}-"
    removed = 0
    raw_ids = queue.connection.lrange(queue.key, 0, -1)
    for raw_id in raw_ids:
        job_id = raw_id.decode("utf-8") if isinstance(raw_id, bytes) else str(raw_id)
        if not job_id.startswith(prefix):
            continue
        try:
            queue.connection.lrem(queue.key, 0, raw_id)
            job = Job.fetch(job_id, connection=queue.connection)
            job.cancel()
            job.delete()
            removed += 1
        except Exception:
            log.exception("Unable to remove cancelled bulk RQ job %s", job_id)
    return removed


def _public_job(row) -> dict:
    payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
    public = payload.get("job") if isinstance(payload.get("job"), dict) else {}
    now = time.time()
    job = dict(public)
    job.update({
        "job_id": row["job_id"],
        "site_user_id": row["user_id"],
        "web_uid": row["web_uid"],
        "kind": row["kind"],
        "account_keys": list(row.get("account_keys") or []),
        "charged": int(row.get("cost") or 0),
        "attempt_count": int(row.get("attempt_count") or 0),
        "checkpoint": dict(row.get("checkpoint") or {}),
    })
    job.setdefault("status", "queued")
    job.setdefault("events", [{"stage": "queued", "message": "Injection queued — waiting for a worker…", "time": now}])
    job.setdefault("result", None)
    job.setdefault("created_at", float(row.get("created_at") or now))
    job["updated_at"] = now
    return job


def dispatch_pending_once(limit: int = 10) -> int:
    queue = _queue()
    store = get_job_store()
    rows = postgres_accounts.claim_outbox_batch(limit)
    dispatched = 0
    for row in rows:
        job_id = row["job_id"]
        next_attempt = int(row.get("attempt_count") or 0) + 1
        rq_job_id = f"inject-{job_id}-a{next_attempt}"
        try:
            store.create(job_id, _public_job(row))
            from rq.job import Job

            if not Job.exists(rq_job_id, connection=queue.connection):
                queue.enqueue(
                    "worker_tasks.process_injection_job",
                    job_id,
                    job_id=rq_job_id,
                    unique=True,
                    job_timeout=JOB_TIMEOUT_SECONDS,
                    ttl=QUEUE_TTL_SECONDS,
                    result_ttl=JOB_RETENTION_SECONDS,
                    failure_ttl=FAILURE_TTL_SECONDS,
                    description=f"TNNR {row['kind']} injection {job_id}",
                )
            postgres_accounts.mark_outbox_dispatched(job_id)
            store.update(job_id, status="queued", next_attempt=next_attempt)
            dispatched += 1
        except Exception as exc:
            log.exception("Unable to dispatch injection job %s", job_id)
            postgres_accounts.mark_outbox_error(job_id, str(exc), int(row.get("attempts") or 0) + 1)
    return dispatched


def _remove_failed_job(queue, rq_job_id: str) -> None:
    try:
        queue.failed_job_registry.remove(rq_job_id, delete_job=True)
    except Exception:
        log.exception("Unable to remove handled failed RQ job %s", rq_job_id)


def sync_failed_jobs() -> int:
    """Resume hard worker failures from the same paid reservation/checkpoint."""
    from rq import Queue

    queue = Queue(QUEUE_NAME, connection=get_redis())
    store = get_job_store()
    changed = 0
    for rq_job_id in queue.failed_job_registry.get_job_ids():
        match = _RQ_JOB_ID.match(rq_job_id)
        if not match:
            continue
        job_id = match.group("job_id")
        failed_attempt = int(match.group("attempt"))
        current = store.get(job_id)
        reservation = postgres_accounts.get_job_reservation(job_id, include_payload=False)
        if not reservation:
            _remove_failed_job(queue, rq_job_id)
            continue
        if reservation.get("state") in {"completed", "failed", "refunded"}:
            _remove_failed_job(queue, rq_job_id)
            continue
        if failed_attempt != int(reservation.get("attempt_count") or 0):
            _remove_failed_job(queue, rq_job_id)
            continue
        reason = f"RQ worker attempt {failed_attempt} stopped unexpectedly or exceeded its timeout."
        recovery = postgres_accounts.mark_job_resumable(
            job_id,
            reason,
            failed_attempt=failed_attempt,
            delay_seconds=min(600.0, 10.0 * (2 ** min(6, max(0, failed_attempt - 1)))) * random.uniform(0.8, 1.2),
            keep_retrying=str(reservation.get("kind") or "") in {
                "premium", "event", "unlock_all", "catalog", "shared_design",
            },
        )
        if current is None:
            public = _public_job({**reservation, "payload": {}})
            current = store.create(job_id, public)
        checkpoint = recovery.get("checkpoint") or reservation.get("checkpoint") or {}
        completed = int(checkpoint.get("completed_count") or 0)
        if recovery.get("requeued"):
            eta_seconds = min(900, 90 + 10 * (2 ** min(6, max(0, failed_attempt - 1))))
            message = f"Finishing Up and Cleaning Out Errors · Estimated time left: about {eta_seconds} seconds"
            store.update(job_id, status="resume_pending", result=None, checkpoint=checkpoint)
            store.append_event(job_id, "finishing", message, {"eta_seconds": eta_seconds})
        else:
            message = (
                "Automatic recovery reached its safety limit. Your paid reservation and checkpoint "
                "are saved for administrator resume; you will not be charged again."
            )
            store.append_event(job_id, "manual_review", message, {"attempt": failed_attempt, "completed": completed})
            store.update(
                job_id,
                status="manual_review",
                result={"ok": False, "message": message, "failed_ids": []},
                checkpoint=checkpoint,
            )
        _remove_failed_job(queue, rq_job_id)
        changed += 1
    return changed


def sync_failed_bulk_jobs() -> int:
    """Recover child jobs killed by a timeout, crash, or worker restart."""
    queue = _bulk_queue()
    changed = 0
    for rq_job_id in queue.failed_job_registry.get_job_ids():
        match = _BULK_RQ_JOB_ID.match(rq_job_id)
        if not match:
            continue
        batch_id = match.group("batch_id")
        account_index = int(match.group("account_index"))
        failed_attempt = int(match.group("attempt"))
        item = bulk_account_jobs.get_item(batch_id, account_index)
        if not item or item.get("state") in {"complete", "failed", "cancelled"}:
            _remove_failed_job(queue, rq_job_id)
            continue
        result = bulk_account_jobs.fail_or_retry_item(
            batch_id,
            account_index,
            f"Worker attempt {failed_attempt} stopped or timed out. Saved progress will resume automatically.",
            failed_attempt=failed_attempt,
        )
        _remove_failed_job(queue, rq_job_id)
        changed += int(bool(result.get("requeued") or result.get("state") == "failed"))
    return changed


def run_forever() -> None:
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
    stopped = False

    def stop(*_args):
        nonlocal stopped
        stopped = True

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    last_failure_sync = 0.0
    last_expiry_sync = 0.0
    last_stuck_sync = 0.0
    while not stopped:
        try:
            dispatched = dispatch_pending_once(int(os.getenv("OUTBOX_BATCH_SIZE", "10")))
            # Default: enqueue the entire 500-account batch in one pass so RQ
            # workers can drain it continuously toward a ~2 hour finish window.
            bulk_dispatched = dispatch_bulk_pending_once(int(os.getenv("BULK_OUTBOX_BATCH_SIZE", "500")))
            king_dispatched = dispatch_king_pending_once()
            now = time.time()
            if now - last_failure_sync >= 30:
                sync_failed_jobs()
                sync_failed_bulk_jobs()
                last_failure_sync = now
            # Stuck "queued forever" recovery runs often so a 500-account batch
            # does not sit idle after a bad dispatch pass.
            if now - last_stuck_sync >= 15:
                recover_stuck = getattr(bulk_account_jobs, "recover_stuck_queued_items", None)
                recovered = recover_stuck(
                    int(os.getenv("BULK_ACCOUNT_STUCK_QUEUED_SECONDS", "90"))
                ) if callable(recover_stuck) else 0
                if recovered:
                    log.warning("Re-opened %s stuck queued bulk accounts for dispatch", recovered)
                last_stuck_sync = now
            if now - last_expiry_sync >= 60:
                postgres_accounts.expire_abandoned_clone_reservations(
                    int(os.getenv("CLONE_RESERVATION_TTL_SECONDS", "1800"))
                )
                recover_stale = getattr(bulk_account_jobs, "recover_stale_items", None)
                if callable(recover_stale):
                    recover_stale(int(os.getenv("BULK_ACCOUNT_STALE_SECONDS", "1800")))
                revive_initialization = getattr(
                    bulk_account_jobs, "revive_pre_initialization_failures", None
                )
                if callable(revive_initialization):
                    revive_initialization()
                last_expiry_sync = now
            if dispatched == 0 and bulk_dispatched == 0 and king_dispatched == 0:
                time.sleep(max(0.25, float(os.getenv("OUTBOX_POLL_SECONDS", "1"))))
        except Exception:
            log.exception("Outbox dispatcher loop failed")
            time.sleep(5)


if __name__ == "__main__":
    run_forever()
