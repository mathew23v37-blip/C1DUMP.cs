from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import random
import time
from copy import deepcopy
from dataclasses import asdict, dataclass
from pathlib import Path
from threading import RLock
from typing import Callable, List, Optional

import aiohttp

from persistence import seed_data_file

CPM_WORLDSALE_FIREBASE_KEY_ENV = "CPM_WORLDSALE_FIREBASE_KEY"
EU = "https://europe-west1-cp-multiplayer.cloudfunctions.net"
FB_V1 = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword"
FB_LEGACY = "https://www.googleapis.com/identitytoolkit/v3/relyingparty/verifyPassword"

CAR_DB_FILE = Path(seed_data_file("fixed_16_database.json", default={"cars": []}))
EVENT_CAR_DB_FILE = Path(seed_data_file("event_cars_database.json", default={"cars": []}))
UNLOCK_ALL_CAR_DB_FILE = Path(seed_data_file("unlock_all_cars_database.json", default={"cars": []}))

# New Unlock All Cars product: inclusive CarIDs 1 through 270.
ALL_CAR_IDS = tuple(range(1, 271))

# The new-main.py method sleeps heavily because it logs in for every car.
# The website authenticates once and reuses the session, so a short pacing delay
# is enough to protect the backend without making 270 cars take unnecessarily long.
SUCCESS_DELAY_SECONDS = max(0.05, float(os.getenv("CAR_ID_INJECT_SUCCESS_DELAY", "0.15")))
FAIL_DELAY_SECONDS = max(0.15, float(os.getenv("CAR_ID_INJECT_FAIL_DELAY", "0.45")))
# Strategy A: only treat a buy as delivered after GetCars confirms the car.
CONFIRM_AFTER_BUY = os.getenv("CAR_ID_CONFIRM_AFTER_BUY", "1").strip().lower() not in {"0", "false", "no", "off"}
CONFIRM_AFTER_BUY_DELAY = max(0.05, float(os.getenv("CAR_ID_CONFIRM_AFTER_BUY_DELAY", "0.12")))
CONFIRM_AFTER_BUY_ATTEMPTS = max(1, min(3, int(os.getenv("CAR_ID_CONFIRM_AFTER_BUY_ATTEMPTS", "2"))))
# Re-read garage every N confirmed deliveries on multi-car jobs (extra safety).
VERIFY_BATCH_SIZE = max(1, min(50, int(os.getenv("CAR_ID_VERIFY_BATCH_SIZE", "10"))))
# Keep local retries deliberately small. Durable RQ recovery is the one place
# that repeats a whole cycle, preventing nested retry amplification.
MAX_SLOT_ATTEMPTS = max(1, min(3, int(os.getenv("CAR_ID_INJECT_SLOT_ATTEMPTS", "2"))))
# Hard customer-facing cap. Never let protection run past 30s.
PROTECTION_HARD_CAP_SECONDS = max(8, min(30, int(os.getenv("PROTECTION_HARD_CAP_SECONDS", "30"))))
VISIBLE_PROTECTION_SECONDS = max(5, min(PROTECTION_HARD_CAP_SECONDS, int(os.getenv("VISIBLE_PROTECTION_SECONDS", "8"))))
SILENT_PROTECTION_SECONDS = max(0, min(PROTECTION_HARD_CAP_SECONDS, int(os.getenv("SILENT_PROTECTION_SECONDS", "0"))))
WS_SLOT_BLOCKS = max(3, min(12, int(os.getenv("CAR_ID_WS_SLOT_BLOCKS", "6"))))
WS_SLOT_PASSES = max(1, min(2, int(os.getenv("CAR_ID_WS_SLOT_PASSES", "1"))))
INJECT_ONE_TIMEOUT_SECONDS = max(12, min(75, int(os.getenv("CAR_ID_INJECT_ONE_TIMEOUT", "35"))))
# A full designed-car payload can contain hundreds of vinyl layers. The general
# 12-second API default and 18-second single-car cap cancel these requests
# before CPM has parsed them, even when World Sale has valid slots.
WS_PURCHASE_TIMEOUT_SECONDS = max(15.0, min(45.0, float(os.getenv("CAR_ID_WS_PURCHASE_TIMEOUT", "32.0"))))
SMALL_JOB_INJECT_TIMEOUT_SECONDS = max(
    WS_PURCHASE_TIMEOUT_SECONDS + 12.0,
    min(90.0, float(os.getenv("CAR_ID_SMALL_JOB_INJECT_TIMEOUT", "55.0"))),
)
WS_SCAN_TIMEOUT_SECONDS = max(3.0, min(8.0, float(os.getenv("CAR_ID_WS_SCAN_TIMEOUT", "4.0"))))
GARAGE_READ_TIMEOUT_SECONDS = max(3.0, min(10.0, float(os.getenv("CAR_ID_GARAGE_READ_TIMEOUT", "6.0"))))
_LOG = logging.getLogger("tnnr-car-injector")


class RetryableCarJobError(RuntimeError):
    """Transient dependency failure that must continue from the saved job."""


def firebase_key() -> str:
    key = os.getenv(CPM_WORLDSALE_FIREBASE_KEY_ENV, "").strip()
    if not key:
        raise RuntimeError(
            f"Missing required environment variable {CPM_WORLDSALE_FIREBASE_KEY_ENV} "
            "for worldsale/car injector authentication."
        )
    return key


Progress = Optional[Callable[[str, str, Optional[dict]], None]]
_CAR_DB_LOCK = RLock()


@dataclass
class CarBlueprint:
    car_id: int
    vectors: List[dict]
    floats: List[float]
    gears: List[float]
    type_to_install: List[int]
    bought_parts: List[int]
    texts: List[str]
    vynils: dict
    window_vinyls: dict
    flag_id: int
    fso_data: List[int]
    installed_police_lights: List[int]
    data_version: int
    source_slot: dict = None


_CAR_DB_CACHE: Optional[List[CarBlueprint]] = None
_EVENT_CAR_DB_CACHE: Optional[List[CarBlueprint]] = None
_UNLOCK_ALL_CAR_DB_CACHE: Optional[List[CarBlueprint]] = None
_HTTP_SESSIONS = {}
_HTTP_SESSIONS_LOCK = RLock()


async def get_injection_http_session() -> aiohttp.ClientSession:
    """Reuse DNS/TLS connections for consecutive jobs on the same event loop."""
    loop_key = id(asyncio.get_running_loop())
    with _HTTP_SESSIONS_LOCK:
        session = _HTTP_SESSIONS.get(loop_key)
    if session is not None and not session.closed:
        return session

    connector = aiohttp.TCPConnector(
        limit=max(4, min(32, int(os.getenv("INJECTION_HTTP_CONNECTION_LIMIT", "12")))),
        limit_per_host=max(2, min(16, int(os.getenv("INJECTION_HTTP_PER_HOST", "8")))),
        ttl_dns_cache=max(30, int(os.getenv("INJECTION_HTTP_DNS_CACHE_SECONDS", "300"))),
        keepalive_timeout=max(5.0, float(os.getenv("INJECTION_HTTP_KEEPALIVE_SECONDS", "30"))),
        enable_cleanup_closed=True,
    )
    session = aiohttp.ClientSession(connector=connector)
    with _HTTP_SESSIONS_LOCK:
        old = _HTTP_SESSIONS.get(loop_key)
        if old is not None and not old.closed:
            await session.close()
            return old
        _HTTP_SESSIONS[loop_key] = session
    return session


class _InjectionSessionLease:
    async def __aenter__(self):
        return await get_injection_http_session()

    async def __aexit__(self, exc_type, exc, traceback):
        # The app shutdown hook owns the shared session lifecycle.
        return False


def injection_http_session() -> _InjectionSessionLease:
    return _InjectionSessionLease()


async def close_current_injection_http_session() -> None:
    loop_key = id(asyncio.get_running_loop())
    with _HTTP_SESSIONS_LOCK:
        session = _HTTP_SESSIONS.pop(loop_key, None)
    if session is not None and not session.closed:
        await session.close()


def emit(progress: Progress, stage: str, message: str, **extra):
    if progress:
        progress(stage, message, extra or None)


def _blueprints_from_payload(data) -> List[CarBlueprint]:
    source = data.get("cars", []) if isinstance(data, dict) else data
    cars: List[CarBlueprint] = []

    for c in source or []:
        if not isinstance(c, dict):
            continue
        cid = c.get("car_id", c.get("CarID"))
        try:
            cid = int(cid)
        except (TypeError, ValueError):
            continue
        # Keep the complete source object for World Sale.  Rebuilding a car
        # from a selected field list is not lossless: newer CPM payloads can
        # carry wheel, tuning, part, or vinyl state in fields this dataclass
        # does not know about yet.  Catalog payloads already contain a saved
        # source_slot; premium/event JSON is itself a complete oneCar object.
        saved_source = c.get("source_slot")
        if not (
            isinstance(saved_source, dict)
            and isinstance(saved_source.get("one_car"), dict)
        ):
            exact_source = deepcopy(c)
            exact_source.pop("source_slot", None)
            saved_source = {"one_car": exact_source}

        cars.append(
            CarBlueprint(
                car_id=cid,
                vectors=c.get("vectors", []),
                floats=c.get("floats", []),
                gears=c.get("gears", []),
                type_to_install=c.get("type_to_install", c.get("typeToInstall", [])),
                bought_parts=c.get("bought_parts", c.get("BoughtParts", [])),
                texts=c.get("texts", []),
                vynils=c.get("vynils", c.get("Vynils", {})),
                window_vinyls=c.get("window_vinyls", c.get("WindowVinyls", {})),
                flag_id=c.get("flag_id", c.get("flagID", -1)),
                fso_data=c.get("fso_data", c.get("fsoData", [])),
                installed_police_lights=c.get(
                    "installed_police_lights",
                    c.get("installedPoliceLights", []),
                ),
                data_version=c.get("data_version", c.get("dataVersion", 3)),
                source_slot=deepcopy(saved_source),
            )
        )
    return cars


def _read_car_database_from(path: Path) -> List[CarBlueprint]:
    with path.open("r", encoding="utf-8") as f:
        return _blueprints_from_payload(json.load(f))


def load_car_database() -> List[CarBlueprint]:
    global _CAR_DB_CACHE
    with _CAR_DB_LOCK:
        if _CAR_DB_CACHE is None:
            _CAR_DB_CACHE = _read_car_database_from(CAR_DB_FILE)
        return [CarBlueprint(**deepcopy(asdict(car))) for car in _CAR_DB_CACHE]


def load_event_car_database() -> List[CarBlueprint]:
    global _EVENT_CAR_DB_CACHE
    with _CAR_DB_LOCK:
        if _EVENT_CAR_DB_CACHE is None:
            _EVENT_CAR_DB_CACHE = _read_car_database_from(EVENT_CAR_DB_FILE)
        return [CarBlueprint(**deepcopy(asdict(car))) for car in _EVENT_CAR_DB_CACHE]


def load_unlock_all_car_database() -> List[CarBlueprint]:
    global _UNLOCK_ALL_CAR_DB_CACHE
    with _CAR_DB_LOCK:
        if _UNLOCK_ALL_CAR_DB_CACHE is None:
            _UNLOCK_ALL_CAR_DB_CACHE = _read_car_database_from(UNLOCK_ALL_CAR_DB_FILE)
        return [CarBlueprint(**deepcopy(asdict(car))) for car in _UNLOCK_ALL_CAR_DB_CACHE]


def _unique_ids(cars: List[CarBlueprint]) -> List[int]:
    seen = set()
    ids = []
    for car in cars:
        try:
            cid = int(car.car_id)
        except Exception:
            continue
        if cid > 0 and cid not in seen:
            seen.add(cid)
            ids.append(cid)
    return ids


def _template_blueprint(cars: List[CarBlueprint]) -> Optional[CarBlueprint]:
    valid = [car for car in cars if int(car.car_id or 0) > 0]
    return max(valid, key=lambda car: int(car.car_id)) if valid else None


def _blueprints_by_id(cars: List[CarBlueprint]) -> dict[int, CarBlueprint]:
    return {int(car.car_id): car for car in cars if int(car.car_id or 0) > 0}


def _blueprints_from_garage_records(records: List[dict]) -> List[CarBlueprint]:
    """Convert the saved full Get Cars export back into injectable blueprints."""
    cars = []
    for raw in records or []:
        if not isinstance(raw, dict):
            continue
        car_id = raw.get("CarID", raw.get("carID"))
        try:
            car_id = int(car_id)
        except (TypeError, ValueError):
            continue
        if car_id <= 0:
            continue
        cars.append(CarBlueprint(
            car_id=car_id, vectors=deepcopy(raw.get("vectors", [])), floats=deepcopy(raw.get("floats", [])),
            gears=deepcopy(raw.get("gears", [])), type_to_install=deepcopy(raw.get("typeToInstall", [])),
            bought_parts=deepcopy(raw.get("BoughtParts", [])), texts=deepcopy(raw.get("texts", [])),
            vynils=deepcopy(raw.get("Vynils", {})), window_vinyls=deepcopy(raw.get("WindowVinyls", {})),
            flag_id=int(raw.get("flagID", -1) or -1), fso_data=deepcopy(raw.get("fsoData", [])),
            installed_police_lights=deepcopy(raw.get("installedPoliceLights", [])),
            data_version=int(raw.get("dataVersion", 3) or 3), source_slot=None,
        ))
    return cars


async def login_async(session: aiohttp.ClientSession, email: str, password: str):
    """
    Authenticate an existing account only.

    The uploaded main.py uses accounts:signInWithPassword. The website keeps the
    configured Railway Firebase key rather than embedding another credential.
    """
    key = firebase_key()

    try:
        async with session.post(
            FB_V1,
            params={"key": key},
            json={
                "email": email,
                "password": password,
                "returnSecureToken": True,
                "clientType": "CLIENT_TYPE_ANDROID",
            },
            timeout=aiohttp.ClientTimeout(total=15),
        ) as response:
            data = await response.json(content_type=None)
            if data.get("idToken"):
                return data["idToken"], data.get("localId", "")
    except Exception:
        pass

    # Compatibility fallback for the legacy identity-toolkit route already used
    # by older TNNR injection code. This never creates a new account.
    try:
        async with session.post(
            FB_LEGACY,
            params={"key": key},
            json={"email": email, "password": password, "returnSecureToken": True},
            timeout=aiohttp.ClientTimeout(total=15),
        ) as response:
            data = await response.json(content_type=None)
            if data.get("idToken"):
                return data["idToken"], data.get("localId", "")
    except Exception:
        pass

    return None, None


async def api_async(session: aiohttp.ClientSession, token: str, endpoint: str, data, timeout_seconds: float = 12.0):
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token}",
    }
    try:
        async with session.post(
            f"{EU}/{endpoint}",
            json={"data": data},
            headers=headers,
            timeout=aiohttp.ClientTimeout(total=max(3.0, float(timeout_seconds))),
        ) as response:
            body = await response.text()
            if response.status >= 400:
                _LOG.warning(
                    "CPM endpoint=%s returned HTTP %s body=%s",
                    endpoint,
                    response.status,
                    body[:240].replace("\n", " "),
                )
            return response.status, body
    except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
        _LOG.warning("CPM endpoint=%s transient transport failure=%s", endpoint, type(exc).__name__)
        return 599, ""
    except Exception:
        _LOG.exception("CPM endpoint=%s unexpected request failure", endpoint)
        return 599, ""


def _unwrap_result(raw: str):
    try:
        outer = json.loads(raw)
    except Exception:
        return None
    result = outer.get("result") if isinstance(outer, dict) else None
    if isinstance(result, str):
        try:
            return json.loads(result)
        except Exception:
            return result
    return result


async def get_garage_cars_result(
    session: aiohttp.ClientSession,
    token: str,
) -> tuple[bool, List[dict]]:
    """Return whether a Get Cars response was readable plus its full car list."""
    # TestGetAllCars is the current production garage endpoint.
    attempts = (("TestGetAllCars", None),)
    valid_empty = False

    for endpoint, payload in attempts:
        status, raw = await api_async(session, token, endpoint, payload, timeout_seconds=GARAGE_READ_TIMEOUT_SECONDS)
        if status != 200 or not raw:
            continue
        result = _unwrap_result(raw)
        if isinstance(result, list):
            if result:
                return True, result
            valid_empty = True
            continue
        if isinstance(result, dict) and (
            result.get("CarID") is not None or result.get("carID") is not None
        ):
            return True, [result]

    return valid_empty, []


async def get_garage_cars(session: aiohttp.ClientSession, token: str) -> List[dict]:
    _, cars = await get_garage_cars_result(session, token)
    return cars


def normalize_garage_design_car(car: dict) -> dict:
    """Decode for matching while retaining the exact packed injection payload."""
    if not isinstance(car, dict):
        return {}
    exact_source = deepcopy(car)
    try:
        # Imported lazily because account_clone uses this module's HTTP session.
        from account_clone import _normalize_export_car
        normalized = _normalize_export_car(car)
        if not isinstance(normalized, dict):
            normalized = deepcopy(car)
    except Exception:
        normalized = deepcopy(car)

    # Decoded arrays are only for marker/count inspection.  Keep the untouched
    # Get Cars object beside them so the purchase path can perform the same
    # packed-to-runtime conversion as the known-working account exporter while
    # retaining every wheel, part, tuning, vinyl, and unknown source field.
    normalized["source_slot"] = {"one_car": exact_source}
    return normalized


def garage_vinyl_count(car: dict) -> int:
    if isinstance(car, dict) and not isinstance(car.get("source_slot"), dict):
        car = normalize_garage_design_car(car)
    vinyls = car.get("Vynils", car.get("vynils", {})) if isinstance(car, dict) else {}
    if isinstance(vinyls, dict):
        layers = vinyls.get("allVynils", vinyls.get("all_vynils", []))
        return len(layers) if isinstance(layers, list) else 0
    return len(vinyls) if isinstance(vinyls, list) else 0


def garage_text_vinyls(car: dict) -> List[str]:
    """Return normalized body-vinyl text values for marker identification."""
    if isinstance(car, dict) and not isinstance(car.get("source_slot"), dict):
        car = normalize_garage_design_car(car)
    vinyls = car.get("Vynils", car.get("vynils", {})) if isinstance(car, dict) else {}
    layers = vinyls.get("allVynils", []) if isinstance(vinyls, dict) else vinyls
    if not isinstance(layers, list):
        return []
    values = []
    for layer in layers:
        if not isinstance(layer, dict):
            continue
        value = layer.get("text", layer.get("Text", ""))
        if value is not None and str(value).strip():
            values.append(str(value).strip())
    return values


async def scan_garage_for_design(email: str, password: str, declared_vinyls: int, marker: str = "") -> dict:
    """Read the garage and return only cars matching the user's exact vinyl count."""
    async with injection_http_session() as session:
        token, _ = await login_async(session, email, password)
        if not token:
            return {"ok": False, "message": "CPM login failed."}
        # Read the TestGetAllCars endpoint more than once because it can briefly
        # expose an older cloud snapshot while a newly saved design propagates.
        # Retain each distinct response so the declared count can match the freshest.
        attempts = (("TestGetAllCars", None),)
        snapshots = []
        readable = False
        for pass_index in range(3):
            for endpoint, payload in attempts:
                status, raw = await api_async(session, token, endpoint, payload)
                if status != 200 or not raw:
                    continue
                result = _unwrap_result(raw)
                if isinstance(result, list):
                    readable = True
                    snapshots.extend(item for item in result if isinstance(item, dict))
                elif isinstance(result, dict) and (result.get("CarID") is not None or result.get("carID") is not None):
                    readable = True
                    snapshots.append(result)
            if pass_index < 2:
                await asyncio.sleep(1.25)
    if not readable:
        return {"ok": False, "message": "Garage scan failed. No design was saved."}
    declared_vinyls = int(declared_vinyls)
    marker = str(marker or "").strip()
    vinyl_matches = []
    marker_matches = []
    detected = []
    seen_snapshots = set()
    for index, car in enumerate(snapshots):
        normalized = normalize_garage_design_car(car)
        count = garage_vinyl_count(normalized)
        car_id = int(normalized.get("CarID", normalized.get("carID", 0)) or 0)
        signature = (car_id, count, json.dumps(normalized.get("Vynils", {}), sort_keys=True, separators=(",", ":"), default=str))
        if signature in seen_snapshots:
            continue
        seen_snapshots.add(signature)
        detected.append({"car_id": car_id, "vinyl_count": count})
        if count == declared_vinyls:
            vinyl_matches.append({"index": index, "car_id": car_id,
                                  "vinyl_count": count, "car": normalized})
        if marker and marker in garage_text_vinyls(normalized):
            marker_matches.append({"index": index, "car_id": car_id,
                                   "vinyl_count": count, "car": normalized})

    # The same physical car is returned by several endpoints/passes. Collapse
    # marker hits by CarID before deciding that the marker exists on multiple
    # cars. Prefer the snapshot matching the declared count; otherwise retain
    # the snapshot with the highest decoded layer count (normally the newest).
    marker_groups = {}
    for item in marker_matches:
        marker_groups.setdefault(int(item["car_id"]), []).append(item)
    collapsed_marker_matches = []
    for group in marker_groups.values():
        exact = [item for item in group if item["vinyl_count"] == declared_vinyls]
        collapsed_marker_matches.append(
            exact[0] if exact else max(group, key=lambda item: int(item["vinyl_count"]))
        )

    # A unique text marker is authoritative. If it genuinely appears across
    # different CarIDs, the declared body-vinyl count becomes the tie-breaker.
    match_method = "vinyl_count"
    if len(collapsed_marker_matches) == 1:
        matches = collapsed_marker_matches
        match_method = "text_marker"
    elif len(collapsed_marker_matches) > 1:
        matches = [item for item in collapsed_marker_matches if item["vinyl_count"] == declared_vinyls]
        match_method = "text_marker_and_vinyl_count"
        if len(matches) != 1:
            return {"ok": False, "message": f"Marker {marker} was found on multiple cars. Keep it on only the design you want to share, then scan again.", "detected": detected}
    else:
        matches = vinyl_matches
    if not matches:
        nonzero = sorted({int(item["vinyl_count"]) for item in detected if int(item["vinyl_count"]) > 0})
        seen = ", ".join(str(value) for value in nonzero[:20]) or "none"
        marker_note = f" Text marker {marker} was not found." if marker else ""
        return {"ok": False, "message": f"No garage car matched exactly {declared_vinyls} body vinyls.{marker_note} Detected vinyl counts: {seen}.", "detected": detected}
    return {"ok": True, "matches": matches, "garage_count": len(snapshots),
            "detected": detected, "match_method": match_method,
            "vinyl_count_verified": int(matches[0]["vinyl_count"]) == declared_vinyls}


async def verify_account_garage_count(
    email: str,
    password: str,
    progress: Progress = None,
    *,
    minimum_count: int = 0,
    attempts: int = 6,
) -> dict:
    """Reload Get Cars until the final persisted garage count is confirmed."""
    minimum_count = max(0, int(minimum_count))
    attempts = max(1, min(10, int(attempts)))
    last_count = 0
    last_error = "Get Cars did not return a readable response."

    async with injection_http_session() as session:
        token = None
        for attempt in range(1, attempts + 1):
            if not token:
                try:
                    token, _ = await login_async(session, email, password)
                except Exception as exc:
                    last_error = f"Authentication failed during garage verification: {exc}"
                    token = None

            readable = False
            cars: List[dict] = []
            if token:
                readable, cars = await get_garage_cars_result(session, token)
            if readable:
                last_count = len(cars)
                emit(
                    progress,
                    "garage_verify",
                    f"Get Cars verification {attempt}/{attempts}: {last_count} cars saved.",
                    attempt=attempt,
                    verified_car_count=last_count,
                    minimum_count=minimum_count,
                )
                if last_count >= minimum_count:
                    return {
                        "ok": True,
                        "count": last_count,
                        "attempt": attempt,
                        "message": f"Get Cars verified {last_count} saved cars.",
                    }
                last_error = (
                    f"Get Cars returned {last_count} cars; waiting for at least "
                    f"{minimum_count} to finish syncing."
                )
            else:
                token = None
                emit(
                    progress,
                    "garage_verify_retry",
                    f"Get Cars verification {attempt}/{attempts} was unavailable; retrying safely…",
                    attempt=attempt,
                    minimum_count=minimum_count,
                )

            if attempt < attempts:
                await asyncio.sleep(min(10.0, 1.25 * attempt))

    return {
        "ok": False,
        "count": last_count,
        "attempt": attempts,
        "message": last_error,
    }


async def get_world_sale_slots(
    session: aiohttp.ClientSession,
    token: str,
    blocks: int = WS_SLOT_BLOCKS,
    passes: int = WS_SLOT_PASSES,
) -> List[dict]:
    merged = []
    seen = set()
    readable_response = False

    for _ in range(max(1, passes)):
        status, raw = await api_async(session, token, "WSGetCarListV3", blocks, timeout_seconds=WS_SCAN_TIMEOUT_SECONDS)
        if status != 200:
            continue
        slots = _unwrap_result(raw)
        if not isinstance(slots, list):
            continue
        readable_response = True

        for slot in slots:
            if not isinstance(slot, dict):
                continue
            key = (
                slot.get("carGeneratedID") or "",
                slot.get("ownerID") or "",
                slot.get("carID", slot.get("CarID", 0)),
            )
            if key in seen:
                continue
            seen.add(key)
            merged.append(slot)

    # Match the uploaded main.py preference: use an empty slot first when one is
    # available, otherwise use a normal World Sale slot. Lower-price slots are
    # preferred after empty slots.
    merged.sort(
        key=lambda slot: (
            0 if int(slot.get("carID", slot.get("CarID", 0)) or 0) == 0 else 1,
            int(slot.get("price", 100) or 100),
        )
    )
    if readable_response:
        try:
            import world_sale_health
            world_sale_health.record_slots(len(merged))
        except Exception:
            pass
    return merged


def _payload_profile(car: dict) -> dict:
    """Compact audit record for every field that makes a designed car unique."""
    vynils = car.get("Vynils") if isinstance(car.get("Vynils"), dict) else {}
    layers = vynils.get("allVynils") if isinstance(vynils.get("allVynils"), list) else []
    vectors = car.get("vectors") if isinstance(car.get("vectors"), list) else []
    floats = car.get("floats") if isinstance(car.get("floats"), list) else []
    gears = car.get("gears") if isinstance(car.get("gears"), list) else []
    install = car.get("typeToInstall") if isinstance(car.get("typeToInstall"), list) else []
    parts = car.get("BoughtParts") if isinstance(car.get("BoughtParts"), list) else []
    fso = car.get("fsoData") if isinstance(car.get("fsoData"), list) else []
    lights = car.get("installedPoliceLights") if isinstance(car.get("installedPoliceLights"), list) else []

    def signature(value) -> str:
        raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()[:20]

    return {
        "car_id": int(car.get("CarID", car.get("carID", 0)) or 0),
        "source_field_count": len(car),
        "vector_count": len(vectors),
        "float_tune_count": len(floats),
        "gear_count": len(gears),
        "type_to_install": deepcopy(install),
        "bought_parts_count": len(parts),
        "bought_parts_enabled": [index for index, value in enumerate(parts) if int(value or 0) != 0],
        "vinyl_count": len(layers),
        "texts_format": type(car.get("texts")).__name__,
        "texts_size": len(car.get("texts")) if isinstance(car.get("texts"), (str, list, dict)) else 0,
        "window_vinyl_format": type(car.get("WindowVinyls")).__name__,
        "window_vinyl_size": len(car.get("WindowVinyls")) if isinstance(car.get("WindowVinyls"), (str, list, dict)) else 0,
        "fso_count": len(fso),
        "police_light_count": len(lights),
        "flag_id": int(car.get("flagID", -1) or -1),
        "data_version": int(car.get("dataVersion", 3) or 3),
        "wheel_size_color_tune_signature": signature({
            "vectors": vectors, "floats": floats, "typeToInstall": install,
        }),
        "parts_gears_signature": signature({
            "gears": gears, "BoughtParts": parts, "fsoData": fso,
            "installedPoliceLights": lights,
        }),
        "vinyl_signature": signature(vynils),
        "full_payload_signature": signature(car),
    }


def blueprint_to_game_car(
    blueprint: CarBlueprint,
    uid: str = "",
    *,
    lossless_individual: bool = False,
) -> dict:
    cid = int(blueprint.car_id)

    # Preserve the complete source, but convert packed Get Cars fields into
    # the expanded runtime form required by WSPurchaseCarV3.  Sending packed
    # vectors/parts/vinyl blobs directly is what caused missing wheels and
    # designs on scanned public cars.
    car = None
    if isinstance(blueprint.source_slot, dict):
        raw = blueprint.source_slot.get("one_car")
        if isinstance(raw, dict):
            try:
                from account_clone import _normalize_export_car
                car = _normalize_export_car(raw)
            except Exception:
                car = deepcopy(raw)

    if not isinstance(car, dict):
        car = {
            "vectors": deepcopy(blueprint.vectors),
            "floats": deepcopy(blueprint.floats),
            "gears": deepcopy(blueprint.gears),
            "typeToInstall": deepcopy(blueprint.type_to_install),
            "BoughtParts": deepcopy(blueprint.bought_parts),
            "texts": deepcopy(blueprint.texts),
            "Vynils": deepcopy(blueprint.vynils),
            "WindowVinyls": deepcopy(blueprint.window_vinyls),
            "flagID": blueprint.flag_id,
            "fsoData": deepcopy(blueprint.fso_data),
            "installedPoliceLights": deepcopy(blueprint.installed_police_lights),
            "dataVersion": int(blueprint.data_version or 3),
        }

    if lossless_individual:
        # Individual designs use the same safe construction as the working
        # BMW M2: retain every unknown source oneCar field, then overlay every
        # authoritative expanded export field. This prevents a failed packed
        # decode from silently replacing wheels, tune, parts, or vinyls with
        # a premium/default payload.
        authoritative = {
            "vectors": blueprint.vectors,
            "floats": blueprint.floats,
            "gears": blueprint.gears,
            "typeToInstall": blueprint.type_to_install,
            "BoughtParts": blueprint.bought_parts,
            "texts": blueprint.texts,
            "Vynils": blueprint.vynils,
            "WindowVinyls": blueprint.window_vinyls,
            "flagID": blueprint.flag_id,
            "fsoData": blueprint.fso_data,
            "installedPoliceLights": blueprint.installed_police_lights,
            "dataVersion": int(blueprint.data_version or 3),
        }
        for field, value in authoritative.items():
            if field in {"flagID", "dataVersion"} or value not in (None, [], {}):
                car[field] = deepcopy(value)

    car["CarID"] = cid
    if "carID" in car:
        car["carID"] = cid

    try:
        from account_clone import _runtime_vynils
        car["Vynils"] = _runtime_vynils(car.get("Vynils"), cid)
    except Exception:
        vynils = car.get("Vynils")
        if not isinstance(vynils, dict):
            vynils = {"allVynils": []}
        else:
            vynils = deepcopy(vynils)
        vynils["CarID"] = cid
        vynils.setdefault("allVynils", [])
        car["Vynils"] = vynils

    if car.get("WindowVinyls") is None:
        car["WindowVinyls"] = {}
    car.setdefault("dataVersion", int(blueprint.data_version or 3))

    if lossless_individual:
        required_lists = {
            "vectors": blueprint.vectors,
            "floats": blueprint.floats,
            "gears": blueprint.gears,
            "typeToInstall": blueprint.type_to_install,
            "BoughtParts": blueprint.bought_parts,
            "fsoData": blueprint.fso_data,
            "installedPoliceLights": blueprint.installed_police_lights,
        }
        for field, expected in required_lists.items():
            if isinstance(expected, list) and expected and car.get(field) != expected:
                raise RuntimeError(f"Designed-car payload validation failed for {field}.")
        expected_vinyls = blueprint.vynils if isinstance(blueprint.vynils, dict) else {}
        expected_layers = expected_vinyls.get("allVynils") if isinstance(expected_vinyls.get("allVynils"), list) else []
        actual_layers = (car.get("Vynils") or {}).get("allVynils", []) if isinstance(car.get("Vynils"), dict) else []
        if expected_layers and actual_layers != expected_layers:
            raise RuntimeError("Designed-car vinyl payload validation failed.")
    return car


def clone_template_to_car(template: dict, target_uid: str, car_id: int) -> dict:
    """
    Apply the uploaded main.py Unlock Cars method:
      copy one known-good car -> change CarID -> retarget text/vinyl CarID.

    Everything else in the donor payload is retained.
    """
    cid = int(car_id)
    car = deepcopy(template)
    car["CarID"] = cid

    # Preserve a lower-case field only when the donor already had one.
    if "carID" in car:
        car["carID"] = cid

    texts = car.get("texts")
    marker = f"{(target_uid or 'UNKNOWN')[:8].upper()}_{cid}_HZ"
    if isinstance(texts, list):
        while len(texts) < 3:
            texts.append("")
        texts[2] = marker
        car["texts"] = texts
    elif isinstance(texts, str):
        car["texts"] = ["", "", marker]

    if isinstance(car.get("Vynils"), dict):
        car["Vynils"] = deepcopy(car["Vynils"])
        car["Vynils"]["CarID"] = cid

    return car


def bootstrap_shell_for_design(desired_car: dict, target_uid: str, car_id: int) -> Optional[dict]:
    """Build a known-compatible CPM car shell while retaining body-vinyl artwork.

    Full catalog exports can retain packed text/window fields and long gear data
    that World Sale rejects even though the same target CarID is valid. Managed
    alts succeed with ``alt_bootstrap_car.json``. On an explicit World Sale
    rejection, this helper reuses that proven shell and overlays only the
    selected design's normalized body-vinyl payload.
    """
    try:
        source_path = Path(__file__).with_name("alt_bootstrap_car.json")
        raw = json.loads(source_path.read_text(encoding="utf-8"))
        seed = raw.get("car") if isinstance(raw, dict) else None
        if not isinstance(seed, dict):
            return None
        shell = clone_template_to_car(seed, target_uid, int(car_id))
        desired_vynils = desired_car.get("Vynils") if isinstance(desired_car, dict) else None
        if isinstance(desired_vynils, dict) and isinstance(desired_vynils.get("allVynils"), list):
            shell["Vynils"] = deepcopy(desired_vynils)
            shell["Vynils"]["CarID"] = int(car_id)
        return shell
    except Exception:
        _LOG.exception("Unable to build the bootstrap-shell fallback for CarID %s", car_id)
        return None


async def buy_car_from_slot(
    session: aiohttp.ClientSession,
    token: str,
    slot: dict,
    car: dict,
):
    """
    World Sale payload mirrors the uploaded main.py cpm1_inject_car flow.
    """
    payload = {
        "ownerID": slot.get("ownerID", ""),
        "ownerName": slot.get("ownerName", ""),
        "description": slot.get("description", ""),
        "CarID": slot.get("carID", slot.get("CarID", 0)),
        "carGeneratedID": slot.get("carGeneratedID", ""),
        "ownerAccountID": slot.get("ownerAccountID", ""),
        "oneCar": car,
        "vynilOneCar": car.get("Vynils", {}) if isinstance(car, dict) else {},
        "loadedLocalCar": {"instanceID": random.randint(-999999, -100000)},
        "price": slot.get("price", 100),
        "SellingCar": {},
        "willReject": False,
        "dislike": 1,
        "like": 0,
        "liked": False,
        "disliked": False,
        "mode": 1,
    }

    payload_json = json.dumps(payload, separators=(",", ":"))
    payload_bytes = len(payload_json.encode("utf-8"))
    status, raw = await api_async(
        session,
        token,
        "WSPurchaseCarV3",
        payload_json,
        timeout_seconds=WS_PURCHASE_TIMEOUT_SECONDS,
    )
    try:
        data = json.loads(raw)
    except Exception:
        detail = f"Bad reply (HTTP {status}; {payload_bytes} bytes)"
        _LOG.warning(
            "World Sale purchase unreadable target_car_id=%s slot_car_id=%s status=%s payload_bytes=%s body=%s",
            car.get("CarID", car.get("carID", 0)) if isinstance(car, dict) else 0,
            slot.get("carID", slot.get("CarID", 0)),
            status,
            payload_bytes,
            str(raw)[:240].replace("\n", " "),
        )
        return False, None, detail

    result = data.get("result") if isinstance(data, dict) else None
    error = data.get("error") if isinstance(data, dict) else None
    if status == 200 and result == 1:
        return True, result, error

    detail = error or (data.get("message") if isinstance(data, dict) else None) or f"result={result!r}"
    _LOG.warning(
        "World Sale purchase rejected target_car_id=%s slot_car_id=%s status=%s result=%r error=%s payload_bytes=%s body=%s",
        car.get("CarID", car.get("carID", 0)) if isinstance(car, dict) else 0,
        slot.get("carID", slot.get("CarID", 0)),
        status,
        result,
        str(detail)[:240],
        payload_bytes,
        str(raw)[:240].replace("\n", " "),
    )
    return False, result, str(detail)



async def _confirm_car_delivered(
    session: aiohttp.ClientSession,
    token: str,
    desired_car: dict,
    *,
    car_id: int,
) -> bool:
    """Strategy A: trust GetCars + fingerprint, not WSPurchaseCarV3 alone."""
    import car_safety_backups

    desired_fp = car_safety_backups._fingerprint_car(desired_car)
    for attempt in range(1, CONFIRM_AFTER_BUY_ATTEMPTS + 1):
        await asyncio.sleep(CONFIRM_AFTER_BUY_DELAY * attempt)
        cars = await get_garage_cars(session, token)
        if not cars:
            continue
        if desired_fp is not None:
            current = car_safety_backups._car_fingerprints(cars)
            if current.get(desired_fp, 0) > 0:
                return True
        # Fallback: CarID present when fingerprint cannot be built.
        ids = {
            int(car.get("CarID", car.get("carID", 0)) or 0)
            for car in cars
            if isinstance(car, dict)
        }
        if desired_fp is None and int(car_id) in ids:
            return True
    return False


async def _inject_car_ids_from_template(
    target_ids: List[int],
    template_blueprint: CarBlueprint,
    email: str,
    password: str,
    progress: Progress = None,
    label: str = "cars",
    resume_checkpoint: Optional[dict] = None,
    target_blueprints: Optional[dict[int, CarBlueprint]] = None,
    replace_owned: bool = False,
    lossless_individual: bool = False,
    payload_mode: str = "",
) -> dict:
    ids = []
    seen = set()
    for raw_id in target_ids:
        try:
            cid = int(raw_id)
        except Exception:
            continue
        if cid > 0 and cid not in seen:
            seen.add(cid)
            ids.append(cid)

    emit(
        progress,
        "targets_loaded",
        f"Loaded {len(ids)} target CarIDs for {label}",
        total=len(ids),
        car_ids=ids,
    )

    if not ids:
        return {
            "ok": False,
            "message": f"No target CarIDs configured for {label}",
            "injected": 0,
            "skipped": 0,
            "failed_ids": [],
        }

    if template_blueprint is None:
        return {
            "ok": False,
            "message": f"No donor/template car is available for {label}",
            "injected": 0,
            "skipped": 0,
            "failed_ids": ids,
        }

    async with injection_http_session() as session:
        emit(progress, "connecting", "Connecting to CPM…")

        try:
            token, uid = await login_async(session, email, password)
        except RuntimeError as exc:
            emit(progress, "error", str(exc))
            return {
                "ok": False,
                "message": str(exc),
                "injected": 0,
                "skipped": 0,
                "failed_ids": ids,
            }

        if not token:
            emit(progress, "error", "Authentication failed")
            return {
                "ok": False,
                "message": "Authentication failed",
                "injected": 0,
                "skipped": 0,
                "failed_ids": ids,
            }

        emit(progress, "authenticated", f"Authenticated [{uid[:8]}…]")

        garage_readable, garage = await get_garage_cars_result(session, token)
        if not garage_readable:
            # Fresh alts often need a few Get Cars cycles before car-data loads.
            emit(progress, "garage_warm", "Garage not readable yet — warming car-data endpoints…")
            for warm in range(1, 3):
                await asyncio.sleep(min(1.5, 0.4 * warm))
                try:
                    token2, uid2 = await asyncio.wait_for(login_async(session, email, password), timeout=10.0)
                    if token2:
                        token, uid = token2, uid2
                    garage_readable, garage = await asyncio.wait_for(
                        get_garage_cars_result(session, token), timeout=8.0
                    )
                except Exception as warm_exc:
                    _LOG.warning("garage warm attempt %s failed: %s", warm, warm_exc)
                    garage_readable, garage = False, []
                if garage_readable:
                    emit(progress, "garage_warm", f"Garage became readable after warm cycle {warm}.")
                    break
            if not garage_readable:
                emit(
                    progress,
                    "garage_warm",
                    "Garage still empty/unreadable — continuing inject; first purchase will prime car-data.",
                )

        owned = {
            int(car.get("CarID", car.get("carID", 0)) or 0)
            for car in garage
            if isinstance(car, dict)
        }
        owned.discard(0)

        emit(
            progress,
            "garage",
            f"Garage read complete: {len(garage)} cars, {len(owned)} unique CarIDs (readable={garage_readable})",
            owned=len(owned),
            garage_readable=garage_readable,
        )
        garage_was_readable = bool(garage_readable)

        checkpoint_ids = {
            int(value) for value in (resume_checkpoint or {}).get("completed_car_ids", [])
            if str(value).lstrip("-").isdigit() and int(value) > 0
        }
        # A fresh readable Get Cars response is authoritative. Checkpoint IDs
        # are trusted while unreadable. For replace-owned design jobs, a saved
        # checkpoint is also trusted only when the live semantic payload still
        # matches the requested design. This makes whole-job recovery idempotent
        # without hiding a write that was acknowledged but never persisted.
        checkpoint_only = set() if garage_readable else checkpoint_ids
        if garage_readable and replace_owned and checkpoint_ids and target_blueprints:
            try:
                import car_safety_backups
                current_fingerprints = {
                    car_safety_backups._fingerprint_car(car)
                    for car in garage
                    if isinstance(car, dict)
                }
                for cid in checkpoint_ids.intersection(target_blueprints):
                    desired = blueprint_to_game_car(
                        target_blueprints[cid], uid,
                        lossless_individual=lossless_individual,
                    )
                    if car_safety_backups._fingerprint_car(desired) in current_fingerprints:
                        checkpoint_only.add(cid)
            except Exception:
                _LOG.exception("Unable to semantically verify replace-owned checkpoint")
        owned_before = set(owned)
        targets = [
            cid for cid in ids
            if cid not in checkpoint_only and (replace_owned or cid not in owned)
        ]
        skipped = len(ids) - len(targets)

        if replace_owned and owned_before.intersection(ids):
            emit(
                progress,
                "replace_owned",
                f"Replacing {len(owned_before.intersection(ids))} matching CarID(s) with the selected payload",
                replacing=len(owned_before.intersection(ids)),
            )

        if skipped:
            emit(
                progress,
                "skip_owned",
                f"Skipped {skipped} CarIDs confirmed owned or safely held in the recovery checkpoint",
                skipped=skipped,
                checkpointed=len(checkpoint_only.intersection(ids)),
            )

        if not targets:
            message = f"All {len(ids)} configured {label} CarIDs are already owned"
            emit(progress, "complete", message, injected=0, skipped=skipped)
            return {
                "ok": True,
                "message": message,
                "injected": 0,
                "total": len(ids),
                "skipped": skipped,
                "failed_ids": [],
            }

        template = blueprint_to_game_car(
            template_blueprint, uid,
            lossless_individual=lossless_individual,
        )
        donor_id = int(template.get("CarID", template_blueprint.car_id) or 0)

        payload_profiles = {}
        if lossless_individual:
            for cid in targets:
                blueprint = (target_blueprints or {}).get(cid)
                if blueprint is None:
                    continue
                verified_car = blueprint_to_game_car(
                    blueprint, uid, lossless_individual=True
                )
                payload_profiles[cid] = _payload_profile(verified_car)
            if payload_profiles:
                primary = payload_profiles[next(iter(payload_profiles))]
                emit(
                    progress,
                    "payload_verified",
                    "Full designed-car payload verified before World Sale injection",
                    payload_profile=primary,
                    payload_profiles=payload_profiles,
                )

        mode = (payload_mode or "").strip().lower()
        if not mode:
            if lossless_individual and target_blueprints:
                mode = "verified_full"
            elif target_blueprints:
                mode = "scanned_public"
            else:
                mode = "donor_unlock"

        if mode == "verified_full":
            emit(
                progress,
                "template",
                f"Verified full payload (vinyls, wheels, colors, parts) — injecting complete design using donor slot CarID #{donor_id}",
                donor_car_id=donor_id,
                targets=len(targets),
                payload_mode=mode,
            )
        elif mode == "scanned_public":
            emit(
                progress,
                "template",
                f"Using scanned public-car payload (vinyls, wheels, colors) from the marketplace listing — donor slot CarID #{donor_id}",
                donor_car_id=donor_id,
                targets=len(targets),
                payload_mode=mode,
            )
        else:
            emit(
                progress,
                "template",
                f"Using donor CarID #{donor_id}; changing only the target CarID for each unlock",
                donor_car_id=donor_id,
                targets=len(targets),
                payload_mode=mode,
            )

        slot_pool: List[dict] = []
        used_slots = set()
        small_job = len(targets) <= 2
        slot_blocks = 4 if small_job else WS_SLOT_BLOCKS
        slot_passes = 1
        confirm_timeout = 5.0 if small_job else 8.0
        one_timeout = float(SMALL_JOB_INJECT_TIMEOUT_SECONDS) if small_job else float(INJECT_ONE_TIMEOUT_SECONDS)
        scan_timeout = 5.0 if small_job else 8.0

        async def refill_slots(passes: int = 1):
            nonlocal slot_pool
            slots = await get_world_sale_slots(
                session,
                token,
                blocks=slot_blocks,
                passes=max(1, min(passes, slot_passes if small_job else passes)),
            )
            fresh = []
            for slot in slots:
                key = (
                    slot.get("carGeneratedID") or "",
                    slot.get("ownerID") or "",
                    slot.get("carID", slot.get("CarID", 0)),
                )
                if key not in used_slots:
                    fresh.append(slot)
            slot_pool.extend(fresh)
            if not fresh:
                try:
                    import world_sale_health
                    health = world_sale_health.get_status()
                    if health.get("delayed"):
                        raise RetryableCarJobError(
                            "World Sale has no usable slots; the durable job will continue after the shared cooldown."
                        )
                except RetryableCarJobError:
                    raise
                except Exception:
                    _LOG.exception("Unable to read World Sale circuit state")
            return len(fresh)

        emit(
            progress,
            "slots",
            f"Scanning World Sale for a purchase slot ({slot_blocks} blocks, {slot_passes} pass)…",
            blocks=slot_blocks,
            passes=slot_passes,
        )
        try:
            await asyncio.wait_for(refill_slots(passes=slot_passes), timeout=scan_timeout)
        except asyncio.TimeoutError:
            emit(progress, "slots", f"World Sale scan timed out after {int(scan_timeout)}s — trying with whatever slots were found.")
        emit(
            progress,
            "slots",
            f"World Sale ready: {len(slot_pool)} candidate slots",
            slots=len(slot_pool),
        )

        injected = 0
        replaced_ids = set()
        failed_ids = []

        async def inject_one(cid: int, retry_mode: bool = False) -> bool:
            nonlocal slot_pool, garage_was_readable

            for attempt in range(1, MAX_SLOT_ATTEMPTS + 1):
                if not slot_pool:
                    found = await refill_slots(
                        passes=2 if attempt > 1 or retry_mode else 1
                    )
                    if not found:
                        await asyncio.sleep((0.8 + attempt * 0.4) * random.uniform(0.8, 1.25))
                        continue

                # Try a few different live slots before doing a full rescan.
                last_error = None
                for _ in range(min(4, len(slot_pool))):
                    slot = slot_pool.pop(0)
                    key = (
                        slot.get("carGeneratedID") or "",
                        slot.get("ownerID") or "",
                        slot.get("carID", slot.get("CarID", 0)),
                    )
                    if key in used_slots:
                        continue
                    used_slots.add(key)

                    # A supplied JSON blueprint is authoritative.  This keeps
                    # vinyls/tuning from decrypted exports instead of turning
                    # every requested car into one donor clone.
                    blueprint = (target_blueprints or {}).get(cid)
                    car = (
                        blueprint_to_game_car(
                            blueprint, uid,
                            lossless_individual=lossless_individual,
                        )
                        if blueprint is not None
                        else clone_template_to_car(template, uid, cid)
                    )
                    ok, result, error = await buy_car_from_slot(
                        session, token, slot, car
                    )
                    # The working managed-alt flow uses alt_bootstrap_car.json.
                    # Retry only a confirmed World Sale rejection (result=0),
                    # never an ambiguous timeout, with that compatible shell.
                    if not ok and result == 0:
                        fallback_car = bootstrap_shell_for_design(car, uid, cid)
                        if fallback_car is not None:
                            emit(
                                progress,
                                "payload_fallback",
                                f"#{cid}: full payload was rejected; retrying the same selected body vinyls with the compatible alt shell.",
                                car_id=cid,
                                payload_mode="bootstrap_shell",
                            )
                            fallback_ok, fallback_result, fallback_error = await buy_car_from_slot(
                                session, token, slot, fallback_car
                            )
                            if fallback_ok:
                                car = fallback_car
                                ok, result, error = fallback_ok, fallback_result, fallback_error
                            else:
                                error = (
                                    f"full payload: {error or f'result={result!r}'}; "
                                    f"bootstrap shell: {fallback_error or f'result={fallback_result!r}'}"
                                )
                    if ok:
                        # Strategy A: WS accept is not enough — confirm in garage.
                        delivered = True
                        if CONFIRM_AFTER_BUY:
                            try:
                                delivered = await asyncio.wait_for(
                                    _confirm_car_delivered(
                                        session, token, car, car_id=cid,
                                    ),
                                    timeout=confirm_timeout,
                                )
                            except asyncio.TimeoutError:
                                delivered = False
                                last_error = "garage_confirm_timeout"
                        if not delivered:
                            # Europe TestGetAllCars can lag behind a successful
                            # WSPurchaseCarV3 response. The managed-alt bootstrap
                            # already treats that accepted purchase as the source
                            # of truth. Do the same here: never submit the same
                            # accepted CarID to more slots simply because the
                            # read-back endpoint has not caught up yet.
                            delivered = True
                            emit(
                                progress,
                                "garage_confirm_pending",
                                f"#{cid}: World Sale accepted; TestGetAllCars is still syncing, so the accepted buy is recorded without another purchase retry.",
                                car_id=cid,
                                attempt=attempt,
                                confirmation="world_sale_accept",
                            )
                        owned.add(cid)
                        garage_was_readable = True
                        if cid in owned_before:
                            replaced_ids.add(cid)
                        return True

                    last_error = str(error or f"World Sale result={result!r}")[:240]

                if last_error:
                    emit(
                        progress,
                        "slot_retry",
                        f"#{cid}: World Sale rejected this attempt; rescanning",
                        car_id=cid,
                        attempt=attempt,
                        error=last_error,
                    )

                await asyncio.sleep((0.5 + attempt * 0.35) * random.uniform(0.8, 1.25))

            return False

        total_targets = len(targets)
        for index, cid in enumerate(targets, 1):
            # Strategy A: do not start more buys while World Sale is delayed.
            try:
                import world_sale_health
                if world_sale_health.get_status().get("delayed"):
                    emit(
                        progress,
                        "ws_delayed",
                        "World Sale is delayed — pausing further purchases until the market recovers.",
                    )
                    failed_ids.extend(targets[index - 1 :])
                    break
            except Exception:
                pass

            try:
                ok = await asyncio.wait_for(inject_one(cid), timeout=one_timeout)
            except asyncio.TimeoutError:
                ok = False
                emit(
                    progress,
                    "car_timeout",
                    f"[{index}/{total_targets}] CarID #{cid} timed out after {int(one_timeout)}s — skipping to avoid a hung task",
                    car_id=cid,
                    index=index,
                    total=total_targets,
                )

            if ok:
                injected += 1
                emit(
                    progress,
                    "car_success",
                    f"[{index}/{total_targets}] Unlocked CarID #{cid} · "
                    f"{injected} successful",
                    index=index,
                    total=total_targets,
                    car_id=cid,
                    injected=injected,
                )
                await asyncio.sleep(SUCCESS_DELAY_SECONDS)
                # Periodic garage re-sync on large jobs.
                if injected % VERIFY_BATCH_SIZE == 0 and index < total_targets:
                    try:
                        synced = await get_garage_cars(session, token)
                        for car in synced:
                            if not isinstance(car, dict):
                                continue
                            try:
                                owned.add(int(car.get("CarID", car.get("carID", 0)) or 0))
                            except Exception:
                                pass
                        emit(
                            progress,
                            "batch_verify",
                            f"Garage re-synced after {injected} confirmed deliveries ({len(synced)} cars on account).",
                            injected=injected,
                            garage_count=len(synced),
                        )
                    except Exception:
                        _LOG.exception("Batch garage verify failed after %s deliveries", injected)
            else:
                failed_ids.append(cid)
                emit(
                    progress,
                    "car_failed",
                    f"[{index}/{total_targets}] CarID #{cid} failed; queued for retry",
                    index=index,
                    total=total_targets,
                    car_id=cid,
                )
                await asyncio.sleep(FAIL_DELAY_SECONDS)

        if failed_ids and not small_job:
            emit(
                progress,
                "retry",
                f"Verifying garage before retrying {len(failed_ids)} failed CarIDs…",
                count=len(failed_ids),
            )

            refreshed = await get_garage_cars(session, token)
            refreshed_ids = {
                int(car.get("CarID", car.get("carID", 0)) or 0)
                for car in refreshed
                if isinstance(car, dict)
            }

            retry_ids = []
            for cid in failed_ids:
                if cid in refreshed_ids and not replace_owned:
                    injected += 1
                    emit(
                        progress,
                        "verified",
                        f"Verified CarID #{cid} in garage after delayed server sync",
                        car_id=cid,
                    )
                else:
                    retry_ids.append(cid)

            failed_ids = []
            slot_pool.clear()
            await refill_slots(passes=2)

            for index, cid in enumerate(retry_ids, 1):
                try:
                    ok = await asyncio.wait_for(inject_one(cid, retry_mode=True), timeout=one_timeout)
                except asyncio.TimeoutError:
                    ok = False
                if ok:
                    injected += 1
                    emit(
                        progress,
                        "retry_success",
                        f"Retry unlocked CarID #{cid}",
                        car_id=cid,
                    )
                else:
                    failed_ids.append(cid)
                    emit(
                        progress,
                        "retry_failed",
                        f"Retry failed CarID #{cid}",
                        car_id=cid,
                    )
                await asyncio.sleep(SUCCESS_DELAY_SECONDS if ok else FAIL_DELAY_SECONDS)

        completed = len(ids) - len(failed_ids)
        message = (
            f"{label.title()} complete: {completed}/{len(ids)} CarIDs applied "
            f"({injected} injected, {len(replaced_ids)} existing replaced, {skipped} skipped)"
        )

        emit(
            progress,
            "complete",
            message,
            injected=injected,
            total=len(ids),
            skipped=skipped,
            replaced=len(replaced_ids),
            failed_ids=failed_ids,
        )

        response = {
            "ok": len(failed_ids) == 0,
            "message": message,
            "injected": injected,
            "total": len(ids),
            "skipped": skipped,
            "replaced": len(replaced_ids),
            "failed_ids": failed_ids,
            "donor_car_id": donor_id,
        }
        if payload_profiles:
            response["payload_profiles"] = payload_profiles
            if len(payload_profiles) == 1:
                response["payload_profile"] = next(iter(payload_profiles.values()))
        return response


async def inject_saved_cars(
    email: str,
    password: str,
    progress: Progress = None,
    resume_checkpoint: Optional[dict] = None,
) -> dict:
    """
    Premium section.

    Keep the exact premium CarIDs already present in fixed_16_database.json, but
    use the new template-CarID injection method instead of one blueprint per ID.
    """
    cars = load_car_database()
    return await _inject_car_ids_from_template(
        _unique_ids(cars),
        _template_blueprint(cars),
        email,
        password,
        progress,
        label="premium cars",
        resume_checkpoint=resume_checkpoint,
        target_blueprints=_blueprints_by_id(cars),
        lossless_individual=True,
        payload_mode="verified_full",
    )


async def inject_catalog_car(
    payload: dict,
    target_car_id: int,
    email: str,
    password: str,
    progress: Progress = None,
    resume_checkpoint: Optional[dict] = None,
) -> dict:
    """Inject one saved designed-car payload with its complete vinyl data."""
    cars = _blueprints_from_payload(payload)
    target_car_id = int(target_car_id)
    target = next((car for car in cars if int(car.car_id) == target_car_id), None)
    if target is None:
        raise RuntimeError("The selected designed-car payload is unavailable.")
    return await _inject_car_ids_from_template(
        [target_car_id],
        target,
        email,
        password,
        progress,
        label="designed car",
        resume_checkpoint=resume_checkpoint,
        target_blueprints={target_car_id: target},
        replace_owned=True,
        lossless_individual=True,
        payload_mode="verified_full",
    )


async def inject_public_design_collection(
    payload: dict,
    email: str,
    password: str,
    progress: Progress = None,
    resume_checkpoint: Optional[dict] = None,
) -> dict:
    """Inject a persisted, one-design-per-CarID public collection.

    The collection planner has already selected one full verified design per
    unique CarID from the static catalog and public marketplace. Replacing an
    existing CarID makes a durable retry idempotent and preserves the selected
    design rather than falling back to a generic donor-only car.
    """
    cars = _blueprints_from_payload(payload)
    by_id = _blueprints_by_id(cars)
    ids = sorted(by_id)
    if len(ids) != len(cars):
        raise RuntimeError("The public collection contains duplicate or invalid CarIDs.")
    if not ids:
        raise RuntimeError("The public collection contains no valid car payloads.")
    return await _inject_car_ids_from_template(
        ids,
        _template_blueprint(cars),
        email,
        password,
        progress,
        label="king public collection",
        resume_checkpoint=resume_checkpoint,
        target_blueprints=by_id,
        replace_owned=True,
        lossless_individual=True,
        payload_mode="verified_full",
    )


async def inject_custom_car_file(
    payload: dict,
    email: str,
    password: str,
    progress: Progress = None,
    resume_checkpoint: Optional[dict] = None,
) -> dict:
    """Inject every valid car in an administrator-supplied decrypted save JSON."""
    cars = _blueprints_from_payload(payload)
    if not cars:
        raise RuntimeError("The uploaded safe file contains no readable cars.")
    return await _inject_car_ids_from_template(
        _unique_ids(cars), cars[0], email, password, progress,
        label="admin safe-file cars", resume_checkpoint=resume_checkpoint,
        target_blueprints=_blueprints_by_id(cars),
        replace_owned=True,
        lossless_individual=True,
        payload_mode="verified_full",
    )


async def inject_public_car(
    payload: dict,
    email: str,
    password: str,
    progress: Progress = None,
    resume_checkpoint: Optional[dict] = None,
) -> dict:
    """Inject a marketplace listing using the scanned public-car payload."""
    cars = _blueprints_from_payload(payload)
    if not cars:
        raise RuntimeError("The scanned public-car payload is unavailable.")
    ids = _unique_ids(cars)
    emit(
        progress,
        "payload_verified",
        "Using scanned public-car payload (vinyls, wheels, colors, parts) from the marketplace listing",
        payload_mode="scanned_public",
        total=len(ids),
    )
    return await _inject_car_ids_from_template(
        ids, cars[0], email, password, progress,
        label="public car", resume_checkpoint=resume_checkpoint,
        target_blueprints=_blueprints_by_id(cars),
        replace_owned=True,
        lossless_individual=True,
        payload_mode="scanned_public",
    )


async def inject_event_cars(
    email: str,
    password: str,
    progress: Progress = None,
    resume_checkpoint: Optional[dict] = None,
) -> dict:
    """
    Event section.

    Keep the exact event CarIDs already present in event_cars_database.json, but
    use the same template-CarID injection method.
    """
    cars = load_event_car_database()
    return await _inject_car_ids_from_template(
        _unique_ids(cars),
        _template_blueprint(cars),
        email,
        password,
        progress,
        label="event cars",
        resume_checkpoint=resume_checkpoint,
        target_blueprints=_blueprints_by_id(cars),
        lossless_individual=True,
        payload_mode="verified_full",
    )


async def inject_premium_and_event_cars(
    email: str,
    password: str,
    progress: Progress = None,
    resume_checkpoint: Optional[dict] = None,
) -> dict:
    """Inject the complete premium *and* event-car catalog for one account.

    The two catalogs have separate donor payloads, so they are deliberately run
    in sequence.  Each pass reloads the live garage before it starts; that makes
    an overlapping CarID harmless and keeps retry/resume behaviour durable.
    """
    premium_ids = _unique_ids(load_car_database())
    event_ids = _unique_ids(load_event_car_database())
    all_ids = list(dict.fromkeys([*premium_ids, *event_ids]))

    emit(
        progress,
        "cars_premium",
        f"Injecting {len(premium_ids)} configured premium cars…",
        total=len(all_ids),
    )
    premium_result = await inject_saved_cars(
        email, password, progress, resume_checkpoint=resume_checkpoint
    )

    # Run the event pass even when an individual premium CarID needs a retry.
    # The parent job records the combined failures and resumes only what is
    # still missing, instead of silently leaving the event catalog untouched.
    emit(
        progress,
        "cars_event",
        f"Injecting {len(event_ids)} configured event cars…",
        total=len(all_ids),
    )
    event_result = await inject_event_cars(
        email, password, progress, resume_checkpoint=resume_checkpoint
    )

    failed_ids = list(
        dict.fromkeys(
            [
                *premium_result.get("failed_ids", []),
                *event_result.get("failed_ids", []),
            ]
        )
    )
    injected = int(premium_result.get("injected", 0)) + int(event_result.get("injected", 0))
    skipped = int(premium_result.get("skipped", 0)) + int(event_result.get("skipped", 0))
    completed = len(all_ids) - len(failed_ids)
    message = (
        f"Premium + event cars complete: {completed}/{len(all_ids)} unique CarIDs owned "
        f"({injected} newly injected, {skipped} already owned)"
    )
    emit(
        progress,
        "complete",
        message,
        injected=injected,
        total=len(all_ids),
        skipped=skipped,
        failed_ids=failed_ids,
    )
    return {
        "ok": not failed_ids,
        "message": message,
        "injected": injected,
        "total": len(all_ids),
        "skipped": skipped,
        "failed_ids": failed_ids,
    }


async def inject_all_cars(
    email: str,
    password: str,
    progress: Progress = None,
    resume_checkpoint: Optional[dict] = None,
) -> dict:
    """Inject every CarID in the decrypted 221 JSON, with up to five passes."""
    cars = load_unlock_all_car_database()
    ids = _unique_ids(cars)
    if not ids:
        return {"ok": False, "message": "Unlock All Cars database is empty.", "failed_ids": []}
    blueprints = _blueprints_by_id(cars)
    remaining = list(ids)
    injected = skipped = 0
    failed_ids: List[int] = []
    for pass_number in range(1, 6):
        if not remaining:
            break
        emit(progress, "unlock_all_pass", f"Unlock All JSON pass {pass_number}/5: checking {len(remaining)} cars…", pass_number=pass_number, total_passes=5)
        result = await _inject_car_ids_from_template(
            remaining, _template_blueprint(cars), email, password, progress,
            label="unlock all cars", resume_checkpoint=resume_checkpoint,
            target_blueprints=blueprints,
            lossless_individual=True,
            payload_mode="verified_full",
        )
        injected += int(result.get("injected") or 0)
        skipped += int(result.get("skipped") or 0)
        failed_ids = list(result.get("failed_ids") or [])
        remaining = failed_ids
    completed = len(ids) - len(failed_ids)
    message = f"Unlock All JSON complete after {min(5, pass_number)}/5 passes: {completed}/{len(ids)} configured cars confirmed."
    emit(progress, "complete", message, injected=injected, total=len(ids), skipped=skipped, failed_ids=failed_ids)
    return {"ok": not failed_ids, "message": message, "injected": injected, "total": len(ids), "skipped": skipped, "failed_ids": failed_ids}


async def reinject_missing_backup_cars(
    email: str,
    password: str,
    backup_records: List[dict],
    missing_ids: List[int],
    missing_records: Optional[List[dict]] = None,
    deadline_monotonic: Optional[float] = None,
) -> dict:
    """Quietly restore only original backup CarIDs found missing after a job."""
    selected_records = list(missing_records or [])
    if not selected_records:
        wanted = {int(value) for value in missing_ids if str(value).lstrip("-").isdigit()}
        selected_records = [
            record for record in backup_records or []
            if isinstance(record, dict)
            and int(record.get("CarID", record.get("carID", 0)) or 0) in wanted
        ]
    blueprints = _blueprints_from_garage_records(selected_records)
    by_id = _blueprints_by_id(blueprints)
    remaining = [car_id for car_id in dict.fromkeys(int(value) for value in missing_ids) if car_id in by_id]
    last = {"failed_ids": remaining, "injected": 0, "skipped": 0}
    for _ in range(5):
        if not remaining:
            break
        remaining_seconds = (
            float(deadline_monotonic) - time.monotonic()
            if deadline_monotonic is not None else None
        )
        if remaining_seconds is not None and remaining_seconds <= 0:
            break
        repair = _inject_car_ids_from_template(
            remaining, blueprints[0] if blueprints else None, email, password,
            None, label="backup recovery", target_blueprints=by_id,
            replace_owned=True,
            lossless_individual=True,
        )
        try:
            last = await asyncio.wait_for(repair, timeout=max(0.05, remaining_seconds)) \
                if remaining_seconds is not None else await repair
        except asyncio.TimeoutError:
            _LOG.warning("Backup recovery reached its phase deadline with %s cars pending", len(remaining))
            break
        remaining = list(last.get("failed_ids") or [])
    last["failed_ids"] = remaining
    return last


async def _verify_protection_with_retries(
    job_id: str,
    email: str,
    password: str,
    progress: Progress,
    *,
    allowed_replaced_ids=None,
    attempts: int = 4,
    deadline_monotonic: Optional[float] = None,
) -> tuple[bool, dict, List[dict]]:
    """Retry delayed cloud reads before declaring protection failure."""
    import car_safety_backups

    attempts = max(1, min(2, int(attempts)))
    wait_seconds = 1
    backup = car_safety_backups.get(job_id) or {}
    last_cars: List[dict] = []
    last_comparison = {
        "ok": False,
        "message": "Protection verification could not read the garage.",
        "missing_original_ids": [],
    }
    async with injection_http_session() as session:
        login_timeout = 8.0
        if deadline_monotonic is not None:
            login_timeout = min(login_timeout, max(0.05, deadline_monotonic - time.monotonic()))
        try:
            token, _ = await asyncio.wait_for(login_async(session, email, password), timeout=login_timeout)
        except asyncio.TimeoutError:
            _LOG.warning("job=%s protection login reached its phase deadline", job_id)
            return False, last_comparison, last_cars
        for attempt in range(1, attempts + 1):
            remaining_seconds = (
                float(deadline_monotonic) - time.monotonic()
                if deadline_monotonic is not None else None
            )
            if remaining_seconds is not None and remaining_seconds <= 0:
                break
            eta_seconds = max(1, int(remaining_seconds)) if remaining_seconds is not None else max(
                15, (attempts - attempt + 1) * wait_seconds + 20
            )
            emit(
                progress,
                "finishing",
                f"Finishing Up and Cleaning Out Errors · Estimated time left: about {eta_seconds} seconds",
                eta_seconds=eta_seconds,
                countdown_deadline=(time.time() + remaining_seconds) if remaining_seconds is not None else None,
                cleanup_started=True,
            )
            read_timeout = 6.0
            if remaining_seconds is not None:
                read_timeout = min(read_timeout, max(0.05, remaining_seconds))
            try:
                readable, cars = await asyncio.wait_for(
                    get_garage_cars_result(session, token), timeout=read_timeout
                ) if token else (False, [])
            except asyncio.TimeoutError:
                readable, cars = False, []
                _LOG.warning("job=%s protection read cycle=%s/%s timed out", job_id, attempt, attempts)
            if readable:
                last_cars = cars
                last_comparison = car_safety_backups.compare(
                    backup, cars, allowed_replaced_ids=allowed_replaced_ids
                )
                if last_comparison.get("ok"):
                    saved = car_safety_backups.verify(
                        job_id, cars, allowed_replaced_ids=allowed_replaced_ids
                    )
                    return True, saved, cars
                _LOG.warning(
                    "job=%s protection cycle=%s/%s missing_ids=%s",
                    job_id,
                    attempt,
                    attempts,
                    last_comparison.get("missing_original_ids", []),
                )
            else:
                _LOG.warning("job=%s protection cycle=%s/%s garage unreadable", job_id, attempt, attempts)
            if attempt < attempts:
                sleep_seconds = wait_seconds * random.uniform(0.85, 1.2)
                if deadline_monotonic is not None:
                    sleep_seconds = min(sleep_seconds, max(0.0, deadline_monotonic - time.monotonic()))
                if sleep_seconds > 0:
                    await asyncio.sleep(sleep_seconds)

    if last_cars:
        last_comparison = car_safety_backups.verify(
            job_id, last_cars, allowed_replaced_ids=allowed_replaced_ids
        )
    return False, last_comparison, last_cars


async def inject_with_garage_protection(
    job_id: str,
    kind: str,
    email: str,
    password: str,
    progress: Progress = None,
    resume_checkpoint: Optional[dict] = None,
    site_user_id: str = "",
    catalog_payload: Optional[dict] = None,
    catalog_car_id: Optional[int] = None,
    custom_payload: Optional[dict] = None,
) -> dict:
    """Back up the live garage before World Sale work and prove it survived."""
    import car_safety_backups
    import world_sale_health

    world_sale_health.register_probe_credentials(email, password)

    health = world_sale_health.get_status()
    if health.get("delayed"):
        # The core injector performs its own live-slot scan. Do not reject every
        # website job merely because the shared background probe is stale; this
        # aligns protected jobs with the working alternate-account flow.
        emit(
            progress,
            "worldsale_health_stale",
            "World Sale health probe is delayed; continuing with a live slot scan.",
            health=health,
        )

    async with injection_http_session() as session:
        token, _ = await login_async(session, email, password)
        readable, before = await get_garage_cars_result(session, token) if token else (False, [])

    # Do not make an unreadable Get Cars response a hard website-only block.
    # Fresh and recently warmed accounts can accept World Sale purchases before
    # the garage endpoint catches up, which is how the successful alt workflow
    # operates. Preserve that behavior while surfacing that backup verification
    # must be retried after the write.
    backup = None
    if readable:
        backup = car_safety_backups.create_once(
            job_id, kind=kind, email=email, site_user_id=site_user_id, cars=before
        )
        emit(
            progress,
            "safety_backup",
            f"Safety backup saved: {int(backup.get('original_car_count') or len(before))} original cars recorded.",
            backup_job_id=job_id,
        )
    else:
        emit(
            progress,
            "safety_backup_deferred",
            "Garage verification is temporarily unavailable; continuing with live World Sale injection and deferring safety backup verification.",
            backup_job_id=job_id,
        )

    allowed_replaced_ids = set()
    if kind == "catalog" and int(catalog_car_id or 0) > 0:
        allowed_replaced_ids.add(int(catalog_car_id))
    elif kind in {"custom_safe_file", "shared_design", "garage_recovery"}:
        allowed_replaced_ids.update(_unique_ids(_blueprints_from_payload(custom_payload or {})))

    if kind == "premium":
        result = await inject_saved_cars(email, password, progress, resume_checkpoint)
    elif kind == "event":
        result = await inject_event_cars(email, password, progress, resume_checkpoint)
    elif kind == "unlock_all":
        result = await inject_all_cars(email, password, progress, resume_checkpoint)
    elif kind == "catalog":
        result = await inject_catalog_car(
            catalog_payload or {}, int(catalog_car_id or 0), email, password,
            progress, resume_checkpoint,
        )
    elif kind == "shared_design":
        result = await inject_public_car(
            custom_payload or {}, email, password, progress, resume_checkpoint,
        )
    elif kind == "custom_safe_file":
        result = await inject_custom_car_file(
            custom_payload or {}, email, password, progress, resume_checkpoint,
        )
    else:
        raise RuntimeError(f"Unsupported protected car job: {kind}")

    if backup is None:
        # A purchase result remains authoritative when Get Cars is lagging, just
        # as in the successful alternate bootstrap. Mark the missing backup
        # explicitly instead of rewriting a completed injection as a failure.
        deferred_verification = {
            "ok": False,
            "message": "Safety backup and garage verification were deferred because Get Cars was unavailable before injection.",
            "missing_original_ids": [],
            "missing_original_cars": [],
        }
        result["safety_backup_job_id"] = job_id
        result["safety_verification"] = deferred_verification
        result["protection_incomplete"] = True
        result["protection_diagnostics"] = {
            "protection_verified": False,
            "backup_deferred": True,
            "reason": "garage_unreadable_before_injection",
        }
        emit(
            progress,
            "safety_backup_deferred",
            "World Sale injection finished; garage backup verification is deferred until Get Cars becomes available.",
            backup_job_id=job_id,
            injection_ok=bool(result.get("ok")),
        )
        return result

    original_count = int(backup.get("original_car_count") or len(before) or 0)
    small_job = kind in {"catalog", "shared_design"} or int(result.get("total") or 1) <= 2 or original_count <= 2
    protection_started = time.monotonic()
    visible_seconds = 6 if small_job else VISIBLE_PROTECTION_SECONDS
    silent_seconds = 0 if small_job else min(SILENT_PROTECTION_SECONDS, max(0, PROTECTION_HARD_CAP_SECONDS - visible_seconds))
    visible_deadline = protection_started + min(visible_seconds, PROTECTION_HARD_CAP_SECONDS)
    visible_epoch_deadline = time.time() + min(visible_seconds, PROTECTION_HARD_CAP_SECONDS)
    emit(
        progress,
        "finishing",
        f"Verifying garage · about {int(visible_deadline - time.monotonic())}s",
        eta_seconds=max(1, int(visible_deadline - time.monotonic())),
        countdown_deadline=visible_epoch_deadline,
        cleanup_started=True,
    )

    readable = False
    after: List[dict] = []
    verification = {
        "ok": False,
        "message": "Protection verification is still running.",
        "missing_original_ids": [],
        "missing_original_cars": [],
    }
    recovery = {"failed_ids": [], "injected": 0, "skipped": 0}

    async def protection_cycle(deadline: float, visible_progress: Progress):
        nonlocal readable, verification, after, recovery
        try:
            readable, checked, scanned = await _verify_protection_with_retries(
                job_id, email, password, visible_progress,
                allowed_replaced_ids=allowed_replaced_ids, attempts=2 if small_job else 3,
                deadline_monotonic=min(deadline, protection_started + PROTECTION_HARD_CAP_SECONDS),
            )
        except Exception as exc:
            _LOG.exception("job=%s protection verification cycle raised an exception", job_id)
            remaining_seconds = max(0, int(deadline - time.monotonic()))
            emit(
                progress,
                "protection_check",
                str(exc),
                eta_seconds=remaining_seconds,
                countdown_deadline=time.time() + max(0.0, deadline - time.monotonic()),
                cleanup_started=True,
            )
            if remaining_seconds > 0:
                await asyncio.sleep(min(2.0, remaining_seconds))
            return
        if scanned:
            after = scanned
            verification = checked
        elif checked:
            verification = checked
        if verification.get("ok") or time.monotonic() >= deadline:
            return
        missing_ids = list(verification.get("missing_original_ids") or [])
        missing_records = list(verification.get("missing_original_cars") or [])
        if missing_ids and not small_job and (deadline - time.monotonic()) >= 6:
            # Strategy B: never hammer World Sale while the market is delayed.
            try:
                import world_sale_health
                if world_sale_health.get_status().get("delayed"):
                    remaining_seconds = max(0, int(deadline - time.monotonic()))
                    emit(
                        progress,
                        "protection_check",
                        "World Sale delayed — pausing original-car recovery until slots recover.",
                        eta_seconds=remaining_seconds,
                        countdown_deadline=time.time() + max(0.0, deadline - time.monotonic()),
                        cleanup_started=True,
                        missing_count=len(missing_ids),
                    )
                    if remaining_seconds > 0:
                        await asyncio.sleep(min(5.0, remaining_seconds))
                    return
            except Exception:
                _LOG.exception("job=%s unable to read World Sale health during protection", job_id)
            try:
                recovery = await reinject_missing_backup_cars(
                    email, password, list(backup.get("garage_export") or []),
                    missing_ids, missing_records, deadline_monotonic=deadline,
                )
            except Exception as exc:
                _LOG.exception("job=%s backup recovery cycle raised an exception", job_id)
                emit(
                    progress,
                    "protection_check",
                    str(exc),
                    eta_seconds=max(0, int(deadline - time.monotonic())),
                    countdown_deadline=time.time() + max(0.0, deadline - time.monotonic()),
                    cleanup_started=True,
                )

    while (
        time.monotonic() < visible_deadline
        and not verification.get("ok")
        and (time.monotonic() - protection_started) < PROTECTION_HARD_CAP_SECONDS
    ):
        await protection_cycle(visible_deadline, progress)

    result["safety_backup_job_id"] = job_id
    result["safety_verification"] = verification
    result["backup_recovery"] = recovery
    if verification.get("ok"):
        emit(progress, "safety_verified", f"Original garage verified: {verification.get('original_car_count', 0)} saved cars are still present.", final_car_count=verification.get("final_car_count", 0))
        return result

    # Customer is released at the visible deadline. Silent repair is skipped
    # for 1-car catalog/public jobs so they cannot sit past 30s.
    emit(
        progress,
        "public_success",
        "Car injection completed successfully.",
        public_complete=True,
        cleanup_started=True,
        eta_seconds=0,
    )
    if silent_seconds > 0 and (time.monotonic() - protection_started) < PROTECTION_HARD_CAP_SECONDS:
        silent_deadline = min(
            time.monotonic() + silent_seconds,
            protection_started + PROTECTION_HARD_CAP_SECONDS,
        )
        while time.monotonic() < silent_deadline and not verification.get("ok"):
            await protection_cycle(silent_deadline, None)

    result["safety_verification"] = verification
    result["backup_recovery"] = recovery
    if not verification.get("ok"):
        missing_ids = list(verification.get("missing_original_ids") or [])
        delivered = bool(result.get("ok")) or int(result.get("injected") or 0) > 0
        if small_job and delivered:
            result["protection_incomplete"] = True
            result["protection_diagnostics"] = {
                "protection_verified": False,
                "missing_original_ids": missing_ids,
                "missing_count": len(missing_ids),
                "backup_recovery": recovery,
                "customer_forced_success": True,
            }
            result["ok"] = True
            result["message"] = result.get("message") or "Car injection completed successfully."
        else:
            result.update({
                "ok": False,
                "protection_incomplete": True,
                "message": "Protection recovery remains incomplete after the silent repair window; durable recovery will continue.",
                "missing_original_ids": missing_ids,
                "protection_diagnostics": {
                    "protection_verified": False,
                    "missing_original_ids": missing_ids,
                    "missing_count": len(missing_ids),
                    "backup_recovery": recovery,
                },
            })
        try:
            import car_safety_backups
            car_safety_backups.mark_protection_incomplete(job_id, missing_ids)
        except Exception:
            _LOG.exception("job=%s unable to persist protection_incomplete flag", job_id)
    return result
