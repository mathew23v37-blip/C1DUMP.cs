#!/usr/bin/env python3
"""Run the durable outbox dispatcher and a bounded RQ worker pool on Railway."""

from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
import hardcoded_settings  # noqa: F401 - loads concrete deployment settings


def main() -> int:
    if not os.getenv("REDIS_URL", "").strip() or not os.getenv("DATABASE_URL", "").strip():
        print("REDIS_URL and DATABASE_URL are required for the worker service.", file=sys.stderr)
        return 2

    # 4 concurrent bulk workers targets ~500 accounts in about two hours.
    # Raise RQ_WORKER_PROCESSES up to 8 on larger Railway plans if needed.
    worker_processes = max(1, min(8, int(os.getenv("RQ_WORKER_PROCESSES", "4"))))
    children = [subprocess.Popen([sys.executable, "outbox_dispatcher.py"])]
    children.extend(
        subprocess.Popen([sys.executable, "rq_worker.py"])
        for _ in range(worker_processes)
    )
    print(f"Started durable dispatcher with {worker_processes} RQ worker processes.", flush=True)
    stopping = False

    def stop(signum, _frame):
        nonlocal stopping
        if stopping:
            return
        stopping = True
        for child in children:
            if child.poll() is None:
                child.send_signal(signum)

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)

    exit_code = 0
    try:
        while True:
            for child in children:
                code = child.poll()
                if code is not None:
                    exit_code = code or 1
                    stop(signal.SIGTERM, None)
                    return exit_code
            time.sleep(0.5)
    finally:
        # Give RQ a warm-shutdown window. If Railway ultimately stops the
        # process first, the durable checkpoint/outbox recovery resumes it.
        shutdown_grace = max(30, int(os.getenv("WORKER_SHUTDOWN_GRACE_SECONDS", "300")))
        deadline = time.time() + shutdown_grace
        for child in children:
            if child.poll() is None:
                remaining = max(0.1, deadline - time.time())
                try:
                    child.wait(timeout=remaining)
                except subprocess.TimeoutExpired:
                    child.kill()
        for child in children:
            child.wait()


if __name__ == "__main__":
    raise SystemExit(main())
