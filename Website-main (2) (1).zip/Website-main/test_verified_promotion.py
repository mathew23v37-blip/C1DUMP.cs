import contextlib
import unittest

import design_marketplace as marketplace


class FakePromotionDB:
    def __init__(self):
        self.design = {
            "design_id": "public-1",
            "share_code": "TNNR-PUBLIC1",
            "owner_user_id": "seller-1",
            "title": "Public Track Car",
            "description": "Community design",
            "visibility": "public",
            "status": "active",
            "car_id": 123,
            "vinyl_count": 42,
            "payload": {"cars": [{"CarID": 123, "Vynils": [{"id": 1}]}]},
            "photo_data": b"image-bytes",
            "photo_mime": "image/png",
        }
        self.promotion = None
        self.inserts = 0

    def __call__(self):
        return self

    def __enter__(self):
        return self

    def __exit__(self, *_):
        return False

    @contextlib.contextmanager
    def transaction(self):
        yield self

    def execute(self, sql, params=()):
        text = " ".join(str(sql).split())
        if text.startswith("SELECT * FROM shared_car_designs"):
            return _Result(self.design)
        if text.startswith("SELECT promotion_id,enabled"):
            return _Result(self.promotion)
        if text.startswith("INSERT INTO verified_catalog_promotions"):
            self.inserts += 1
            self.promotion = {"promotion_id": params[0], "enabled": True}
            return _Result(None)
        if text.startswith("INSERT INTO shared_design_moderation_events"):
            return _Result(None)
        raise AssertionError(f"Unhandled SQL: {text}")


class _Result:
    def __init__(self, value):
        self.value = value

    def fetchone(self):
        return self.value

    def fetchall(self):
        return []


class VerifiedPromotionTests(unittest.TestCase):
    def setUp(self):
        self.db = FakePromotionDB()
        self.original_connection = marketplace.connection
        marketplace.connection = self.db

    def tearDown(self):
        marketplace.connection = self.original_connection

    def test_promotion_keeps_public_listing_and_is_idempotent(self):
        first = marketplace.promote_public_design("public-1")
        second = marketplace.promote_public_design("public-1")
        self.assertTrue(first["ok"])
        self.assertIn("remains active", first["message"])
        self.assertTrue(second["ok"])
        self.assertTrue(second["already_promoted"])
        self.assertEqual(self.db.inserts, 1)
        self.assertEqual(self.db.design["visibility"], "public")
        self.assertEqual(self.db.design["status"], "active")


if __name__ == "__main__":
    unittest.main()
