# TNNR CPM1 Webtool - Malik Logic Website Build

This is the updated Flask website build with the game-modifier logic adapted from the provided Malik source code. Telegram bot commands, bot tokens, aiogram handlers, admin chat flows, broadcasts, and other Telegram-only behavior are intentionally excluded from the website runtime.

## What changed

- Replaced the old simplified CPM save/load flow with the Malik source flow for:
  - Firebase login
  - token refresh
  - `firebase_uid` storage
  - `GetPlayerRecords3` account loading
  - Malik record decoding/parsing
  - `SavePlayerRecordsPartially8` partial save payloads
  - `SetUserRating4` rank updates
- Expanded the website action routing so modifiers are not limited to cash and coins.
- Expanded the dashboard UI so every mapped modifier has a website button/form.
- Added dependencies needed by the Malik record decode/save logic.
- Removed the old note that `cpm_nuker.py` was a stub.

## Modifier coverage

### Money / coins / presets
- Set money, capped at 50,000,000
- Set coins, capped at 500,000
- Presets:
  - 50M cash + 30K coins
  - 50M cash + 50K coins
  - 50M cash + 100K coins
  - 50M cash + 500K coins

### Profile and stats
- Change player name
- Change player ID
- Set race wins
- Set race losses
- Fix account data

### Feature unlocks
- W16 engine
- Horns
- No damage
- Unlimited fuel
- Smoke
- Animations
- Wheels
- Houses
- Complete all levels
- Max rank
- Unlock all features

### Equipment
- Unlock male equipment
- Unlock female equipment

## Run locally

1. Create and activate a virtual environment:

   ```bash
   python -m venv venv
   source venv/bin/activate
   ```

   On Windows:

   ```bat
   venv\Scripts\activate
   ```

2. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

3. Start the website:

   ```bash
   python app.py
   ```

4. Open the site:

   ```text
   http://127.0.0.1:8080
   ```

## Usage notes

- Log out of the game before applying modifiers on the website.
- Login to the website with the target CPM account.
- If account stats do not appear immediately, click **Refresh Account Data**.
- Apply the desired modifier and wait for a success message.
- Log back into the game only after the website reports success.

## Configuration

Optional environment variables:

- `FLASK_SECRET_KEY` or `FLASK_SECRET` - Flask session secret.
- `PORT` - port used by `python app.py` (defaults to `8080`).
- `CPM_FIREBASE_KEY` - override the Firebase API key from the Malik source.
- `CPM_LOAD_URL` - override the account-load endpoint.
- `CPM_SAVE_URL` - override the account-save endpoint.
- `CPM_RANK_URL` - override the rank endpoint.

## Files

- `app.py` - Flask routes, login, dashboard, and action dispatch.
- `cpm_nuker.py` - website-safe Malik CPM logic and modifier functions.
- `templates/` - HTML templates.
- `requirements.txt` - Python dependencies.
- `runtime.txt` - Python runtime hint for hosting platforms.
