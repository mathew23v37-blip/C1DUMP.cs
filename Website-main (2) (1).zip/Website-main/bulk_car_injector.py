"""Bulk car injection service for the Flask dashboard.

Loads complete car payloads from fixed_16_database.json and uses the
credentials already stored for the signed-in website session.
"""

import asyncio
import json
import os
import random
from copy import deepcopy
from typing import Any, Dict, List, Tuple

import aiohttp

from persistence import seed_data_file

CPM_WORLDSALE_FIREBASE_KEY_ENV = "CPM_WORLDSALE_FIREBASE_KEY"
EUROPE_FUNCTIONS_URL = "https://europe-west1-cp-multiplayer.cloudfunctions.net"
_FUNCTIONS_URL_OVERRIDE = os.getenv("CPM_FUNCTIONS_URL", "").strip()
# Old Railway deployments can retain a US-region override after the CPM1
# service is unavailable there. Never allow it to route a car injection away
# from the verified Europe functions base.
FUNCTIONS_URL = (
    EUROPE_FUNCTIONS_URL
    if "us-central1-cp-multiplayer.cloudfunctions.net" in _FUNCTIONS_URL_OVERRIDE
    else (_FUNCTIONS_URL_OVERRIDE or EUROPE_FUNCTIONS_URL)
)
FIREBASE_URL = "https://www.googleapis.com/identitytoolkit/v3/relyingparty"


def _firebase_key() -> str:
    key = os.getenv(CPM_WORLDSALE_FIREBASE_KEY_ENV, "").strip()
    if not key:
        raise RuntimeError(f"Missing required environment variable {CPM_WORLDSALE_FIREBASE_KEY_ENV} for worldsale/car injector authentication.")
    return key


DATABASE_FILE = os.getenv("CAR_DATABASE_FILE") or seed_data_file("fixed_16_database.json", default={"cars": []})
FORCED_PRICE = 1000


async def _login(session: aiohttp.ClientSession, email: str, password: str) -> Tuple[str | None, str | None]:
    firebase_key = _firebase_key()
    for endpoint in ("verifyPassword", "signupNewUser"):
        try:
            async with session.post(
                f"{FIREBASE_URL}/{endpoint}",
                params={"key": firebase_key},
                json={"email": email, "password": password, "returnSecureToken": True},
                timeout=aiohttp.ClientTimeout(total=15),
            ) as response:
                data = await response.json(content_type=None)
                token = data.get("idToken")
                if token:
                    return token, data.get("localId")
        except Exception:
            continue
    return None, None


async def _api(session: aiohttp.ClientSession, token: str, endpoint: str, data: Any) -> Tuple[int, str]:
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}"}
    try:
        async with session.post(
            f"{FUNCTIONS_URL}/{endpoint}",
            json={"data": data},
            headers=headers,
            timeout=aiohttp.ClientTimeout(total=20),
        ) as response:
            return response.status, await response.text()
    except Exception as exc:
        return 500, str(exc)


async def _get_slots(session: aiohttp.ClientSession, token: str) -> List[dict]:
    _, raw = await _api(session, token, "WSGetCarListV3", 20)
    try:
        response = json.loads(raw)
        result = response.get("result")
        slots = json.loads(result) if isinstance(result, str) else result
        return slots if isinstance(slots, list) else []
    except Exception:
        return []


def _load_cars() -> List[dict]:
    path = DATABASE_FILE
    if not os.path.isabs(path):
        path = seed_data_file(path, default={"cars": []})

    with open(path, "r", encoding="utf-8") as handle:
        database = json.load(handle)

    source = database.get("cars", []) if isinstance(database, dict) else database
    if not isinstance(source, list):
        raise ValueError("The car database must contain a cars array.")

    key_map = {
        "car_id": "CarID",
        "type_to_install": "typeToInstall",
        "bought_parts": "BoughtParts",
        "vynils": "Vynils",
        "window_vinyls": "WindowVinyls",
        "flag_id": "flagID",
        "fso_data": "fsoData",
        "installed_police_lights": "installedPoliceLights",
        "data_version": "dataVersion",
    }

    cars: List[dict] = []
    for entry in source:
        if not isinstance(entry, dict):
            continue
        car = {key_map.get(key, key): deepcopy(value) for key, value in entry.items() if key != "source_slot"}
        car_id = car.get("CarID")
        if not car_id:
            continue
        car.setdefault("vectors", [])
        car.setdefault("floats", [])
        car.setdefault("gears", [])
        car.setdefault("typeToInstall", [])
        car.setdefault("BoughtParts", [])
        car.setdefault("texts", ["", "", "", ""])
        car.setdefault("Vynils", {"allVynils": [], "CarID": car_id})
        car.setdefault("WindowVinyls", {})
        car.setdefault("flagID", -1)
        car.setdefault("fsoData", [-1, 0, 255, 255, 255, 255, 255, 255])
        car.setdefault("installedPoliceLights", [8, 2, 0, 0, -1])
        car["dataVersion"] = 3
        if isinstance(car.get("Vynils"), dict):
            car["Vynils"]["CarID"] = car_id
        cars.append(car)
    return cars


def _prepare_car(car: dict, uid: str) -> dict:
    prepared = deepcopy(car)
    car_id = int(prepared["CarID"])

    texts = prepared.get("texts")
    if isinstance(texts, str):
        texts = [texts, "", "", ""]
    elif not isinstance(texts, list):
        texts = ["", "", "", ""]
    while len(texts) < 4:
        texts.append("")
    if not texts[2]:
        texts[2] = f"{(uid or 'UNKNOWN')[:8].upper()}_{car_id}_HZ"
    prepared["texts"] = texts

    vinyls = prepared.get("Vynils")
    if not isinstance(vinyls, dict):
        vinyls = {"allVynils": []}
    vinyls["CarID"] = car_id
    prepared["Vynils"] = vinyls
    prepared["dataVersion"] = 3
    return prepared


async def _purchase(session: aiohttp.ClientSession, token: str, slot: dict, car: dict) -> bool:
    payload = {
        "ownerID": slot.get("ownerID", ""),
        "ownerName": slot.get("ownerName", ""),
        "description": slot.get("description", ""),
        "CarID": slot.get("carID") or slot.get("CarID") or 0,
        "carGeneratedID": slot.get("carGeneratedID", ""),
        "ownerAccountID": slot.get("ownerAccountID", ""),
        "oneCar": car,
        "vynilOneCar": car.get("Vynils", {}),
        "loadedLocalCar": {"instanceID": random.randint(-999999, -100000)},
        "price": FORCED_PRICE,
        "SellingCar": {},
        "willReject": False,
        "dislike": 1,
        "like": 0,
        "liked": False,
        "disliked": False,
        "mode": 1,
    }
    _, raw = await _api(session, token, "WSPurchaseCarV3", json.dumps(payload))
    try:
        return json.loads(raw).get("result") == 1
    except Exception:
        return False


async def bulk_inject_saved_cars(email: str, password: str) -> Dict[str, Any]:
    """Inject every saved database car, always using a payload price of 1000."""
    if not email or not password:
        return {"ok": False, "message": "Stored login credentials are unavailable."}

    try:
        cars = _load_cars()
    except Exception as exc:
        return {"ok": False, "message": f"Could not load {DATABASE_FILE}: {exc}"}

    if not cars:
        return {"ok": False, "message": "The fixed car database contains no usable cars."}

    connector = aiohttp.TCPConnector(limit=12, limit_per_host=12)
    async with aiohttp.ClientSession(connector=connector) as http:
        try:
            token, uid = await _login(http, email, password)
        except RuntimeError as exc:
            return {"ok": False, "message": str(exc)}
        if not token:
            return {"ok": False, "message": "Stored account login could not be authenticated."}

        injected = 0
        failed: List[int] = []
        used_slots = set()

        for saved_car in cars:
            car_id = int(saved_car["CarID"])
            success = False

            for _ in range(5):
                slots = await _get_slots(http, token)
                available = [
                    slot for slot in slots
                    if (slot.get("carID") or slot.get("CarID")) not in used_slots
                ]
                if not available:
                    await asyncio.sleep(0.5)
                    continue

                slot = available[0]
                slot_id = slot.get("carID") or slot.get("CarID")
                used_slots.add(slot_id)
                prepared = _prepare_car(saved_car, uid or "")
                success = await _purchase(http, token, slot, prepared)
                if success:
                    injected += 1
                    break
                await asyncio.sleep(0.6)

            if not success:
                failed.append(car_id)
            await asyncio.sleep(0.8)

    if failed:
        return {
            "ok": injected > 0,
            "message": f"Bulk injection finished at forced price {FORCED_PRICE}. Injected {injected}/{len(cars)}; failed IDs: {failed}",
            "injected": injected,
            "total": len(cars),
            "failed": failed,
            "price": FORCED_PRICE,
        }

    return {
        "ok": True,
        "message": f"Injected all {injected} cars in bulk at the forced price of {FORCED_PRICE}.",
        "injected": injected,
        "total": len(cars),
        "failed": [],
        "price": FORCED_PRICE,
    }
