# Existing Database: One-Command Managed-Alt Migration

Copy `migrate_alts_existing_db.py`, `migrate_managed_alts_to_postgres.py`, and the updated `user_cpm_alts.py` into the deployed `/app` directory. The service must already have its existing PostgreSQL `DATABASE_URL` configured.

Keep this value set until the migration has finished:

```bash
POSTGRES_ACCOUNTS_ENABLED=0
```

In the Railway **Web** service console, run these commands:

```bash
cd /app

# 1. No-write check: confirms every owner in user_cpm_alts.json exists in your current database.
python migrate_alts_existing_db.py --dry-run

# 2. One command: creates managed-alt tables, imports every preference and alt, then verifies totals.
python migrate_alts_existing_db.py

# 3. After the output shows "exact_match": true, enable persistent runtime storage.
# Set POSTGRES_ACCOUNTS_ENABLED=1 on BOTH Web and Worker services, then redeploy both.
```

The importer defaults to `${DATA_DIR:-/app/data}/user_cpm_alts.json`. If your exported file is elsewhere, use:

```bash
python migrate_alts_existing_db.py --source /app/data/your-backup-folder/user_cpm_alts.json
```

For the file already reviewed, a successful migration should report **20 source user buckets**, **29 source managed alts**, **0 missing site users**, and `exact_match: true`.

> The importer blocks without changing data if one of the alt owners is not already in `site_users`, or if an existing alternate email belongs to a different alternate ID. This prevents attaching an alternate to the wrong site user.
