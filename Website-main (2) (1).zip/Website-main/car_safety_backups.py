"""Durable pre-injection garage snapshots and loss checks."""

from __future__ import annotations

from collections import Counter
import hashlib
import json
import os
import time
from typing import Any, Dict, List, Optional

from persistence import atomic_write_json, load_json, seed_data_file

_FILE = seed_data_file("car_safety_backups.json", default={"backups": {}})
_POSTGRES = bool(os.getenv("DATABASE_URL", "").strip()) and os.getenv(
    "POSTGRES_ACCOUNTS_ENABLED", "auto"
).strip().lower() not in {"0", "false", "no", "off"}


def _car_id_counts(cars: List[dict]) -> Dict[str, int]:
    counts: Counter[str] = Counter()
    for car in cars or []:
        if not isinstance(car, dict):
            continue
        raw = car.get("CarID", car.get("carID"))
        try:
            car_id = int(raw)
        except (TypeError, ValueError):
            continue
        if car_id > 0:
            counts[str(car_id)] += 1
    return dict(counts)


_PROTECTED_CAR_FIELDS = (
    "CarID", "carID", "vectors", "floats", "gears", "typeToInstall",
    "BoughtParts", "texts", "Vynils", "WindowVinyls", "flagID",
    "fsoData", "installedPoliceLights", "dataVersion",
)


def _semantic_value(value):
    """Canonicalize harmless API serialization differences before hashing."""
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        number = round(float(value), 6)
        return int(number) if number.is_integer() else number
    if isinstance(value, dict):
        cleaned = {
            str(key): _semantic_value(item)
            for key, item in value.items()
            if item not in (None, "", [], {})
        }
        return {key: cleaned[key] for key in sorted(cleaned)}
    if isinstance(value, (list, tuple)):
        return [_semantic_value(item) for item in value]
    return str(value)


def _normalized_protected_car(car: dict) -> dict:
    try:
        # Get Cars can return packed or expanded payloads. Normalize both into
        # the same semantic form before comparing designs, wheels, and parts.
        from account_clone import _normalize_export_car
        normalized = _normalize_export_car(car)
        if not isinstance(normalized, dict):
            normalized = car
    except Exception:
        normalized = car
    protected = {
        key: normalized.get(key)
        for key in _PROTECTED_CAR_FIELDS
        if key in normalized and normalized.get(key) not in (None, "", [], {})
    }
    return _semantic_value(protected)


def _fingerprint_car(car: dict) -> tuple[int, str] | None:
    if not isinstance(car, dict):
        return None
    try:
        car_id = int(car.get("CarID", car.get("carID", 0)) or 0)
    except (TypeError, ValueError):
        return None
    if car_id <= 0:
        return None
    encoded = json.dumps(
        _normalized_protected_car(car),
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    ).encode("utf-8")
    return car_id, hashlib.sha256(encoded).hexdigest()


def _car_fingerprints(cars: List[dict], ignored_ids=None) -> Counter:
    """Fingerprint semantic car content, excluding volatile server formatting."""
    ignored = {int(value) for value in (ignored_ids or []) if str(value).lstrip("-").isdigit()}
    found: Counter = Counter()
    for car in cars or []:
        if not isinstance(car, dict):
            continue
        fingerprint = _fingerprint_car(car)
        if fingerprint is None:
            continue
        car_id, digest = fingerprint
        if car_id <= 0 or car_id in ignored:
            continue
        found[(car_id, digest)] += 1
    return found


def compare(record: Dict[str, Any], cars: List[dict], *, allowed_replaced_ids=None) -> Dict[str, Any]:
    """Compare counts and stable payload identities without persisting an interim failure."""
    before = {str(k): int(v) for k, v in (record.get("original_id_counts") or {}).items()}
    after = _car_id_counts(cars)
    missing = []
    for car_id, count in before.items():
        absent = max(0, count - int(after.get(car_id, 0)))
        if absent:
            missing.extend([int(car_id)] * absent)

    ignored = {int(value) for value in (allowed_replaced_ids or []) if str(value).lstrip("-").isdigit()}
    original_fingerprints = _car_fingerprints(list(record.get("garage_export") or []), ignored)
    current_fingerprints = _car_fingerprints(cars, ignored)
    changed_payload_ids = []
    missing_original_cars = []
    remaining_current = current_fingerprints.copy()
    for original in list(record.get("garage_export") or []):
        fingerprint = _fingerprint_car(original)
        if fingerprint is None or fingerprint[0] in ignored:
            continue
        if remaining_current.get(fingerprint, 0) > 0:
            remaining_current[fingerprint] -= 1
        else:
            missing_original_cars.append(original)
    for (car_id, fingerprint), count in original_fingerprints.items():
        absent = max(0, count - int(current_fingerprints.get((car_id, fingerprint), 0)))
        if absent:
            changed_payload_ids.extend([int(car_id)] * absent)

    # A physically missing car also lacks its payload fingerprint. Merge by
    # multiplicity instead of counting the same loss twice.
    missing_counts = Counter(missing)
    changed_counts = Counter(changed_payload_ids)
    missing = []
    for car_id in sorted(set(missing_counts) | set(changed_counts)):
        missing.extend([int(car_id)] * max(missing_counts[car_id], changed_counts[car_id]))
    return {
        "ok": not missing,
        "missing_original_ids": missing,
        "missing_original_cars": missing_original_cars,
        "changed_payload_ids": changed_payload_ids,
        "original_car_count": sum(before.values()),
        "final_car_count": len(cars or []),
        "check_method": "car_id_multiplicity_and_payload_fingerprint",
    }


def get(job_id: str) -> Optional[Dict[str, Any]]:
    if _POSTGRES:
        from postgres_db import connection
        with connection() as conn:
            row = conn.execute(
                "SELECT * FROM car_safety_backups WHERE job_id = %s", (job_id,)
            ).fetchone()
        return dict(row) if row else None
    return load_json(_FILE, {"backups": {}}).get("backups", {}).get(job_id)


def create_once(job_id: str, *, kind: str, email: str, site_user_id: str = "", cars: List[dict]) -> Dict[str, Any]:
    """Save the first readable pre-action garage only; never overwrite it."""
    existing = get(job_id)
    if existing:
        return existing
    now = time.time()
    record = {
        "job_id": job_id,
        "kind": kind,
        "email": (email or "").strip().lower(),
        "site_user_id": site_user_id or "",
        "created_at": now,
        "original_car_count": len(cars or []),
        "original_id_counts": _car_id_counts(cars),
        "garage_export": cars or [],
        "final_car_count": None,
        "missing_original_ids": [],
        "verified_at": None,
        "verification_state": "backup_saved",
    }
    if _POSTGRES:
        from postgres_db import connection
        from psycopg.types.json import Jsonb
        with connection() as conn, conn.transaction():
            conn.execute(
                """
                INSERT INTO car_safety_backups
                    (job_id, kind, email, site_user_id, created_at, original_car_count,
                     original_id_counts, garage_export, verification_state)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,'backup_saved')
                ON CONFLICT (job_id) DO NOTHING
                """,
                (job_id, record["kind"], record["email"], record["site_user_id"], now,
                 record["original_car_count"], Jsonb(record["original_id_counts"]), Jsonb(record["garage_export"])),
            )
        return get(job_id) or record
    data = load_json(_FILE, {"backups": {}})
    data.setdefault("backups", {}).setdefault(job_id, record)
    atomic_write_json(_FILE, data)
    return data["backups"][job_id]


def verify(job_id: str, cars: List[dict], *, allowed_replaced_ids=None) -> Dict[str, Any]:
    record = get(job_id)
    if not record:
        return {"ok": False, "message": "Pre-injection backup was not found."}
    result = compare(record, cars, allowed_replaced_ids=allowed_replaced_ids)
    missing = list(result.get("missing_original_ids") or [])
    state = "verified" if not missing else "protection_failed"
    now = time.time()
    if _POSTGRES:
        from postgres_db import connection
        from psycopg.types.json import Jsonb
        with connection() as conn, conn.transaction():
            conn.execute(
                """UPDATE car_safety_backups SET final_car_count=%s, missing_original_ids=%s,
                   verified_at=%s, verification_state=%s WHERE job_id=%s""",
                (len(cars or []), Jsonb(missing), now, state, job_id),
            )
    else:
        data = load_json(_FILE, {"backups": {}})
        saved = data.setdefault("backups", {}).get(job_id, record)
        saved.update({"final_car_count": len(cars or []), "missing_original_ids": missing,
                      "verified_at": now, "verification_state": state})
        atomic_write_json(_FILE, data)
    return {**result, "state": state}


def recent(limit: int = 10) -> List[Dict[str, Any]]:
    limit = max(1, min(50, int(limit)))
    if _POSTGRES:
        from postgres_db import connection
        with connection() as conn:
            rows = conn.execute("SELECT job_id, kind, email, created_at, original_car_count, final_car_count, verification_state FROM car_safety_backups ORDER BY created_at DESC LIMIT %s", (limit,)).fetchall()
        return [dict(row) for row in rows]
    rows = list(load_json(_FILE, {"backups": {}}).get("backups", {}).values())
    rows.sort(key=lambda row: float(row.get("created_at") or 0), reverse=True)
    return [{key: row.get(key) for key in ("job_id", "kind", "email", "created_at", "original_car_count", "final_car_count", "verification_state")} for row in rows[:limit]]


def for_user(site_user_id: str, limit: int = 2000) -> List[Dict[str, Any]]:
    """Return save metadata belonging to one signed-in site user only."""
    site_user_id = str(site_user_id or "").strip()
    if not site_user_id:
        return []
    limit = max(1, min(5000, int(limit)))
    fields = (
        "job_id", "kind", "email", "site_user_id", "created_at",
        "original_car_count", "final_car_count", "verification_state",
    )
    if _POSTGRES:
        from postgres_db import connection
        with connection() as conn:
            rows = conn.execute(
                """
                SELECT job_id, kind, email, site_user_id, created_at,
                       original_car_count, final_car_count, verification_state
                  FROM car_safety_backups
                 WHERE site_user_id = %s
                 ORDER BY created_at DESC
                 LIMIT %s
                """,
                (site_user_id, limit),
            ).fetchall()
        return [dict(row) for row in rows]

    data = load_json(_FILE, {"backups": {}})
    rows = [
        {key: row.get(key) for key in fields}
        for row in (data.get("backups") or {}).values()
        if isinstance(row, dict) and str(row.get("site_user_id") or "") == site_user_id
    ]
    rows.sort(key=lambda row: float(row.get("created_at") or 0), reverse=True)
    return rows[:limit]


def get_for_user(job_id: str, site_user_id: str) -> Optional[Dict[str, Any]]:
    """Resolve a save only when it belongs to the requesting site account."""
    site_user_id = str(site_user_id or "").strip()
    if not site_user_id:
        return None
    record = get(str(job_id or ""))
    if not record or str(record.get("site_user_id") or "") != site_user_id:
        return None
    return record


def mark_protection_incomplete(job_id: str, missing_ids=None) -> None:
    """Persist that post-job original-car recovery did not fully complete."""
    job_id = str(job_id or "")
    if not job_id:
        return
    missing_ids = list(missing_ids or [])
    now = time.time()
    if _POSTGRES:
        from postgres_db import connection
        from psycopg.types.json import Jsonb
        with connection() as conn, conn.transaction():
            conn.execute(
                """UPDATE car_safety_backups
                      SET verification_state=%s, missing_original_ids=%s, verified_at=%s
                    WHERE job_id=%s""",
                ("protection_incomplete", Jsonb(missing_ids), now, job_id),
            )
        return
    data = load_json(_FILE, {"backups": {}})
    row = data.setdefault("backups", {}).get(job_id)
    if not isinstance(row, dict):
        return
    row["verification_state"] = "protection_incomplete"
    row["missing_original_ids"] = missing_ids
    row["verified_at"] = now
    atomic_write_json(_FILE, data)


def diff_missing_cars(saved_cars: List[dict], live_cars: List[dict]) -> List[dict]:
    """Strategy D: cars present in the save but not (by fingerprint) on the target garage."""
    record = {
        "garage_export": list(saved_cars or []),
        "original_id_counts": _car_id_counts(list(saved_cars or [])),
    }
    comparison = compare(record, list(live_cars or []))
    missing = list(comparison.get("missing_original_cars") or [])
    if missing:
        return missing
    # Fallback when fingerprint list empty but ids differ
    missing_ids = set(int(x) for x in (comparison.get("missing_original_ids") or []))
    if not missing_ids:
        return []
    out = []
    for car in saved_cars or []:
        if not isinstance(car, dict):
            continue
        try:
            cid = int(car.get("CarID", car.get("carID", 0)) or 0)
        except (TypeError, ValueError):
            continue
        if cid in missing_ids:
            out.append(car)
            missing_ids.discard(cid)
    return out
