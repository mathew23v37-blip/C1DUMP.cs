#!/usr/bin/env python3
"""Idempotently import managed alternate accounts from a JSON backup into PostgreSQL."""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path


def load_json(path: Path) -> dict:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Unable to read {path}: {exc}") from exc
    if not isinstance(value, dict) or not isinstance(value.get("users"), dict):
        raise RuntimeError("Expected a managed-alt JSON object containing a users map.")
    return value


def jsonb(value):
    from psycopg.types.json import Jsonb
    return Jsonb(value if isinstance(value, (dict, list)) else {})


def ensure_schema(conn) -> None:
    conn.execute("""
        CREATE TABLE IF NOT EXISTS managed_alt_preferences (
            site_user_id TEXT PRIMARY KEY REFERENCES site_users(user_id) ON DELETE CASCADE,
            email_prefix TEXT NOT NULL DEFAULT '',
            password TEXT NOT NULL DEFAULT '',
            password_set_at DOUBLE PRECISION,
            email_domain TEXT NOT NULL DEFAULT 'proton.me',
            active_id TEXT NOT NULL DEFAULT '',
            updated_at DOUBLE PRECISION NOT NULL
        )
    """)
    conn.execute("ALTER TABLE managed_alt_preferences ADD COLUMN IF NOT EXISTS active_id TEXT NOT NULL DEFAULT ''")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS managed_alt_accounts (
            account_id TEXT PRIMARY KEY,
            site_user_id TEXT NOT NULL REFERENCES site_users(user_id) ON DELETE CASCADE,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            firebase_uid TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'active',
            initialized BOOLEAN NOT NULL DEFAULT FALSE,
            car_count_last INTEGER NOT NULL DEFAULT 0,
            car_count_checked_at DOUBLE PRECISION,
            created_at DOUBLE PRECISION NOT NULL,
            reason TEXT NOT NULL DEFAULT '',
            actions JSONB NOT NULL DEFAULT '[]'::jsonb,
            updated_at DOUBLE PRECISION NOT NULL
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_managed_alt_accounts_user ON managed_alt_accounts(site_user_id, created_at DESC)")


def main() -> int:
    parser = argparse.ArgumentParser(description="Import managed alt accounts from user_cpm_alts.json.")
    parser.add_argument("--source", required=True, help="Path to exported user_cpm_alts.json")
    parser.add_argument("--dry-run", action="store_true", help="Validate source structure and report counts without using PostgreSQL.")
    args = parser.parse_args()

    source = Path(args.source).resolve()
    data = load_json(source)
    if args.dry_run:
        buckets = [bucket for bucket in data.get("users", {}).values() if isinstance(bucket, dict)]
        accounts = [row for bucket in buckets for row in (bucket.get("accounts") or []) if isinstance(row, dict)]
        invalid = sum(1 for row in accounts if not all(str(row.get(key) or "").strip() for key in ("id", "email", "password")))
        print(json.dumps({
            "dry_run": True,
            "source": str(source),
            "source_user_buckets": len(buckets),
            "managed_alt_accounts": len(accounts),
            "accounts_missing_id_email_or_password": invalid,
        }, indent=2, sort_keys=True))
        return 0 if invalid == 0 else 1
    if not os.getenv("DATABASE_URL", "").strip():
        print("DATABASE_URL is required.", file=sys.stderr)
        return 2
    from postgres_db import connection

    users_seen = preferences_upserted = accounts_upserted = skipped_missing_users = 0
    now = time.time()
    with connection() as conn, conn.transaction():
        ensure_schema(conn)
        for raw_user_id, raw_bucket in data.get("users", {}).items():
            if not isinstance(raw_bucket, dict):
                continue
            site_user_id = str(raw_user_id or "").strip()
            if not site_user_id:
                continue
            users_seen += 1
            owner = conn.execute("SELECT 1 FROM site_users WHERE user_id=%s", (site_user_id,)).fetchone()
            if not owner:
                skipped_missing_users += 1
                continue
            pref = raw_bucket.get("preference") if isinstance(raw_bucket.get("preference"), dict) else {}
            conn.execute("""INSERT INTO managed_alt_preferences
                (site_user_id,email_prefix,password,password_set_at,email_domain,active_id,updated_at)
                VALUES (%s,%s,%s,%s,%s,%s,%s)
                ON CONFLICT (site_user_id) DO UPDATE SET email_prefix=EXCLUDED.email_prefix,
                    password=EXCLUDED.password,password_set_at=EXCLUDED.password_set_at,
                    email_domain=EXCLUDED.email_domain,active_id=EXCLUDED.active_id,updated_at=EXCLUDED.updated_at""", (
                site_user_id,
                str(pref.get("email_prefix") or ""),
                str(pref.get("password") or ""),
                pref.get("password_set_at"),
                str(pref.get("email_domain") or "proton.me"),
                str(raw_bucket.get("active_id") or ""),
                now,
            ))
            preferences_upserted += 1
            for raw_account in raw_bucket.get("accounts") or []:
                if not isinstance(raw_account, dict):
                    continue
                account_id = str(raw_account.get("id") or "").strip()
                email = str(raw_account.get("email") or "").strip().lower()
                password = str(raw_account.get("password") or "")
                if not account_id or not email or not password:
                    continue
                conn.execute("""INSERT INTO managed_alt_accounts
                    (account_id,site_user_id,email,password,firebase_uid,status,initialized,car_count_last,
                     car_count_checked_at,created_at,reason,actions,updated_at)
                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                    ON CONFLICT (account_id) DO UPDATE SET site_user_id=EXCLUDED.site_user_id,
                        email=EXCLUDED.email,password=EXCLUDED.password,firebase_uid=EXCLUDED.firebase_uid,
                        status=EXCLUDED.status,initialized=EXCLUDED.initialized,
                        car_count_last=EXCLUDED.car_count_last,car_count_checked_at=EXCLUDED.car_count_checked_at,
                        created_at=EXCLUDED.created_at,reason=EXCLUDED.reason,actions=EXCLUDED.actions,
                        updated_at=EXCLUDED.updated_at""", (
                    account_id, site_user_id, email, password,
                    str(raw_account.get("firebase_uid") or ""), str(raw_account.get("status") or "active"),
                    bool(raw_account.get("initialized")), int(raw_account.get("car_count_last") or 0),
                    raw_account.get("car_count_checked_at"), float(raw_account.get("created_at") or now),
                    str(raw_account.get("reason") or ""), jsonb(raw_account.get("actions") or []), now,
                ))
                accounts_upserted += 1

        stored = conn.execute("SELECT count(*) AS n FROM managed_alt_accounts").fetchone()["n"]
    print(json.dumps({
        "source": str(source),
        "source_user_buckets": users_seen,
        "preferences_upserted": preferences_upserted,
        "accounts_upserted": accounts_upserted,
        "skipped_missing_site_users": skipped_missing_users,
        "persistent_managed_alt_accounts": int(stored),
    }, indent=2, sort_keys=True))
    return 0 if skipped_missing_users == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
