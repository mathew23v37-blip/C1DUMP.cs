#!/usr/bin/env python3
"""Durable PostgreSQL state and outbox for 500-account generation batches."""

from __future__ import annotations

import os
import re
import secrets
import time
import uuid
from typing import Any, Dict, Optional

from postgres_db import connection, ensure_schema


BULK_ACCOUNT_TOTAL = 500
BULK_ACCOUNT_PRICE = 100_000
BULK_ACCOUNT_MAX_COINS = 500_000
BULK_ACCOUNT_MAX_ATTEMPTS = max(2, min(20, int(os.getenv("BULK_ACCOUNT_MAX_ATTEMPTS", "6"))))
BULK_ACCOUNT_EMAIL_DOMAIN = "proton.me"
EMAIL_PREFIX_RE = re.compile(r"^[a-z0-9](?:[a-z0-9._-]{0,46}[a-z0-9])?$")
ACTIVE_STATES = {"queued", "running"}
TERMINAL_ITEM_STATES = {"complete", "failed", "cancelled"}


def _jsonb(value):
    from psycopg.types.json import Jsonb

    return Jsonb(value)


def configured() -> bool:
    return bool(os.getenv("DATABASE_URL", "").strip() and os.getenv("REDIS_URL", "").strip())


def _password() -> str:
    """Return the requested six-digit numeric CPM password."""
    return f"{secrets.randbelow(1_000_000):06d}"


def _password_batch() -> list[str]:
    passwords: list[str] = []
    seen: set[str] = set()
    while len(passwords) < BULK_ACCOUNT_TOTAL:
        password = _password()
        if password not in seen:
            seen.add(password)
            passwords.append(password)
    return passwords


def _normalize_email_prefix(value: str) -> str:
    return str(value or "").strip().lower()


def _email(email_prefix: str, account_index: int) -> str:
    return f"{email_prefix}{int(account_index)}@{BULK_ACCOUNT_EMAIL_DOMAIN}"


def _coin_schedule(
    coin_plan: str,
    coin_amount: Any,
    coin_allocations: Any,
) -> tuple[list[int], list[dict[str, int]]]:
    """Validate and expand a uniform or distributed 500-account coin plan."""
    plan = str(coin_plan or "uniform").strip().lower()
    if plan == "uniform":
        try:
            amount = int(coin_amount)
        except (TypeError, ValueError):
            raise ValueError("Enter a whole-number coin amount.")
        if not 1 <= amount <= BULK_ACCOUNT_MAX_COINS:
            raise ValueError(f"Coin amount must be between 1 and {BULK_ACCOUNT_MAX_COINS:,}.")
        return [amount] * BULK_ACCOUNT_TOTAL, [{"count": BULK_ACCOUNT_TOTAL, "amount": amount}]

    if plan != "spread":
        raise ValueError("Choose one coin amount for all accounts or a spread.")

    normalized: list[dict[str, int]] = []
    for allocation in coin_allocations or []:
        if not isinstance(allocation, dict):
            continue
        try:
            count = int(allocation.get("count"))
            amount = int(allocation.get("amount"))
        except (TypeError, ValueError):
            raise ValueError("Every coin spread row needs a whole-number account count and coin amount.")
        if count < 1:
            raise ValueError("Every coin spread account count must be at least 1.")
        if not 1 <= amount <= BULK_ACCOUNT_MAX_COINS:
            raise ValueError(f"Every spread coin amount must be between 1 and {BULK_ACCOUNT_MAX_COINS:,}.")
        normalized.append({"count": count, "amount": amount})

    if not normalized:
        raise ValueError("Add at least one coin spread row.")
    total = sum(row["count"] for row in normalized)
    if total != BULK_ACCOUNT_TOTAL:
        raise ValueError(f"Coin spread account counts must total exactly {BULK_ACCOUNT_TOTAL}; current total is {total}.")
    schedule = [row["amount"] for row in normalized for _ in range(row["count"])]
    return schedule, normalized


def _event(conn, batch_id: str, account_index: Optional[int], stage: str, message: str, meta=None) -> int:
    row = conn.execute(
        """
        INSERT INTO bulk_account_events
            (batch_id, account_index, stage, message, event_time, meta)
        VALUES (%s, %s, %s, %s, %s, %s)
        RETURNING id
        """,
        (
            batch_id,
            account_index,
            str(stage or "working")[:80],
            str(message or "")[:2000],
            time.time(),
            _jsonb(meta if isinstance(meta, dict) else {}),
        ),
    ).fetchone()
    return int(row["id"])


def create_batch(
    *,
    user_id: str,
    mode: str,
    email_prefix: str,
    coin_plan: str = "uniform",
    coin_amount: Any = 30_000,
    coin_allocations: Any = None,
    source_email: str = "",
    source_password: str = "",
    unlimited: bool = False,
) -> Dict[str, Any]:
    """Charge once and atomically create the parent plus 500 child jobs."""
    ensure_schema()
    # Bulk generation is never covered by the display-only Unlimited Currency
    # switch. It must debit the user's stored (paid) site balance.
    unlimited = False
    mode = str(mode or "").strip().lower()
    # Accept an older page submission during a rolling deploy, but save every
    # new non-clone batch as premium-only.
    if mode == "unlock_all":
        mode = "premium"
    email_prefix = _normalize_email_prefix(email_prefix)
    source_email = str(source_email or "").strip().lower()
    source_password = str(source_password or "")
    if mode not in {"clone", "premium"}:
        return {"ok": False, "message": "Choose Clone Source Garage or Premium & Event Cars."}
    if not EMAIL_PREFIX_RE.fullmatch(email_prefix):
        return {
            "ok": False,
            "message": "Enter an email prefix using 1–48 lowercase letters, numbers, dots, dashes, or underscores.",
        }
    if mode == "clone" and (not source_email or not source_password):
        return {"ok": False, "message": "Source CPM email and password are required for clone mode."}
    try:
        coin_schedule, normalized_coin_plan = _coin_schedule(coin_plan, coin_amount, coin_allocations)
    except ValueError as exc:
        return {"ok": False, "message": str(exc)}

    now = time.time()
    batch_id = uuid.uuid4().hex
    generated_emails = [_email(email_prefix, account_index) for account_index in range(1, BULK_ACCOUNT_TOTAL + 1)]
    generated_passwords = _password_batch()
    with connection() as conn, conn.transaction():
        conn.execute("SELECT pg_advisory_xact_lock(hashtextextended(%s, 0))", (f"bulk-account:{user_id}",))
        existing = conn.execute(
            """
            SELECT batch_id, state FROM bulk_account_batches
             WHERE user_id = %s AND state IN ('queued', 'running')
             ORDER BY created_at DESC LIMIT 1
            """,
            (user_id,),
        ).fetchone()
        if existing:
            return {
                "ok": True,
                "duplicate": True,
                "batch_id": existing["batch_id"],
                "state": existing["state"],
                "message": "Your existing 500-account batch is still active.",
            }

        # Serialize the selected namespace and reject reuse before the debit.
        # The unique item-email constraint remains the final race-safe guard.
        conn.execute(
            "SELECT pg_advisory_xact_lock(hashtextextended(%s, 0))",
            (f"bulk-email-prefix:{email_prefix}@{BULK_ACCOUNT_EMAIL_DOMAIN}",),
        )
        conflict = conn.execute(
            "SELECT email FROM bulk_account_items WHERE email = ANY(%s) LIMIT 1",
            (generated_emails,),
        ).fetchone()
        if conflict:
            return {
                "ok": False,
                "message": (
                    f"That email format is already in use ({conflict['email']}). "
                    "Choose a different prefix; no credits were charged."
                ),
            }

        user = conn.execute(
            "SELECT balance FROM site_users WHERE user_id = %s FOR UPDATE", (user_id,)
        ).fetchone()
        if not user:
            return {"ok": False, "message": "Sign in to a site account first."}
        balance = int(user["balance"])
        charged = 0 if unlimited else BULK_ACCOUNT_PRICE
        if balance < charged:
            return {
                "ok": False,
                "message": f"Not enough balance. Need {BULK_ACCOUNT_PRICE:,}, you have {balance:,}.",
                "balance": balance,
                "cost": BULK_ACCOUNT_PRICE,
            }
        after = balance - charged
        if charged:
            conn.execute(
                "UPDATE site_users SET balance = %s, updated_at = %s WHERE user_id = %s",
                (after, now, user_id),
            )
            conn.execute(
                """
                INSERT INTO credit_ledger
                    (user_id, entry_type, amount, reason, balance_after,
                     event_time, meta, source_key)
                VALUES (%s, 'debit', %s, %s, %s, %s, %s, %s)
                ON CONFLICT (source_key) DO NOTHING
                """,
                (
                    user_id,
                    charged,
                    "bulk_account_generation",
                    after,
                    now,
                    _jsonb({"batch_id": batch_id, "mode": mode, "accounts": BULK_ACCOUNT_TOTAL}),
                    f"bulk-account-debit:{batch_id}",
                ),
            )

        conn.execute(
            """
            INSERT INTO bulk_account_batches
                (batch_id, user_id, mode, email_prefix, source_email, source_password,
                 total_accounts, price, charged, state, created_at, updated_at,
                 last_message)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, 'queued', %s, %s, %s)
            """,
            (
                batch_id,
                user_id,
                mode,
                email_prefix,
                source_email or None,
                source_password or None,
                BULK_ACCOUNT_TOTAL,
                BULK_ACCOUNT_PRICE,
                charged,
                now,
                now,
                "Payment accepted. Preparing 500 durable account jobs.",
            ),
        )
        for account_index in range(1, BULK_ACCOUNT_TOTAL + 1):
            email = generated_emails[account_index - 1]
            password = generated_passwords[account_index - 1]
            conn.execute(
                """
                INSERT INTO bulk_account_items
                    (batch_id, account_index, email, password, coin_amount, state, stage,
                     last_message, max_attempts, created_at, updated_at)
                VALUES (%s, %s, %s, %s, %s, 'pending', 'waiting', %s, %s, %s, %s)
                """,
                (
                    batch_id,
                    account_index,
                    email,
                    password,
                    coin_schedule[account_index - 1],
                    "Saved safely and waiting for a worker.",
                    BULK_ACCOUNT_MAX_ATTEMPTS,
                    now,
                    now,
                ),
            )
            conn.execute(
                """
                INSERT INTO bulk_account_outbox
                    (batch_id, account_index, available_at, created_at, updated_at)
                VALUES (%s, %s, %s, %s, %s)
                """,
                (batch_id, account_index, now, now, now),
            )
        _event(
            conn,
            batch_id,
            None,
            "batch_created",
            f"100,000-credit package accepted — 500 {mode.replace('_', ' ')} accounts saved to the durable queue.",
            {
                "charged": charged,
                "balance": after,
                "total": BULK_ACCOUNT_TOTAL,
                "email_prefix": email_prefix,
                "email_domain": BULK_ACCOUNT_EMAIL_DOMAIN,
                "coin_plan": normalized_coin_plan,
            },
        )
    return {
        "ok": True,
        "duplicate": False,
        "batch_id": batch_id,
        "state": "queued",
        "charged": charged,
        "balance": after,
        "total_accounts": BULK_ACCOUNT_TOTAL,
        "email_prefix": email_prefix,
        "email_domain": BULK_ACCOUNT_EMAIL_DOMAIN,
        "coin_plan": normalized_coin_plan,
    }


def get_batch(batch_id: str, user_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
    where = "b.batch_id = %s"
    params: list[Any] = [batch_id]
    if user_id is not None:
        where += " AND b.user_id = %s"
        params.append(user_id)
    with connection() as conn:
        row = conn.execute(f"SELECT b.* FROM bulk_account_batches b WHERE {where}", params).fetchone()
    return dict(row) if row else None


def latest_batch(user_id: str) -> Optional[Dict[str, Any]]:
    with connection() as conn:
        row = conn.execute(
            "SELECT * FROM bulk_account_batches WHERE user_id = %s ORDER BY created_at DESC LIMIT 1",
            (user_id,),
        ).fetchone()
    return dict(row) if row else None


def cancel_batch(batch_id: str, user_id: str) -> Dict[str, Any]:
    """Permanently stop a user's active batch without touching its debit."""
    now = time.time()
    with connection() as conn, conn.transaction():
        batch = conn.execute(
            "SELECT * FROM bulk_account_batches WHERE batch_id = %s AND user_id = %s FOR UPDATE",
            (batch_id, user_id),
        ).fetchone()
        if not batch:
            return {"ok": False, "message": "Batch not found."}
        if batch["state"] == "cancelled":
            return {"ok": True, "already_cancelled": True, "message": "This batch is already cancelled."}
        if batch["state"] not in ACTIVE_STATES:
            return {"ok": False, "message": f"This batch can no longer be cancelled ({batch['state']})."}

        counts = conn.execute(
            """
            SELECT COUNT(*) FILTER (WHERE state = 'complete')::int AS completed,
                   COUNT(*) FILTER (WHERE state = 'failed')::int AS failed,
                   COUNT(*) FILTER (WHERE state NOT IN ('complete', 'failed'))::int AS cancelled
              FROM bulk_account_items
             WHERE batch_id = %s
            """,
            (batch_id,),
        ).fetchone()
        conn.execute(
            """
            UPDATE bulk_account_items
               SET state = 'cancelled', stage = 'cancelled',
                   last_message = %s, completed_at = %s,
                   last_heartbeat = %s, updated_at = %s
             WHERE batch_id = %s AND state NOT IN ('complete', 'failed')
            """,
            (
                "Batch cancelled by its owner. No further account work will run.",
                now,
                now,
                now,
                batch_id,
            ),
        )
        outbox_rows = conn.execute(
            "DELETE FROM bulk_account_outbox WHERE batch_id = %s RETURNING account_index",
            (batch_id,),
        ).fetchall()
        message = (
            f"Batch cancelled: {int(counts['completed'] or 0)} completed accounts preserved; "
            f"{int(counts['cancelled'] or 0)} unfinished accounts stopped. No credits were refunded or charged."
        )
        conn.execute(
            """
            UPDATE bulk_account_batches
               SET state = 'cancelled', completed_at = %s, updated_at = %s,
                   last_message = %s, source_password = NULL
             WHERE batch_id = %s
            """,
            (now, now, message, batch_id),
        )
        _event(
            conn,
            batch_id,
            None,
            "cancelled",
            message,
            {"completed": int(counts["completed"] or 0), "cancelled": int(counts["cancelled"] or 0)},
        )
    return {
        "ok": True,
        "message": message,
        "completed": int(counts["completed"] or 0),
        "cancelled": int(counts["cancelled"] or 0),
        "pending_outbox_rows": len(outbox_rows),
    }


def get_item(batch_id: str, account_index: int, *, for_update: bool = False, conn=None):
    suffix = " FOR UPDATE" if for_update else ""
    query = f"""
        SELECT i.*, b.user_id, b.mode, b.source_email, b.source_password,
               b.total_accounts, b.state AS batch_state
          FROM bulk_account_items i
          JOIN bulk_account_batches b ON b.batch_id = i.batch_id
         WHERE i.batch_id = %s AND i.account_index = %s{suffix}
    """
    if conn is not None:
        row = conn.execute(query, (batch_id, int(account_index))).fetchone()
        return dict(row) if row else None
    with connection() as own_conn:
        row = own_conn.execute(query, (batch_id, int(account_index))).fetchone()
    return dict(row) if row else None


def claim_outbox_batch(limit: int = 25) -> list[Dict[str, Any]]:
    now = time.time()
    lease_until = now + 60.0
    with connection() as conn, conn.transaction():
        rows = conn.execute(
            """
            SELECT o.batch_id, o.account_index, o.attempts,
                   i.attempt_count, i.max_attempts, i.state, i.car_amount
              FROM bulk_account_outbox o
              JOIN bulk_account_items i
                ON i.batch_id = o.batch_id AND i.account_index = o.account_index
              JOIN bulk_account_batches b ON b.batch_id = i.batch_id
             WHERE o.dispatched_at IS NULL
               AND o.available_at <= %s
               AND i.state IN ('pending', 'queued', 'retry_pending')
               AND b.state IN ('queued', 'running')
             -- Prefer accounts that already saved the most cars (near-full first).
             -- Fresh/zero-car retries and recently failed partials wait their cooldown
             -- via available_at, so a 19-car failure is not hammered immediately.
             ORDER BY COALESCE(i.car_amount, 0) DESC,
                      o.available_at ASC,
                      o.created_at ASC,
                      o.account_index ASC
             FOR UPDATE OF o SKIP LOCKED
             LIMIT %s
            """,
            # Allow claiming the full 500-account batch in one dispatcher pass.
            (now, max(1, min(500, int(limit)))),
        ).fetchall()
        for row in rows:
            conn.execute(
                """
                UPDATE bulk_account_outbox
                   SET attempts = attempts + 1, available_at = %s, updated_at = %s
                 WHERE batch_id = %s AND account_index = %s
                """,
                (lease_until, now, row["batch_id"], row["account_index"]),
            )
    return [dict(row) for row in rows]


def mark_outbox_dispatched(batch_id: str, account_index: int) -> None:
    now = time.time()
    with connection() as conn, conn.transaction():
        conn.execute(
            """
            UPDATE bulk_account_outbox SET dispatched_at = %s, updated_at = %s
             WHERE batch_id = %s AND account_index = %s
            """,
            (now, now, batch_id, int(account_index)),
        )
        conn.execute(
            """
            UPDATE bulk_account_items SET state = 'queued', updated_at = %s
             WHERE batch_id = %s AND account_index = %s
               AND state IN ('pending', 'retry_pending')
            """,
            (now, batch_id, int(account_index)),
        )


def mark_outbox_error(batch_id: str, account_index: int, error: str, attempts: int) -> None:
    now = time.time()
    # Fair cooldown: short base, grows with attempts, capped so full-batch
    # throughput stays high while failed partials are not immediately re-hit.
    delay = min(90.0, max(3.0, 2.0 ** min(6, max(1, int(attempts)))))
    with connection() as conn:
        conn.execute(
            """
            UPDATE bulk_account_outbox
               SET last_error = %s, available_at = %s, updated_at = %s
             WHERE batch_id = %s AND account_index = %s AND dispatched_at IS NULL
            """,
            ((error or "")[:1000], now + delay, now, batch_id, int(account_index)),
        )


def start_item(batch_id: str, account_index: int) -> Dict[str, Any]:
    now = time.time()
    with connection() as conn, conn.transaction():
        row = get_item(batch_id, account_index, for_update=True, conn=conn)
        if not row:
            raise RuntimeError("Bulk account item was not found.")
        if row["state"] == "cancelled" or row["batch_state"] == "cancelled":
            return {**row, "cancelled": True}
        if row["state"] == "complete":
            return {**row, "already_complete": True}
        if row["state"] not in {"queued", "pending", "retry_pending", "running"}:
            raise RuntimeError(f"Bulk account item is not runnable ({row['state']}).")
        if row["state"] != "running":
            conn.execute(
                """
                UPDATE bulk_account_items
                   SET state = 'running', stage = 'starting',
                       attempt_count = attempt_count + 1,
                       started_at = COALESCE(started_at, %s),
                       last_heartbeat = %s, updated_at = %s,
                       last_message = %s
                 WHERE batch_id = %s AND account_index = %s
                """,
                (
                    now,
                    now,
                    now,
                    "Worker claimed this account and is resuming from its saved checkpoint.",
                    batch_id,
                    int(account_index),
                ),
            )
            conn.execute(
                """
                UPDATE bulk_account_batches
                   SET state = 'running', started_at = COALESCE(started_at, %s),
                       updated_at = %s, last_message = %s
                 WHERE batch_id = %s AND state = 'queued'
                """,
                (now, now, f"Account {account_index}/500 started.", batch_id),
            )
            _event(conn, batch_id, account_index, "starting", f"Account {account_index}/500 claimed by a worker.")
        return get_item(batch_id, account_index, for_update=False, conn=conn) or row


_CAR_SUCCESS_STAGES = {"car_success", "retry_success", "verified", "injected"}


def record_progress(batch_id: str, account_index: int, stage: str, message: str, extra=None) -> Dict[str, Any]:
    now = time.time()
    details = dict(extra) if isinstance(extra, dict) else {}
    with connection() as conn, conn.transaction():
        row = conn.execute(
            "SELECT state, checkpoint FROM bulk_account_items WHERE batch_id = %s AND account_index = %s FOR UPDATE",
            (batch_id, int(account_index)),
        ).fetchone()
        if not row:
            raise RuntimeError("Bulk account progress target was not found.")
        if row["state"] == "cancelled":
            raise RuntimeError("Bulk account was cancelled by its owner.")
        checkpoint = dict(row.get("checkpoint") or {})
        completed_car_ids = {
            int(value) for value in checkpoint.get("completed_car_ids", [])
            if str(value).lstrip("-").isdigit() and int(value) > 0
        }
        car_id = details.get("car_id")
        if stage in _CAR_SUCCESS_STAGES and car_id is not None:
            try:
                car_id = int(car_id)
            except (TypeError, ValueError):
                car_id = 0
            if car_id > 0:
                completed_car_ids.add(car_id)
        completed_steps = set(checkpoint.get("completed_steps") or [])
        if stage == "step_complete" and details.get("step"):
            completed_steps.add(str(details["step"]))
        checkpoint.update({
            "completed_car_ids": sorted(completed_car_ids),
            "completed_count": len(completed_car_ids),
            "completed_steps": sorted(completed_steps),
            "last_stage": str(stage or "working")[:80],
            "last_message": str(message or "")[:500],
            "last_extra": details,
            "last_event_at": now,
        })
        conn.execute(
            """
            UPDATE bulk_account_items
               SET stage = %s, last_message = %s, checkpoint = %s,
                   last_heartbeat = %s, updated_at = %s
             WHERE batch_id = %s AND account_index = %s
            """,
            (
                str(stage or "working")[:80],
                str(message or "")[:2000],
                _jsonb(checkpoint),
                now,
                now,
                batch_id,
                int(account_index),
            ),
        )
        conn.execute(
            "UPDATE bulk_account_batches SET updated_at = %s, last_message = %s WHERE batch_id = %s",
            (now, str(message or "")[:2000], batch_id),
        )
        event_id = _event(conn, batch_id, account_index, stage, message, details)
    checkpoint["event_id"] = event_id
    return checkpoint


def _refresh_batch_state(conn, batch_id: str) -> None:
    now = time.time()
    counts = conn.execute(
        """
        SELECT COUNT(*)::int AS total,
               COUNT(*) FILTER (WHERE state = 'complete')::int AS completed,
               COUNT(*) FILTER (WHERE state = 'failed')::int AS failed
          FROM bulk_account_items WHERE batch_id = %s
        """,
        (batch_id,),
    ).fetchone()
    processed = int(counts["completed"]) + int(counts["failed"])
    if processed >= int(counts["total"]):
        state = "completed" if int(counts["failed"]) == 0 else "completed_with_errors"
        message = f"Batch finished: {int(counts['completed'])} complete, {int(counts['failed'])} failed."
        conn.execute(
            """
            UPDATE bulk_account_batches
               SET state = %s, completed_at = %s, updated_at = %s,
                   last_message = %s, source_password = NULL
             WHERE batch_id = %s
            """,
            (state, now, now, message, batch_id),
        )
        _event(conn, batch_id, None, state, message, dict(counts))


def finish_item(batch_id: str, account_index: int, *, car_amount: int, message: str) -> bool:
    now = time.time()
    with connection() as conn, conn.transaction():
        batch = conn.execute(
            "SELECT state FROM bulk_account_batches WHERE batch_id = %s FOR UPDATE",
            (batch_id,),
        ).fetchone()
        if not batch or batch["state"] == "cancelled":
            conn.execute(
                "DELETE FROM bulk_account_outbox WHERE batch_id = %s AND account_index = %s",
                (batch_id, int(account_index)),
            )
            return False
        updated = conn.execute(
            """
            UPDATE bulk_account_items
               SET state = 'complete', stage = 'complete', last_message = %s,
                   car_amount = %s, completed_at = %s, last_heartbeat = %s,
                   updated_at = %s
             WHERE batch_id = %s AND account_index = %s AND state <> 'cancelled'
            """,
            (str(message)[:2000], max(0, int(car_amount)), now, now, now, batch_id, int(account_index)),
        )
        if not updated.rowcount:
            return False
        conn.execute(
            "DELETE FROM bulk_account_outbox WHERE batch_id = %s AND account_index = %s",
            (batch_id, int(account_index)),
        )
        _event(conn, batch_id, account_index, "complete", message, {"car_amount": max(0, int(car_amount))})
        _refresh_batch_state(conn, batch_id)
    return True


def fail_or_retry_item(batch_id: str, account_index: int, reason: str, *, failed_attempt=None) -> Dict[str, Any]:
    now = time.time()
    with connection() as conn, conn.transaction():
        row = conn.execute(
            """
            SELECT state, attempt_count, max_attempts FROM bulk_account_items
             WHERE batch_id = %s AND account_index = %s FOR UPDATE
            """,
            (batch_id, int(account_index)),
        ).fetchone()
        if not row:
            return {"ok": False, "message": "Bulk account item not found."}
        if row["state"] in TERMINAL_ITEM_STATES:
            return {"ok": True, "terminal": True, "state": row["state"]}
        attempt = int(row["attempt_count"])
        if failed_attempt is not None and int(failed_attempt) != attempt:
            return {"ok": True, "stale": True, "attempt_count": attempt}
        if attempt >= int(row["max_attempts"]):
            conn.execute(
                """
                UPDATE bulk_account_items
                   SET state = 'failed', stage = 'failed', last_message = %s,
                       completed_at = %s, last_heartbeat = %s, updated_at = %s
                 WHERE batch_id = %s AND account_index = %s
                """,
                ((reason or "Retry limit reached.")[:2000], now, now, now, batch_id, int(account_index)),
            )
            conn.execute(
                "DELETE FROM bulk_account_outbox WHERE batch_id = %s AND account_index = %s",
                (batch_id, int(account_index)),
            )
            _event(conn, batch_id, account_index, "failed", reason, {"attempt": attempt})
            _refresh_batch_state(conn, batch_id)
            return {"ok": True, "requeued": False, "state": "failed", "attempt_count": attempt}

        # Fair cooldown before the same account is claimed again. Partial
        # progress (higher car_amount) still ranks first once available_at passes.
        delay = min(120.0, max(4.0, 6.0 * max(1, attempt)))
        conn.execute(
            """
            UPDATE bulk_account_items
               SET state = 'retry_pending', stage = 'retry_pending',
                   last_message = %s, last_heartbeat = %s, updated_at = %s
             WHERE batch_id = %s AND account_index = %s
            """,
            ((reason or "Worker stopped; retry saved.")[:2000], now, now, batch_id, int(account_index)),
        )
        conn.execute(
            """
            INSERT INTO bulk_account_outbox
                (batch_id, account_index, available_at, dispatched_at, attempts,
                 last_error, created_at, updated_at)
            VALUES (%s, %s, %s, NULL, 0, %s, %s, %s)
            ON CONFLICT (batch_id, account_index) DO UPDATE SET
                available_at = EXCLUDED.available_at,
                dispatched_at = NULL,
                attempts = 0,
                last_error = EXCLUDED.last_error,
                updated_at = EXCLUDED.updated_at
            """,
            (batch_id, int(account_index), now + delay, (reason or "")[:1000], now, now),
        )
        _event(conn, batch_id, account_index, "retry_pending", reason, {"attempt": attempt, "retry_in": delay})
    return {"ok": True, "requeued": True, "state": "retry_pending", "attempt_count": attempt}


def recover_stale_items(stale_seconds: int = 1800, limit: int = 100) -> int:
    cutoff = time.time() - max(300, int(stale_seconds))
    with connection() as conn:
        rows = conn.execute(
            """
            SELECT batch_id, account_index, attempt_count
              FROM bulk_account_items
             WHERE state = 'running' AND COALESCE(last_heartbeat, updated_at) < %s
             ORDER BY updated_at LIMIT %s
            """,
            (cutoff, max(1, min(500, int(limit)))),
        ).fetchall()
    recovered = 0
    for row in rows:
        result = fail_or_retry_item(
            row["batch_id"],
            row["account_index"],
            "Worker heartbeat expired. Saved progress will resume automatically.",
            failed_attempt=row["attempt_count"],
        )
        recovered += int(bool(result.get("requeued")))
    return recovered


def revive_pre_initialization_failures(limit: int = 500) -> int:
    """Requeue jobs failed by the old no-player-record implementation once."""
    now = time.time()
    revived_batches = set()
    with connection() as conn, conn.transaction():
        rows = conn.execute(
            """
            SELECT i.batch_id, i.account_index
              FROM bulk_account_items i
              JOIN bulk_account_batches b ON b.batch_id = i.batch_id
             WHERE i.state = 'failed'
               AND lower(i.last_message) LIKE %s
               AND (b.mode IN ('premium', 'unlock_all') OR b.source_password IS NOT NULL)
             ORDER BY i.updated_at
             FOR UPDATE OF i SKIP LOCKED
             LIMIT %s
            """,
            ("%player record is not ready yet%", max(1, min(500, int(limit)))),
        ).fetchall()
        for row in rows:
            batch_id = row["batch_id"]
            account_index = int(row["account_index"])
            conn.execute(
                """
                UPDATE bulk_account_items
                   SET state = 'retry_pending', stage = 'retry_pending',
                       attempt_count = 0, completed_at = NULL,
                       last_message = %s, last_heartbeat = %s, updated_at = %s
                 WHERE batch_id = %s AND account_index = %s
                """,
                (
                    "Player-record initialization fallback added; retrying this saved account without another charge.",
                    now,
                    now,
                    batch_id,
                    account_index,
                ),
            )
            conn.execute(
                """
                INSERT INTO bulk_account_outbox
                    (batch_id, account_index, available_at, dispatched_at,
                     attempts, last_error, created_at, updated_at)
                VALUES (%s, %s, %s, NULL, 0, NULL, %s, %s)
                ON CONFLICT (batch_id, account_index) DO UPDATE SET
                    available_at = EXCLUDED.available_at,
                    dispatched_at = NULL,
                    attempts = 0,
                    last_error = NULL,
                    updated_at = EXCLUDED.updated_at
                """,
                (batch_id, account_index, now, now, now),
            )
            _event(
                conn,
                batch_id,
                account_index,
                "retry_pending",
                "Saved identity revived for the new CPM player-record initialization fallback.",
                {"automatic_fix": True},
            )
            revived_batches.add(batch_id)
        for batch_id in revived_batches:
            conn.execute(
                """
                UPDATE bulk_account_batches
                   SET state = 'running', completed_at = NULL, updated_at = %s,
                       last_message = %s
                 WHERE batch_id = %s
                """,
                (now, "Previously failed fresh records were revived without another charge.", batch_id),
            )
    return len(rows)


def batch_status(batch_id: str, user_id: str, *, after_event_id: int = 0, event_limit: int = 200) -> Optional[Dict[str, Any]]:
    with connection() as conn:
        batch = conn.execute(
            "SELECT * FROM bulk_account_batches WHERE batch_id = %s AND user_id = %s",
            (batch_id, user_id),
        ).fetchone()
        if not batch:
            return None
        counts = conn.execute(
            """
            SELECT COUNT(*)::int AS total,
                   COUNT(*) FILTER (WHERE state = 'complete')::int AS completed,
                   COUNT(*) FILTER (WHERE state = 'failed')::int AS failed,
                   COUNT(*) FILTER (WHERE state = 'cancelled')::int AS cancelled,
                   COUNT(*) FILTER (WHERE state = 'running')::int AS running,
                   COUNT(*) FILTER (WHERE state IN ('pending','queued','retry_pending'))::int AS waiting,
                   COALESCE(SUM(car_amount), 0)::bigint AS total_cars
              FROM bulk_account_items WHERE batch_id = %s
            """,
            (batch_id,),
        ).fetchone()
        active = conn.execute(
            """
            SELECT account_index, email, state, stage, last_message, car_amount,
                   attempt_count, updated_at
              FROM bulk_account_items
             WHERE batch_id = %s AND state IN ('running','retry_pending','queued')
             ORDER BY CASE state WHEN 'running' THEN 0 WHEN 'retry_pending' THEN 1 ELSE 2 END,
                      updated_at DESC LIMIT 30
            """,
            (batch_id,),
        ).fetchall()
        recent_accounts = conn.execute(
            """
            SELECT account_index, email, password, coin_amount, car_amount, state,
                   completed_at, last_message
              FROM bulk_account_items
             WHERE batch_id = %s AND state IN ('complete', 'failed', 'cancelled')
             ORDER BY completed_at DESC NULLS LAST, account_index DESC
             LIMIT 25
            """,
            (batch_id,),
        ).fetchall()
        if int(after_event_id) > 0:
            events = conn.execute(
                """
                SELECT id, account_index, stage, message, event_time, meta
                  FROM bulk_account_events
                 WHERE batch_id = %s AND id > %s
                 ORDER BY id ASC LIMIT %s
                """,
                (batch_id, int(after_event_id), max(1, min(500, int(event_limit)))),
            ).fetchall()
        else:
            events = conn.execute(
                """
                SELECT id, account_index, stage, message, event_time, meta
                  FROM bulk_account_events
                 WHERE batch_id = %s
                 ORDER BY id DESC LIMIT %s
                """,
                (batch_id, max(1, min(500, int(event_limit)))),
            ).fetchall()
            events = list(reversed(events))

    result = dict(batch)
    result.pop("source_password", None)
    stats = {key: int(value or 0) for key, value in dict(counts).items()}
    processed = stats["completed"] + stats["failed"] + stats["cancelled"]
    started_at = float(batch.get("started_at") or batch["created_at"])
    elapsed = max(1.0, time.time() - started_at)
    speed_per_hour = processed / elapsed * 3600.0
    remaining = max(0, stats["total"] - processed)
    eta_seconds = int(remaining / (speed_per_hour / 3600.0)) if speed_per_hour > 0 else None
    result.update({
        "stats": stats,
        "processed": processed,
        "remaining": remaining,
        "progress_percent": round((processed / max(1, stats["total"])) * 100.0, 2),
        "speed_per_hour": round(speed_per_hour, 2),
        "eta_seconds": eta_seconds,
        "active_items": [dict(row) for row in active],
        "recent_accounts": [dict(row) for row in recent_accounts],
        "events": [dict(row) for row in events],
        "next_event_id": int(events[-1]["id"]) if events else int(after_event_id),
    })
    return result


def export_text(batch_id: str, user_id: str) -> Optional[str]:
    with connection() as conn:
        batch = conn.execute(
            "SELECT batch_id FROM bulk_account_batches WHERE batch_id = %s AND user_id = %s",
            (batch_id, user_id),
        ).fetchone()
        if not batch:
            return None
        rows = conn.execute(
            """
            SELECT email, password, car_amount FROM bulk_account_items
             WHERE batch_id = %s AND state = 'complete'
             ORDER BY account_index
            """,
            (batch_id,),
        ).fetchall()
    blocks = []
    for row in rows:
        blocks.append(
            "Email:\n"
            f"{row['email']}\n"
            "Password:\n"
            f"{row['password']}\n"
            "Car Amount:\n"
            f"{int(row['car_amount'] or 0)}\n"
            "-------------------------------"
        )
    return "\n".join(blocks) + ("\n" if blocks else "")
