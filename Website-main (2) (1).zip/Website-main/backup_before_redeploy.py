#!/usr/bin/env python3
"""Create an encrypted-storage-ready, checksum-verified data snapshot before redeploy."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import time
import zipfile
from pathlib import Path

DEFAULT_FILES = (
    "site_accounts.json",
    "user_cpm_alts.json",
    "accounts_pool.json",
    "credentials_backlog.json",
    "credentials_backlog.jsonl",
    "action_log.json",
    "action_log.jsonl",
    "settings.json",
    "live_stats.json",
    "tracker.json",
    "world_sale_health.json",
    "catalog_cars_database.json",
)


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def json_summary(path: Path) -> dict:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {"parseable_json": False}
    if not isinstance(value, dict):
        return {"parseable_json": True, "top_level_type": type(value).__name__}
    summary = {"parseable_json": True, "top_level_keys": sorted(value)[:40]}
    if isinstance(value.get("users"), dict):
        summary["site_or_alt_user_buckets"] = len(value["users"])
    if isinstance(value.get("stripe_topups"), dict):
        summary["stripe_topups"] = len(value["stripe_topups"])
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(description="Back up Railway JSON state before a redeploy.")
    parser.add_argument("--data-dir", default=os.getenv("DATA_DIR", "/app/data"))
    parser.add_argument("--output-dir", default="")
    args = parser.parse_args()

    data_dir = Path(args.data_dir).resolve()
    stamp = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
    output_dir = Path(args.output_dir).resolve() if args.output_dir else data_dir / f"predeploy-backup-{stamp}"
    output_dir.mkdir(parents=True, exist_ok=False)

    manifest = {
        "created_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "source_data_dir": str(data_dir),
        "files": [],
        "warnings": [],
        "security_notice": "This backup contains account emails and passwords. Store and transfer it only through secure private channels.",
    }
    for filename in DEFAULT_FILES:
        source = data_dir / filename
        if not source.is_file():
            manifest["warnings"].append(f"Missing: {filename}")
            continue
        destination = output_dir / filename
        shutil.copy2(source, destination)
        manifest["files"].append({
            "name": filename,
            "bytes": destination.stat().st_size,
            "sha256": digest(destination),
            "summary": json_summary(destination) if filename.endswith(".json") else {},
        })

    manifest_path = output_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    archive = output_dir.with_suffix(".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for path in sorted(output_dir.iterdir()):
            bundle.write(path, arcname=path.name)
    print(json.dumps({
        "backup_directory": str(output_dir),
        "archive": str(archive),
        "archive_sha256": digest(archive),
        "files_copied": len(manifest["files"]),
        "warnings": manifest["warnings"],
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
