#!/usr/bin/env python3
"""One-time, idempotent migration from Railway volume JSON/JSONL into PostgreSQL."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def _load_json(path: Path, default):
    try:
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def _load_jsonl(path: Path):
    rows = []
    try:
        with path.open("r", encoding="utf-8") as handle:
            for line in handle:
                try:
                    value = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(value, dict):
                    rows.append(value)
    except FileNotFoundError:
        pass
    return rows


def _source_key(prefix: str, index: int, payload: dict) -> str:
    encoded = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return f"{prefix}:" + hashlib.sha256(f"{index}:{encoded}".encode("utf-8")).hexdigest()


def migrate_backlog(data_dir: Path) -> dict:
    from postgres_db import connection
    from psycopg.types.json import Jsonb

    credentials = _load_jsonl(data_dir / "credentials_backlog.jsonl")
    if not credentials:
        legacy = _load_json(data_dir / "credentials_backlog.json", [])
        credentials = legacy if isinstance(legacy, list) else []
    actions = _load_jsonl(data_dir / "action_log.jsonl")
    if not actions:
        legacy = _load_json(data_dir / "action_log.json", [])
        actions = legacy if isinstance(legacy, list) else []
    inserted_credentials = inserted_actions = 0
    with connection() as conn, conn.transaction():
        for index, entry in enumerate(credentials):
            if not isinstance(entry, dict):
                continue
            key = _source_key("legacy-credential", index, entry)
            row = conn.execute(
                """
                INSERT INTO backlog_credentials
                    (player_name, email, password, web_uid, recorded_at, payload, source_key)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (source_key) DO NOTHING
                RETURNING id
                """,
                (
                    str(entry.get("player_name") or "Unknown"),
                    str(entry.get("email") or ""),
                    str(entry.get("password") or ""),
                    str(entry.get("web_uid")) if entry.get("web_uid") is not None else None,
                    float(entry.get("recorded_at") or time.time()),
                    Jsonb(entry),
                    key,
                ),
            ).fetchone()
            inserted_credentials += int(bool(row))
        for index, event in enumerate(actions):
            if not isinstance(event, dict):
                continue
            key = _source_key("legacy-action", index, event)
            row = conn.execute(
                """
                INSERT INTO backlog_actions
                    (email, player_name, action, action_title, success, message,
                     web_uid, event_time, payload, source_key)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (source_key) DO NOTHING
                RETURNING id
                """,
                (
                    str(event.get("email") or "unknown"),
                    str(event.get("player_name") or "Unknown"),
                    str(event.get("action") or "unknown"),
                    str(event.get("action_title") or event.get("action") or "Unknown"),
                    bool(event.get("success")),
                    str(event.get("message") or ""),
                    str(event.get("web_uid")) if event.get("web_uid") is not None else None,
                    float(event.get("timestamp") or time.time()),
                    Jsonb(event),
                    key,
                ),
            ).fetchone()
            inserted_actions += int(bool(row))
    return {
        "source_credentials": len(credentials),
        "source_actions": len(actions),
        "inserted_credentials": inserted_credentials,
        "inserted_actions": inserted_actions,
    }


def migrate_settings_and_counters(data_dir: Path) -> dict:
    import postgres_accounts
    from postgres_db import connection

    settings = _load_json(data_dir / "settings.json", {})
    if isinstance(settings, dict) and settings:
        postgres_accounts.save_settings(settings)
    counters = _load_json(data_dir / "live_stats.json", {})
    counter_keys = {
        "coin_injections",
        "cash_injections",
        "premium_car_injections",
        "event_car_injections",
        "player_mod_unlocks",
    }
    imported = 0
    if isinstance(counters, dict):
        with connection() as conn, conn.transaction():
            for key in counter_keys:
                if key not in counters:
                    continue
                conn.execute(
                    """
                    INSERT INTO live_counters (counter_key, counter_value, updated_at)
                    VALUES (%s, %s, %s)
                    ON CONFLICT (counter_key) DO UPDATE SET
                        counter_value = EXCLUDED.counter_value,
                        updated_at = EXCLUDED.updated_at
                    """,
                    (key, int(counters[key]), float(counters.get("updated_at") or time.time())),
                )
                imported += 1
    return {"settings": len(settings) if isinstance(settings, dict) else 0, "live_counters": imported}


def verify_source_accounts(data: dict) -> dict:
    from postgres_db import connection

    users = data.get("users", {}) if isinstance(data, dict) else {}
    ids = [str(user.get("user_id") or user_id) for user_id, user in users.items() if isinstance(user, dict)]
    source_credits = sum(max(0, int(user.get("balance") or 0)) for user in users.values() if isinstance(user, dict))
    sessions = list((data.get("stripe_topups") or {}).keys()) if isinstance(data, dict) else []
    with connection() as conn:
        if ids:
            row = conn.execute(
                "SELECT COUNT(*)::bigint AS users, COALESCE(SUM(balance), 0)::bigint AS credits FROM site_users WHERE user_id = ANY(%s)",
                (ids,),
            ).fetchone()
        else:
            row = {"users": 0, "credits": 0}
        if sessions:
            stripe = conn.execute(
                "SELECT COUNT(*)::bigint AS n FROM stripe_topups WHERE session_id = ANY(%s)",
                (sessions,),
            ).fetchone()["n"]
        else:
            stripe = 0
    result = {
        "source_users": len(ids),
        "postgres_users_from_source": int(row["users"]),
        "source_credits": source_credits,
        "postgres_credits_from_source": int(row["credits"]),
        "source_stripe_topups": len(sessions),
        "postgres_stripe_topups_from_source": int(stripe),
    }
    result["exact_match"] = (
        result["source_users"] == result["postgres_users_from_source"]
        and result["source_credits"] == result["postgres_credits_from_source"]
        and result["source_stripe_topups"] == result["postgres_stripe_topups_from_source"]
    )
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", default=str(Path(os.getenv("DATA_DIR", "/app/data")) / "site_accounts.json"))
    parser.add_argument("--data-dir", default=os.getenv("DATA_DIR", "/app/data"))
    parser.add_argument("--replace-existing", action="store_true", help="Make existing matching PostgreSQL users exactly match the JSON source.")
    parser.add_argument("--accounts-only", action="store_true")
    args = parser.parse_args()
    if not os.getenv("DATABASE_URL", "").strip():
        print("DATABASE_URL is required.", file=sys.stderr)
        return 2
    source = Path(args.source)
    if not source.exists() and source == Path("/app/data/site_accounts.json"):
        source = ROOT / "site_accounts.json"
    data = _load_json(source, {})
    if not isinstance(data, dict) or not isinstance(data.get("users"), dict):
        print(f"Invalid account source: {source}", file=sys.stderr)
        return 2

    import postgres_accounts

    account_result = postgres_accounts.migrate_json_accounts(data, replace_existing=args.replace_existing)
    output = {"source": str(source), "accounts": account_result}
    if not args.accounts_only:
        data_dir = Path(args.data_dir)
        output["settings_and_counters"] = migrate_settings_and_counters(data_dir)
        output["backlog"] = migrate_backlog(data_dir)
    output["verification"] = verify_source_accounts(data)
    print(json.dumps(output, indent=2, sort_keys=True))
    return 0 if output["verification"]["exact_match"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

