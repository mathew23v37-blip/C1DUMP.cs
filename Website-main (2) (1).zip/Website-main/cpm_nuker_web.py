"""
CPM Nuker Web Edition v4.0
Integrated game account modifier for web platform
All features from Malik bot ported to web interface
"""

import asyncio
import aiohttp
import json
import re
import sqlite3
import time
import struct
import hashlib
import traceback
import logging
import os
from copy import deepcopy
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from enum import Enum

from config import data_path
from persistence import atomic_write_json, load_json

try:
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import unpad
    HAS_CRYPTO = True
except ImportError:
    HAS_CRYPTO = False

try:
    import brotli
    HAS_BROTLI = True
except ImportError:
    HAS_BROTLI = False

import zlib
import base64

# ═══════════════════════════════════════════
#  ⚙️  CONFIG
# ═══════════════════════════════════════════

class Config:
    """Central configuration management"""
    CPM_FIREBASE_KEY_ENV = "CPM_FIREBASE_KEY"
    LOAD_URLS = [
        "https://europe-west1-cp-multiplayer.cloudfunctions.net/GetPlayerRecords4",
        "https://europe-west1-cp-multiplayer.cloudfunctions.net/GetPlayerRecords3",
    ]
    SAVE_URLS = [
        "https://europe-west1-cp-multiplayer.cloudfunctions.net/SavePlayerRecordsPartially8",
        "https://europe-west1-cp-multiplayer.cloudfunctions.net/SavePlayerRecordsPartially7",
    ]
    RANK_URLS = [
        "https://europe-west1-cp-multiplayer.cloudfunctions.net/SetUserRating6",
        "https://europe-west1-cp-multiplayer.cloudfunctions.net/SetUserRating5",
        "https://europe-west1-cp-multiplayer.cloudfunctions.net/SetUserRating2",
        "https://europe-west1-cp-multiplayer.cloudfunctions.net/SetUserRating1",
    ]
    LOAD_URL = LOAD_URLS[0]
    SAVE_URL = SAVE_URLS[0]
    RANK_URL = RANK_URLS[0]
    
    MAX_MONEY = 50_000_000
    MAX_COIN = 500_000
    
    DB_PATH = Path(data_path("cpm_web.db"))
    STORE_PATH = Path(data_path("cpm_web_store.json"))
    
    @staticmethod
    def firebase_key():
        key = os.getenv(Config.CPM_FIREBASE_KEY_ENV, "").strip()
        if not key:
            raise RuntimeError(f"Missing required environment variable {Config.CPM_FIREBASE_KEY_ENV} for CPM nuker Firebase authentication.")
        return key

    GAME_HEADERS = {
        "Accept": "*/*",
        "Accept-Encoding": "gzip",
        "Content-Type": "application/json",
        "User-Agent": "UnityPlayer/2022.3.62f2 (UnityWebRequest/1.0, libcurl/8.10.1-DEV)",
        "X-Unity-Version": "2022.3.62f2",
    }

# ═══════════════════════════════════════════
#  📊 LOGGING
# ═══════════════════════════════════════════

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s │ %(levelname)s │ %(message)s",
    datefmt="%H:%M:%S"
)
log = logging.getLogger("CPM-Web")

# ═══════════════════════════════════════════
#  🗄️  STORE MANAGEMENT
# ═══════════════════════════════════════════

class Store:
    """JSON-based persistent storage"""
    
    DEFAULT: Dict[str, Any] = {
        "users": {},
        "audit_log": [],
        "session_stats": {
            "total_logins": 0,
            "total_actions": 0,
            "total_unlocks": 0
        },
        "daily_stats": {},
    }
    
    @staticmethod
    def load() -> Dict[str, Any]:
        try:
            if Config.STORE_PATH.exists():
                data = load_json(str(Config.STORE_PATH), deepcopy(Store.DEFAULT))
                for k, v in Store.DEFAULT.items():
                    if k not in data:
                        data[k] = deepcopy(v)
                return data
            Store.save(Store.DEFAULT)
            return deepcopy(Store.DEFAULT)
        except Exception as e:
            log.error(f"Store load error: {e}")
            Store.save(Store.DEFAULT)
            return deepcopy(Store.DEFAULT)
    
    @staticmethod
    def save(data: Dict[str, Any]) -> None:
        try:
            atomic_write_json(str(Config.STORE_PATH), data, pretty=True)
        except Exception as e:
            log.error(f"Store save error: {e}")

# ═══════════════════════════════════════════
#  🔐 CRYPTO & PARSING
# ═══════════════════════════════════════════

def make_xor_key(uid: str) -> bytes:
    """Generate XOR key from user ID"""
    chars = list(uid)
    if len(chars) >= 9:
        chars[1], chars[8] = chars[8], chars[1]
    if len(chars) >= 3:
        chars.pop(2)
    if len(chars) >= 5:
        chars.append(chars[4])
    return "".join(chars).encode("utf-8")

def xor_bytes(data: bytes, key: bytes) -> bytes:
    """XOR encryption/decryption"""
    return bytes(data[i] ^ key[i % len(key)] for i in range(len(data)))

def decompress(data: bytes) -> Optional[bytes]:
    """Try multiple decompression methods"""
    if HAS_BROTLI:
        try:
            return brotli.decompress(data)
        except:
            pass
    try:
        return zlib.decompress(data, zlib.MAX_WBITS | 16)
    except:
        pass
    try:
        return zlib.decompress(data)
    except:
        pass
    return None

def decrypt_aes(data: bytes, key: bytes) -> Optional[bytes]:
    """AES-CBC decryption"""
    if not HAS_CRYPTO:
        return None
    try:
        cipher = AES.new(key[:16], AES.MODE_CBC, b"\x00" * 16)
        return unpad(cipher.decrypt(data), 16)
    except:
        return None

def _md5(t):
    return hashlib.md5(t.encode()).digest()

def _sha1(t):
    return hashlib.sha1(t.encode()).digest()[:16]

def build_aes_keys(uid, password=None, email=None):
    """Build all possible AES keys for decryption"""
    keys = [_md5("olzhas_carparking")]
    if password:
        keys += [_md5(password), _sha1(password)]
    if uid:
        keys += [_md5(uid), _sha1(uid)]
    if email:
        keys.append(_md5(email))
    return keys

# ═══════════════════════════════════════════
#  📦 BINARY PARSING
# ═══════════════════════════════════════════

class Reader:
    """Binary data reader"""
    
    def __init__(self, data):
        self.buf = data
        self.pos = 0
    
    def has_bytes(self, n):
        return self.pos + n <= len(self.buf)
    
    def read_byte(self):
        if not self.has_bytes(1):
            return 0
        v = self.buf[self.pos]
        self.pos += 1
        return v
    
    def read_int(self):
        if not self.has_bytes(4):
            self.pos = len(self.buf)
            return 0
        v = struct.unpack_from("<i", self.buf, self.pos)[0]
        self.pos += 4
        return v
    
    def read_float(self):
        if not self.has_bytes(4):
            self.pos = len(self.buf)
            return 0.0
        v = struct.unpack_from("<f", self.buf, self.pos)[0]
        self.pos += 4
        return v
    
    def read_string(self):
        marker = self.read_int()
        if marker in (0, -1):
            return ""
        length = (-marker) - 1 if marker < -1 else marker
        if marker < -1:
            self.read_int()
        if length > 1_000_000:
            length = 1_000_000
        if not self.has_bytes(length):
            return ""
        text = self.buf[self.pos:self.pos + length].decode("utf-8", errors="replace")
        self.pos += length
        return text.replace("\x00", "").strip()
    
    def read_list(self, item_fn):
        count = self.read_int()
        if count <= 0 or count > 1_000_000:
            return []
        result = []
        for _ in range(count):
            if self.pos >= len(self.buf):
                break
            v = item_fn()
            if v is not None:
                result.append(v)
        return result
    
    def read_dict(self):
        count = self.read_int()
        if count <= 0 or count > 1_000_000:
            return {}
        d = {}
        for _ in range(count):
            if self.pos >= len(self.buf):
                break
            d[self.read_int()] = self.read_int()
        return d
    
    def read_equipment(self):
        if self.read_byte() == 0:
            return None
        return {
            "hair": self.read_list(self.read_int),
            "face": self.read_list(self.read_int),
            "beard": self.read_list(self.read_int),
            "cap": self.read_list(self.read_int),
            "mask": self.read_list(self.read_int),
            "top": self.read_list(self.read_int),
            "gloves": self.read_list(self.read_int),
            "bag": self.read_list(self.read_int),
            "pants": self.read_list(self.read_int),
            "shoes": self.read_list(self.read_int),
            "glasses": self.read_list(self.read_int),
            "SelectedEquipments": self.read_list(self.read_int),
            "Gender": self.read_int(),
        }

def parse_player(buf):
    """Parse binary player data"""
    r = Reader(buf)
    if r.read_byte() == 0:
        return None
    p = {}
    p["Name"] = r.read_string()
    p["money"] = r.read_int()
    p["coin"] = r.read_int()
    p["localID"] = r.read_string()
    p["boughtFsos"] = r.read_list(r.read_int)
    
    def read_friend():
        r.read_byte()
        return {
            "id": r.read_string(),
            "Name": r.read_string(),
            "accountID": r.read_string()
        }
    
    p["FriendsID"] = r.read_list(read_friend)
    p["LevelsDoneTime"] = r.read_list(r.read_float)
    p["floats"] = r.read_list(r.read_float)
    p["integers"] = r.read_list(r.read_int)
    p["fcar"] = r.read_list(r.read_int)
    p["favouriteWheels"] = r.read_list(r.read_int)
    p["favouriteVinyls"] = r.read_list(r.read_int)
    p["favouriteEmojis"] = r.read_list(r.read_int)
    p["personEquipmentsMale"] = r.read_equipment()
    p["personEquipmentsFemale"] = r.read_equipment()
    
    if r.read_byte() == 0:
        p["platesData"] = None
    else:
        def read_vinyl():
            r.read_byte()
            def rv():
                return {
                    "x": r.read_float(),
                    "y": r.read_float(),
                    "z": r.read_float()
                }
            return {
                "vectors": r.read_list(rv),
                "v": r.read_list(r.read_string),
                "floats": r.read_list(r.read_float),
                "text": r.read_string()
            }
        
        def read_plate():
            r.read_byte()
            return {
                "plateId": r.read_int(),
                "frontCarId": r.read_int(),
                "rearCarId": r.read_int(),
                "vinyls": r.read_list(read_vinyl)
            }
        
        p["platesData"] = {"allPlates": r.read_list(read_plate)}
    
    if r.read_byte() == 0:
        p["carIDnStatus"] = None
    else:
        p["carIDnStatus"] = {
            "carGeneratedIDs": r.read_list(r.read_string),
            "carStatus": r.read_list(r.read_int),
        }
    
    p["allData"] = r.read_string()
    p["flags"] = r.read_dict()
    p["animations"] = r.read_list(r.read_int)
    p["emojiPacks"] = r.read_list(r.read_int)
    p["wheels"] = r.read_list(r.read_int)
    p["boughtPoliceLights"] = r.read_list(r.read_int)
    p["boughtPoliceSirens"] = r.read_list(r.read_int)
    return p

def try_parse(buf):
    """Try parsing with multiple methods"""
    candidates = [buf]
    d1 = decompress(buf)
    if d1:
        candidates.append(d1)
        d2 = decompress(d1)
        if d2:
            candidates.append(d2)
    
    for c in candidates:
        if not c:
            continue
        if len(c) > 0 and c[0] in (17, 23, 24):
            try:
                p = parse_player(c)
                if p and p.get("Name") is not None:
                    return p
            except:
                pass
        try:
            clean = c[3:] if (len(c) >= 3 and c[0] == 0xef and c[1] == 0xbb) else c
            if clean[0] == 123:
                return json.loads(clean.decode("utf-8"))
        except:
            pass
    return None

def decrypt_player_record(base64_text, uid, password=None, email=None):
    """Decrypt player record"""
    try:
        buf = base64.b64decode(base64_text)
    except:
        return {"success": False, "message": "Bad base64"}
    
    if len(buf) < 10:
        return {"success": False, "message": "Too small"}
    
    direct = try_parse(buf)
    if direct:
        return {"success": True, "record": direct}
    
    if uid:
        try:
            xp = xor_bytes(buf, make_xor_key(uid))
            d = decompress(xp)
            if d:
                p = try_parse(d)
                if p:
                    return {"success": True, "record": p}
        except:
            pass
    
    for key in build_aes_keys(uid or "", password, email):
        plain = decrypt_aes(buf, key)
        if not plain:
            continue
        p = try_parse(plain)
        if p:
            return {"success": True, "record": p}
    
    return {"success": False, "message": "Could not decrypt"}

# ═══════════════════════════════════════════
#  ✍️  BINARY WRITING
# ═══════════════════════════════════════════

class Writer:
    """Binary data writer"""
    
    def __init__(self):
        self._p: List[bytes] = []
    
    def write_byte(self, v):
        self._p.append(bytes([v & 0xFF]))
    
    def write_int(self, v):
        self._p.append(struct.pack("<i", int(v or 0)))
    
    def write_float(self, v):
        self._p.append(struct.pack("<f", float(v or 0.0)))
    
    def write_string(self, s):
        if s is None:
            self._p.append(struct.pack("<i", -1))
            return
        s = str(s)
        if s == "":
            self._p.append(struct.pack("<i", 0))
            return
        enc = s.encode("utf-8")
        self._p.append(struct.pack("<ii", -(len(enc)) - 1, len(s)) + enc)
    
    def write_list(self, lst, fn):
        if lst is None:
            self._p.append(struct.pack("<i", -1))
            return
        self._p.append(struct.pack("<i", len(lst)))
        for item in lst:
            fn(item)
    
    def write_equipment(self, data):
        if not data:
            self.write_byte(0)
            return
        self.write_byte(13)
        for k in ["hair", "face", "beard", "cap", "mask", "top", "gloves", "bag", "pants", "shoes", "glasses", "SelectedEquipments"]:
            self.write_list(data.get(k, []), self.write_int)
        self.write_int(data.get("Gender", 0))
    
    def write_plates(self, data):
        if not data:
            self.write_byte(0)
            return
        self.write_byte(1)
        plates = data.get("allPlates", [])
        self._p.append(struct.pack("<i", len(plates)))
        for plate in plates:
            self.write_byte(4)
            self.write_int(plate.get("plateId", 0))
            self.write_int(plate.get("frontCarId", 0))
            self.write_int(plate.get("rearCarId", 0))
            vinyls = plate.get("vinyls", [])
            self._p.append(struct.pack("<i", len(vinyls)))
            for vinyl in vinyls:
                self.write_byte(4)
                vecs = vinyl.get("vectors", [])
                self._p.append(struct.pack("<i", len(vecs)))
                for vec in vecs:
                    self._p.append(
                        struct.pack("<fff", vec.get("x", 0), vec.get("y", 0), vec.get("z", 0))
                    )
                self.write_list(vinyl.get("v", []), self.write_string)
                self.write_list(vinyl.get("floats", []), self.write_float)
                self.write_string(vinyl.get("text", ""))
    
    def write_car_id_status(self, data):
        if not data:
            self.write_byte(0)
            return
        self.write_byte(2)
        self.write_list(data.get("carGeneratedIDs", []), self.write_string)
        self.write_list(data.get("carStatus", []), self.write_int)
    
    def to_bytes(self):
        return b"".join(self._p)

FIELD_MAPPING = [
    (1, "localID"), (2, "money"), (3, "Name"), (4, "coin"), (5, "allData"),
    (6, "boughtFsos"), (7, "boughtPoliceLights"), (8, "boughtPoliceSirens"),
    (9, "FriendsID"), (10, "LevelsDoneTime"), (11, "floats"), (12, "integers"),
    (13, "fcar"), (14, "favouriteWheels"), (15, "favouriteVinyls"),
    (16, "favouriteEmojis"), (18, "emojiPacks"),
    (41, "personEquipmentsMale"), (42, "personEquipmentsFemale"),
    (43, "platesData"), (44, "carIDnStatus"), (45, "flags"),
    (46, "animations"), (48, "wheels"),
]

INT_LIST_FIELDS = {6, 7, 8, 12, 13, 14, 15, 16, 18, 46, 48}
FLOAT_LIST_FIELDS = {10, 11}
ALWAYS_SEND = {"allData"}

def _field_modified(nv, ov):
    if nv is None and ov is None:
        return False
    if nv is None or ov is None:
        return True
    if type(nv) != type(ov):
        return True
    if isinstance(nv, (dict, list)):
        return json.dumps(nv, sort_keys=True) != json.dumps(ov, sort_keys=True)
    return nv != ov

def serialize_field(fid, value):
    w = Writer()
    if fid in (1, 3, 5):
        w.write_string(value)
        return w.to_bytes()
    if fid in (2, 4):
        w.write_int(value or 0)
        return w.to_bytes()
    if fid == 9:
        friends = value or []
        w._p.append(struct.pack("<i", len(friends)))
        for f in friends:
            w.write_byte(3)
            w.write_string((f or {}).get("id", ""))
            w.write_string((f or {}).get("Name", ""))
            w.write_string((f or {}).get("accountID", ""))
        return w.to_bytes()
    if fid in INT_LIST_FIELDS:
        w.write_list(value or [], w.write_int)
        return w.to_bytes()
    if fid in FLOAT_LIST_FIELDS:
        w.write_list(value or [], w.write_float)
        return w.to_bytes()
    if fid in (41, 42):
        w.write_equipment(value)
        return w.to_bytes()
    if fid == 43:
        w.write_plates(value)
        return w.to_bytes()
    if fid == 44:
        w.write_car_id_status(value)
        return w.to_bytes()
    if fid == 45:
        flags = value or {}
        w._p.append(struct.pack("<i", len(flags)))
        for k, v in flags.items():
            w.write_int(int(k))
            w.write_int(int(v))
        return w.to_bytes()
    return None

def build_payload(record, uid, original=None):
    """Build encoded payload for saving"""
    fields = []
    for fid, key in FIELD_MAPPING:
        value = record.get(key)
        if value is None:
            continue
        if key in ALWAYS_SEND:
            should = isinstance(value, str) and len(value) > 0
        elif original is not None:
            should = _field_modified(value, original.get(key))
        else:
            should = True
        if not should:
            continue
        raw = serialize_field(fid, value)
        if raw is not None:
            fields.append((fid, raw))
    
    parts = [struct.pack("<i", len(fields))]
    for fid, raw in fields:
        parts.append(struct.pack("<hi", fid, len(raw)))
        parts.append(raw)
    combined = b"".join(parts)
    compressed = brotli.compress(combined) if HAS_BROTLI else zlib.compress(combined)
    encrypted = xor_bytes(compressed, make_xor_key(uid))
    return base64.b64encode(encrypted).decode("ascii")

# ═══════════════════════════════════════════
#  🎮 CPM NUKER WEB ENGINE
# ═══════════════════════════════════════════

class CPMNukerWeb:
    """Main game account modifier engine"""
    
    def __init__(self):
        self.cache: Dict[str, Dict] = {}
        self._init_db()
    
    def _init_db(self):
        """Initialize SQLite database"""
        with sqlite3.connect(Config.DB_PATH) as c:
            c.execute("""CREATE TABLE IF NOT EXISTS tokens (
                user_id INTEGER PRIMARY KEY,
                auth_token TEXT,
                email TEXT,
                password TEXT,
                refresh_token TEXT,
                firebase_uid TEXT,
                token_expires_at REAL
            )""")
            c.execute("""CREATE TABLE IF NOT EXISTS user_data (
                cache_key TEXT PRIMARY KEY,
                email TEXT,
                data_json TEXT
            )""")
            try:
                c.execute("ALTER TABLE tokens ADD COLUMN firebase_uid TEXT")
            except:
                pass
            c.commit()
    
    def _cache_key(self, uid, email=None):
        if email:
            return f"{uid}_{email}"
        td = self.get_token_data(uid)
        return f"{uid}_{td['email']}" if td and td.get("email") else str(uid)
    
    def save_token(self, uid, auth, email, pw=None, rt=None, fuid=None):
        """Save authentication token"""
        with sqlite3.connect(Config.DB_PATH) as c:
            c.execute("""INSERT OR REPLACE INTO tokens
                (user_id, auth_token, email, password, refresh_token, firebase_uid, token_expires_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (uid, auth, email, pw, rt, fuid, time.time() + 3600))
            c.commit()
    
    def get_token_data(self, uid):
        """Retrieve token data"""
        with sqlite3.connect(Config.DB_PATH) as c:
            row = c.execute("""SELECT auth_token, email, password, refresh_token,
                firebase_uid, token_expires_at FROM tokens WHERE user_id=?""", (uid,)).fetchone()
        if row:
            return {
                "auth_token": row[0],
                "email": row[1],
                "password": row[2],
                "refresh_token": row[3],
                "firebase_uid": row[4],
                "token_expires_at": row[5]
            }
        return None
    
    def update_token(self, uid, auth, rt=None):
        """Update token expiry"""
        exp = time.time() + 3600
        with sqlite3.connect(Config.DB_PATH) as c:
            if rt:
                c.execute("UPDATE tokens SET auth_token=?, refresh_token=?, token_expires_at=? WHERE user_id=?",
                    (auth, rt, exp, uid))
            else:
                c.execute("UPDATE tokens SET auth_token=?, token_expires_at=? WHERE user_id=?",
                    (auth, exp, uid))
            c.commit()
    
    def delete_token(self, uid):
        """Delete token"""
        with sqlite3.connect(Config.DB_PATH) as c:
            c.execute("DELETE FROM tokens WHERE user_id=?", (uid,))
            c.commit()
        for k in [k for k in self.cache if k.startswith(str(uid))]:
            del self.cache[k]
    
    def is_expired(self, uid):
        """Check token expiry"""
        td = self.get_token_data(uid)
        return not td or not td.get("token_expires_at") or td["token_expires_at"] < time.time()
    
    def get_record(self, uid, email=None):
        """Get cached player record"""
        ck = self._cache_key(uid, email)
        if ck not in self.cache:
            with sqlite3.connect(Config.DB_PATH) as c:
                row = c.execute("SELECT data_json FROM user_data WHERE cache_key=?", (ck,)).fetchone()
            if row:
                try:
                    self.cache[ck] = json.loads(row[0])
                except:
                    pass
        return self.cache.get(ck, {})
    
    def set_record(self, uid, data, email=None):
        """Cache player record"""
        ck = self._cache_key(uid, email)
        self.cache[ck] = data
        with sqlite3.connect(Config.DB_PATH) as c:
            c.execute("INSERT OR REPLACE INTO user_data (cache_key, email, data_json) VALUES (?, ?, ?)",
                (ck, email, json.dumps(data)))
            c.commit()
    
    async def _post(self, url, payload, headers):
        """HTTP POST request"""
        try:
            h = {k: v for k, v in headers.items() if k.lower() != "host"}
            timeout = aiohttp.ClientTimeout(total=30)
            async with aiohttp.ClientSession(timeout=timeout, connector=aiohttp.TCPConnector(ssl=False)) as s:
                async with s.post(url, json=payload, headers=h) as r:
                    text = await r.text()
                    try:
                        return json.loads(text)
                    except:
                        return {"raw": text, "status": r.status}
        except Exception as e:
            log.error(f"HTTP: {e}")
            return None
    
    async def login(self, email, password):
        """Login to game"""
        try:
            key = Config.firebase_key()
        except RuntimeError as exc:
            return {"ok": False, "message": str(exc)}
        url = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={key}"
        h = {
            "Accept": "*/*",
            "Accept-Encoding": "gzip",
            "Content-Type": "application/json",
            "User-Agent": "UnityPlayer/2022.3.62f2 (UnityWebRequest/1.0, libcurl/8.10.1-DEV)",
            "X-Unity-Version": "2022.3.62f2"
        }
        p = {
            "email": email,
            "password": password,
            "returnSecureToken": True,
            "clientType": "CLIENT_TYPE_ANDROID"
        }
        try:
            timeout = aiohttp.ClientTimeout(total=30)
            async with aiohttp.ClientSession(timeout=timeout, connector=aiohttp.TCPConnector(ssl=False)) as s:
                async with s.post(url, json=p, headers=h) as resp:
                    text = await resp.text()
                    log.info(f"Login [{resp.status}] {email}: {text[:200]}")
                    try:
                        r = json.loads(text)
                    except:
                        return {"ok": False, "message": "NETWORK_ERROR"}
        except Exception as e:
            log.error(f"Login: {e}")
            return {"ok": False, "message": "NETWORK_ERROR"}
        
        if "idToken" in r:
            return {
                "ok": True,
                "auth": r["idToken"],
                "refresh_token": r.get("refreshToken", ""),
                "firebase_uid": r.get("localId", "")
            }
        err = str(r.get("error", {}).get("message", "")).upper()
        for k in ["EMAIL_NOT_FOUND", "INVALID_PASSWORD", "INVALID_LOGIN_CREDENTIALS", "TOO_MANY_ATTEMPTS", "USER_DISABLED", "INVALID_EMAIL"]:
            if k in err:
                return {"ok": False, "message": k}
        return {"ok": False, "message": f"LOGIN_FAILED: {err[:60]}"}
    
    async def _refresh(self, uid):
        """Refresh token"""
        td = self.get_token_data(uid)
        if not td:
            return False, "NO_TOKEN"
        rt, em, pw = td.get("refresh_token"), td.get("email"), td.get("password")
        if rt:
            try:
                key = Config.firebase_key()
            except RuntimeError as exc:
                return False, str(exc)
            try:
                timeout = aiohttp.ClientTimeout(total=30)
                async with aiohttp.ClientSession(timeout=timeout, connector=aiohttp.TCPConnector(ssl=False)) as s:
                    async with s.post(
                        f"https://securetoken.googleapis.com/v1/token?key={key}",
                        json={"grant_type": "refresh_token", "refresh_token": rt},
                        headers={"Content-Type": "application/json"}
                    ) as resp:
                        r = await resp.json(content_type=None)
                        if r and r.get("id_token"):
                            self.update_token(uid, r["id_token"], r.get("refresh_token", rt))
                            return True, "OK"
            except:
                pass
        if em and pw:
            res = await self.login(em, pw)
            if res.get("ok"):
                self.save_token(uid, res["auth"], em, pw, res.get("refresh_token", ""), res.get("firebase_uid", ""))
                return True, "OK"
        return False, "REFRESH_FAILED"
    
    async def get_auth(self, uid):
        """Get valid auth token"""
        if self.is_expired(uid):
            ok, msg = await self._refresh(uid)
            if not ok:
                return False, msg, ""
        td = self.get_token_data(uid)
        if td and td.get("auth_token"):
            return True, "OK", td["auth_token"]
        return False, "NO_TOKEN", ""
    
    async def load(self, uid, force=False):
        """Load player record from server"""
        td = self.get_token_data(uid)
        if not td:
            return False
        ck = self._cache_key(uid)
        if not force and ck in self.cache:
            return True
        ok, msg, auth = await self.get_auth(uid)
        if not ok:
            return False
        headers = {**Config.GAME_HEADERS, "Authorization": f"Bearer {auth}"}
        diagnostics = []
        for load_url in Config.LOAD_URLS:
            endpoint = load_url.rsplit("/", 1)[-1]
            try:
                r = await self._post(load_url, {"data": None}, headers)
                if not r or not r.get("result"):
                    diagnostics.append(f"{endpoint}=empty")
                    continue
                dec = decrypt_player_record(
                    r["result"], td.get("firebase_uid", ""),
                    td.get("password", ""), td.get("email", "")
                )
                if dec.get("success") and dec.get("record"):
                    self.set_record(uid, dec["record"], td.get("email", ""))
                    log.info(f"✅ Loaded {uid} via {endpoint}: {dec['record'].get('Name')} ${dec['record'].get('money')}")
                    return True
                diagnostics.append(f"{endpoint}=decrypt:{dec.get('message')}")
            except Exception as e:
                diagnostics.append(f"{endpoint}=error:{e}")
        log.error("Load endpoints failed: %s", " | ".join(diagnostics))
        return False
    
    def _ok(self, v):
        """Check response OK status"""
        if v in (1, True):
            return True
        if v in (0, False, None):
            return False
        if isinstance(v, str):
            text = v.strip()
            lowered = text.lower()
            if text == "1" or lowered in {"ok", "true", "success", "successful"}:
                return True
            if text == "0" or lowered in {"false", "failed", "error"}:
                return False
            try:
                return self._ok(json.loads(text))
            except:
                return False
        if isinstance(v, dict):
            for k in ("result", "ok", "success"):
                if k in v:
                    return self._ok(v[k])
            if int(v.get("status", 0) or 0) == 200 and "raw" in v:
                return self._ok(v.get("raw"))
        return False
    
    async def _send(self, auth, record, fuid, original=None):
        """Send record to server"""
        if not fuid:
            return False, "NO_UID"
        try:
            payload = build_payload(record, fuid, original)
            headers = {**Config.GAME_HEADERS, "Authorization": f"Bearer {auth}", "Connection": "Keep-Alive",
                       "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 12; Pixel 6 Build/SD1A.210817.036)"}
            body = {"data": {"data": payload, "deviceId": fuid[:8]}}
            diagnostics = []
            for save_url in Config.SAVE_URLS:
                endpoint = save_url.rsplit("/", 1)[-1]
                r = await self._post(save_url, body, headers)
                if r and self._ok(r):
                    log.info("Save succeeded via %s", endpoint)
                    return True, f"OK:{endpoint}"
                diagnostics.append(f"{endpoint}={str(r)[:100]}")
            return False, "SAVE_FAILED: " + " | ".join(diagnostics)
        except Exception as e:
            return False, str(e)
    
    async def _save(self, uid, data):
        """Save modified record"""
        ok, msg, auth = await self.get_auth(uid)
        if not ok:
            return {"ok": False, "message": msg}
        td = self.get_token_data(uid)
        fuid = td.get("firebase_uid", "") if td else ""
        email = td.get("email", "") if td else ""
        orig = self.get_record(uid, email) or None
        ok2, msg2 = await self._send(auth, data, fuid, orig)
        if ok2:
            self.set_record(uid, data, email)
            store = Store.load()
            store["session_stats"]["total_actions"] = store["session_stats"].get("total_actions", 0) + 1
            Store.save(store)
            return {"ok": True}
        return {"ok": False, "message": msg2}
    
    async def _modify(self, uid, mods):
        """Modify player data"""
        await self.load(uid)
        td = self.get_token_data(uid)
        email = td.get("email") if td else None
        d = deepcopy(self.get_record(uid, email))
        if not d or not d.get("Name"):
            return {"ok": False, "message": "Could not load account data. Try loading first."}
        for k, v in mods.items():
            if k == "money":
                v = min(v, Config.MAX_MONEY)
            if k == "coin":
                v = min(v, Config.MAX_COIN)
            d[k] = v
        return await self._save(uid, d)
    
    async def _set_floats(self, uid, indices_values):
        """Set float array values"""
        await self.load(uid)
        td = self.get_token_data(uid)
        email = td.get("email") if td else None
        d = deepcopy(self.get_record(uid, email))
        if not d or not d.get("Name"):
            return {"ok": False, "message": "Could not load account data. Try loading first."}
        fl = d.get("floats", [])
        if indices_values:
            max_idx = max(idx for idx, _ in indices_values)
            while len(fl) <= max_idx:
                fl.append(0.0)
            for idx, val in indices_values:
                fl[idx] = float(val)
        d["floats"] = fl
        return await self._save(uid, d)
    
    async def _set_integers(self, uid, indices_values):
        """Set integer array values"""
        await self.load(uid)
        td = self.get_token_data(uid)
        email = td.get("email") if td else None
        d = deepcopy(self.get_record(uid, email))
        if not d or not d.get("Name"):
            return {"ok": False, "message": "Could not load account data. Try loading first."}
        it = d.get("integers", [])
        if indices_values:
            max_idx = max(idx for idx, _ in indices_values)
            while len(it) <= max_idx:
                it.append(0)
            for idx, val in indices_values:
                it[idx] = int(val)
        d["integers"] = it
        return await self._save(uid, d)
    
    # ── Game Operations ───────────────────
    
    async def set_money(self, uid, amount):
        return await self._modify(uid, {"money": min(amount, Config.MAX_MONEY)})
    
    async def set_coin(self, uid, amount):
        return await self._modify(uid, {"coin": min(amount, Config.MAX_COIN)})
    
    async def set_player_name(self, uid, name):
        return await self._modify(uid, {"Name": name})
    
    async def set_player_id(self, uid, pid):
        return await self._modify(uid, {"localID": pid.upper()})
    
    async def set_race_wins(self, uid, amount):
        return await self._set_floats(uid, [(8, float(amount))])
    
    async def set_race_loses(self, uid, amount):
        return await self._set_floats(uid, [(9, float(amount))])
    
    async def unlock_w16(self, uid):
        return await self._set_floats(uid, [(32, 1.0)])
    
    async def unlock_horns(self, uid):
        return await self._set_floats(uid, [(27, 1.0), (28, 1.0), (29, 1.0), (30, 1.0), (31, 1.0)])
    
    async def disable_damage(self, uid):
        return await self._set_floats(uid, [(34, 1.0)])
    
    async def unlimited_fuel(self, uid):
        return await self._set_floats(uid, [(3, 1.0)])
    
    async def unlock_smoke(self, uid):
        return await self._set_floats(uid, [(33, 1.0)])
    
    async def unlock_animations(self, uid):
        await self.load(uid)
        td = self.get_token_data(uid)
        email = td.get("email") if td else None
        d = deepcopy(self.get_record(uid, email))
        if not d or not d.get("Name"):
            return {"ok": False, "message": "Could not load account data."}
        d["animations"] = list(set(d.get("animations", []) + list(range(301))))
        return await self._save(uid, d)
    
    async def unlock_wheels(self, uid):
        await self.load(uid)
        td = self.get_token_data(uid)
        email = td.get("email") if td else None
        d = deepcopy(self.get_record(uid, email))
        if not d or not d.get("Name"):
            return {"ok": False, "message": "Could not load account data."}
        d["wheels"] = list(set(d.get("wheels", []) + list(range(73, 221))))
        it = d.get("integers", [])
        while len(it) < 113:
            it.append(0)
        for i in [0, 1, 2, 3, 4, 5, 110, 111, 112]:
            it[i] = 1
        d["integers"] = it
        return await self._save(uid, d)
    
    async def unlock_houses(self, uid):
        return await self._set_integers(uid, [(8, 1), (110, 1), (111, 1), (112, 1)])
    
    async def complete_all_levels(self, uid):
        lvl = [0] + [120 if i == 43 else 1 for i in range(1, 110)]
        return await self._modify(uid, {"LevelsDoneTime": lvl})
    
    async def set_rank(self, uid):
        """Set max rank using confirmed SetUserRating endpoints with sync-delay classification"""
        ok, msg, auth = await self.get_auth(uid)
        if not ok:
            return {"ok": False, "message": msg}
        king_rank_sync_message = 'King Rank request was sent. King Rank can populate faster on new accounts; older accounts with existing data may take longer to sync. Open the game, check the Achievements menu (most achievements should be maxed out), and give Car Parking Multiplayer time to sync the rank.'
        rank_values = {
            "time": 999999999,
            "cars": 999999999,
            "car_fix": 999999999,
            "car_collided": 999999999,
            "car_exchange": 999999999,
            "car_trade": 999999999,
            "car_wash": 999999999,
            "slicer_cut": 999999999,
            "drift_max": 999999999,
            "drift": 999999999,
            "cargo": 999999999,
            "delivery": 999999999,
            "race_win": 999999999,
            "taxi": 999999999,
            "levels": 999999999,
            "gifts": 999999999,
            "fuel": 999999999,
            "offroad": 999999999,
            "speed_banner": 999999999,
            "reactions": 999999999,
            "run": 999999999,
            "real_estate": 999999999,
            "t_distance": 999999999,
            "treasure": 999999999,
            "block_post": 999999999,
            "push_ups": 999999999,
            "burnt_tire": 999999999,
            "passanger_distance": 999999999,
        }
        rd = {"RatingData": rank_values}
        headers = {**Config.GAME_HEADERS, "Authorization": f"Bearer {auth}"}

        def _safe_response(value):
            try:
                return json.dumps(value, ensure_ascii=False, sort_keys=True)[:700]
            except Exception:
                return str(value)[:700]

        def _parse_result_payload(value):
            if isinstance(value, dict) and "result" in value:
                value = value.get("result")
            if isinstance(value, str):
                try:
                    return json.loads(value)
                except Exception:
                    return value
            return value

        def _classify_rank_response(value):
            if value is None:
                return "failure", "no response"
            if isinstance(value, dict) and value.get("result") == 0:
                return "known-sync", "callable object returned result=0"
            parsed = _parse_result_payload(value)
            if isinstance(parsed, dict):
                callback = parsed.get("callback")
                data = parsed.get("data")
                battlepass = parsed.get("battlepass")
                if isinstance(callback, dict) and callback:
                    return "success", "non-empty callback returned"
                if self._ok(parsed):
                    return "success", "endpoint returned ok/success"
                if data is None and callback is None and isinstance(battlepass, dict):
                    daily = battlepass.get("daily") if isinstance(battlepass.get("daily"), dict) else {}
                    if daily.get("finished") == []:
                        return "known-sync", "null callback/data with empty daily battlepass response"
            if self._ok(value):
                return "success", "endpoint returned ok/success"
            return "failure", _safe_response(value)

        attempts = [
            ("legacy-json-string", {"data": json.dumps(rd, separators=(",", ":"))}),
            ("callable-object", {"data": rd}),
        ]
        diagnostics = []
        saw_known_sync = False
        for rank_url in Config.RANK_URLS:
            endpoint = rank_url.rsplit("/", 1)[-1]
            for label, payload in attempts:
                r = await self._post(rank_url, payload, headers)
                status, detail = _classify_rank_response(r)
                diagnostics.append(f"{endpoint}/{label}={status}: {detail}")
                log.info("King Rank %s attempt uid=%s label=%s status=%s detail=%s raw=%s", endpoint, uid, label, status, detail, _safe_response(r))
                if status == "success":
                    store = Store.load()
                    store["session_stats"]["total_unlocks"] = store["session_stats"].get("total_unlocks", 0) + 1
                    Store.save(store)
                    return {"ok": True, "message": "OK", "rank_endpoint": endpoint, "rank_diagnostics": diagnostics}
                if status == "known-sync":
                    saw_known_sync = True
        if saw_known_sync:
            log.warning("King Rank sync-pending response classified as user-facing success uid=%s diagnostics=%s", uid, " | ".join(diagnostics))
            store = Store.load()
            store["session_stats"]["total_unlocks"] = store["session_stats"].get("total_unlocks", 0) + 1
            Store.save(store)
            return {
                "ok": True,
                "message": king_rank_sync_message,
                "rank_sync_pending": True,
                "rank_diagnostics": diagnostics,
            }
        return {"ok": False, "message": "RANK_FAILED: " + " | ".join(diagnostics)}

    async def fix_account(self, uid):
        """Fix account bugs"""
        await self.load(uid)
        td = self.get_token_data(uid)
        email = td.get("email") if td else None
        d = deepcopy(self.get_record(uid, email))
        if not d or not d.get("Name"):
            return {"ok": False, "message": "Could not load account data."}
        bugs = 0
        fl = (d.get("floats", []))[:54]
        while len(fl) < 54:
            fl.append(0.0)
        fixed_fl = []
        for v in fl:
            if v in (1, 1.0):
                fixed_fl.append(1.0)
            elif isinstance(v, (int, float)) and v > 1:
                bugs += 1
                fixed_fl.append(0.0)
            else:
                fixed_fl.append(float(v) if v else 0.0)
        it = (d.get("integers", []))[:120]
        while len(it) < 120:
            it.append(0)
        fixed_it = []
        for v in it:
            if v == 1:
                fixed_it.append(1)
            elif isinstance(v, (int, float)) and v > 1:
                bugs += 1
                fixed_it.append(0)
            else:
                fixed_it.append(int(v) if v else 0)
        d["floats"] = fixed_fl
        d["integers"] = fixed_it
        result = await self._save(uid, d)
        return {"ok": True, "bugs_fixed": bugs} if result.get("ok") else {"ok": False, "message": "FIX_FAILED"}

# ═══════════════════════════════════════════
#  🌐 INITIALIZE
# ═══════════════════════════════════════════

nuker = CPMNukerWeb()

log.info("━" * 40)
log.info("  🎮 CPM Nuker Web v4.0")
log.info(f"  Brotli: {'✔' if HAS_BROTLI else '✗ pip install brotli'}")
log.info(f"  Crypto: {'✔' if HAS_CRYPTO else '✗ pip install pycryptodome'}")
log.info("━" * 40)

# Export for Flask/Django integration
__all__ = [
    "CPMNukerWeb",
    "Config",
    "Store",
    "nuker",
    "decrypt_player_record",
    "build_payload",
]
