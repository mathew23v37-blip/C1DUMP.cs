from __future__ import annotations

import asyncio
import base64
import json
import random
import struct
from copy import deepcopy
from pathlib import Path
from typing import Callable, Dict, Optional

import aiohttp
import brotli

from car_bulk_injector import (
    api_async,
    firebase_key,
    get_garage_cars,
    get_world_sale_slots,
    inject_catalog_car,
)

WEEKLY_DESIGN_FILE = Path(__file__).with_name("w124.json")
PERMANENT_CROWN_FILE = Path(__file__).with_name("weekly_free_design.json")
WEEKLY_DESIGN_ID = 258
PERMANENT_CROWN_ID = 218
WEEKLY_DESIGN_NAME = "Event Badged Mercedes W124"
PERMANENT_CROWN_NAME = "Badged Toyota Crown"
FORCED_PRICE = 1000
Progress = Optional[Callable[[str, str, Optional[dict]], None]]


def emit(progress: Progress, stage: str, message: str, **extra):
    if progress:
        progress(stage, message, extra or None)


def _unpack_blob(value):
    if not isinstance(value, str) or not value:
        return None
    try:
        return brotli.decompress(base64.b64decode(value, validate=True))
    except Exception:
        return None


def _unpack_counted_floats(value):
    raw = _unpack_blob(value)
    if raw is None or len(raw) < 4:
        return None
    try:
        count = struct.unpack_from("<I", raw, 0)[0]
        if count > 4096 or len(raw) != 4 + count * 4:
            return None
        return list(struct.unpack_from("<" + "f" * count, raw, 4))
    except Exception:
        return None


def _unpack_counted_ints(value):
    raw = _unpack_blob(value)
    if raw is None or len(raw) < 4:
        return None
    try:
        count = struct.unpack_from("<I", raw, 0)[0]
        if count > 4096 or len(raw) != 4 + count * 4:
            return None
        return list(struct.unpack_from("<" + "i" * count, raw, 4))
    except Exception:
        return None


def _unpack_vectors(value):
    raw = _unpack_blob(value)
    if raw is None or len(raw) < 4:
        return None
    try:
        count = struct.unpack_from("<I", raw, 0)[0]
        if count > 1024 or len(raw) != 4 + count * 12:
            return None
        values = struct.unpack_from("<" + "f" * (count * 3), raw, 4)
        return [
            {"x": values[i * 3], "y": values[i * 3 + 1], "z": values[i * 3 + 2]}
            for i in range(count)
        ]
    except Exception:
        return None


def _load_design_car(design_file: Path, required_car_id: int) -> dict:
    with design_file.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    cars = data.get("cars", []) if isinstance(data, dict) else []
    if not cars:
        raise RuntimeError("Free design database is empty")
    for car in cars:
        configured_car_id = int(car.get("car_id", car.get("CarID", 0)) or 0)
        if configured_car_id == int(required_car_id):
            return car
    raise ValueError(f"Free design payload must contain CarID {required_car_id}")


def _load_design_payload(design_file: Path, required_car_id: int) -> dict:
    """Load the complete export and prove the requested designed car exists."""
    with design_file.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise RuntimeError("Free design payload is invalid")
    _load_design_car(design_file, required_car_id)
    return payload


def _build_runtime_viper(stored: dict) -> dict:
    """Build the exact runtime oneCar while preserving the expanded Car170-style vinyls."""
    cid = int(stored.get("car_id", stored.get("CarID", 141)) or 141)
    raw = deepcopy((stored.get("source_slot") or {}).get("one_car") or {})
    if not raw:
        raw = {}

    raw["CarID"] = cid

    # Decode the packed values that caused paint/wheel corruption when sent raw.
    vectors = _unpack_vectors(raw.get("vectors"))
    if vectors is not None:
        raw["vectors"] = vectors
    else:
        raw["vectors"] = deepcopy(stored.get("vectors", []))

    floats = _unpack_counted_floats(raw.get("floats"))
    if floats is not None:
        raw["floats"] = floats
    else:
        raw["floats"] = deepcopy(stored.get("floats", []))

    gears = _unpack_counted_floats(raw.get("gears"))
    if gears is not None:
        raw["gears"] = gears
    else:
        raw["gears"] = deepcopy(stored.get("gears", []))

    type_to_install = _unpack_counted_ints(raw.get("typeToInstall"))
    if type_to_install is not None:
        raw["typeToInstall"] = type_to_install
    else:
        raw["typeToInstall"] = deepcopy(stored.get("type_to_install", []))

    bought_parts = _unpack_counted_ints(raw.get("BoughtParts"))
    if bought_parts is not None:
        raw["BoughtParts"] = bought_parts
    else:
        raw["BoughtParts"] = deepcopy(stored.get("bought_parts", []))

    fso = _unpack_counted_ints(raw.get("fsoData"))
    if fso is not None:
        raw["fsoData"] = fso
    else:
        raw["fsoData"] = deepcopy(stored.get("fso_data", []))

    police = _unpack_counted_ints(raw.get("installedPoliceLights"))
    if police is not None:
        raw["installedPoliceLights"] = police
    else:
        raw["installedPoliceLights"] = deepcopy(stored.get("installed_police_lights", []))

    # viperv1 already contains the working Car170-style Vynils object.
    vynils = deepcopy(stored.get("vynils", stored.get("Vynils", {})))
    if not isinstance(vynils, dict) or not isinstance(vynils.get("allVynils"), list):
        raise RuntimeError("Weekly design vinyl payload is unavailable")
    vynils["CarID"] = cid
    raw["Vynils"] = vynils

    # Preserve packed text/window payload exactly, as in the working standalone tool.
    if raw.get("texts") is None:
        raw["texts"] = deepcopy(stored.get("texts", ["", "", "", ""]))
    if raw.get("WindowVinyls") is None:
        raw["WindowVinyls"] = deepcopy(stored.get("window_vinyls", {}))
    if raw.get("flagID") is None:
        raw["flagID"] = stored.get("flag_id", -1)
    if raw.get("dataVersion") is None:
        raw["dataVersion"] = stored.get("data_version", 3)

    return raw


async def _login(session, email: str, password: str):
    key = firebase_key()
    try:
        async with session.post(
            "https://www.googleapis.com/identitytoolkit/v3/relyingparty/verifyPassword",
            params={"key": key},
            json={"email": email, "password": password, "returnSecureToken": True},
            timeout=aiohttp.ClientTimeout(total=12),
        ) as response:
            data = await response.json(content_type=None)
            if data.get("idToken"):
                return data["idToken"], data["localId"]
    except Exception:
        pass
    return None, None


async def _buy_viper(session, token: str, slot: dict, car: dict):
    vynils = car.get("Vynils", {})
    payload = {
        "ownerID": slot.get("ownerID", ""),
        "ownerName": slot.get("ownerName", ""),
        "description": slot.get("description", ""),
        "CarID": slot.get("carID", 0),
        "carGeneratedID": slot.get("carGeneratedID", ""),
        "ownerAccountID": slot.get("ownerAccountID", ""),
        "oneCar": car,
        "vynilOneCar": vynils,
        "loadedLocalCar": {"instanceID": random.randint(-999999, -100000)},
        "price": FORCED_PRICE,
        "SellingCar": {},
        "willReject": False,
        "dislike": 1,
        "like": 0,
        "liked": False,
        "disliked": False,
        "mode": 1,
    }
    status, raw = await api_async(session, token, "WSPurchaseCarV3", json.dumps(payload))
    try:
        data = json.loads(raw)
        return data.get("result") == 1, data.get("result"), data.get("error")
    except Exception:
        return False, None, f"Bad reply (HTTP {status})"


async def _inject_free_design(
    email: str,
    password: str,
    design_file: Path,
    required_car_id: int,
    design_name: str,
    progress: Progress = None,
) -> Dict:
    """Inject one configured free design with its full runtime payload."""
    import world_sale_health
    world_sale_health.register_probe_credentials(email, password)
    stored = _load_design_car(design_file, required_car_id)
    car = _build_runtime_viper(stored)
    cid = int(car.get("CarID", required_car_id))
    vinyl_count = len((car.get("Vynils") or {}).get("allVynils", []))
    emit(progress, "database", f"Loaded {design_name} with {vinyl_count} vinyl layers", car_id=cid, vinyls=vinyl_count)

    connector = aiohttp.TCPConnector(limit=10)
    async with aiohttp.ClientSession(connector=connector) as session:
        emit(progress, "connecting", "Connecting to CPM…")
        token, uid = await _login(session, email, password)
        if not token:
            return {"ok": False, "message": "Authentication failed", "injected": 0, "failed_ids": [cid]}

        emit(progress, "authenticated", f"Authenticated [{uid[:8]}…]")
        garage = await get_garage_cars(session, token)
        if not garage:
            return {"ok": False, "message": "No garage cars found", "injected": 0, "failed_ids": [cid]}

        owned = {
            int(c.get("CarID") or c.get("carID") or 0)
            for c in garage
            if isinstance(c, dict)
        }
        if cid in owned:
            emit(
                progress,
                "replace_owned",
                f"CarID #{cid} is already owned; replacing it with {design_name}",
                car_id=cid,
            )

        emit(progress, "scan", "Finding an available World Sale slot…")
        used = set()
        last_error = None
        for attempt in range(1, 6):
            slots = await get_world_sale_slots(session, token, blocks=20, passes=2 if attempt < 3 else 3)
            candidates = []
            for slot in slots:
                sid = slot.get("carID") or slot.get("CarID")
                gen = slot.get("carGeneratedID") or ""
                key = (sid, gen)
                if sid is None or key in used:
                    continue
                candidates.append(slot)
            random.shuffle(candidates)

            for slot in candidates[:10]:
                sid = slot.get("carID") or slot.get("CarID")
                gen = slot.get("carGeneratedID") or ""
                used.add((sid, gen))
                emit(progress, "injecting", f"Injecting {design_name} (attempt {attempt}/5)…", attempt=attempt)
                ok, result_code, err = await _buy_viper(session, token, slot, deepcopy(car))
                if ok:
                    await asyncio.sleep(1.0)
                    refreshed = await get_garage_cars(session, token)
                    refreshed_ids = {
                        int(c.get("CarID") or c.get("carID") or 0)
                        for c in refreshed
                        if isinstance(c, dict)
                    } if refreshed else set()
                    if cid in refreshed_ids or not refreshed:
                        msg = f"{design_name} injected with {vinyl_count} vinyl layers"
                        emit(progress, "complete", msg, injected=1, vinyls=vinyl_count)
                        return {"ok": True, "message": msg, "injected": 1, "replaced": int(cid in owned), "total": 1, "failed_ids": []}
                    # Purchase succeeded; still treat as successful even if garage refresh lags.
                    msg = f"{design_name} purchase completed with {vinyl_count} vinyl layers"
                    emit(progress, "complete", msg, injected=1, vinyls=vinyl_count)
                    return {"ok": True, "message": msg, "injected": 1, "replaced": int(cid in owned), "total": 1, "failed_ids": []}
                last_error = err or result_code

            await asyncio.sleep(0.8 + attempt * 0.25)

        return {
            "ok": False,
            "message": f"{design_name} injection failed{f': {last_error}' if last_error else ''}",
            "injected": 0,
            "failed_ids": [cid],
        }


async def inject_weekly_design(email: str, password: str, progress: Progress = None) -> Dict:
    # Use the exact same lossless individual-car pipeline as the working BMW
    # M2 catalog design. The previous standalone path could fall back to a
    # premium/default payload when one packed W124 field decoded differently.
    result = await inject_catalog_car(
        _load_design_payload(WEEKLY_DESIGN_FILE, WEEKLY_DESIGN_ID),
        WEEKLY_DESIGN_ID,
        email,
        password,
        progress,
    )
    profile = result.get("payload_profile") if isinstance(result, dict) else {}
    if result.get("ok"):
        result["message"] = (
            f"{WEEKLY_DESIGN_NAME} injected with "
            f"{int((profile or {}).get('vinyl_count') or 0)} vinyl layers and its full saved wheel/tune payload"
        )
    return result


async def inject_permanent_crown(email: str, password: str, progress: Progress = None) -> Dict:
    result = await inject_catalog_car(
        _load_design_payload(PERMANENT_CROWN_FILE, PERMANENT_CROWN_ID),
        PERMANENT_CROWN_ID,
        email,
        password,
        progress,
    )
    profile = result.get("payload_profile") if isinstance(result, dict) else {}
    if result.get("ok"):
        result["message"] = (
            f"{PERMANENT_CROWN_NAME} injected with "
            f"{int((profile or {}).get('vinyl_count') or 0)} vinyl layers and its full saved wheel/tune payload"
        )
    return result


async def inject_weekly_crown(email: str, password: str, progress: Progress = None) -> Dict:
    """Backward-compatible alias for the current weekly design."""
    return await inject_weekly_design(email, password, progress)
