import os
import hardcoded_settings  # noqa: F401 - loads concrete deployment settings
bind = f"0.0.0.0:{os.getenv('PORT', '8080')}"

# Redis + PostgreSQL move all request-critical mutable state out of the web
# process. Keep the safe single-process fallback until both URLs are present;
# in distributed mode, WEB_WORKERS can be raised without losing job status or
# corrupting balances.
_postgres_flag = os.getenv("POSTGRES_ACCOUNTS_ENABLED", "auto").strip().lower()
_jobs_flag = os.getenv("DISTRIBUTED_JOBS_ENABLED", "auto").strip().lower()
_distributed = bool(
    os.getenv("REDIS_URL", "").strip()
    and os.getenv("DATABASE_URL", "").strip()
    and _postgres_flag not in {"0", "false", "no", "off"}
    and _jobs_flag not in {"0", "false", "no", "off"}
)
workers = max(1, min(4, int(os.getenv("WEB_WORKERS", "2" if _distributed else "1"))))
threads = max(4, min(16, int(os.getenv("WEB_THREADS", os.getenv("GUNICORN_THREADS", "8" if _distributed else "12")))))
worker_class = "gthread"

# Request recycling remains off so capacity changes are intentional and visible
# in Railway metrics; shared state itself survives worker/replica replacement.
max_requests = 0
max_requests_jitter = 0

timeout = int(os.getenv("GUNICORN_TIMEOUT", "120"))
graceful_timeout = int(os.getenv("GUNICORN_GRACEFUL_TIMEOUT", "30"))
keepalive = int(os.getenv("GUNICORN_KEEPALIVE", "5"))

preload_app = False

# High-frequency status polling can flood Railway logs and consume CPU. Enable
# request logs temporarily with GUNICORN_ACCESS_LOG=- when diagnosing traffic.
accesslog = os.getenv("GUNICORN_ACCESS_LOG") or None
errorlog = "-"
loglevel = os.getenv("GUNICORN_LOG_LEVEL", "info")
worker_connections = int(os.getenv("GUNICORN_WORKER_CONNECTIONS", "2000"))


def post_fork(server, worker):
    """Start the optional Unlimited Currency restart monitor."""
    try:
        from app import _ensure_unlimited_restart_supervisor
        _ensure_unlimited_restart_supervisor()
        server.log.info("Optional Unlimited Currency restart supervisor checked")
    except Exception:
        server.log.exception("Unable to start Unlimited Currency restart supervisor")
