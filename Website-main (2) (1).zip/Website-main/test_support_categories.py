import os
import tempfile
import unittest
from pathlib import Path


class SupportCategoryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        os.environ.pop("DATABASE_URL", None)
        os.environ["DATA_DIR"] = self.tmp.name
        import accounts
        import community
        import app as app_module
        self.accounts = accounts
        self.community = community
        self.app_module = app_module
        self.client = app_module.app.test_client()

    def tearDown(self):
        self.tmp.cleanup()

    def test_world_sale_category_survives_ticket_creation(self):
        user = self.accounts.register("support-category@example.test", "password")
        self.assertTrue(user["ok"])
        with self.client.session_transaction() as session:
            session["site_logged_in"] = True
            session["site_user_id"] = user["user_id"]
            session["site_email"] = user["email"]
        response = self.client.post("/support/create", data={
            "category": "world_sale",
            "subject": "Listing report",
            "body": "This design does not match the photo.",
        })
        self.assertEqual(response.status_code, 302)
        ticket = self.community.ticket_list_for_user(user["user_id"])[0]
        self.assertEqual(ticket["category"], "world_sale")
        self.assertEqual(ticket["category_label"], "World Sale")

    def test_new_admin_routes_are_registered(self):
        routes = {rule.rule for rule in self.app_module.app.url_map.iter_rules()}
        self.assertIn(self.app_module.ADMIN_SECRET_PANEL_PATH + "/support", routes)
        self.assertIn(self.app_module.ADMIN_SECRET_PANEL_PATH + "/shared-designs", routes)


if __name__ == "__main__":
    unittest.main()
