"""Hard-coded deployment settings supplied for this application.

This module intentionally contains concrete values only. Railway interpolation
expressions are not included because they were not concrete values in the
provided configuration.
"""
from __future__ import annotations

import os

HARDCODED_SETTINGS = {
    "PGDATA": "/var/lib/postgresql/data/pgdata",
    "PGPORT": "5432",
    "PGDATABASE": "railway",
    "PGUSER": "postgres",
    "POSTGRES_DB": "railway",
    "POSTGRES_USER": "postgres",
    "POSTGRES_PASSWORD": "cuNTjlyrgSlXnTRcgNlSOaVRHjBqbYMk",
    "RAILWAY_DEPLOYMENT_DRAINING_SECONDS": "60",
    "SSL_CERT_DAYS": "820",
    "APP_BASE_URL": "https://tnnr.up.railway.app",
    "BACKLOG_ADMIN_KEY": "1228",
    "CPM_FIREBASE_KEY": "AIzaSyBW1ZbMiUeDZHYUO2bY8Bfnf5rRgrQGPTM",
    "CPM_WORLDSALE_FIREBASE_KEY": "AIzaSyBW1ZbMiUeDZHYUO2bY8Bfnf5rRgrQGPTM",
    "DATA_DIR": "/app/data",
    "DISTRIBUTED_JOBS_ENABLED": "1",
    "FLASK_SECRET_KEY": "1228",
    "MAINTENANCE_MODE": "0",
    "MAX_CONCURRENT_INJECTIONS": "1",
    "MAX_QUEUED_INJECTIONS": "40",
    "POSTGRES_ACCOUNTS_ENABLED": "1",
    "POSTGRES_POOL_MAX": "4",
    "POSTGRES_POOL_MIN": "1",
    "REDIS_RUNTIME_ENABLED": "1",
    "STRIPE_SECRET_KEY": "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",
    "STRIPE_WEBHOOK_SECRET": "whsec_Higv803YpkAEvr5wMDxu9FN7eQazZYcs",
    "TOPUP_CURRENCY": "USD",
    "UNLIMITED_AUTO_RESTART_ENABLED": "0",
    "WEB_THREADS": "10",
    "WEB_WORKERS": "3",
    "REDIS_PASSWORD": "hJdjvCYysAwtsgePTKHqIcAcuCDMitSL",
    "REDISPASSWORD": "hJdjvCYysAwtsgePTKHqIcAcuCDMitSL",
    "REDISPORT": "6379",
    "REDISUSER": "default",
}

# Force the supplied values so deployment does not depend on external .env or
# Railway interpolation. DATABASE_URL and REDIS_URL are intentionally absent:
# their concrete hostnames were not present in the supplied text.
os.environ.update(HARDCODED_SETTINGS)
