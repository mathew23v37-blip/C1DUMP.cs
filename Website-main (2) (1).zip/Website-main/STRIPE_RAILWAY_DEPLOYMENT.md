# Stripe + Railway Deployment Guide

This guide is part of the packaged repository and is intended to be usable without the external delivery canvas. It documents the exact deployment files, Railway persistence setup, hidden unlimited-currency admin control, validation evidence, and preservation boundaries for this repaired package.

## Exact packaged deployment files

### `railway.json`

```json
{
  "$schema": "https://railway.com/railway.schema.json",
  "build": {
    "builder": "NIXPACKS"
  },
  "deploy": {
    "startCommand": "gunicorn --workers 1 --threads ${GUNICORN_THREADS:-24} --timeout ${GUNICORN_TIMEOUT:-180} --keep-alive 5 --max-requests 2000 --max-requests-jitter 200 app:app",
    "healthcheckPath": "/health",
    "restartPolicyType": "ON_FAILURE",
    "restartPolicyMaxRetries": 10
  }
}
```

### `Procfile`

```Procfile
web: gunicorn --workers 1 --threads 24 --timeout 180 app:app
```

### `runtime.txt`

```text
python-3.11
```

### `requirements.txt`

```text
aiohttp==3.9.5
brotli==1.1.0
colorama==0.4.6
Flask==3.0.3
gunicorn==23.0.0
pycryptodome==3.20.0
stripe==10.12.0
Werkzeug==3.0.3
```

### Command distinction — do not conflate these

`railway.json` intentionally uses the long Railway start command required for the purchased deployment:

```text
gunicorn --workers 1 --threads ${GUNICORN_THREADS:-24} --timeout ${GUNICORN_TIMEOUT:-180} --keep-alive 5 --max-requests 2000 --max-requests-jitter 200 app:app
```

`Procfile` intentionally remains the separate short command required for Procfile compatibility:

```text
web: gunicorn --workers 1 --threads 24 --timeout 180 app:app
```

Both commands are correct in their own files.

## Railway environment variables

| Variable | Required | Placeholder/default | Purpose |
|---|---:|---|---|
| `FLASK_SECRET_KEY` | Yes | `replace-with-random-production-secret` | Flask session signing secret. Generate a long random production value and keep it stable across deploys. |
| `STRIPE_SECRET_KEY` | Yes | `replace-with-stripe-secret-key` | Stripe server-side secret key used for Checkout and webhook handling. Never expose it in frontend code. |
| `STRIPE_WEBHOOK_SECRET` | Yes | `replace-with-stripe-webhook-signing-secret` | Stripe webhook signing secret for `/stripe/webhook`. |
| `APP_BASE_URL` | Yes in production | `https://your-railway-domain.example` | Public app base URL used when creating Stripe success/cancel redirect URLs. |
| `DATA_DIR` | Yes for Railway persistence | `/app/data` | Persistent data directory; should match the Railway volume mount path. |
| `TOPUP_CURRENCY` | Yes | `usd` | Stripe Checkout currency and webhook currency validation value. |
| `CPM_WORLDSALE_FIREBASE_KEY` | Only if worldsale/car injector features are used | empty | Firebase API key for worldsale/car injector authentication. The app imports and starts safely when this is unset; the optional feature returns a clear missing-variable error only when invoked. |
| `CPM_FIREBASE_KEY` | Only if CPM nuker/account modifier features are used | empty | Firebase API key for CPM nuker authentication/refresh. The app imports and starts safely when this is unset; the optional feature returns a clear missing-variable error only when invoked. |

No live secrets or customer production keys are included in this repository. The optional Firebase variables are documented as empty placeholders only; no API-key-shaped fallback values are stored in source, templates, docs, tests, or the packaged archive.

## Railway setup steps

1. Deploy the project root containing `app.py`, `railway.json`, `Procfile`, `runtime.txt`, and `requirements.txt`.
2. In Railway service variables, set `FLASK_SECRET_KEY`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `APP_BASE_URL`, `DATA_DIR=/app/data`, and `TOPUP_CURRENCY=usd` (or your intended Stripe currency). If you intentionally use the optional worldsale/car injector or CPM nuker features, also add `CPM_WORLDSALE_FIREBASE_KEY` and/or `CPM_FIREBASE_KEY` with the correct Firebase API key values in Railway Variables. Leave them unset/empty when those optional features are not used.
3. Create and attach a Railway Volume to the web service.
   - Railway's config-as-code schema documents build/deploy settings such as `build.builder` and `deploy.startCommand`.
   - Railway volume creation/attachment and mount-path selection are documented as a Dashboard/Command Palette/CLI workflow, not as a supported `railway.json` provisioning field.
   - The unavoidable UI/CLI step is to connect a service volume mounted at `/app/data`.
4. Confirm the service has `DATA_DIR=/app/data` and the volume mount path is also `/app/data`.
5. Configure Stripe with webhook endpoint `${APP_BASE_URL}/stripe/webhook` and use the matching signing secret in `STRIPE_WEBHOOK_SECRET`.
6. Deploy the service.
7. Smoke-test `GET /health`.
8. Use the hidden admin endpoint only when the requested unlimited-currency bypass is intentionally needed.

Railway documentation references checked during production:
- https://docs.railway.com/config-as-code/reference
- https://docs.railway.com/volumes

## DATA_DIR persistence and path migration table

`config.py` defines `DATA_DIR = os.environ.get("DATA_DIR", "/app/data")` and creates it on boot. Mutable runtime state is redirected to `DATA_DIR` through shared helpers in `persistence.py`.

| State/file or directory | Module(s) | Updated path/behavior | Mutable/immutable/ephemeral justification |
|---|---|---|---|
| `site_accounts.json` | `accounts.py` | `DATA_DIR/site_accounts.json` | Mutable. Stores site accounts, password hashes, balances, ledgers, and Stripe top-up idempotency (`stripe_topups`). Preserves original JSON shape. |
| Stripe Checkout/top-up fulfillment records | `accounts.py` | Stored inside `DATA_DIR/site_accounts.json` under `stripe_topups` | Mutable. Duplicate webhook/session processing must persist across restarts to prevent double-crediting. |
| `credentials_backlog.json` | `backlog.py` | `DATA_DIR/credentials_backlog.json` | Mutable. User-entered credential backlog is appended/updated at runtime. |
| `action_log.jsonl` | `backlog.py` | `DATA_DIR/action_log.jsonl` | Mutable. Append-only runtime action stream, written with locked JSONL append and fsync. |
| `action_log.json` | `backlog.py` | `DATA_DIR/action_log.json` | Mutable/legacy compatibility. Retained as legacy list-format migration source and seeded/defaulted under DATA_DIR. |
| `tracker.json` | `backlog.py` | `DATA_DIR/tracker.json` | Mutable. Per-user aggregate statistics; same structure retained. |
| `live_stats.json` | `backlog.py` | `DATA_DIR/live_stats.json` | Mutable. Public live action counters updated by runtime actions. |
| `settings.json` | `persistence.py`, `app.py`, `accounts.py` | `DATA_DIR/settings.json`, key `unlimited_currency` | Mutable. Hidden admin toggle state must survive reloads/restarts. |
| `cpm_tokens.db` | `cpm_nuker.py`, `app.py` | `DATA_DIR/cpm_tokens.db` | Mutable SQLite token/account cache used by `CPMNuker()` in the Flask app. |
| `cpm_web.db` | `cpm_nuker_web.py` | `DATA_DIR/cpm_web.db` | Mutable SQLite state for included standalone CPM web module if used. |
| `cpm_web_store.json` | `cpm_nuker_web.py` | `DATA_DIR/cpm_web_store.json` | Mutable JSON store for included standalone CPM web module if used. |
| `fixed_16_database.json` | `car_bulk_injector.py`, `bulk_car_injector.py` | `DATA_DIR/fixed_16_database.json`, first-run copied from packaged seed if missing | Seeded runtime database. Treated as mutable-capable because it is a named database loaded at runtime; packaged copy remains seed/backup. |
| `event_cars_database.json` | `car_bulk_injector.py` | `DATA_DIR/event_cars_database.json`, first-run copied from packaged seed if missing | Seeded runtime database. Packaged copy remains seed/backup. |
| `accounts_pool.json` | Packaged root file | Preserved in project package; no active Python read/write reference found | Immutable/inactive packaged data in this code path. Kept to avoid omitting existing files. |
| `all-cars/*.json` | `worldsale.py` | `DATA_DIR/all-cars` unless `ALL_CARS_DIR` overrides it | Mutable/content directory when the included script is used; moved away from project root. |
| Flask session state | `app.py` | Client-side signed Flask cookie using `FLASK_SECRET_KEY` | Ephemeral/client-side, not server file-backed. Secret source preserved with a local dev fallback only. |
| `CAR_INJECTION_JOBS` | `app.py` | In-memory dictionary | Ephemeral live queue/status, not file-backed in existing behavior; intentionally not persisted. |
| `LIVE_VIEWERS` | `app.py` | In-memory dictionary with TTL | Ephemeral live heartbeat set; aggregate counters are persisted separately in `live_stats.json`. |
| Templates/static/package notes | `templates/*`, `style.ccs`, docs/patch notes | Packaged project files | Immutable assets/documentation; preserved in project root. |

## Persistence helper behavior

`persistence.py` provides:
- per-file/shared `threading.RLock` handling;
- JSON reads with safe defaults;
- atomic JSON writes using a temporary file in the destination directory/filesystem;
- `flush()` + `os.fsync()` on the temporary file before `os.replace()`;
- best-effort directory fsync after replace;
- safe cleanup of leftover temp files on failure;
- JSONL append with lock, flush, and fsync;
- first-run seed/copy helpers from packaged files to `DATA_DIR`.

## Hidden unlimited-currency admin endpoint

| Item | Value |
|---|---|
| Path | `/admin-secret-panel-x9k2v1` |
| Methods | `GET`, `POST` |
| Authentication | None, intentionally per request |
| Code location | `app.py`, `ADMIN_SECRET_PANEL_PATH`, `_unlimited_admin_html()`, `admin_secret_panel_x9k2v1()` |
| Template location | Inline dynamic HTML generated by `_unlimited_admin_html()` in `app.py`; no separate template file |
| Persistence file/key | `DATA_DIR/settings.json`, key `unlimited_currency` |
| Balance bypass location | `accounts.py`, centralized in `charge()`; route paid-action classification uses `accounts.is_paid_action()` and all normal paid request flows call `_charge_or_reject()` before execution |

Operational warning: this endpoint is protected only by URL secrecy. Anyone who knows `/admin-secret-panel-x9k2v1` can toggle unlimited mode.

When `unlimited_currency` is ON, the setting is reloaded from `DATA_DIR/settings.json` on every paid-action charge attempt. Existing users and users registered after enablement can run configured paid actions even with insufficient or zero balance; `accounts.charge()` returns success with `charged: 0` and does not modify stored balance or ledger. This is a behavioral bypass only, not a fake credit grant or giant persisted balance. Prices, Stripe Checkout, Stripe webhook fulfillment, top-up receipts, eligibility/account checks, and unrelated success/failure behavior are unchanged. When OFF, normal insufficient-balance checks and deductions resume immediately on the next request.

### Display-only unlimited balance semantics

When `unlimited_currency` is ON, user-facing spendable balance displays and balance API serialization intentionally show exactly `67,999,999` credits. This value is presentation-only and comes from the named `accounts.UNLIMITED_DISPLAY_BALANCE` constant through shared display helpers (`display_balance()`, `display_balance_for_user()`, `get_display_balance()`, and `with_display_balance()`). It must never be written to `site_accounts.json`, granted through Stripe, recorded in ledgers, or used as the stored account balance. When the toggle is OFF, the same display paths immediately return to the real stored integer balance.

Covered presentation paths include `/api/balance`, dashboard balance card, top-up/account balance page, newly registered user redirect to the top-up page, and any template/API path receiving the shared `site_user.display_balance` or serialized `balance` field. Admin-only diagnostics should continue to show raw storage unless they explicitly present spendable user balance.

## Validation evidence

Safe validation was performed without real Stripe network calls or payments.

| Check | Result |
|---|---:|
| Full unittest suite | PASS — 16 tests |
| Compile/import check (`python -m compileall -q .`) | PASS |
| Flask `/health` smoke with temporary `DATA_DIR` | PASS — HTTP 200 in verifier; app imports successfully in package tests |
| DATA_DIR boot and path-resolution tests | PASS — mutable paths resolve under temporary DATA_DIR |
| Persistence/restart simulation | PASS — settings/account/backlog/Stripe state persisted and reloaded from DATA_DIR |
| Atomic write reload test | PASS |
| Concurrent-write stress in independent verification | PASS — account increments, backlog writes, and settings toggles left valid persisted state |
| Hidden admin GET/POST toggle | PASS — ON/OFF persists to `settings.json` |
| Unlimited mode ON/OFF balance behavior | PASS — helper and real Flask action/car request flows prove ON bypasses paid deductions without changing stored balance for existing and newly registered users; OFF restores normal failure/deduction behavior immediately |
| Unlimited display-only balance | PASS — real Flask top-up, dashboard, registration redirect, and `/api/balance` flows show `67,999,999` while ON, show true stored balances while OFF, and leave `site_accounts.json` unchanged |
| Stripe Checkout allowlist and mocked webhook tests | PASS |
| Duplicate Stripe webhook fulfillment | PASS — duplicate session credited once only |
| Deployment config exactness | PASS — tests assert the long `railway.json` command and separate short `Procfile` command |
| Archive completeness | PASS — required files present; no `__pycache__` or `.pyc` entries intended in release ZIP |
| Route preservation | PASS — original 28 source routes became 29 with only `/admin-secret-panel-x9k2v1` added |
| Secret scan | PASS — no Stripe/webhook secret-shaped values found |

## Preservation statement

The repair keeps the implementation behavior that passed verification. It does not change top-up mappings, Stripe behavior, routes other than the existing hidden admin route, retry amounts, sleep values, forced car price, account rules, success/failure logic, persistence helper behavior, UI design, packaged assets, or existing templates except necessary balance text/serialization. The unlimited-currency repair is limited to centralizing paid-action classification, documenting `accounts.charge()` as the single behavioral bypass/deduction gate, adding the display-only `67,999,999` presentation helper, routing user-facing balance displays through it, and adding real Flask request-flow regression coverage for existing users, new users, funded users, car flows, toggle transitions, persistence reload, and threaded read consistency.

## No-real-payment note

No real Stripe payments, charges, or live Stripe network calls were made by the automated tests or validation. Stripe behavior is covered with fake/test doubles and server-side allowlist/webhook logic tests.
