# Ezoic Ads Integration Notes for TNNR.Shop

## What changed

This package adds the basic Ezoic Ads JavaScript integration for `tnnr.shop`.

### Changed files

- `app.py`
  - Adds `/ads.txt` as a 301 redirect to `https://srv.adstxtmanager.com/19390/tnnr.shop`.
- `templates/base.html`
  - Adds the Ezoic privacy scripts at the top of `<head>`.
  - Adds the Ezoic header script, `ezstandalone` command queue initialization, and Ezoic analytics script immediately after the privacy scripts.
  - Adds shared top-of-content and bottom-of-content Ezoic ad placements inside the main content wrapper.
  - Adds `.ezoic-ad-slot` CSS spacing for ad placement areas.
- `templates/index.html`
  - Adds a mid-content ad placement between the hero section and login card.
- `templates/dashboard.html`
  - Adds a mid-content ad placement after the dashboard summary cards and before the main action panels.

## How to apply

Option 1: Replace the current site source with the modified files in this ZIP and redeploy the Flask app normally.

Option 2: Apply the patch file `tnnr-shop-ezoic-integration.patch` to your existing copy of the original source, then redeploy.

## Verification after deployment

1. Visit `https://tnnr.shop/ads.txt`.
   - Expected behavior: it should redirect to `https://srv.adstxtmanager.com/19390/tnnr.shop` and show the managed ads.txt seller list.
2. Visit a page on the site with `?ez_js_debugger=1`, for example:
   - `https://tnnr.shop/?ez_js_debugger=1`
   - If logged in and checking the dashboard: `https://tnnr.shop/dashboard?ez_js_debugger=1`
3. Confirm the Ezoic debugger modal reports the integration script in the page head and shows ad request / placeholder information.
4. If changes do not appear immediately, clear the website/CDN cache and reload.

## Notes

- No existing conflicting ad-network code was found in the provided source, so no ad code was removed.
- The uploaded source did not include live hosting credentials; this package is ready for redeployment but was not deployed to the live server.
- Ezoic account-side settings, approval, demand, fill rate, and revenue outcomes are outside this code package.
