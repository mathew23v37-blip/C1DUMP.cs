#!/usr/bin/env python3
"""CPM2 coin-farming service with a PostgreSQL-backed lifetime cap.

Passwords exist only in the in-process worker call and are never written to
PostgreSQL, logs, Redis, or the job-status response.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import os
import random
import re
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from contextvars import ContextVar
from typing import Any, Dict, Optional

import aiohttp
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

import postgres_db


LIFETIME_COIN_LIMIT = 4_000
MAX_WORKERS = max(1, min(4, int(os.getenv("CPM2_COIN_WORKERS", "2"))))
FIREBASE_API_KEY = os.getenv(
    "CPM2_FIREBASE_API_KEY", "AIzaSyCQDz9rgjgmvmFkvVfmvr2-7fT4tfrzRRQ"
).strip()
CF_BASE = os.getenv(
    "CPM2_CLOUD_FUNCTIONS_BASE",
    "https://europe-west1-cpm-2-7cea1.cloudfunctions.net",
).rstrip("/")
OG_BASE = os.getenv("CPM2_OGAMES_BASE", "https://cpm-2.ogames.kz/api").rstrip("/")
OG_API_KEY = os.getenv("CPM2_OGAMES_API_KEY", "320b93f3e7f4410aa52ce24da363ad04")
CLIENT_HASH = os.getenv(
    "CPM2_CLIENT_HASH", "F05A72840B40DC4FAADF539C5E38062527AE6422"
)
CLIENT_VERSION = os.getenv("CPM2_CLIENT_VERSION", "1.3.2.3")
PROXY_HOST = os.getenv("CPM2_PROXY_HOST", "rp.scrapegw.com").strip()
PROXY_PORT = os.getenv("CPM2_PROXY_PORT", "6060").strip()
PROXY_USERNAME = os.getenv("CPM2_PROXY_USERNAME", "vdggrosqnogvcx9").strip()
PROXY_PASSWORD = os.getenv("CPM2_PROXY_PASSWORD", "zz0znqa7bynevpe")
# Whole-job sticky; country is per-job (default de, bulk rotates test set).
PROXY_STICKY = True
PROXY_LANE_COUNT = 10
PROXY_SESSION_LIFETIME_MIN = 30
# Brute-test country rotation for bulk account generation + inject.
BULK_TEST_COUNTRIES = ("us", "gb", "de", "kz", "nl", "fr", "pl", "ca")
BULK_MAX_ACCOUNTS = 500
BULK_EMAIL_DOMAIN = "cpm2gen.tnnr.internal"
UNITY_VERSION = "2022.3.62f2"
USER_AGENT = "UnityPlayer/2022.3.62f2 (UnityWebRequest/1.0, libcurl/8.10.1-DEV)"
BUNDLE_ID = "com.olzhas.carparking.multyplayer2"
KEY_ADD = "12345678"
IV_ADD = "01234567"

# Logical lane, sticky session id, and country for the active job.
_current_proxy_lane: ContextVar[int] = ContextVar("cpm2_proxy_lane", default=0)
_current_proxy_session_id: ContextVar[str] = ContextVar(
    "cpm2_proxy_session_id", default=""
)
_current_proxy_country: ContextVar[str] = ContextVar("cpm2_proxy_country", default="de")

_EXECUTOR = ThreadPoolExecutor(max_workers=MAX_WORKERS, thread_name_prefix="cpm2-coins")
_SCHEMA_READY = False

_SCHEMA = """
CREATE TABLE IF NOT EXISTS cpm2_coin_jobs (
    job_id TEXT PRIMARY KEY,
    site_user_id TEXT NOT NULL,
    game_email TEXT NOT NULL,
    email_key TEXT NOT NULL,
    account_key TEXT,
    game_uid TEXT,
    status TEXT NOT NULL,
    injected_this_job BIGINT NOT NULL DEFAULT 0,
    lifetime_injected BIGINT NOT NULL DEFAULT 0,
    operations_completed INTEGER NOT NULL DEFAULT 0,
    task_pass_completed BOOLEAN NOT NULL DEFAULT FALSE,
    message TEXT NOT NULL,
    created_at DOUBLE PRECISION NOT NULL,
    updated_at DOUBLE PRECISION NOT NULL,
    completed_at DOUBLE PRECISION
);
CREATE INDEX IF NOT EXISTS idx_cpm2_coin_jobs_owner_time
    ON cpm2_coin_jobs (site_user_id, created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS uq_cpm2_active_email
    ON cpm2_coin_jobs (email_key)
    WHERE status IN ('queued', 'authenticating', 'running');
CREATE TABLE IF NOT EXISTS cpm2_coin_accounts (
    account_key TEXT PRIMARY KEY,
    game_uid TEXT NOT NULL,
    latest_email TEXT NOT NULL,
    lifetime_injected BIGINT NOT NULL DEFAULT 0,
    current_job_id TEXT,
    task_pass_completed BOOLEAN NOT NULL DEFAULT FALSE,
    first_seen_at DOUBLE PRECISION NOT NULL,
    updated_at DOUBLE PRECISION NOT NULL
);
ALTER TABLE cpm2_coin_jobs
    ADD COLUMN IF NOT EXISTS task_pass_completed BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE cpm2_coin_accounts
    ADD COLUMN IF NOT EXISTS task_pass_completed BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE cpm2_coin_jobs
    ADD COLUMN IF NOT EXISTS proxy_country TEXT;
CREATE TABLE IF NOT EXISTS cpm2_bulk_batches (
    batch_id TEXT PRIMARY KEY,
    site_user_id TEXT NOT NULL,
    status TEXT NOT NULL,
    target_count INTEGER NOT NULL,
    created_count INTEGER NOT NULL DEFAULT 0,
    injected_count INTEGER NOT NULL DEFAULT 0,
    failed_count INTEGER NOT NULL DEFAULT 0,
    total_coins BIGINT NOT NULL DEFAULT 0,
    countries TEXT NOT NULL DEFAULT '',
    message TEXT NOT NULL DEFAULT '',
    created_at DOUBLE PRECISION NOT NULL,
    updated_at DOUBLE PRECISION NOT NULL,
    completed_at DOUBLE PRECISION
);
CREATE INDEX IF NOT EXISTS idx_cpm2_bulk_batches_owner
    ON cpm2_bulk_batches (site_user_id, created_at DESC);
CREATE TABLE IF NOT EXISTS cpm2_bulk_accounts (
    id BIGSERIAL PRIMARY KEY,
    batch_id TEXT NOT NULL REFERENCES cpm2_bulk_batches(batch_id) ON DELETE CASCADE,
    ordinal INTEGER NOT NULL,
    email TEXT NOT NULL,
    game_uid TEXT,
    proxy_country TEXT NOT NULL,
    create_status TEXT NOT NULL DEFAULT 'pending',
    inject_job_id TEXT,
    inject_status TEXT NOT NULL DEFAULT 'pending',
    coins_reported BIGINT NOT NULL DEFAULT 0,
    log_text TEXT NOT NULL DEFAULT '',
    created_at DOUBLE PRECISION NOT NULL,
    updated_at DOUBLE PRECISION NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cpm2_bulk_accounts_batch
    ON cpm2_bulk_accounts (batch_id, ordinal);
CREATE TABLE IF NOT EXISTS cpm2_bulk_logs (
    id BIGSERIAL PRIMARY KEY,
    batch_id TEXT NOT NULL,
    account_ordinal INTEGER,
    level TEXT NOT NULL DEFAULT 'info',
    message TEXT NOT NULL,
    created_at DOUBLE PRECISION NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cpm2_bulk_logs_batch
    ON cpm2_bulk_logs (batch_id, id);
"""


class CPM2Error(RuntimeError):
    pass


class _Crypto:
    def __init__(self, uid: str):
        self.key = (uid[:8] + KEY_ADD).encode()[:16]
        self.iv = (uid[:8] + IV_ADD).encode()[:16]

    def encrypt(self, value: str) -> str:
        cipher = AES.new(self.key, AES.MODE_CBC, self.iv)
        return base64.b64encode(cipher.encrypt(pad(value.encode(), 16))).decode()

    def decrypt(self, value: str) -> Optional[str]:
        try:
            cipher = AES.new(self.key, AES.MODE_CBC, self.iv)
            return unpad(cipher.decrypt(base64.b64decode(value)), 16).decode()
        except Exception:
            return None

    def integer(self, value: Any) -> Optional[int]:
        if isinstance(value, bool):
            return None
        if isinstance(value, (int, float)):
            return int(value)
        if isinstance(value, str):
            try:
                return self.integer(json.loads(value))
            except Exception:
                match = re.search(r"\d+", value)
                return int(match.group(0)) if match else None
        if isinstance(value, list):
            for item in value:
                found = self.integer(item)
                if found is not None:
                    return found
        if isinstance(value, dict):
            for key in ("coins", "value", "coin", "amount", "points", "data"):
                if key in value:
                    found = self.integer(value[key])
                    if found is not None:
                        return found
        return None


def _ensure_schema() -> None:
    global _SCHEMA_READY
    if _SCHEMA_READY:
        return
    if not postgres_db.configured():
        raise CPM2Error("CPM2 Inject Coins requires Railway PostgreSQL.")
    with postgres_db.connection() as conn:
        with conn.transaction():
            conn.execute("SELECT pg_advisory_xact_lock(914002202)")
            for statement in _SCHEMA.split(";"):
                if statement.strip():
                    conn.execute(statement)
    _SCHEMA_READY = True


def _email_key(email: str) -> str:
    return hashlib.sha256(email.strip().lower().encode()).hexdigest()


def _account_key(uid: str) -> str:
    return hashlib.sha256(("cpm2:" + uid).encode()).hexdigest()


def _proxy_kwargs() -> Dict[str, Any]:
    """Return HTTP proxy config for the active job (ProxyScrape residential).

    Username shape:
      {user}-country-{cc}-session-{id}-lifetime-30
    Country comes from the per-job ContextVar (default de; bulk rotates).
    """
    if not PROXY_HOST or not PROXY_PORT or not PROXY_USERNAME or not PROXY_PASSWORD:
        raise CPM2Error(
            "CPM2 Inject Coins is waiting for its Railway proxy secrets."
        )
    if not PROXY_PORT.isdigit() or not 1 <= int(PROXY_PORT) <= 65_535:
        raise CPM2Error("The CPM2 proxy port is invalid.")
    parts = [PROXY_USERNAME]
    country = re.sub(r"[^a-z]", "", (_current_proxy_country.get() or "de").lower())[:2]
    if country:
        parts.append(f"country-{country}")
    session_id = (_current_proxy_session_id.get() or "").strip()
    if PROXY_STICKY and session_id:
        parts.append(f"session-{session_id}")
        parts.append(f"lifetime-{PROXY_SESSION_LIFETIME_MIN}")
    username = "-".join(parts)
    return {
        "proxy": f"http://{PROXY_HOST}:{PROXY_PORT}",
        "proxy_auth": aiohttp.BasicAuth(username, PROXY_PASSWORD),
    }


def _bind_job_proxy_lane(lane: int, country: str = "de") -> int:
    """Pin this job to one logical lane, sticky session, and exit country."""
    lane = int(lane) % PROXY_LANE_COUNT
    cc = re.sub(r"[^a-z]", "", (country or "de").lower())[:2] or "de"
    _current_proxy_lane.set(lane)
    _current_proxy_country.set(cc)
    _current_proxy_session_id.set(f"cpm2j{lane}{uuid.uuid4().hex[:12]}")
    return lane


def _new_http_session() -> aiohttp.ClientSession:
    """Single-session factory used for the whole job (login through combos)."""
    timeout = aiohttp.ClientTimeout(total=30, connect=12)
    connector = aiohttp.TCPConnector(limit=60)
    return aiohttp.ClientSession(timeout=timeout, connector=connector)


def _public_job(row: Any) -> Optional[Dict[str, Any]]:
    if not row:
        return None
    task_pass_completed = bool(row["task_pass_completed"])
    reported = min(LIFETIME_COIN_LIMIT, int(row["lifetime_injected"] or 0))
    return {
        "job_id": row["job_id"],
        "status": row["status"],
        "email": row["game_email"],
        "injected_this_job": int(row["injected_this_job"] or 0),
        "lifetime_injected": reported,
        "remaining": 0 if task_pass_completed else max(0, LIFETIME_COIN_LIMIT - reported),
        "operations_completed": int(row["operations_completed"] or 0),
        "task_pass_completed": task_pass_completed,
        "message": row["message"],
        "complete": row["status"] in {"complete", "limit_reached", "blocked", "failed"},
    }


def start_job(
    site_user_id: str,
    email: str,
    password: str,
    proxy_country: str = "de",
) -> Dict[str, Any]:
    _ensure_schema()
    _proxy_kwargs()
    email = email.strip().lower()
    if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email) or len(email) > 254:
        return {"ok": False, "message": "Enter a valid CPM2 account email."}
    if not 6 <= len(password) <= 256:
        return {"ok": False, "message": "Enter the CPM2 account password."}
    country = re.sub(r"[^a-z]", "", (proxy_country or "de").lower())[:2] or "de"

    job_id = uuid.uuid4().hex
    now = time.time()
    try:
        with postgres_db.connection() as conn:
            with conn.transaction():
                stale_before = now - max(300, int(os.getenv("CPM2_JOB_STALE_SECONDS", "900")))
                stale_rows = conn.execute(
                    """UPDATE cpm2_coin_jobs SET status='failed',
                       message='The previous worker stopped. Submit the account again to resume safely.',
                       updated_at=%s, completed_at=%s
                       WHERE status IN ('queued', 'authenticating', 'running') AND updated_at < %s
                       RETURNING job_id""",
                    (now, now, stale_before),
                ).fetchall()
                stale_ids = [row["job_id"] for row in stale_rows]
                if stale_ids:
                    conn.execute(
                        """UPDATE cpm2_coin_accounts SET current_job_id=NULL, updated_at=%s
                           WHERE current_job_id = ANY(%s)""",
                        (now, stale_ids),
                    )
                conn.execute(
                    """INSERT INTO cpm2_coin_jobs
                       (job_id, site_user_id, game_email, email_key, status, message,
                        proxy_country, created_at, updated_at)
                       VALUES (%s, %s, %s, %s, 'queued', %s, %s, %s, %s)""",
                    (job_id, site_user_id, email, _email_key(email),
                     f"Waiting to authenticate ({country.upper()} proxy)…",
                     country, now, now),
                )
    except Exception as exc:
        if "uq_cpm2_active_email" in str(exc) or "duplicate key" in str(exc).lower():
            return {"ok": False, "message": "This CPM2 account already has an Inject Coins job running."}
        raise

    _EXECUTOR.submit(_run_job, job_id, email, password, country)
    return {
        "ok": True,
        "job_id": job_id,
        "proxy_country": country,
        "message": "CPM2 coin injection started.",
    }


def get_job(job_id: str, site_user_id: str) -> Optional[Dict[str, Any]]:
    _ensure_schema()
    with postgres_db.connection() as conn:
        row = conn.execute(
            "SELECT * FROM cpm2_coin_jobs WHERE job_id=%s AND site_user_id=%s",
            (job_id, site_user_id),
        ).fetchone()
    return _public_job(row)


def _set_job(job_id: str, **fields: Any) -> None:
    allowed = {
        "status", "account_key", "game_uid",
        "injected_this_job", "lifetime_injected", "operations_completed", "message",
        "completed_at", "task_pass_completed",
    }
    clean = {key: value for key, value in fields.items() if key in allowed}
    clean["updated_at"] = time.time()
    assignments = ", ".join(f"{key}=%s" for key in clean)
    with postgres_db.connection() as conn:
        conn.execute(
            f"UPDATE cpm2_coin_jobs SET {assignments} WHERE job_id=%s",
            (*clean.values(), job_id),
        )


def _claim_account(job_id: str, uid: str, email: str) -> Dict[str, Any]:
    key = _account_key(uid)
    now = time.time()
    with postgres_db.connection() as conn:
        with conn.transaction():
            conn.execute("SELECT pg_advisory_xact_lock(hashtext(%s))", (key,))
            row = conn.execute(
                "SELECT * FROM cpm2_coin_accounts WHERE account_key=%s FOR UPDATE", (key,)
            ).fetchone()
            if not row:
                conn.execute(
                    """INSERT INTO cpm2_coin_accounts
                       (account_key, game_uid, latest_email, lifetime_injected,
                        current_job_id, task_pass_completed, first_seen_at, updated_at)
                       VALUES (%s, %s, %s, 0, %s, FALSE, %s, %s)""",
                    (key, uid, email, job_id, now, now),
                )
                lifetime = 0
                task_pass_completed = False
            else:
                lifetime = int(row["lifetime_injected"] or 0)
                task_pass_completed = bool(row["task_pass_completed"])
                active = str(row["current_job_id"] or "")
                if active and active != job_id:
                    active_row = conn.execute(
                        "SELECT status FROM cpm2_coin_jobs WHERE job_id=%s", (active,)
                    ).fetchone()
                    if active_row and active_row["status"] in {"queued", "authenticating", "running"}:
                        raise CPM2Error("This CPM2 account already has an Inject Coins job running.")
                conn.execute(
                    """UPDATE cpm2_coin_accounts
                       SET latest_email=%s, current_job_id=%s, updated_at=%s
                       WHERE account_key=%s""",
                    (email, job_id, now, key),
                )
            conn.execute(
                """UPDATE cpm2_coin_jobs SET account_key=%s, game_uid=%s,
                   lifetime_injected=%s, task_pass_completed=%s,
                   updated_at=%s WHERE job_id=%s""",
                (key, uid, lifetime, task_pass_completed, now, job_id),
            )
    return {
        "account_key": key,
        "lifetime": lifetime,
        "task_pass_completed": task_pass_completed,
    }


def _record_bot_progress(job_id: str, account_key: str, reported_coins: int, operations: int) -> Dict[str, int]:
    """Persist only the original bot's reported result; no balance reads occur."""
    now = time.time()
    reported = min(LIFETIME_COIN_LIMIT, max(0, int(reported_coins)))
    with postgres_db.connection() as conn:
        with conn.transaction():
            account = conn.execute(
                "SELECT * FROM cpm2_coin_accounts WHERE account_key=%s FOR UPDATE", (account_key,)
            ).fetchone()
            lifetime = max(int(account["lifetime_injected"] or 0), reported)
            conn.execute(
                """UPDATE cpm2_coin_accounts SET lifetime_injected=%s,
                   updated_at=%s WHERE account_key=%s""",
                (lifetime, now, account_key),
            )
            conn.execute(
                """UPDATE cpm2_coin_jobs SET injected_this_job=%s,
                   lifetime_injected=%s, operations_completed=%s, updated_at=%s WHERE job_id=%s""",
                (reported, lifetime, operations, now, job_id),
            )
    return {"lifetime": lifetime, "reported": reported}


def _finish(
    job_id: str,
    account_key: Optional[str],
    status: str,
    message: str,
    *,
    task_pass_completed: bool = False,
) -> None:
    now = time.time()
    with postgres_db.connection() as conn:
        with conn.transaction():
            conn.execute(
                """UPDATE cpm2_coin_jobs SET status=%s, message=%s,
                   task_pass_completed=(task_pass_completed OR %s),
                   updated_at=%s, completed_at=%s WHERE job_id=%s""",
                (status, message, task_pass_completed, now, now, job_id),
            )
            if account_key:
                conn.execute(
                    """UPDATE cpm2_coin_accounts SET current_job_id=NULL,
                       task_pass_completed=(task_pass_completed OR %s), updated_at=%s
                       WHERE account_key=%s AND current_job_id=%s""",
                    (task_pass_completed, now, account_key, job_id),
                )


def _headers(token: str) -> Dict[str, str]:
    return {
        "User-Agent": USER_AGENT,
        "Content-Type": "application/json; charset=utf-8",
        "X-Unity-Version": UNITY_VERSION,
        "Authorization": f"Bearer {token}",
        "X-Client-Hash": CLIENT_HASH,
    }


async def _login(session: aiohttp.ClientSession, email: str, password: str) -> Dict[str, str]:
    url = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={FIREBASE_API_KEY}"
    async with session.post(
        url,
        json={"email": email, "password": password, "returnSecureToken": True},
        **_proxy_kwargs(),
    ) as response:
        data = await response.json(content_type=None)
    if response.status != 200 or not data.get("idToken"):
        detail = str((data.get("error") or {}).get("message") or "Login failed")
        raise CPM2Error("CPM2 login failed: " + detail.replace("_", " ").title())
    return {"token": data["idToken"], "uid": data["localId"]}


async def _cloud_call(session: aiohttp.ClientSession, token: str, name: str, value: Any) -> Any:
    for attempt in range(3):
        try:
            async with session.post(
                f"{CF_BASE}/{name}", headers=_headers(token), json={"data": value},
                **_proxy_kwargs(),
            ) as response:
                text = await response.text()
                if response.status in {429, 500, 502, 503}:
                    await asyncio.sleep(1.0 + attempt * 1.5)
                    continue
                if response.status != 200:
                    return None
                data = json.loads(text)
                return data.get("result")
        except (aiohttp.ClientError, asyncio.TimeoutError, json.JSONDecodeError):
            if attempt == 2:
                return None
            await asyncio.sleep(1.0 + attempt * 1.5)
    return None


async def _start_session(session: aiohttp.ClientSession, token: str) -> None:
    device = "TNNR-CPM2-" + "".join(random.choice("0123456789abcdef") for _ in range(28))
    og_headers = {
        "X-Firebase-Token": token, "X-Client-Platform": "ANDROID",
        "X-Client-Version": CLIENT_VERSION, "X-Client-DeviceId": device,
        "X-Api-Key": OG_API_KEY, "X-Client-Env": "prod", "X-Bundle-Id": BUNDLE_ID,
        "Content-Type": "application/json", "User-Agent": USER_AGENT,
        "X-Client-Hash": CLIENT_HASH,
    }
    try:
        async with session.get(
            f"{OG_BASE}/check-service/v1/hash/check", headers=og_headers,
            **_proxy_kwargs(),
        ):
            pass
        async with session.post(
            f"{OG_BASE}/check-service/v1/session/start", headers=og_headers, json={},
            **_proxy_kwargs(),
        ):
            pass
    except (aiohttp.ClientError, asyncio.TimeoutError):
        pass
    await _cloud_call(session, token, "MasterMainStartup23_1", "0")


async def _execute_drag_sequence(
    session: aiohttp.ClientSession,
    token: str,
    crypto: _Crypto,
    sequence: tuple[int, int, int],
) -> tuple[str, int]:
    """Original flankerv2 SetDragRacing23_1 sequence operation."""
    payload = ",".join(map(str, sequence))
    encrypted = crypto.encrypt(payload)
    try:
        async with session.post(
            f"{CF_BASE}/SetDragRacing23_1",
            headers=_headers(token),
            data=json.dumps({"data": encrypted}),
            **_proxy_kwargs(),
        ) as response:
            if response.status != 200:
                return payload, 0
            result = await response.json(content_type=None)
            result_data = result.get("result") if isinstance(result, dict) else None
            encrypted_response = result_data.get("data") if isinstance(result_data, dict) else None
            decrypted = crypto.decrypt(encrypted_response) if encrypted_response else None
            return payload, crypto.integer(decrypted) or 0
    except (aiohttp.ClientError, asyncio.TimeoutError, ValueError, json.JSONDecodeError):
        return payload, 0


async def _execute_combo(
    session: aiohttp.ClientSession,
    token: str,
    crypto: _Crypto,
    combo: tuple[int, int, int],
) -> tuple[str, int]:
    """Original flankerv2 SetDragRacing22_1 combo operation."""
    payload = ",".join(map(str, combo))
    encrypted = crypto.encrypt(payload)
    response = await _cloud_call(session, token, "SetDragRacing22_1", encrypted)
    values: list[Any] = []
    if isinstance(response, str):
        try:
            parsed = json.loads(response)
            if isinstance(parsed, list) and len(parsed) >= 2:
                values = parsed
        except json.JSONDecodeError:
            pass
    elif isinstance(response, list) and len(response) >= 2:
        values = response
    if len(values) < 2 or not isinstance(values[1], str):
        return payload, 0
    decrypted = crypto.decrypt(values[1])
    try:
        return payload, int(decrypted) if decrypted else 0
    except (TypeError, ValueError):
        return payload, 0


async def _farm(
    job_id: str, email: str, password: str, proxy_country: str = "de"
) -> None:
    # One sticky lane for the entire job so login + every task call share the
    # same exit IP (mid-job IP changes were preventing coin rewards). Lane is
    # derived from job_id so concurrent jobs spread across the ten lanes.
    lane = int(hashlib.sha256(job_id.encode()).hexdigest(), 16) % PROXY_LANE_COUNT
    _bind_job_proxy_lane(lane, proxy_country)

    # Single ClientSession for the whole Flanker sequence — matches the
    # earlier working builds. TCP connections still drop on close via force_close.
    async with _new_http_session() as session:
        _set_job(job_id, status="authenticating", message="Signing in to the CPM2 account…")
        auth = await _login(session, email, password)
        await _start_session(session, auth["token"])
        claimed = _claim_account(job_id, auth["uid"], email)
        account_key = str(claimed["account_key"])
        if claimed["task_pass_completed"]:
            _finish(
                job_id,
                account_key,
                "limit_reached",
                "This CPM2 account has already run Auto Complete. Use a new CPM2 account.",
            )
            return

        _set_job(
            job_id,
            status="running",
            message="Auto Complete is running the original Drag Racing reward tasks…",
        )
        crypto = _Crypto(auth["uid"])
        drag_sequences = [
            (a, b, c) for a in range(10) for b in range(1, 7) for c in range(10)
        ]
        combo_tasks = [
            (car, place, gear)
            for car in range(6)
            for place in range(1, 4)
            for gear in range(2)
        ]
        total_reported = 0
        successful_operations = 0
        total_operations = 0

        # Original flankerv2 flow: 600 sequences, 50 at a time (same session).
        batch_size = 50
        for offset in range(0, len(drag_sequences), batch_size):
            batch = drag_sequences[offset:offset + batch_size]
            results = await asyncio.gather(*(
                _execute_drag_sequence(session, auth["token"], crypto, sequence)
                for sequence in batch
            ))
            for _payload, coins in results:
                if coins > 0:
                    total_reported += coins
                    successful_operations += 1
                total_operations += 1
            progress = _record_bot_progress(
                job_id, account_key, total_reported, total_operations
            )
            _set_job(
                job_id,
                message=(
                    f"Auto Complete: Drag Racing tasks "
                    f"{min(offset + batch_size, len(drag_sequences))}/{len(drag_sequences)} · "
                    f"up to {progress['reported']:,} of {LIFETIME_COIN_LIMIT:,} coins reported."
                ),
            )
            await asyncio.sleep(0.5)

        # Original flankerv2 flow: retry unfinished combo tasks for ten rounds.
        completed_combos: set[tuple[int, int, int]] = set()
        for round_number in range(1, 11):
            pending = [combo for combo in combo_tasks if combo not in completed_combos]
            if not pending:
                break
            results = await asyncio.gather(*(
                _execute_combo(session, auth["token"], crypto, combo)
                for combo in pending
            ))
            round_successes = 0
            for payload, coins in results:
                if coins > 0:
                    completed_combos.add(tuple(map(int, payload.split(","))))
                    total_reported += coins
                    round_successes += 1
                    successful_operations += 1
                total_operations += 1
            progress = _record_bot_progress(
                job_id, account_key, total_reported, total_operations
            )
            _set_job(
                job_id,
                message=(
                    f"Auto Complete: combo round {round_number}/10 · "
                    f"{len(completed_combos)}/{len(combo_tasks)} tasks completed · "
                    f"up to {progress['reported']:,} of {LIFETIME_COIN_LIMIT:,} coins reported."
                ),
            )
            if round_successes == 0 and round_number > 1:
                await _start_session(session, auth["token"])
                await asyncio.sleep(0.3)
            elif round_successes < len(pending):
                await asyncio.sleep(0.5 if round_number <= 3 else 1.5)

        final_reported = min(LIFETIME_COIN_LIMIT, max(0, total_reported))
        _record_bot_progress(job_id, account_key, final_reported, total_operations)
        _finish(
            job_id,
            account_key,
            "complete",
            (
                f"Auto Complete finished: {successful_operations}/{total_operations} "
                f"task calls reported rewards. The most this tool can pull is "
                f"{LIFETIME_COIN_LIMIT:,} coins, and this account's task pass is now used."
            ),
            task_pass_completed=True,
        )


def _run_job(
    job_id: str, email: str, password: str, proxy_country: str = "de"
) -> None:
    account_key: Optional[str] = None
    try:
        asyncio.run(_farm(job_id, email, password, proxy_country))
        return
    except Exception as exc:
        try:
            with postgres_db.connection() as conn:
                row = conn.execute("SELECT account_key FROM cpm2_coin_jobs WHERE job_id=%s", (job_id,)).fetchone()
                account_key = row["account_key"] if row else None
        except Exception:
            pass
        message = str(exc) if isinstance(exc, CPM2Error) else "CPM2 coin injection stopped because of a temporary service error. You can retry safely."
        try:
            _finish(job_id, account_key, "blocked" if "already" in message.lower() else "failed", message[:500])
        except Exception:
            pass


def _bulk_log(
    batch_id: str,
    message: str,
    level: str = "info",
    account_ordinal: Optional[int] = None,
) -> None:
    now = time.time()
    try:
        with postgres_db.connection() as conn:
            conn.execute(
                """INSERT INTO cpm2_bulk_logs
                   (batch_id, account_ordinal, level, message, created_at)
                   VALUES (%s, %s, %s, %s, %s)""",
                (batch_id, account_ordinal, level, message[:2000], now),
            )
            conn.execute(
                "UPDATE cpm2_bulk_batches SET message=%s, updated_at=%s WHERE batch_id=%s",
                (message[:500], now, batch_id),
            )
    except Exception:
        pass


def _bulk_set_account(
    batch_id: str,
    ordinal: int,
    **fields: Any,
) -> None:
    if not fields:
        return
    allowed = {
        "email", "game_uid", "proxy_country", "create_status", "inject_job_id",
        "inject_status", "coins_reported", "log_text",
    }
    sets = []
    values: list[Any] = []
    for key, value in fields.items():
        if key not in allowed:
            continue
        sets.append(f"{key}=%s")
        values.append(value)
    if not sets:
        return
    sets.append("updated_at=%s")
    values.append(time.time())
    values.extend([batch_id, ordinal])
    with postgres_db.connection() as conn:
        conn.execute(
            f"UPDATE cpm2_bulk_accounts SET {', '.join(sets)} "
            f"WHERE batch_id=%s AND ordinal=%s",
            tuple(values),
        )


async def _signup(
    session: aiohttp.ClientSession, email: str, password: str
) -> Dict[str, str]:
    url = (
        "https://identitytoolkit.googleapis.com/v1/accounts:signUp"
        f"?key={FIREBASE_API_KEY}"
    )
    async with session.post(
        url,
        json={"email": email, "password": password, "returnSecureToken": True},
        **_proxy_kwargs(),
    ) as response:
        data = await response.json(content_type=None)
    if response.status != 200 or not data.get("idToken"):
        detail = str((data.get("error") or {}).get("message") or "Signup failed")
        raise CPM2Error("CPM2 signup failed: " + detail.replace("_", " ").title())
    return {
        "token": data["idToken"],
        "uid": data["localId"],
        "email": data.get("email") or email,
    }


def _random_password() -> str:
    alphabet = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#"
    return "".join(random.choice(alphabet) for _ in range(14))


def _random_email() -> str:
    local = "tnnr" + uuid.uuid4().hex[:12]
    return f"{local}@{BULK_EMAIL_DOMAIN}"


def start_bulk_batch(
    site_user_id: str,
    count: int,
    countries: Optional[list[str]] = None,
) -> Dict[str, Any]:
    """Create up to 500 Firebase accounts and run inject on each, rotating countries."""
    _ensure_schema()
    _proxy_kwargs()
    try:
        count = int(count)
    except (TypeError, ValueError):
        return {"ok": False, "message": "Enter how many accounts to generate (1–500)."}
    if not 1 <= count <= BULK_MAX_ACCOUNTS:
        return {
            "ok": False,
            "message": f"Choose between 1 and {BULK_MAX_ACCOUNTS} accounts.",
        }
    if countries:
        cleaned = []
        for item in countries:
            cc = re.sub(r"[^a-z]", "", str(item).lower())[:2]
            if cc and cc not in cleaned:
                cleaned.append(cc)
        country_list = tuple(cleaned) or BULK_TEST_COUNTRIES
    else:
        country_list = BULK_TEST_COUNTRIES

    batch_id = uuid.uuid4().hex
    now = time.time()
    with postgres_db.connection() as conn:
        with conn.transaction():
            conn.execute(
                """INSERT INTO cpm2_bulk_batches
                   (batch_id, site_user_id, status, target_count, countries,
                    message, created_at, updated_at)
                   VALUES (%s, %s, 'running', %s, %s, %s, %s, %s)""",
                (
                    batch_id,
                    site_user_id,
                    count,
                    ",".join(country_list),
                    f"Starting bulk generate+inject for {count} accounts…",
                    now,
                    now,
                ),
            )
            for ordinal in range(count):
                conn.execute(
                    """INSERT INTO cpm2_bulk_accounts
                       (batch_id, ordinal, email, proxy_country, create_status,
                        inject_status, created_at, updated_at)
                       VALUES (%s, %s, %s, %s, 'pending', 'pending', %s, %s)""",
                    (
                        batch_id,
                        ordinal,
                        "",
                        country_list[ordinal % len(country_list)],
                        now,
                        now,
                    ),
                )

    _EXECUTOR.submit(_run_bulk_batch, batch_id, site_user_id, count, list(country_list))
    return {
        "ok": True,
        "batch_id": batch_id,
        "target_count": count,
        "countries": list(country_list),
        "message": f"Bulk batch started for {count} accounts.",
    }


def get_bulk_batch(batch_id: str, site_user_id: str) -> Optional[Dict[str, Any]]:
    _ensure_schema()
    with postgres_db.connection() as conn:
        batch = conn.execute(
            "SELECT * FROM cpm2_bulk_batches WHERE batch_id=%s AND site_user_id=%s",
            (batch_id, site_user_id),
        ).fetchone()
        if not batch:
            return None
        accounts = conn.execute(
            """SELECT ordinal, email, game_uid, proxy_country, create_status,
                      inject_job_id, inject_status, coins_reported, log_text,
                      updated_at
               FROM cpm2_bulk_accounts WHERE batch_id=%s ORDER BY ordinal""",
            (batch_id,),
        ).fetchall()
        logs = conn.execute(
            """SELECT account_ordinal, level, message, created_at
               FROM cpm2_bulk_logs WHERE batch_id=%s ORDER BY id DESC LIMIT 200""",
            (batch_id,),
        ).fetchall()
    by_country: Dict[str, Dict[str, Any]] = {}
    for row in accounts:
        cc = row["proxy_country"] or "?"
        bucket = by_country.setdefault(
            cc, {"accounts": 0, "created": 0, "injected": 0, "failed": 0, "coins": 0}
        )
        bucket["accounts"] += 1
        if row["create_status"] == "ok":
            bucket["created"] += 1
        if row["inject_status"] == "complete":
            bucket["injected"] += 1
            bucket["coins"] += int(row["coins_reported"] or 0)
        if row["create_status"] == "failed" or row["inject_status"] in {
            "failed", "blocked",
        }:
            bucket["failed"] += 1
    return {
        "batch_id": batch["batch_id"],
        "status": batch["status"],
        "target_count": int(batch["target_count"]),
        "created_count": int(batch["created_count"] or 0),
        "injected_count": int(batch["injected_count"] or 0),
        "failed_count": int(batch["failed_count"] or 0),
        "total_coins": int(batch["total_coins"] or 0),
        "countries": str(batch["countries"] or ""),
        "message": batch["message"],
        "complete": batch["status"] in {"complete", "failed", "cancelled"},
        "by_country": by_country,
        "accounts": [
            {
                "ordinal": int(r["ordinal"]),
                "email": r["email"],
                "game_uid": r["game_uid"],
                "proxy_country": r["proxy_country"],
                "create_status": r["create_status"],
                "inject_status": r["inject_status"],
                "inject_job_id": r["inject_job_id"],
                "coins_reported": int(r["coins_reported"] or 0),
                "log_text": r["log_text"],
            }
            for r in accounts
        ],
        "logs": [
            {
                "ordinal": r["account_ordinal"],
                "level": r["level"],
                "message": r["message"],
                "created_at": float(r["created_at"]),
            }
            for r in reversed(list(logs))
        ],
    }


def _run_bulk_batch(
    batch_id: str,
    site_user_id: str,
    count: int,
    countries: list[str],
) -> None:
    created = 0
    injected = 0
    failed = 0
    total_coins = 0
    _bulk_log(
        batch_id,
        f"Bulk worker started · {count} accounts · countries={','.join(countries)}",
    )
    try:
        for ordinal in range(count):
            country = countries[ordinal % len(countries)]
            email = _random_email()
            password = _random_password()
            _bulk_set_account(
                batch_id,
                ordinal,
                email=email,
                proxy_country=country,
                create_status="creating",
                log_text=f"Creating account via Firebase ({country})…",
            )
            _bulk_log(
                batch_id,
                f"[{ordinal + 1}/{count}] Creating {email} via {country.upper()} proxy",
                account_ordinal=ordinal,
            )
            try:
                lane = ordinal % PROXY_LANE_COUNT
                _bind_job_proxy_lane(lane, country)

                async def _create_one() -> Dict[str, str]:
                    async with _new_http_session() as session:
                        return await _signup(session, email, password)

                auth = asyncio.run(_create_one())
                created += 1
                _bulk_set_account(
                    batch_id,
                    ordinal,
                    email=auth.get("email") or email,
                    game_uid=auth.get("uid"),
                    create_status="ok",
                    inject_status="queued",
                    log_text=f"Created uid={auth.get('uid')} · starting inject…",
                )
                _bulk_log(
                    batch_id,
                    f"[{ordinal + 1}/{count}] Created uid={auth.get('uid')} · "
                    f"queueing inject ({country.upper()})",
                    account_ordinal=ordinal,
                )
            except Exception as exc:
                failed += 1
                err = str(exc)[:400]
                _bulk_set_account(
                    batch_id,
                    ordinal,
                    create_status="failed",
                    inject_status="skipped",
                    log_text=f"Create failed: {err}",
                )
                _bulk_log(
                    batch_id,
                    f"[{ordinal + 1}/{count}] CREATE FAILED ({country}): {err}",
                    level="error",
                    account_ordinal=ordinal,
                )
                with postgres_db.connection() as conn:
                    conn.execute(
                        """UPDATE cpm2_bulk_batches SET created_count=%s, failed_count=%s,
                           updated_at=%s WHERE batch_id=%s""",
                        (created, failed, time.time(), batch_id),
                    )
                continue

            # Run inject synchronously in this worker so we capture final coins
            # before moving to the next account (serial brute test + full logs).
            try:
                result = start_job(
                    site_user_id, email, password, proxy_country=country
                )
                if not result.get("ok"):
                    raise CPM2Error(result.get("message") or "Inject start failed")
                job_id = str(result["job_id"])
                _bulk_set_account(
                    batch_id,
                    ordinal,
                    inject_job_id=job_id,
                    inject_status="running",
                    log_text=f"Inject job {job_id} running…",
                )
                _bulk_log(
                    batch_id,
                    f"[{ordinal + 1}/{count}] Inject started job={job_id}",
                    account_ordinal=ordinal,
                )
                # Poll until job completes (password never stored in DB).
                final_status = "failed"
                coins = 0
                final_message = ""
                for _ in range(900):  # up to ~30 min at 2s
                    time.sleep(2)
                    job = get_job(job_id, site_user_id)
                    if not job:
                        break
                    final_status = job.get("status") or "running"
                    coins = int(job.get("injected_this_job") or 0)
                    final_message = str(job.get("message") or "")
                    if job.get("complete"):
                        break
                if final_status == "complete":
                    injected += 1
                    total_coins += coins
                else:
                    failed += 1
                _bulk_set_account(
                    batch_id,
                    ordinal,
                    inject_status=final_status,
                    coins_reported=coins,
                    log_text=f"{final_status}: {coins} coins · {final_message[:300]}",
                )
                _bulk_log(
                    batch_id,
                    f"[{ordinal + 1}/{count}] Inject {final_status} · "
                    f"{coins} coins · country={country.upper()} · {final_message[:200]}",
                    level="info" if final_status == "complete" else "error",
                    account_ordinal=ordinal,
                )
            except Exception as exc:
                failed += 1
                err = str(exc)[:400]
                _bulk_set_account(
                    batch_id,
                    ordinal,
                    inject_status="failed",
                    log_text=f"Inject failed: {err}",
                )
                _bulk_log(
                    batch_id,
                    f"[{ordinal + 1}/{count}] INJECT FAILED ({country}): {err}",
                    level="error",
                    account_ordinal=ordinal,
                )

            with postgres_db.connection() as conn:
                conn.execute(
                    """UPDATE cpm2_bulk_batches
                       SET created_count=%s, injected_count=%s, failed_count=%s,
                           total_coins=%s, updated_at=%s WHERE batch_id=%s""",
                    (created, injected, failed, total_coins, time.time(), batch_id),
                )

        with postgres_db.connection() as conn:
            conn.execute(
                """UPDATE cpm2_bulk_batches
                   SET status='complete', created_count=%s, injected_count=%s,
                       failed_count=%s, total_coins=%s, message=%s,
                       updated_at=%s, completed_at=%s WHERE batch_id=%s""",
                (
                    created,
                    injected,
                    failed,
                    total_coins,
                    (
                        f"Bulk complete: created={created} injected={injected} "
                        f"failed={failed} total_coins={total_coins:,}"
                    ),
                    time.time(),
                    time.time(),
                    batch_id,
                ),
            )
        _bulk_log(
            batch_id,
            f"DONE created={created} injected={injected} failed={failed} "
            f"total_coins={total_coins}",
            level="info",
        )
    except Exception as exc:
        _bulk_log(batch_id, f"Bulk worker crashed: {exc}", level="error")
        try:
            with postgres_db.connection() as conn:
                conn.execute(
                    """UPDATE cpm2_bulk_batches SET status='failed', message=%s,
                       updated_at=%s, completed_at=%s WHERE batch_id=%s""",
                    (str(exc)[:500], time.time(), time.time(), batch_id),
                )
        except Exception:
            pass


def shutdown() -> None:
    _EXECUTOR.shutdown(wait=False, cancel_futures=False)
