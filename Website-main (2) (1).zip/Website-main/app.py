#!/usr/bin/env python3
"""TNNR CPM1 Webtool - Malik logic website adapter."""

import asyncio
import json
import atexit
import html
import hmac
import io
import os
import re
import signal
import uuid
import threading
import time
import hardcoded_settings  # noqa: F401 - loads concrete deployment settings
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from concurrent.futures import ThreadPoolExecutor
from functools import wraps
from typing import Any, Callable, Dict, Optional

from flask import Flask, Response, flash, g, jsonify, redirect, render_template, request, send_file, session, url_for

try:
    import stripe
except ImportError:
    stripe = None

from cpm_nuker import MAX_COIN, MAX_MONEY, CPMNuker
from car_bulk_injector import (
    close_current_injection_http_session,
    inject_all_cars,
    inject_event_cars,
    inject_saved_cars,
    inject_with_garage_protection,
    inject_custom_car_file,
    scan_garage_for_design,
    verify_account_garage_count,
    injection_http_session,
    login_async,
    get_garage_cars_result,
)
from weekly_crown_injector import inject_permanent_crown, inject_weekly_design
from account_clone import clone_account, validate_clone_target
import backlog
import accounts
import car_safety_backups
import catalog_repository
import bulk_account_jobs
import king_account_jobs
import outbox_dispatcher
import community
import design_marketplace
import admin_ticket_context
import world_sale_health
import user_cpm_alts
import affected_refunds
import cpm2_coin_farm
import giveaway
from redis_jobs import distributed_mode_enabled, get_job_store
from config import DATA_DIR
from persistence import (
    is_maintenance_bypass,
    is_dashboard_maintenance,
    load_settings,
    maintenance_bypass_user_ids,
    save_settings,
    set_maintenance_bypass,
    set_dashboard_maintenance,
    set_maintenance_controls,
    set_unlimited_currency,
)

os.makedirs(DATA_DIR, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY") or "dev-only-change-me-in-production"

# Keep both the TNNR site-account login and the CPM game login active while a
# user moves between pages. The lifetime is intentionally finite and refreshes
# on active requests, so an idle browser is signed out automatically.
SESSION_LIFETIME_MINUTES = max(10, int(os.getenv("SESSION_LIFETIME_MINUTES", str(60 * 24 * 400))))
app.permanent_session_lifetime = timedelta(minutes=SESSION_LIFETIME_MINUTES)
app.config.update(
    SESSION_REFRESH_EACH_REQUEST=True,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
)

DASHBOARD_MAINTENANCE_TITLE = "Currently Under Maintenance,"
DASHBOARD_MAINTENANCE_MESSAGE = (
    "I'm trying to work on site lag, please be patient and enjoy what's free for now "
    "that I can run with no issues."
)
TELEGRAM_URL = "https://t.me/TnnrCPM"
CLONE_ACCOUNTS_ENABLED = False
BULK_ACCOUNT_GENERATOR_ENABLED = False
UNLOCK_ALL_CARS_ENABLED = False
EASTERN_TIME = ZoneInfo("America/New_York")
MAINTENANCE_SECTIONS = {
    "money": "Money modifications",
    "coins": "Coin modifications",
    "currency_presets": "Money & coin presets",
    "player_modifications": "Player modifications",
    "player_unlocks": "Player unlocks",
    "account_repair": "Fix account data",
    "premium_car_injections": "Premium car pack injections",
    "event_car_injections": "Event car pack injections",
    "designed_car_injections": "Designed and weekly car injections",
    "public_car_injections": "Public-sale car injections",
    "custom_car_injections": "Custom safe-file car injections",
    "other_car_injections": "Other/bulk car injection tools",
    "public_listings": "Create and manage Public Cars",
    "cpm2_coins": "CPM2 Inject Coins",
}


def _maintenance_active_for_request() -> bool:
    """Maintenance applies unless the signed-in site User ID is allowlisted."""
    return bool(
        is_dashboard_maintenance()
        and not is_maintenance_bypass(session.get("site_user_id"))
    )


def _maintenance_settings() -> Dict[str, Any]:
    settings = load_settings()
    mode = str(settings.get("maintenance_mode") or "off").lower()
    if not settings.get("dashboard_maintenance"):
        mode = "off"
    enabled_sections = set(settings.get("maintenance_enabled_sections") or [])
    # Seamless compatibility with the previous single All Car Injections switch.
    if "car_injections" in enabled_sections:
        enabled_sections.discard("car_injections")
        enabled_sections.update({
            "premium_car_injections", "event_car_injections",
            "designed_car_injections", "public_car_injections",
            "custom_car_injections", "other_car_injections",
        })
    return {
        "mode": mode if mode in {"off", "unlimited", "paid"} else "unlimited",
        "enabled_sections": enabled_sections,
        "schedule_enabled": bool(settings.get("hourly_access_schedule_enabled", True)),
    }


def _hourly_access_status(now: Optional[datetime] = None) -> Dict[str, Any]:
    now = (now or datetime.now(timezone.utc)).astimezone(EASTERN_TIME)
    paid_window = now.minute < 40
    boundary = now.replace(second=0, microsecond=0, minute=40 if paid_window else 0)
    if not paid_window:
        boundary += timedelta(hours=1)
    seconds = max(0, int((boundary - now).total_seconds()))
    return {
        "phase": "paid" if paid_window else "free",
        "phase_label": "Paid Users" if paid_window else "Free Users",
        "next_label": "Free Users" if paid_window else "Paid Users",
        "seconds_remaining": seconds,
        "deadline_epoch": int(boundary.timestamp()),
        "eastern_now": now.strftime("%I:%M:%S %p ET").lstrip("0"),
    }


def _request_user_is_paid() -> bool:
    user_id = str(session.get("site_user_id") or "")
    try:
        return bool(user_id and accounts.has_paid_history(user_id))
    except Exception:
        app.logger.exception("Unable to determine paid-user schedule tier")
        return False


@app.context_processor
def inject_site_status():
    """Expose the persisted maintenance state and permanent Telegram link."""
    unread_messages = 0
    site_user_id = str(session.get("site_user_id") or "")
    if site_user_id:
        try:
            unread_messages = int(community.inbox_unread_count(site_user_id) or 0)
        except Exception:
            app.logger.exception("Unable to load inbox unread count")
            unread_messages = 0
        try:
            unread_messages += int(giveaway.site_inbox_unread_count(site_user_id) or 0)
        except Exception:
            pass
    try:
        world_sale = world_sale_health.get_status()
    except Exception:
        world_sale = {"state": "available", "paused": False, "delayed": False, "slot_count": 0}
    maintenance = _maintenance_settings()
    return {
        "dashboard_maintenance": _maintenance_active_for_request(),
        "maintenance_bypass_active": bool(
            is_dashboard_maintenance()
            and is_maintenance_bypass(session.get("site_user_id"))
        ),
        "dashboard_maintenance_title": DASHBOARD_MAINTENANCE_TITLE,
        "dashboard_maintenance_message": DASHBOARD_MAINTENANCE_MESSAGE,
        "telegram_url": TELEGRAM_URL,
        "clone_accounts_enabled": CLONE_ACCOUNTS_ENABLED,
        "inbox_unread_count": unread_messages,
        "giveaway_enabled": giveaway.is_enabled(),
        "world_sale_status": world_sale,
        "maintenance_mode": maintenance["mode"],
        "maintenance_enabled_sections": maintenance["enabled_sections"],
        "hourly_access_schedule": _hourly_access_status(),
        "hourly_access_schedule_enabled": maintenance["schedule_enabled"],
        "schedule_user_is_paid": _request_user_is_paid(),
    }


# ---------------------------------------------------------------------------
# Unlimited Currency -> Railway process restart supervisor
# ---------------------------------------------------------------------------
UNLIMITED_RESTART_INTERVAL_SECONDS = 5 * 60
UNLIMITED_AUTO_RESTART_ENABLED = os.getenv(
    "UNLIMITED_AUTO_RESTART_ENABLED", "0"
).strip().lower() in {"1", "true", "yes", "on"} and not (
    os.getenv("REDIS_URL", "").strip() and os.getenv("DATABASE_URL", "").strip()
)
UNLIMITED_RESTART_GRACE_SECONDS = min(
    15, max(1, int(os.getenv("UNLIMITED_RESTART_GRACE_SECONDS", "15")))
)
UNLIMITED_RESTART_POLL_SECONDS = max(
    5.0, float(os.getenv("UNLIMITED_RESTART_POLL_SECONDS", "10"))
)
SLOW_REQUEST_SECONDS = max(0.25, float(os.getenv("SLOW_REQUEST_SECONDS", "1.0")))

_RESTART_SUPERVISOR_GUARD = threading.Lock()
_RESTART_SUPERVISOR_STARTED = False
_RESTART_EXIT_REQUESTED = False
_ACTIVE_REQUESTS_LOCK = threading.Lock()
_ACTIVE_REQUESTS = 0
_MARKETPLACE_RECONCILIATION_GUARD = threading.Lock()
_MARKETPLACE_RECONCILIATION_STARTED = False


def _run_marketplace_reconciliation():
    try:
        reconcile = getattr(design_marketplace, "reconcile_existing_marketplace", None)
        if not callable(reconcile):
            app.logger.info("Existing marketplace reconciliation is unavailable in this deployment; skipping")
            return
        result = reconcile()
        app.logger.info("Existing marketplace reconciliation result=%s", result)
    except Exception:
        app.logger.exception("Existing marketplace reconciliation failed; a later deployment/request can retry")


def _ensure_marketplace_reconciliation():
    global _MARKETPLACE_RECONCILIATION_STARTED
    if not os.getenv("DATABASE_URL", "").strip():
        return
    with _MARKETPLACE_RECONCILIATION_GUARD:
        if _MARKETPLACE_RECONCILIATION_STARTED:
            return
        _MARKETPLACE_RECONCILIATION_STARTED = True
        threading.Thread(
            target=_run_marketplace_reconciliation,
            name="marketplace-existing-listing-cleanup",
            daemon=True,
        ).start()


def _schedule_unlimited_restart(enabled: bool):
    """Arm a fresh five-minute cycle on ON; cancel immediately on OFF."""
    now = time.time()
    settings = load_settings()
    settings["unlimited_currency"] = bool(enabled)
    settings["unlimited_restart_draining"] = False
    settings["unlimited_restart_next_at"] = (
        now + UNLIMITED_RESTART_INTERVAL_SECONDS
        if enabled and UNLIMITED_AUTO_RESTART_ENABLED
        else 0.0
    )
    return save_settings(settings)


def _unlimited_restart_status():
    settings = load_settings()
    enabled = bool(settings.get("unlimited_currency"))
    next_at = float(settings.get("unlimited_restart_next_at") or 0.0)
    draining = bool(settings.get("unlimited_restart_draining"))

    if not UNLIMITED_AUTO_RESTART_ENABLED:
        pending_jobs, active_requests = _restart_pending_work()
        return {
            "enabled": enabled,
            "auto_restart_enabled": False,
            "next_restart_at": 0.0,
            "seconds_remaining": 0,
            "draining": False,
            "warning": False,
            "pending_jobs": pending_jobs,
            "active_requests": active_requests,
            "interval_seconds": UNLIMITED_RESTART_INTERVAL_SECONDS,
            "grace_seconds": UNLIMITED_RESTART_GRACE_SECONDS,
        }

    if enabled and next_at <= 0:
        next_at = time.time() + UNLIMITED_RESTART_INTERVAL_SECONDS
        settings["unlimited_restart_next_at"] = next_at
        settings["unlimited_restart_draining"] = False
        save_settings(settings)
        draining = False

    remaining = max(0, int(round(next_at - time.time()))) if enabled and next_at else 0
    pending_jobs, active_requests = _restart_pending_work()
    warning = bool(enabled and not draining and remaining <= 60)
    return {
        "enabled": enabled,
        "auto_restart_enabled": True,
        "next_restart_at": next_at if enabled else 0.0,
        "seconds_remaining": remaining,
        "draining": draining if enabled else False,
        "warning": warning,
        "pending_jobs": pending_jobs,
        "active_requests": active_requests,
        "interval_seconds": UNLIMITED_RESTART_INTERVAL_SECONDS,
        "grace_seconds": UNLIMITED_RESTART_GRACE_SECONDS,
    }


def _restart_pending_work():
    pending_jobs = 0
    try:
        if SHARED_INJECTION_MODE:
            states = SHARED_JOB_STORE.states()
            pending_jobs = int(states.get("queued", 0)) + int(states.get("running", 0))
        else:
            with CAR_INJECTION_LOCK:
                pending_jobs = sum(
                    1
                    for job in CAR_INJECTION_JOBS.values()
                    if job.get("status") in ("queued", "running")
                )
    except Exception:
        pending_jobs = 0

    with _ACTIVE_REQUESTS_LOCK:
        active_requests = max(0, int(_ACTIVE_REQUESTS))

    return pending_jobs, active_requests


def _request_full_process_exit():
    """
    Terminate the Gunicorn master so Railway restarts the existing deployment.

    This is a process restart, not a code redeploy. DATA_DIR is mounted on the
    existing Railway volume and is never deleted by this routine.
    """
    global _RESTART_EXIT_REQUESTED
    if _RESTART_EXIT_REQUESTED:
        return
    _RESTART_EXIT_REQUESTED = True

    settings = load_settings()
    settings["unlimited_restart_last_requested_at"] = time.time()
    settings["unlimited_restart_draining"] = True
    settings["unlimited_restart_next_at"] = 0.0
    save_settings(settings)

    app.logger.warning(
        "Unlimited Currency 5-minute reset: requesting full Railway process restart"
    )

    try:
        _shutdown_infrastructure()
    except Exception:
        app.logger.exception("Restart pre-exit infrastructure cleanup failed")

    parent_pid = os.getppid()
    try:
        if parent_pid and parent_pid > 1:
            os.kill(parent_pid, signal.SIGTERM)
            time.sleep(5)
    except Exception:
        app.logger.exception("Unable to signal parent process for restart")

    os._exit(0)


def _unlimited_restart_supervisor():
    while True:
        try:
            status = _unlimited_restart_status()

            if not status["enabled"]:
                time.sleep(UNLIMITED_RESTART_POLL_SECONDS)
                continue

            if status["seconds_remaining"] > 0:
                time.sleep(
                    min(
                        UNLIMITED_RESTART_POLL_SECONDS,
                        max(0.25, status["seconds_remaining"]),
                    )
                )
                continue

            settings = load_settings()
            settings["unlimited_restart_draining"] = True
            save_settings(settings)

            app.logger.warning(
                "Unlimited Currency 5-minute deadline reached; draining active work"
            )

            grace_deadline = time.time() + UNLIMITED_RESTART_GRACE_SECONDS
            while time.time() < grace_deadline:
                pending_jobs, active_requests = _restart_pending_work()
                if pending_jobs == 0 and active_requests == 0:
                    break
                time.sleep(0.25)

            pending_jobs, active_requests = _restart_pending_work()
            if pending_jobs or active_requests:
                app.logger.warning(
                    "5-minute recovery forcing exit after %ss grace with pending_jobs=%s active_requests=%s",
                    UNLIMITED_RESTART_GRACE_SECONDS,
                    pending_jobs,
                    active_requests,
                )

            # Always force recovery after the bounded grace period, even if work is stuck.
            _request_full_process_exit()
            return

        except Exception:
            app.logger.exception("Unlimited restart supervisor error")
            time.sleep(1.0)


def _ensure_unlimited_restart_supervisor():
    global _RESTART_SUPERVISOR_STARTED
    if not UNLIMITED_AUTO_RESTART_ENABLED:
        return
    with _RESTART_SUPERVISOR_GUARD:
        if _RESTART_SUPERVISOR_STARTED:
            return
        _RESTART_SUPERVISOR_STARTED = True
        threading.Thread(
            target=_unlimited_restart_supervisor,
            name="unlimited-7min-restart",
            daemon=True,
        ).start()


def _restart_drain_blocks_path(path: str) -> bool:
    return (
        path.startswith("/action/")
        or path.startswith("/free/action/")
        or path == "/free/weekly-design"
        or path == "/free/permanent-crown"
        or path == "/cars/bulk-inject"
        or path == "/cars/event-inject"
        or path == "/cars/unlock-all"
        or path == "/clone-account/purchase"
        or path == "/cpm2/inject-coins"
        or path == "/cpm2/bulk-start"
    )


def _dashboard_maintenance_blocks_path(path: str) -> bool:
    """Block every route that can create, copy, or inject car data."""
    return (
        path in {
            "/free/weekly-design", "/free/permanent-crown",
            "/cars/bulk-inject", "/cars/event-inject", "/cars/unlock-all",
            "/clone-account/purchase", "/clone-account/start",
            "/bulk-account-generator/start",
        }
        or (path.startswith("/cars/catalog/") and path.endswith("/inject"))
        or (path.startswith("/shared-designs/") and path.endswith("/inject"))
        or path.endswith("/safe-file")
        or path == "/bulk-account-generator/start"
    )


def _action_maintenance_section(action: str) -> str:
    if action == "set_money": return "money"
    if action == "set_coin": return "coins"
    if action.startswith("preset_"): return "currency_presets"
    if action in {"set_player_name", "set_player_id", "set_race_wins", "set_race_loses"}:
        return "player_modifications"
    if action == "fix_account": return "account_repair"
    if action in FEATURE_ACTIONS: return "player_unlocks"
    return "player_modifications"


def _request_maintenance_section(path: str) -> Optional[str]:
    if path in {"/cpm2/inject-coins", "/cpm2/bulk-start"}:
        return "cpm2_coins"
    if path.startswith(("/action/", "/free/action/")):
        return _action_maintenance_section(path.rsplit("/", 1)[-1])
    if path == "/cars/bulk-inject":
        return "premium_car_injections"
    if path == "/cars/event-inject":
        return "event_car_injections"
    if path in {"/free/weekly-design", "/free/permanent-crown"} or (
        path.startswith("/cars/catalog/") and path.endswith("/inject")
    ):
        return "designed_car_injections"
    if path.startswith("/shared-designs/") and path.endswith("/inject"):
        return "public_car_injections"
    if path.endswith("/safe-file"):
        return "custom_car_injections"
    if _dashboard_maintenance_blocks_path(path):
        return "other_car_injections"
    if path.startswith("/shared-designs/create") or (
        path.startswith("/shared-designs/") and path.endswith(("/manage", "/delete"))
    ):
        return "public_listings"
    return None


def _is_new_tool_request(path: str) -> bool:
    section = _request_maintenance_section(path)
    # Marketplace listing creation/management remains available around the clock.
    return bool(section and section != "public_listings")


def _world_sale_car_path(path: str) -> bool:
    """World Sale pause affects car jobs only; player/currency tools stay open."""
    return (
        path in {
            "/free/weekly-design", "/free/permanent-crown", "/cars/bulk-inject",
            "/cars/event-inject", "/cars/unlock-all",
        }
        or (path.startswith("/cars/catalog/") and path.endswith("/inject"))
        or (path.startswith("/shared-designs/") and path.endswith("/inject"))
        or path.endswith("/safe-file")
    )


@app.before_request
def _start_marketplace_reconciliation():
    _ensure_marketplace_reconciliation()
    world_sale_health.ensure_monitor()


@app.before_request
def _enforce_world_sale_pause():
    if request.method != "POST" or not _world_sale_car_path(request.path):
        return None
    status = world_sale_health.get_status()
    if not status.get("paused"):
        return None
    # Reuse the active CPM login in memory for background recovery probes.
    # The blocked car request is not queued or charged.
    try:
        token_data = nuker.get_token_data(session.get("web_uid")) if session.get("web_uid") else None
        if token_data:
            world_sale_health.register_probe_credentials(
                token_data.get("email", ""), token_data.get("password", "")
            )
    except Exception:
        pass
    message = (
        "World Sale is temporarily paused because no slots have been available for over 10 minutes. "
        "Car injections will reopen automatically when slots return. Money, coins, and player modifications are still available."
    )
    if request.path.startswith(("/cars/", "/shared-designs/")) or request.accept_mimetypes.accept_json:
        return jsonify({"ok": False, "world_sale_paused": True, "message": message}), 503
    flash(message, "info")
    return redirect(url_for("free_page" if request.path.startswith("/free/") else "index"))


@app.route("/api/world-sale-status")
def world_sale_status_api():
    return jsonify({"ok": True, **world_sale_health.get_status()})


@app.before_request
def _start_request_timer():
    g.request_started_at = time.perf_counter()


@app.after_request
def _record_request_timing(response):
    started = getattr(g, "request_started_at", None)
    if started is None:
        return response
    duration_ms = (time.perf_counter() - started) * 1000.0
    response.headers["Server-Timing"] = f"app;dur={duration_ms:.1f}"
    if "/status/" in request.path or request.path == "/cars/inject-queue":
        response.headers["Cache-Control"] = "no-store"
    if duration_ms >= (SLOW_REQUEST_SECONDS * 1000.0) and not request.path.startswith(
        ("/cars/", "/clone-account/status/", "/api/live-")
    ):
        app.logger.warning(
            "Slow request method=%s path=%s status=%s duration_ms=%.1f",
            request.method,
            request.path,
            response.status_code,
            duration_ms,
        )
    return response


@app.before_request
def _enforce_dashboard_maintenance():
    if not _maintenance_active_for_request():
        return None

    if request.method != "POST":
        return None
    section = _request_maintenance_section(request.path)
    controls = _maintenance_settings()
    if section and section not in controls["enabled_sections"]:
        label = MAINTENANCE_SECTIONS.get(section, "This section")
        car_message = f"{label} is temporarily disabled for maintenance."
        if (
            request.path.startswith(("/cars/", "/shared-designs/", "/clone-account/", "/bulk-account-generator/"))
            or request.accept_mimetypes.accept_json
        ):
            return jsonify(
                {
                    "ok": False,
                    "maintenance": True,
                    "section_disabled": section,
                    "message": car_message,
                    "free_dashboard_url": url_for("free_page"),
                }
            ), 503
        flash(car_message, "info")
        return redirect(url_for("free_page"))

    return None


@app.before_request
def _enforce_hourly_paid_free_schedule():
    if request.method != "POST" or not _is_new_tool_request(request.path):
        return None
    if is_maintenance_bypass(session.get("site_user_id")):
        return None
    controls = _maintenance_settings()
    if not controls["schedule_enabled"]:
        return None
    status = _hourly_access_status()
    user_is_paid = _request_user_is_paid()
    allowed = (status["phase"] == "paid" and user_is_paid) or (
        status["phase"] == "free" and not user_is_paid
    )
    if allowed:
        return None
    minutes, seconds = divmod(status["seconds_remaining"], 60)
    message = (
        f"{status['phase_label']} tool window is active. Your {status['next_label']} window "
        f"begins in {minutes:02d}:{seconds:02d}. Jobs already running will continue safely."
    )
    if request.accept_mimetypes.accept_json or request.path.startswith(("/cars/", "/shared-designs/")):
        return jsonify({"ok": False, "schedule_blocked": True, "message": message,
                        "retry_after_seconds": status["seconds_remaining"]}), 429
    flash(message, "info")
    return redirect(url_for("dashboard" if session.get("logged_in") else "index"))


@app.before_request
def _track_restart_requests_and_drain():
    global _ACTIVE_REQUESTS
    if not UNLIMITED_AUTO_RESTART_ENABLED:
        return None
    _ensure_unlimited_restart_supervisor()

    status = _unlimited_restart_status()
    if (
        status["enabled"]
        and status["draining"]
        and request.method == "POST"
        and _restart_drain_blocks_path(request.path)
    ):
        payload = {
            "ok": False,
            "message": (
                "Unlimited Currency reset is draining active work. "
                "The site will restart momentarily; retry after it comes back online."
            ),
            "restart_draining": True,
        }
        if (
            request.accept_mimetypes.accept_json
            or request.path.startswith(("/cars/", "/clone-account/", "/free/"))
        ):
            return jsonify(payload), 503
        flash(payload["message"], "error")
        return redirect(url_for("dashboard"))

    with _ACTIVE_REQUESTS_LOCK:
        _ACTIVE_REQUESTS += 1


@app.teardown_request
def _release_restart_request_counter(_exc):
    global _ACTIVE_REQUESTS
    with _ACTIVE_REQUESTS_LOCK:
        if _ACTIVE_REQUESTS > 0:
            _ACTIVE_REQUESTS -= 1



@app.before_request
def _keep_active_login_session():
    # Once either login exists, make the shared Flask session persistent for the
    # configured idle lifetime. Flask refreshes its expiry on active requests.
    if session.get("logged_in") or session.get("site_logged_in"):
        session.permanent = True


def _stripe_secret_key() -> str:
    return os.getenv("STRIPE_SECRET_KEY", "").strip()


def _stripe_webhook_secret() -> str:
    return os.getenv("STRIPE_WEBHOOK_SECRET", "").strip()


def _stripe_currency() -> str:
    return os.getenv("TOPUP_CURRENCY", "usd").strip().lower() or "usd"


ADMIN_SECRET_PANEL_PATH = "/admin-secret-panel-x9k2v1"


def _admin_credentials_configured() -> bool:
    return bool(os.getenv("ADMIN_EMAIL", "").strip() and os.getenv("ADMIN_PASSWORD", ""))


def _admin_authenticated() -> bool:
    return bool(session.get("admin_authenticated")) or not _admin_credentials_configured()


def _require_admin(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not _admin_authenticated():
            return redirect(url_for("admin_login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def _admin_user_id(raw: str) -> str:
    """Normalize and validate admin-entered site user IDs only."""
    user_id = (raw or "").strip()
    if not user_id:
        raise ValueError("Enter a user ID.")
    if not re.fullmatch(r"[0-9a-f]{12}", user_id):
        raise ValueError("User ID must be the 12-character site account ID.")
    return user_id


def _admin_balance_amount(raw: str) -> int:
    """Parse an exact stored integer balance for the admin set-balance form."""
    value = (raw or "").strip()
    if not value:
        raise ValueError("Enter a target credit amount.")
    if not re.fullmatch(r"(?:\d+|\d{1,3}(?:,\d{3})+)", value):
        raise ValueError("Target credit amount must be a whole-number integer.")
    amount = int(value.replace(",", ""))
    if amount < 0:
        raise ValueError("Target credit amount cannot be negative.")
    if amount > accounts.MAX_STORED_BALANCE:
        raise ValueError(f"Target credit amount cannot exceed {accounts.MAX_STORED_BALANCE:,} credits.")
    return amount


def _unlimited_admin_html(
    enabled: bool,
    dashboard_maintenance: bool,
    message: str = "",
    lookup_message: str = "",
    set_message: str = "",
    lookup_user_id: str = "",
    set_user_id: str = "",
    set_amount: str = "",
    refund_candidates=None,
    refund_batches=None,
    refund_message: str = "",
    refund_include_public: bool = True,
    refund_include_failed: bool = True,
    refund_start_date: str = "",
    refund_end_date: str = "",
    refund_multiplier: str = "1",
    car_diagnostics=None,
    bypass_user_ids=None,
    bypass_message: str = "",
    maintenance_mode: str = "off",
    maintenance_sections=None,
    schedule_enabled: bool = True,
    wipe_message: str = "",
    grant_message: str = "",
    giveaway_message: str = "",
    giveaway_enabled: bool = False,
    giveaway_status: str = "none",
    giveaway_entries: int = 0,
    giveaway_prizes: int = 0,
    giveaway_batches_html: str = "<p class='help'>No giveaway history yet.</p>",
) -> str:
    state = "ON" if enabled else "OFF"
    next_value = "0" if enabled else "1"
    next_label = "Turn OFF" if enabled else "Turn ON"
    maintenance_state = "ON" if dashboard_maintenance else "OFF"
    maintenance_next_value = "0" if dashboard_maintenance else "1"
    maintenance_next_label = "Turn OFF" if dashboard_maintenance else "Turn ON"
    selected_sections = set(maintenance_sections or [])
    maintenance_checks = "".join(
        "<label><input type='checkbox' name='maintenance_section' value='{}' {}> {}</label>".format(
            html.escape(section), "checked" if section in selected_sections else "", html.escape(label)
        ) for section, label in MAINTENANCE_SECTIONS.items()
    )

    def notice(text: str, kind: str = "message") -> str:
        if not text:
            return ""
        return f"<p class='{kind}'>{html.escape(text)}</p>"

    try:
        backups = car_safety_backups.recent(10)
    except Exception:
        backups = []
    backup_rows = "".join(
        "<tr><td><a style='color:#38bdf8' href='{}/car-backup/{}.json'>{}</a></td><td>{}</td><td>{}</td><td>{}</td></tr>".format(
            ADMIN_SECRET_PANEL_PATH, html.escape(str(row.get("job_id") or "")),
            html.escape(str(row.get("kind") or "")),
            html.escape(str(row.get("email") or "")),
            int(row.get("original_car_count") or 0),
            html.escape(str(row.get("verification_state") or "")),
        ) for row in backups
    ) or "<tr><td colspan='4'>No car safety backups saved yet.</td></tr>"

    refund_candidates = list(refund_candidates or [])
    refund_batches = list(refund_batches or [])
    refund_rows = "".join(
        "<tr><td><input class='refund-user' type='checkbox' name='refund_user_id' value='{}' data-spend='{}' checked></td>"
        "<td><strong>{}</strong><br><small><code>{}</code></small></td>"
        "<td>{:,}<br><small>{} purchase(s)</small></td>"
        "<td>{:,}<br><small>{} failed job(s)</small></td>"
        "<td><strong>{:,}</strong></td><td>{:,}</td></tr>".format(
            html.escape(str(row.get("user_id") or "")), int(row.get("qualifying_spend") or 0),
            html.escape(str(row.get("email") or "")), html.escape(str(row.get("user_id") or "")),
            int(row.get("public_spend") or 0), int(row.get("public_count") or 0),
            int(row.get("failed_spend") or 0), int(row.get("failed_count") or 0),
            int(row.get("qualifying_spend") or 0), int(row.get("balance") or 0),
        ) for row in refund_candidates
    ) or "<tr><td colspan='6'>No unrefunded affected charges match these filters.</td></tr>"
    refund_batch_rows = "".join(
        "<tr><td><code>{}</code></td><td>{}×</td><td>{}</td><td>{:,}</td><td>{:,}</td><td>{}</td></tr>".format(
            html.escape(str(row.get("batch_id") or "")[:10]),
            html.escape(str(row.get("multiplier") or "")), int(row.get("user_count") or 0),
            int(row.get("total_qualifying_spend") or 0), int(row.get("total_refunded") or 0),
            html.escape(str(row.get("note") or "")),
        ) for row in refund_batches
    ) or "<tr><td colspan='6'>No refund batches yet.</td></tr>"
    refund_public_total = sum(int(row.get("public_spend") or 0) for row in refund_candidates)
    refund_failed_total = sum(int(row.get("failed_spend") or 0) for row in refund_candidates)
    refund_total = refund_public_total + refund_failed_total
    diagnostic_rows = "".join(
        "<tr><td>{}</td><td><code>{}</code></td><td>{}</td><td>{}</td><td>{}</td></tr>".format(
            html.escape(datetime.fromtimestamp(float(row.get("event_time") or 0)).strftime("%m/%d %H:%M:%S")),
            html.escape(str(row.get("job_id") or "")[:12]),
            html.escape(str(row.get("email") or row.get("user_id") or "")),
            html.escape(str(row.get("stage") or "")),
            html.escape(str(row.get("message") or "")),
        ) for row in list(car_diagnostics or [])
    ) or "<tr><td colspan='5'>No internal car recovery diagnostics saved yet.</td></tr>"
    bypass_rows = "".join(
        "<tr><td><code>{}</code></td><td>{}</td><td><form method='post' style='margin:0'>"
        "<input type='hidden' name='action' value='remove_maintenance_bypass'>"
        "<input type='hidden' name='user_id' value='{}'>"
        "<button type='submit' style='margin:0;background:#f87171;color:#450a0a'>Remove bypass</button>"
        "</form></td></tr>".format(
            html.escape(str(user_id)),
            html.escape(str((accounts.get_user(str(user_id)) or {}).get("email") or "Unknown user")),
            html.escape(str(user_id)),
        )
        for user_id in list(bypass_user_ids or [])
    ) or "<tr><td colspan='3'>No friend bypass users added.</td></tr>"

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Currency Control</title>
  <style>
    body {{ font-family: Arial, sans-serif; background:#0f172a; color:#e5e7eb; margin:0; min-height:100vh; display:grid; place-items:center; }}
    .card {{ width:min(1100px, calc(100% - 32px)); background:#111827; border:1px solid #334155; border-radius:18px; padding:28px; box-shadow:0 18px 60px rgba(0,0,0,.35); }}
    h1 {{ margin-top:0; }}
    h2 {{ margin:0 0 10px; font-size:20px; }}
    .panel {{ border:1px solid #334155; border-radius:14px; padding:18px; margin-top:18px; background:#0b1220; }}
    .state {{ display:inline-block; padding:10px 16px; border-radius:999px; font-weight:700; background:{'#064e3b' if enabled else '#7f1d1d'}; color:#fff; }}
    label {{ display:block; margin:12px 0 6px; font-weight:700; color:#cbd5e1; }}
    input[type=text], input[type=password], input[type=date], input[type=number] {{ width:100%; box-sizing:border-box; border:1px solid #475569; border-radius:10px; background:#020617; color:#e5e7eb; padding:12px; font-size:15px; }}
    input[type=range] {{ width:100%; accent-color:#38bdf8; }}
    input[type=checkbox] {{ width:18px; height:18px; accent-color:#38bdf8; }}
    button {{ margin-top:16px; width:100%; border:0; border-radius:12px; padding:14px 18px; font-size:16px; font-weight:700; cursor:pointer; background:#38bdf8; color:#082f49; }}
    .warning {{ color:#fbbf24; line-height:1.45; }}
    .message {{ color:#86efac; }}
    .error {{ color:#fca5a5; }}
    .help {{ color:#94a3b8; font-size:13px; line-height:1.45; }}
    code {{ background:#020617; padding:2px 6px; border-radius:6px; }}
    .stats {{ display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin:14px 0; }}
    .stat {{ padding:12px;border:1px solid #334155;border-radius:12px;background:#020617; }}
    .stat small {{ display:block;color:#94a3b8;margin-bottom:5px; }}
    .stat strong {{ font-size:20px;color:#38bdf8; }}
    .checks {{ display:flex;gap:18px;flex-wrap:wrap; }}
    .checks label {{ display:flex;align-items:center;gap:8px;margin:8px 0; }}
    .table-wrap {{ overflow:auto;border:1px solid #334155;border-radius:12px;margin-top:14px; }}
    table {{ width:100%;border-collapse:collapse;min-width:800px;font-size:13px; }}
    th,td {{ padding:10px;text-align:left;border-bottom:1px solid #263449;vertical-align:top; }}
    th {{ color:#94a3b8;background:#020617; }}
    .refund-preview {{ display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap;padding:14px;border:1px solid #854d0e;border-radius:12px;background:#1c1405;margin-top:14px; }}
    @media(max-width:700px) {{ .card {{padding:18px}} .stats {{grid-template-columns:repeat(2,minmax(0,1fr))}} }}
  </style>
</head>
<body>
  <main class="card">
    <h1>Hidden Currency Control</h1>
    {notice(message)}
    <section class="panel" aria-label="Unlimited Currency toggle">
      <h2>Unlimited Currency</h2>
      <p>Unlimited-currency mode is currently <span class="state">{state}</span>.</p>
      <p class="warning"><strong>Warning:</strong> this page intentionally has no login or API key. Anyone who knows this URL can toggle unlimited mode.</p>
      <form method="post">
        <input type="hidden" name="action" value="toggle_unlimited">
        <input type="hidden" name="enabled" value="{next_value}">
        <button type="submit">{next_label} unlimited mode</button>
      </form>
      <p><small>Setting is persisted in the configured shared data backend.</small></p>
      <div id="restart-timer-panel" style="margin-top:14px;padding:14px;border:1px solid #334155;border-radius:12px;background:#020617;display:{'block' if enabled else 'none'};">
        <div style="font-size:12px;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em;font-weight:700;">Process stability</div>
        <div id="restart-countdown" style="font-size:30px;font-weight:800;margin-top:5px;color:#38bdf8;">{'05:00' if UNLIMITED_AUTO_RESTART_ENABLED else 'STABLE'}</div>
        <div id="restart-countdown-state" class="help">{'Optional five-minute recovery is enabled.' if UNLIMITED_AUTO_RESTART_ENABLED else 'Forced five-minute restarts are disabled to protect active injection jobs.'}</div>
      </div>
    </section>

    <section class="panel" aria-label="Dashboard maintenance controls">
      <h2>Maintenance & Hourly Access</h2>
      <p>Maintenance mode is currently <span class="state" style="background:{'#7f1d1d' if dashboard_maintenance else '#064e3b'}">{maintenance_state}</span>.</p>
      <p class="help"><strong>Unlimited:</strong> selected sections run free. <strong>Paid Credits:</strong> selected sections run at normal credit prices. Unselected sections are disabled. Browsing, Support, Inbox, and Telegram stay available.</p>
      <form method="post">
        <input type="hidden" name="action" value="save_maintenance_controls">
        <label for="maintenance_mode">Maintenance mode</label>
        <select id="maintenance_mode" name="maintenance_mode" style="width:100%;padding:12px;border-radius:10px;background:#020617;color:#e5e7eb;border:1px solid #475569">
          <option value="off" {'selected' if maintenance_mode == 'off' else ''}>Off</option>
          <option value="unlimited" {'selected' if maintenance_mode == 'unlimited' else ''}>Unlimited maintenance</option>
          <option value="paid" {'selected' if maintenance_mode == 'paid' else ''}>Paid credits maintenance</option>
        </select>
        <div class="checks" style="margin-top:12px">{maintenance_checks}</div>
        <label><input type="checkbox" name="schedule_enabled" value="1" {'checked' if schedule_enabled else ''}> Enforce hourly Paid/Free schedule</label>
        <button type="submit">Save maintenance controls</button>
      </form>
      <p class="help"><strong>Eastern Time schedule:</strong> Paid Users :00–:39 (40 minutes/hour, 16 hours/day). Free Users :40–:59 (20 minutes/hour, 8 hours/day). Running jobs may finish after a window changes.</p>
    </section>

    <section class="panel" aria-label="Wipe free economy">
      <h2>Wipe Free Economy</h2>
      <p class="warning"><strong>Protected wipe:</strong> only never-paid site accounts are reset to 0 credits. Anyone with a fulfilled Stripe payment is excluded permanently.</p>
      {notice(wipe_message, 'error' if wipe_message.startswith(('Type', 'Unable')) else 'message')}
      <form method="post" onsubmit="return confirm('Reset every never-paid account to 0 credits? Paying customers are protected.');">
        <input type="hidden" name="action" value="wipe_free_economy">
        <label for="wipe_confirmation">Type WIPE FREE ECONOMY</label>
        <input id="wipe_confirmation" type="text" name="wipe_confirmation" autocomplete="off">
        <button type="submit" style="background:#f87171;color:#450a0a">Wipe free credits</button>
      </form>
    </section>

    <section class="panel" aria-label="Add credits by account tier">
      <h2>Add Credits to Free or Paid Users</h2>
      <p class="help">These amounts are added on top of every matching user's existing balance. Nothing is replaced. Paid users are identified by fulfilled Stripe payment history.</p>
      {notice(grant_message, 'error' if grant_message.startswith(('Enter', 'Unable', 'Grant')) else 'message')}
      <form method="post" onsubmit="return confirm('Add these credits to every matching account balance?');">
        <input type="hidden" name="action" value="grant_tier_credits">
        <label for="free_credit_amount">Add to every Free User</label>
        <input id="free_credit_amount" type="number" name="free_credit_amount" min="0" max="{accounts.MAX_STORED_BALANCE}" step="1" value="0">
        <label for="paid_credit_amount">Add to every Paid User</label>
        <input id="paid_credit_amount" type="number" name="paid_credit_amount" min="0" max="{accounts.MAX_STORED_BALANCE}" step="1" value="0">
        <button type="submit">Add credits to selected tiers</button>
      </form>
      <p class="help">Leave either tier at 0 to skip it. Existing balances and prior purchases remain intact.</p>
    </section>

    <section class="panel" aria-label="Friend maintenance bypass">
      <h2>Friend Maintenance Bypass</h2>
      <p class="help">Add a 12-character site User ID. That signed-in site account bypasses maintenance completely and receives the normal site, car injections, and normal pricing. Everyone else remains restricted.</p>
      {notice(bypass_message, 'error' if bypass_message.startswith(('Invalid', 'Enter', 'User')) else 'message')}
      <form method="post">
        <input type="hidden" name="action" value="add_maintenance_bypass">
        <label for="bypass_user_id">Site User ID</label>
        <input id="bypass_user_id" type="text" name="user_id" autocomplete="off" placeholder="12-character user ID">
        <button type="submit">Add friend bypass</button>
      </form>
      <div class="table-wrap"><table><thead><tr><th>User ID</th><th>Email</th><th>Action</th></tr></thead><tbody>{bypass_rows}</tbody></table></div>
    </section>

    <section class="panel" aria-label="Balance lookup">
      <h2>Balance lookup</h2>
      <p class="help">Enter a site account user ID only. This shows the stored/real balance, not the Unlimited Currency display override.</p>
      {notice(lookup_message, 'error' if lookup_message.startswith(('Invalid', 'Enter', 'User')) else 'message')}
      <form method="post">
        <input type="hidden" name="action" value="lookup_balance">
        <label for="lookup_user_id">User ID</label>
        <input id="lookup_user_id" type="text" name="user_id" value="{html.escape(lookup_user_id)}" autocomplete="off" inputmode="text" placeholder="12-character user ID">
        <button type="submit">Look up stored balance</button>
      </form>
    </section>

    <section class="panel" aria-label="Set custom balance">
      <h2>Set custom balance</h2>
      <p class="help">Enter a site account user ID only and the exact target integer credit amount. This replaces the stored balance exactly; it is not a separate delta-adjustment tool. Allowed range: 0 to {accounts.MAX_STORED_BALANCE:,} credits.</p>
      {notice(set_message, 'error' if set_message.startswith(('Invalid', 'Enter', 'User', 'Target')) else 'message')}
      <form method="post">
        <input type="hidden" name="action" value="set_balance">
        <label for="set_user_id">User ID</label>
        <input id="set_user_id" type="text" name="user_id" value="{html.escape(set_user_id)}" autocomplete="off" inputmode="text" placeholder="12-character user ID">
        <label for="target_balance">Target credit amount</label>
        <input id="target_balance" type="text" name="target_balance" value="{html.escape(set_amount)}" autocomplete="off" inputmode="numeric" placeholder="0">
        <button type="submit">Set exact stored balance</button>
      </form>
    </section>

    <section class="panel" aria-label="Reset site password">
      <h2>Reset site password</h2>
      <p class="help">Set a new password for a site account. The old password cannot be recovered.</p>
      <form method="post">
        <input type="hidden" name="action" value="reset_password">
        <label for="reset_email">Account email</label>
        <input id="reset_email" type="text" name="email" autocomplete="off" placeholder="name@example.com">
        <label for="reset_password">New password</label>
        <input id="reset_password" type="password" name="password" autocomplete="new-password" placeholder="New password">
        <button type="submit">Set new password</button>
      </form>
    </section>

    <section class="panel" aria-label="Broadcast inbox message">
      <h2>Broadcast to every user inbox</h2>
      <p class="help">Send one persistent PostgreSQL message to every site account. It appears in Inbox and activates each user's red unread notification badge until opened.</p>
      <form method="post" onsubmit="return confirm('Send this inbox notification to every site user?');">
        <input type="hidden" name="action" value="broadcast_inbox">
        <label for="broadcast_title">Message title</label>
        <input id="broadcast_title" type="text" name="broadcast_title" maxlength="120" required placeholder="Important site update">
        <label for="broadcast_body">Message</label>
        <textarea id="broadcast_body" name="broadcast_body" maxlength="4000" required rows="6" style="width:100%;box-sizing:border-box;border:1px solid #475569;border-radius:10px;background:#020617;color:#e5e7eb;padding:12px;font-size:15px;resize:vertical" placeholder="Write the message users should receive…"></textarea>
        <button type="submit">Send broadcast notification</button>
      </form>
    </section>

    <section class="panel" aria-label="Giveaway controls">
      <h2>Giveaway!</h2>
      <p class="help">Toggle the public <strong>Giveaway!</strong> page, set up prize pools (custom credit amounts + CPM1/CPM2 account lists), open queueing, then start the spinner. The winner receives the prize in their Inbox automatically. The last winner stays visible until you create a new setup.</p>
      {notice(giveaway_message, 'error' if giveaway_message.startswith(('Unable', 'Add', 'Create', 'Open', 'No ')) else 'message')}
      <p class="help">Page is currently: <strong>{'ENABLED' if giveaway_enabled else 'DISABLED'}</strong>
        · Current status: <strong>{html.escape(str(giveaway_status))}</strong>
        · Entrants: <strong>{int(giveaway_entries)}</strong>
        · Prizes left: <strong>{int(giveaway_prizes)}</strong>
      </p>
      <form method="post" style="margin-bottom:14px">
        <input type="hidden" name="action" value="giveaway_toggle">
        <input type="hidden" name="giveaway_enabled" value="{'0' if giveaway_enabled else '1'}">
        <button type="submit">{'Disable Giveaway page' if giveaway_enabled else 'Enable Giveaway page'}</button>
      </form>
      <form method="post" style="margin-bottom:14px">
        <input type="hidden" name="action" value="giveaway_setup">
        <label for="gw_title">Title</label>
        <input id="gw_title" type="text" name="title" maxlength="80" value="Giveaway!" placeholder="Giveaway!">
        <label for="gw_credits">Custom credit amounts (comma-separated, each becomes a prize slot)</label>
        <input id="gw_credits" type="text" name="credit_amounts" placeholder="100,250,500,1000">
        <label for="gw_cpm1">CPM1 accounts (one email:password per line — each line is one prize)</label>
        <textarea id="gw_cpm1" name="cpm1_accounts" rows="5" style="width:100%;box-sizing:border-box;border:1px solid #475569;border-radius:10px;background:#020617;color:#e5e7eb;padding:12px;font-size:14px;resize:vertical;font-family:ui-monospace,monospace" placeholder="user1@mail.com:pass1&#10;user2@mail.com:pass2"></textarea>
        <label for="gw_cpm2">CPM2 accounts (one email:password per line — each line is one prize)</label>
        <textarea id="gw_cpm2" name="cpm2_accounts" rows="5" style="width:100%;box-sizing:border-box;border:1px solid #475569;border-radius:10px;background:#020617;color:#e5e7eb;padding:12px;font-size:14px;resize:vertical;font-family:ui-monospace,monospace" placeholder="cpm2a@mail.com:pass&#10;cpm2b@mail.com:pass"></textarea>
        <button type="submit">Save giveaway setup</button>
      </form>
      <div style="display:flex;flex-wrap:wrap;gap:10px">
        <form method="post" onsubmit="return confirm('Open queueing so users can join?');">
          <input type="hidden" name="action" value="giveaway_queue">
          <button type="submit">Start queueing</button>
        </form>
        <form method="post" onsubmit="return confirm('Spin now and award a prize to one random entrant?');">
          <input type="hidden" name="action" value="giveaway_spin">
          <button type="submit" style="background:#f4c95d;color:#1a1200">Start spinner</button>
        </form>
      </div>
      <p class="help" style="margin-top:12px">Public page: <code>/giveaway</code></p>
      <hr style="border:0;border-top:1px solid #334155;margin:18px 0">
      <h3 style="margin:0 0 8px">Resend prizes (old giveaways)</h3>
      <p class="help">Fast-fix winners who never got an Inbox message. <strong>Resend all</strong> re-delivers every stored prize for that giveaway (credits + account lines) via Inbox.</p>
      {giveaway_batches_html}
      <hr style="border:0;border-top:1px solid #334155;margin:18px 0">
      <h3 style="margin:0 0 8px">Manual inbox / single winner</h3>
      <p class="help">Lookup username → site user ID, resend one winner, or send a custom Inbox message.</p>
      <form method="post" style="margin-bottom:12px">
        <input type="hidden" name="action" value="giveaway_lookup">
        <label for="gw_lookup">Lookup username or site user ID</label>
        <input id="gw_lookup" type="text" name="username_or_id" placeholder="justtnnr  or  site-user-id" required>
        <button type="submit">Resolve to site user ID</button>
      </form>
      <form method="post" style="margin-bottom:12px">
        <input type="hidden" name="action" value="giveaway_resend_prize">
        <label for="gw_resend">Re-send stored prize to winner (username or site user ID)</label>
        <input id="gw_resend" type="text" name="username_or_id" placeholder="winner username" required>
        <button type="submit">Re-send prize via Inbox</button>
      </form>
      <form method="post">
        <input type="hidden" name="action" value="giveaway_manual_inbox">
        <label for="gw_manual_user">Username or site user ID</label>
        <input id="gw_manual_user" type="text" name="username_or_id" required placeholder="username or site user id">
        <label for="gw_manual_title">Message title</label>
        <input id="gw_manual_title" type="text" name="title" maxlength="120" required value="🎁 Giveaway prize!">
        <label for="gw_manual_body">Message body</label>
        <textarea id="gw_manual_body" name="body" maxlength="4000" required rows="5" style="width:100%;box-sizing:border-box;border:1px solid #475569;border-radius:10px;background:#020617;color:#e5e7eb;padding:12px;font-size:14px;resize:vertical" placeholder="Prize details for the user…"></textarea>
        <button type="submit">Send Inbox message</button>
      </form>
    </section>

    <section class="panel" aria-label="Car safety backups">
      <h2>Car safety backups</h2>
      <p class="help">The original full garage export is retained before each World Sale car task. This list shows the latest saved protection checks.</p>
      <div style="overflow:auto"><table style="width:100%;border-collapse:collapse;font-size:13px"><thead><tr><th>Task</th><th>Account</th><th>Before</th><th>Check</th></tr></thead><tbody>{backup_rows}</tbody></table></div>
    </section>

    <section id="affected-refunds" class="panel" aria-label="Affected user refund controls">
      <h2>Affected User Refunds</h2>
      <p class="help">This scans the full PostgreSQL history, including legacy public-car purchases and paid car jobs with Failed, Manual Review, protection-failed backup, or internal recovery records. Already-refunded charges and ordinary unaffected users are excluded.</p>
      {notice(refund_message, 'error' if refund_message.startswith(('Unable', 'Invalid', 'Select', 'No ')) else 'message')}

      <form method="post">
        <input type="hidden" name="action" value="filter_affected_refunds">
        <div class="checks">
          <label><input type="checkbox" name="refund_include_public" value="1" {'checked' if refund_include_public else ''}> Public car purchases</label>
          <label><input type="checkbox" name="refund_include_failed" value="1" {'checked' if refund_include_failed else ''}> Failed car jobs</label>
        </div>
        <div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px">
          <label>Incident start date<input type="date" name="refund_start_date" value="{html.escape(refund_start_date)}"></label>
          <label>Incident end date<input type="date" name="refund_end_date" value="{html.escape(refund_end_date)}"></label>
        </div>
        <button type="submit">Recalculate affected users</button>
      </form>

      <div class="stats">
        <div class="stat"><small>Affected users</small><strong>{len(refund_candidates):,}</strong></div>
        <div class="stat"><small>Public-car spend</small><strong>{refund_public_total:,}</strong></div>
        <div class="stat"><small>Failed-job spend</small><strong>{refund_failed_total:,}</strong></div>
        <div class="stat"><small>Total qualifying</small><strong>{refund_total:,}</strong></div>
      </div>

      <form id="affected-refund-form" method="post" onsubmit="return confirm('Apply this multiplier refund to every checked affected user? This is permanent and audited.');">
        <input type="hidden" name="action" value="apply_affected_refund">
        {'<input type="hidden" name="refund_include_public" value="1">' if refund_include_public else ''}
        {'<input type="hidden" name="refund_include_failed" value="1">' if refund_include_failed else ''}
        <input type="hidden" name="refund_start_date" value="{html.escape(refund_start_date)}">
        <input type="hidden" name="refund_end_date" value="{html.escape(refund_end_date)}">
        <div style="display:grid;grid-template-columns:minmax(0,1fr) 180px;gap:14px;align-items:end">
          <label>Refund multiplier <strong id="refund-rate-output" style="float:right;color:#38bdf8">{html.escape(refund_multiplier)}×</strong>
            <input id="refund-rate" type="range" name="refund_multiplier" min="0.01" max="10" step="0.01" value="{html.escape(refund_multiplier)}">
            <small class="help">0.5× refunds half · 1× refunds all · 10× refunds ten times</small>
          </label>
          <label>Exact multiplier<input id="refund-rate-number" type="number" min="0.01" max="10" step="0.01" value="{html.escape(refund_multiplier)}"></label>
        </div>
        <label>Audit reason<input type="text" name="refund_note" maxlength="1000" value="Car injection issue compensation"></label>
        <div class="refund-preview"><span>Selected qualifying spend: <strong id="refund-selected-spend">{refund_total:,} credits</strong></span><span>Proposed refund: <strong id="refund-proposed">{refund_total:,} credits</strong></span></div>
        <div class="table-wrap"><table><thead><tr><th><input id="refund-select-all" type="checkbox" checked></th><th>User</th><th>Public cars</th><th>Failed jobs</th><th>Qualifying</th><th>Balance</th></tr></thead><tbody>{refund_rows}</tbody></table></div>
        <button type="submit" {'disabled' if not refund_candidates else ''}>Apply refund to checked affected users</button>
      </form>

      <h2 style="margin-top:24px">Refund batch history</h2>
      <p class="help">Each qualifying charge can be claimed by only one batch, preventing accidental duplicate refunds.</p>
      <div class="table-wrap"><table><thead><tr><th>Batch</th><th>Rate</th><th>Users</th><th>Qualifying</th><th>Refunded</th><th>Reason</th></tr></thead><tbody>{refund_batch_rows}</tbody></table></div>
    </section>

    <section class="panel" aria-label="Admin tools">
      <h2>Internal car recovery logs</h2>
      <p class="help">Detailed verification, retry, and worker errors are visible here only. Customers receive the simplified finishing message.</p>
      <div class="table-wrap"><table><thead><tr><th>Time</th><th>Job</th><th>User</th><th>Stage</th><th>Internal detail</th></tr></thead><tbody>{diagnostic_rows}</tbody></table></div>
    </section>

    <section class="panel" aria-label="Admin tools">
      <h2>Admin tools</h2>
      <p class="help">Support conversations are stored in PostgreSQL and can be closed, reopened, or archived.</p>
      <p><a style="color:#38bdf8;font-weight:700" href="{ADMIN_SECRET_PANEL_PATH}/support">Support Desk — Free, Paid &amp; World Sale queues</a></p>
      <p><a style="color:#38bdf8;font-weight:700" href="{ADMIN_SECRET_PANEL_PATH}/shared-designs">World Sale Support — listings, reports &amp; moderation</a></p>
      <p><a style="color:#a78bfa;font-weight:700" href="{ADMIN_SECRET_PANEL_PATH}/king-account-generator">Open King Account Generator</a></p>
      <p><a style="color:#f4c95d;font-weight:700" href="#affected-refunds">Affected User Refunds (on this page)</a></p>
      <p><a style="color:#94a3b8" href="{ADMIN_SECRET_PANEL_PATH}/logout">Sign out of admin</a></p>
    </section>
  </main>

<script>
(() => {{
  const panel = document.getElementById('restart-timer-panel');
  const countdown = document.getElementById('restart-countdown');
  const state = document.getElementById('restart-countdown-state');
  if (!panel || !countdown || !state) return;

  const fmt = (seconds) => {{
    seconds = Math.max(0, Number(seconds || 0));
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${{String(m).padStart(2, '0')}}:${{String(s).padStart(2, '0')}}`;
  }};

  async function updateRestartTimer() {{
    try {{
      const response = await fetch('/api/unlimited-restart-status', {{
        headers: {{'Accept': 'application/json'}},
        cache: 'no-store'
      }});
      const data = await response.json();
      if (!data.enabled) {{
        panel.style.display = 'none';
        return;
      }}
      panel.style.display = 'block';
      if (!data.auto_restart_enabled) {{
        countdown.textContent = 'STABLE';
        state.textContent = 'Forced five-minute restarts are disabled to protect active injection jobs.';
      }} else if (data.draining) {{
        countdown.textContent = 'RESETTING…';
        state.textContent = 'Restarting now - active work has up to ' + (data.grace_seconds || 15) + 's to finish before forced recovery. Keep this page open.';
      }} else if (data.warning) {{
        countdown.textContent = fmt(data.seconds_remaining);
        state.textContent = 'The website will be restarting soon, please understand this is a function to keep the website running while unlimited currency is available to everybody!';
      }} else {{
        countdown.textContent = fmt(data.seconds_remaining);
        state.textContent = 'Unlimited Currency is active. Keep this page open during tasks; the service automatically recovers every 5 minutes.';
      }}
    }} catch (_) {{}}
  }}

  updateRestartTimer();
  window.setInterval(() => {{
    if (!document.hidden) updateRestartTimer();
  }}, 15000);
}})();
</script>

<script>
(() => {{
  const slider = document.getElementById('refund-rate');
  const number = document.getElementById('refund-rate-number');
  const output = document.getElementById('refund-rate-output');
  const selectAll = document.getElementById('refund-select-all');
  const checks = [...document.querySelectorAll('.refund-user')];
  const selected = document.getElementById('refund-selected-spend');
  const proposed = document.getElementById('refund-proposed');
  const update = () => {{
    const rate = Math.max(.01, Math.min(10, Number(slider?.value || 1)));
    if (number) number.value = rate;
    if (output) output.textContent = rate + '×';
    const spend = checks.filter(item => item.checked).reduce((sum,item) => sum + Number(item.dataset.spend || 0), 0);
    if (selected) selected.textContent = Math.round(spend).toLocaleString() + ' credits';
    if (proposed) proposed.textContent = Math.round(spend * rate).toLocaleString() + ' credits';
    if (selectAll) selectAll.checked = checks.length > 0 && checks.every(item => item.checked);
  }};
  slider?.addEventListener('input', update);
  number?.addEventListener('input', () => {{ slider.value = Math.max(.01, Math.min(10, Number(number.value || 1))); update(); }});
  checks.forEach(item => item.addEventListener('change', update));
  selectAll?.addEventListener('change', () => {{ checks.forEach(item => item.checked = selectAll.checked); update(); }});
  update();
}})();
</script>

</body>
</html>"""

def _external_app_url(endpoint: str, **values) -> str:
    """Build an external URL, optionally pinned to APP_BASE_URL for Railway."""
    base_url = os.getenv("APP_BASE_URL", "").strip().rstrip("/")
    if base_url:
        return f"{base_url}{url_for(endpoint, **values)}"
    return url_for(endpoint, _external=True, **values)


def _stripe_ready_for_checkout() -> bool:
    return bool(stripe and _stripe_secret_key())


nuker = CPMNuker()

SHARED_INJECTION_MODE = distributed_mode_enabled()
SHARED_JOB_STORE = get_job_store() if SHARED_INJECTION_MODE else None
CAR_INJECTION_JOBS: Dict[str, Dict[str, Any]] = {}
CAR_INJECTION_LOCK = threading.Lock()
CAR_ENQUEUE_LOCK = threading.Lock()
LIVE_VIEWERS: Dict[str, float] = {}
LIVE_VIEWERS_LOCK = threading.Lock()
LIVE_VIEWER_TTL_SECONDS = int(os.getenv("LIVE_VIEWER_TTL_SECONDS", "120"))
MAX_CONCURRENT_INJECTIONS = max(
    1, min(4, int(os.getenv("MAX_CONCURRENT_INJECTIONS", "1")))
)
MAX_QUEUED_INJECTIONS = max(
    MAX_CONCURRENT_INJECTIONS,
    min(100, int(os.getenv("MAX_QUEUED_INJECTIONS", "40"))),
)
MAX_JOB_EVENTS = max(200, min(2000, int(os.getenv("MAX_JOB_EVENTS", "600"))))
CAR_INJECTION_WORKERS = MAX_CONCURRENT_INJECTIONS
CAR_INJECTION_EXECUTOR = None if SHARED_INJECTION_MODE else ThreadPoolExecutor(
    max_workers=CAR_INJECTION_WORKERS,
    thread_name_prefix="car-inject",
)
MAX_CONCURRENT_ACCOUNT_ACTIONS = max(
    1, min(8, int(os.getenv("MAX_CONCURRENT_ACCOUNT_ACTIONS", "4")))
)
ACCOUNT_ACTION_SEMAPHORE = threading.BoundedSemaphore(MAX_CONCURRENT_ACCOUNT_ACTIONS)
INJECTION_PROMOTION_INTERVAL_SECONDS = max(0.1, float(os.getenv("INJECTION_PROMOTION_INTERVAL_SECONDS", "0.75")))
_LAST_INJECTION_PROMOTION_AT = 0.0
_ASYNC_LOCAL = threading.local()
_ASYNC_LOOP_LOCK = threading.Lock()
_ASYNC_LOOPS = []


def _bounded_account_action(fn):
    """Reject excess modifier work quickly so status/login threads stay free."""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not ACCOUNT_ACTION_SEMAPHORE.acquire(blocking=False):
            message = "The site is handling several account actions. Please retry in a few seconds."
            if request.accept_mimetypes.accept_json and not request.accept_mimetypes.accept_html:
                return jsonify({
                    "ok": False,
                    "message": message,
                    "retry_after_seconds": 3,
                }), 429, {"Retry-After": "3"}
            flash(message, "error")
            if request.path == "/login":
                destination = "index"
            elif request.path.startswith("/free/"):
                destination = "free_page"
            else:
                destination = "dashboard"
            return redirect(url_for(destination))
        try:
            return fn(*args, **kwargs)
        finally:
            ACCOUNT_ACTION_SEMAPHORE.release()

    return wrapper

FEATURE_ACTIONS = {
    "unlock_w16": ("W16 Engine", nuker.unlock_w16),
    "unlock_horns": ("Horns", nuker.unlock_horns),
    "disable_damage": ("No Damage", nuker.disable_damage),
    "unlimited_fuel": ("Unlimited Fuel", nuker.unlimited_fuel),
    "unlock_smoke": ("Smoke", nuker.unlock_smoke),
    "unlock_animations": ("Animations", nuker.unlock_animations),
    "unlock_wheels": ("Wheels", nuker.unlock_wheels),
    "unlock_houses": ("Houses", nuker.unlock_houses),
    "complete_levels": ("Complete All Levels", nuker.complete_all_levels),
    "set_rank": ("Max Rank", nuker.set_rank),
    "unlock_all_features": ("Unlock All Features", nuker.unlock_all_features),
}

MAINTENANCE_FREE_DASHBOARD_ACTIONS = {
    "set_money", "set_coin", "set_player_name", "set_player_id",
    "set_race_wins", "set_race_loses", "fix_account",
    "preset_50m_30k", "preset_50m_50k", "preset_50m_100k", "preset_50m_500k",
    *FEATURE_ACTIONS.keys(),
}

# Set this to a non-empty string to protect the /backlog admin view.
# When set, visitors must supply ?key=... matching this value.
BACKLOG_ADMIN_KEY = os.getenv("BACKLOG_ADMIN_KEY", "")


def get_web_uid() -> int:
    if "web_uid" not in session:
        session["web_uid"] = int(str(uuid.uuid4().int)[:12])
        session["email"] = None
    return session["web_uid"]


def get_email() -> str:
    return session.get("email") or "Not logged in"

def _site_user_id():
    return session.get("site_user_id")


def _require_site_user():
    uid = _site_user_id()
    if not uid:
        return None
    return accounts.get_user(uid)


def _request_managed_alt_id():
    """Read optional manual alt selection from JSON body, form, or query."""
    alt_id = ""
    if request.is_json:
        body = request.get_json(silent=True) or {}
        alt_id = str(body.get("managed_alt_id") or body.get("alt_id") or "")
    if not alt_id:
        alt_id = str(request.form.get("managed_alt_id") or request.form.get("alt_id") or "")
    if not alt_id:
        alt_id = str(request.args.get("managed_alt_id") or request.args.get("alt_id") or "")
    return alt_id.strip() or None


def _resolve_managed_car_alt(*, for_recovery: bool = False, account_id: str = None):
    """Car purchases always use a managed alt (site account only — no game login)."""
    user = _require_site_user()
    if not user:
        return None, (
            jsonify({
                "ok": False,
                "message": "Sign in to your site account to use car tools.",
                "need_site_login": True,
            }),
            401,
        )
    if not user_cpm_alts.preference_ready(user["user_id"]):
        return None, (
            jsonify({
                "ok": False,
                "need_setup": True,
                "setup_url": url_for("my_cpm_accounts_page"),
                "message": "Claim your alt email prefix and password on My CPM Accounts before using car tools.",
            }),
            400,
        )
    require_under = user_cpm_alts.RECOVERY_MAX_TARGET_CARS if for_recovery else None
    chosen = account_id if account_id is not None else _request_managed_alt_id()
    try:
        resolved = run_async(
            user_cpm_alts.resolve_active_alt_for_cars(
                user["user_id"],
                require_under_cars=require_under,
                account_id=chosen,
            )
        )
    except Exception as exc:
        app.logger.exception("Managed alt resolve failed")
        return None, (jsonify({"ok": False, "message": f"Could not prepare a managed alternate account: {exc}"}), 500)
    if not resolved.get("ok"):
        payload = {
            "ok": False,
            "message": resolved.get("message") or "Managed alternate unavailable.",
        }
        if resolved.get("need_setup"):
            payload["need_setup"] = True
            payload["setup_url"] = url_for("my_cpm_accounts_page")
            payload["message"] = (
                resolved.get("message")
                or "Choose an email prefix and password on My CPM Accounts before using car tools."
            )
        return None, (jsonify(payload), 400)
    if for_recovery and int(resolved.get("car_count") or 0) > user_cpm_alts.RECOVERY_MAX_TARGET_CARS:
        return None, (
            jsonify({
                "ok": False,
                "message": (
                    f"Recovery declined: the managed alternate already has {resolved.get('car_count')} cars "
                    f"(limit is {user_cpm_alts.RECOVERY_MAX_TARGET_CARS}). Try again to provision a fresh empty alternate."
                ),
            }),
            400,
        )
    alerts = list(resolved.get("alerts") or [])
    if resolved.get("message") and resolved.get("message") not in alerts:
        alerts.append(str(resolved.get("message")))
    return {
        "site_user": user,
        "email": resolved["email"],
        "password": resolved["password"],
        "account_id": resolved["account_id"],
        "car_count": int(resolved.get("car_count") or 0),
        "created": bool(resolved.get("created")),
        "message": " ".join(alerts) if alerts else (resolved.get("message") or ""),
        "alerts": alerts,
    }, None



def _display_site_user(user=None):
    """Return a public site-user dict with display-only balance attached."""
    if user is None:
        user = _require_site_user()
    return accounts.with_display_balance(user)


def _serialize_balance_response(user):
    """Serialize the user-facing balance API through the shared display helper."""
    display_user = _display_site_user(user)
    if not display_user:
        return {"ok": False, "balance": 0, "logged_in": False}
    return {
        "ok": True,
        "logged_in": True,
        "user_id": display_user["user_id"],
        "balance": display_user["display_balance"],
        "email": display_user["email"],
        "unlimited_currency": accounts.is_unlimited_currency(),
    }


def _charge_or_reject(action: str, amount=None):
    """Charge site balance for a paid action. Returns (ok, payload_or_redirect)."""
    user = _require_site_user()
    if not user:
        return False, {"ok": False, "message": "Create a site account and sign in to use paid tools.", "need_site_login": True}
    result = accounts.charge(user["user_id"], action, amount=amount)
    if not result.get("ok"):
        return False, result
    return True, result



def _thread_event_loop():
    loop = getattr(_ASYNC_LOCAL, "loop", None)
    if loop is None or loop.is_closed():
        loop = asyncio.new_event_loop()
        _ASYNC_LOCAL.loop = loop
        asyncio.set_event_loop(loop)
        with _ASYNC_LOOP_LOCK:
            _ASYNC_LOOPS.append(loop)
    return loop


def run_async(coro):
    try:
        loop = _thread_event_loop()
        return loop.run_until_complete(coro)
    except Exception as exc:
        app.logger.exception("Async action failed")
        return {"ok": False, "message": str(exc)}


def _shutdown_infrastructure():
    # Close persistent aiohttp clients before stopping their owning loops.
    with _ASYNC_LOOP_LOCK:
        loops = list(_ASYNC_LOOPS)
        _ASYNC_LOOPS.clear()
    for loop in loops:
        if loop.is_closed():
            continue
        try:
            loop.run_until_complete(nuker.close_current_loop_network_client())
            loop.run_until_complete(close_current_injection_http_session())
            loop.run_until_complete(loop.shutdown_asyncgens())
        except Exception:
            app.logger.debug("Ignoring async shutdown failure", exc_info=True)
        finally:
            loop.close()
    if CAR_INJECTION_EXECUTOR is not None:
        CAR_INJECTION_EXECUTOR.shutdown(wait=False, cancel_futures=False)
    cpm2_coin_farm.shutdown()


atexit.register(_shutdown_infrastructure)


def parse_int_field(name: str, default: int = 0) -> int:
    raw = str(request.form.get(name, default)).replace(",", "").replace(" ", "").strip()
    return int(raw)


def action_result(ok: bool, message: str = "") -> Dict[str, Any]:
    return {"ok": ok, "message": message}


def flash_result(action_name: str, result: Dict[str, Any]):
    if result.get("ok"):
        detail = result.get("message")
        flash(f"✅ {action_name} completed successfully" + (f": {detail}" if detail and detail != "OK" else "!"), "success")
    else:
        flash(f"❌ {action_name} failed: {result.get('message', 'Unknown error')}", "error")




@app.route(ADMIN_SECRET_PANEL_PATH + "/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        supplied_email = str(request.form.get("email", "")).strip().lower()
        supplied_password = str(request.form.get("password", ""))
        expected_email = os.getenv("ADMIN_EMAIL", "").strip().lower()
        expected_password = os.getenv("ADMIN_PASSWORD", "")
        if (expected_email and expected_password
                and hmac.compare_digest(supplied_email, expected_email)
                and hmac.compare_digest(supplied_password, expected_password)):
            session["admin_authenticated"] = True
            session.permanent = True
            return redirect(request.args.get("next") or ADMIN_SECRET_PANEL_PATH)
        flash("Invalid admin email or password.", "error")
    return render_template("admin_login.html")


@app.route(ADMIN_SECRET_PANEL_PATH + "/logout")
def admin_logout():
    session.pop("admin_authenticated", None)
    return redirect(url_for("admin_login"))


@app.route(ADMIN_SECRET_PANEL_PATH, methods=["GET", "POST"])
@_require_admin
def admin_secret_panel_x9k2v1():
    """Hidden URL-only controls for unlimited mode and exact stored balances."""
    message = ""
    lookup_message = ""
    set_message = ""
    lookup_user_id = ""
    set_user_id = ""
    set_amount = ""
    refund_message = ""
    refund_include_public = True
    refund_include_failed = True
    refund_start_date = ""
    refund_end_date = ""
    refund_multiplier = "1"
    refund_start_at = refund_end_at = None
    bypass_message = ""
    wipe_message = ""
    grant_message = ""
    giveaway_message = ""
    if request.method == "POST":
        action = str(request.form.get("action", "")).strip().lower()
        if action in {"filter_affected_refunds", "apply_affected_refund"}:
            refund_include_public = request.form.get("refund_include_public") == "1"
            refund_include_failed = request.form.get("refund_include_failed") == "1"
            refund_start_date = str(request.form.get("refund_start_date", "")).strip()
            refund_end_date = str(request.form.get("refund_end_date", "")).strip()
            refund_multiplier = str(request.form.get("refund_multiplier", "1")).strip() or "1"
            try:
                refund_start_at = _admin_refund_date(refund_start_date)
                refund_end_at = _admin_refund_date(refund_end_date, end_of_day=True)
                if refund_start_at is not None and refund_end_at is not None and refund_start_at >= refund_end_at:
                    raise ValueError("End date must be on or after the start date.")
            except ValueError as exc:
                refund_message = f"Invalid refund date range: {exc}"
                refund_start_at = refund_end_at = None
        # Preserve the original toggle behavior for existing callers/tests that
        # only post the `enabled` field.
        if action in {"", "toggle_unlimited"} and "enabled" in request.form:
            enabled_raw = str(request.form.get("enabled", "")).strip().lower()
            enabled = enabled_raw in {"1", "true", "on", "yes"}
            settings = set_unlimited_currency(enabled)
            settings = _schedule_unlimited_restart(bool(settings.get("unlimited_currency")))
            _ensure_unlimited_restart_supervisor()
            if settings.get("unlimited_currency"):
                message = "Unlimited-currency mode saved as ON. Automatic Railway reset armed for 5 minutes."
            else:
                message = "Unlimited-currency mode saved as OFF. Automatic Railway reset timer cancelled."
        elif action == "toggle_dashboard_maintenance":
            enabled_raw = str(request.form.get("enabled", "")).strip().lower()
            maintenance_enabled = enabled_raw in {"1", "true", "on", "yes"}
            settings = set_dashboard_maintenance(maintenance_enabled)
            if settings.get("dashboard_maintenance"):
                message = "Maintenance is ON. Car injections are disabled and all non-car dashboard tools are free. Public Car listing creation remains available."
            else:
                message = "Maintenance mode is OFF. The full dashboard is available again."
        elif action == "save_maintenance_controls":
            try:
                saved = set_maintenance_controls(
                    request.form.get("maintenance_mode", "off"),
                    request.form.getlist("maintenance_section"),
                    request.form.get("schedule_enabled") == "1",
                )
                mode_label = str(saved.get("maintenance_mode", "off")).replace("_", " ").title()
                message = f"Maintenance controls saved. Mode: {mode_label}."
            except ValueError as exc:
                message = f"Invalid maintenance controls: {exc}"
        elif action == "wipe_free_economy":
            if str(request.form.get("wipe_confirmation") or "").strip() != "WIPE FREE ECONOMY":
                wipe_message = "Type WIPE FREE ECONOMY exactly to continue."
            else:
                try:
                    result = accounts.wipe_free_economy()
                    wipe_message = (
                        f"Free economy wiped: {int(result.get('wiped_users') or 0):,} never-paid accounts reset; "
                        f"{int(result.get('credits_removed') or 0):,} credits removed; "
                        f"{int(result.get('paid_users_protected') or 0):,} paying customers protected."
                    )
                except Exception as exc:
                    app.logger.exception("Unable to wipe free economy")
                    wipe_message = f"Unable to wipe free economy: {exc}"
        elif action == "grant_tier_credits":
            try:
                free_amount = int(request.form.get("free_credit_amount") or 0)
                paid_amount = int(request.form.get("paid_credit_amount") or 0)
                result = accounts.grant_free_and_paid_balances(
                    free_amount=free_amount,
                    paid_amount=paid_amount,
                    reason_free="admin_additive_grant_free_users",
                    reason_paid="admin_additive_grant_paid_users",
                )
                if result.get("ok"):
                    grant_message = (
                        f"Credits added without replacing balances: {int(result.get('free_updated') or 0):,} Free Users +{free_amount:,}; "
                        f"{int(result.get('paid_updated') or 0):,} Paid Users +{paid_amount:,}."
                    )
                else:
                    grant_message = str(result.get("message") or "Grant could not be completed.")
            except (TypeError, ValueError):
                grant_message = "Enter valid whole-number credit amounts of 0 or more."
            except Exception as exc:
                app.logger.exception("Unable to add tier credits")
                grant_message = f"Unable to add tier credits: {exc}"
        elif action in {"add_maintenance_bypass", "remove_maintenance_bypass"}:
            raw_user_id = str(request.form.get("user_id", "")).strip().lower()
            try:
                user_id = _admin_user_id(raw_user_id)
                if action == "add_maintenance_bypass" and not accounts.get_user(user_id):
                    bypass_message = "User not found for that site User ID."
                else:
                    enabled_bypass = action == "add_maintenance_bypass"
                    set_maintenance_bypass(user_id, enabled_bypass)
                    bypass_message = (
                        f"Maintenance bypass enabled for {user_id}."
                        if enabled_bypass else f"Maintenance bypass removed for {user_id}."
                    )
            except ValueError as exc:
                bypass_message = f"Invalid user ID: {exc}"
        elif action == "lookup_balance":
            lookup_user_id = str(request.form.get("user_id", "")).strip()
            try:
                user_id = _admin_user_id(lookup_user_id)
                user = accounts.get_user(user_id)
                if not user:
                    lookup_message = "User not found for that user ID."
                else:
                    lookup_message = f"Stored balance for user {user_id}: {int(user.get('balance', 0)):,} credits."
            except ValueError as exc:
                lookup_message = f"Invalid user ID: {exc}"
        elif action == "set_balance":
            set_user_id = str(request.form.get("user_id", "")).strip()
            set_amount = str(request.form.get("target_balance", "")).strip()
            try:
                user_id = _admin_user_id(set_user_id)
                target_balance = _admin_balance_amount(set_amount)
                result = accounts.set_balance(user_id, target_balance)
                if result.get("ok"):
                    set_message = f"Stored balance for user {user_id} set to exactly {int(result['balance']):,} credits."
                else:
                    set_message = result.get("message", "Unable to set balance.")
            except ValueError as exc:
                set_message = f"Invalid amount or user ID: {exc}"
        elif action == "filter_affected_refunds":
            if not refund_include_public and not refund_include_failed:
                refund_message = "Select public purchases, failed jobs, or both."
        elif action == "apply_affected_refund":
            if not refund_message:
                try:
                    result = affected_refunds.apply_multiplier(
                        user_ids=request.form.getlist("refund_user_id"),
                        multiplier=refund_multiplier,
                        include_public=refund_include_public,
                        include_failed=refund_include_failed,
                        start_at=refund_start_at,
                        end_at=refund_end_at,
                        note=request.form.get("refund_note", "Car injection issue compensation"),
                    )
                    refund_message = (
                        f"Refund completed: {int(result.get('user_count') or 0):,} affected users received "
                        f"{int(result.get('refunded') or 0):,} credits at {result.get('multiplier', refund_multiplier)}×."
                        if result.get("ok") else result.get("message", "Unable to apply affected-user refunds.")
                    )
                except Exception as exc:
                    app.logger.exception("Unable to apply affected-user refund inside admin panel")
                    refund_message = f"Unable to apply affected-user refunds: {exc}"
        elif action == "broadcast_inbox":
            try:
                result = community.admin_broadcast(
                    title=request.form.get("broadcast_title", ""),
                    body=request.form.get("broadcast_body", ""),
                )
                message = (
                    "Broadcast sent to every user inbox. Unread notification badges are now active."
                    if result.get("ok") else str(result.get("message") or "Unable to send broadcast.")
                )
            except Exception as exc:
                app.logger.exception("Unable to send admin inbox broadcast")
                message = f"Unable to send broadcast: {exc}"
        elif action == "giveaway_toggle":
            try:
                enabled_flag = str(request.form.get("giveaway_enabled") or "0") in {"1", "true", "on"}
                result = giveaway.set_enabled(enabled_flag)
                giveaway_message = (
                    "Giveaway page ENABLED." if result.get("enabled") else "Giveaway page DISABLED."
                )
            except Exception as exc:
                app.logger.exception("Unable to toggle giveaway")
                giveaway_message = f"Unable to toggle giveaway: {exc}"
        elif action == "giveaway_setup":
            try:
                credits_raw = str(request.form.get("credit_amounts") or "")
                credit_amounts = []
                for part in re.split(r"[\s,]+", credits_raw):
                    if not part:
                        continue
                    try:
                        credit_amounts.append(int(part))
                    except ValueError:
                        pass
                cpm1_lines = [
                    ln.strip() for ln in str(request.form.get("cpm1_accounts") or "").splitlines()
                    if ln.strip()
                ]
                cpm2_lines = [
                    ln.strip() for ln in str(request.form.get("cpm2_accounts") or "").splitlines()
                    if ln.strip()
                ]
                result = giveaway.create_or_update_setup(
                    title=str(request.form.get("title") or "Giveaway!"),
                    credit_amounts=credit_amounts,
                    cpm1_lines=cpm1_lines,
                    cpm2_lines=cpm2_lines,
                )
                giveaway_message = str(result.get("message") or "Setup saved.")
            except Exception as exc:
                app.logger.exception("Unable to save giveaway setup")
                giveaway_message = f"Unable to save giveaway setup: {exc}"
        elif action == "giveaway_queue":
            try:
                result = giveaway.start_queueing()
                giveaway_message = str(result.get("message") or "Queueing updated.")
            except Exception as exc:
                app.logger.exception("Unable to open giveaway queue")
                giveaway_message = f"Unable to open queueing: {exc}"
        elif action == "giveaway_spin":
            try:
                result = giveaway.start_spinner()
                giveaway_message = str(result.get("message") or "Spinner finished.")
                if result.get("delivery"):
                    giveaway_message += f" · Delivery: {result['delivery']}"
            except Exception as exc:
                app.logger.exception("Unable to run giveaway spinner")
                giveaway_message = f"Unable to start spinner: {exc}"
        elif action == "giveaway_lookup":
            try:
                resolved = giveaway.resolve_user(str(request.form.get("username_or_id") or ""))
                if resolved:
                    giveaway_message = (
                        f"Resolved: username={resolved['username']} → "
                        f"site_user_id={resolved['site_user_id']}"
                    )
                else:
                    giveaway_message = "Could not resolve that username or site user ID."
            except Exception as exc:
                app.logger.exception("Giveaway lookup failed")
                giveaway_message = f"Unable to lookup user: {exc}"
        elif action == "giveaway_manual_inbox":
            try:
                result = giveaway.admin_send_inbox(
                    username_or_id=str(request.form.get("username_or_id") or ""),
                    title=str(request.form.get("title") or ""),
                    body=str(request.form.get("body") or ""),
                )
                giveaway_message = str(result.get("message") or "Send finished.")
            except Exception as exc:
                app.logger.exception("Manual giveaway inbox send failed")
                giveaway_message = f"Unable to send inbox message: {exc}"
        elif action == "giveaway_resend_prize":
            try:
                result = giveaway.resend_prize_to_winner(
                    str(request.form.get("username_or_id") or "")
                )
                giveaway_message = str(result.get("message") or "Resend finished.")
            except Exception as exc:
                app.logger.exception("Giveaway prize resend failed")
                giveaway_message = f"Unable to resend prize: {exc}"
        elif action == "giveaway_resend_all":
            try:
                result = giveaway.resend_all_prizes_for_giveaway(
                    str(request.form.get("giveaway_id") or "")
                )
                giveaway_message = str(result.get("message") or "Bulk resend finished.")
                details = result.get("details") or []
                if details:
                    giveaway_message += " · " + " | ".join(details[:5])
                    if len(details) > 5:
                        giveaway_message += f" · +{len(details)-5} more"
            except Exception as exc:
                app.logger.exception("Giveaway bulk resend failed")
                giveaway_message = f"Unable to bulk-resend prizes: {exc}"
        elif action == "giveaway_resend_one":
            try:
                result = giveaway.resend_prize_by_history_id(
                    request.form.get("history_id")
                )
                giveaway_message = str(result.get("message") or "Resend finished.")
            except Exception as exc:
                app.logger.exception("Giveaway single history resend failed")
                giveaway_message = f"Unable to resend prize: {exc}"
        elif action == "reset_password":
            result = accounts.reset_password_by_email(
                request.form.get("email", ""), request.form.get("password", "")
            )
            message = (
                f"Password updated for {result['email']}." if result.get("ok")
                else result.get("message", "Unable to update password.")
            )
        else:
            message = "Invalid admin action."
    try:
        refund_candidates = affected_refunds.candidates(
            include_public=refund_include_public,
            include_failed=refund_include_failed,
            start_at=refund_start_at,
            end_at=refund_end_at,
        ) if (refund_include_public or refund_include_failed) else []
        refund_batches = affected_refunds.recent_batches(20)
    except Exception as exc:
        app.logger.exception("Unable to load affected refunds inside admin panel")
        refund_candidates, refund_batches = [], []
        if not refund_message:
            refund_message = f"Unable to load refund records: {exc}"
    try:
        car_diagnostics = accounts.recent_job_diagnostics(100)
    except Exception:
        app.logger.exception("Unable to load internal car diagnostics inside admin panel")
        car_diagnostics = []

    current_settings = load_settings()
    current_controls = _maintenance_settings()
    enabled = bool(current_settings.get("unlimited_currency"))
    try:
        _gw_snap = giveaway.admin_snapshot()
    except Exception:
        app.logger.exception("Unable to load giveaway admin snapshot")
        _gw_snap = {"enabled": False, "current": None, "batches": []}
    _gw_batches_html_parts = []
    for _b in (_gw_snap.get("batches") or []):
        if int(_b.get("winner_count") or 0) <= 0:
            continue
        _rows = []
        for _i, _w in enumerate(_b.get("winners") or [], 1):
            _rows.append(
                "<tr><td>{}</td><td><strong>{}</strong></td><td><code>{}</code></td><td>{}</td>"
                "<td><form method='post' style='margin:0'>"
                "<input type='hidden' name='action' value='giveaway_resend_one'>"
                "<input type='hidden' name='history_id' value='{}'>"
                "<button type='submit'>Resend</button></form></td></tr>".format(
                    _i,
                    html.escape(str(_w.get("winner_username") or "")),
                    html.escape(str(_w.get("winner_user_id") or "")),
                    html.escape(str(_w.get("prize_label") or "")),
                    int(_w.get("history_id") or 0),
                )
            )
        _gw_batches_html_parts.append(
            "<div style='border:1px solid #334155;border-radius:12px;padding:12px;margin:10px 0;background:#020617'>"
            "<div style='display:flex;flex-wrap:wrap;gap:8px;align-items:center;justify-content:space-between'>"
            "<div><strong>{}</strong> <small style='color:#94a3b8'>({} · {} winners · <code>{}…</code>)</small></div>"
            "<form method='post' style='margin:0' onsubmit=\"return confirm('Resend ALL prizes for this giveaway via Inbox?');\">"
            "<input type='hidden' name='action' value='giveaway_resend_all'>"
            "<input type='hidden' name='giveaway_id' value='{}'>"
            "<button type='submit' style='background:#f4c95d;color:#1a1200'>Resend all prizes</button></form>"
            "</div>"
            "<div style='overflow:auto;max-height:240px;margin-top:10px'>"
            "<table style='width:100%;border-collapse:collapse;font-size:12px'>"
            "<thead><tr><th>#</th><th>Username</th><th>Site user ID</th><th>Prize</th><th></th></tr></thead>"
            "<tbody>{}</tbody></table></div></div>".format(
                html.escape(str(_b.get("title") or "Giveaway!")),
                html.escape(str(_b.get("status") or "")),
                int(_b.get("winner_count") or 0),
                html.escape(str(_b.get("giveaway_id") or "")[:12]),
                html.escape(str(_b.get("giveaway_id") or "")),
                "".join(_rows),
            )
        )
    giveaway_batches_html = (
        "".join(_gw_batches_html_parts)
        or "<p class='help'>No giveaway winners stored yet.</p>"
    )
    return _unlimited_admin_html(

        enabled,
        dashboard_maintenance=is_dashboard_maintenance(),
        message=message,
        lookup_message=lookup_message,
        set_message=set_message,
        lookup_user_id=lookup_user_id,
        set_user_id=set_user_id,
        set_amount=set_amount,
        refund_candidates=refund_candidates,
        refund_batches=refund_batches,
        refund_message=refund_message,
        refund_include_public=refund_include_public,
        refund_include_failed=refund_include_failed,
        refund_start_date=refund_start_date,
        refund_end_date=refund_end_date,
        refund_multiplier=refund_multiplier,
        car_diagnostics=car_diagnostics,
        bypass_user_ids=maintenance_bypass_user_ids(),
        bypass_message=bypass_message,
        maintenance_mode=current_controls["mode"],
        maintenance_sections=current_controls["enabled_sections"],
        schedule_enabled=current_controls["schedule_enabled"],
        wipe_message=wipe_message,
        grant_message=grant_message,
        giveaway_message=giveaway_message,
        giveaway_enabled=bool(_gw_snap.get("enabled")),
        giveaway_status=((_gw_snap.get("current") or {}).get("status") or "none"),
        giveaway_entries=int(((_gw_snap.get("current") or {}).get("entry_count") or 0)),
        giveaway_prizes=int(((_gw_snap.get("current") or {}).get("prize_count") or 0)),
        giveaway_batches_html=giveaway_batches_html,
    )


@app.route(ADMIN_SECRET_PANEL_PATH + "/car-backup/<job_id>.json")
@_require_admin
def admin_car_safety_backup(job_id: str):
    """Download the exact pre-action garage export from the existing admin area."""
    if not re.fullmatch(r"[0-9a-f]{32}", job_id or ""):
        return jsonify({"ok": False, "message": "Backup not found."}), 404
    backup = car_safety_backups.get(job_id)
    if not backup:
        return jsonify({"ok": False, "message": "Backup not found."}), 404
    return Response(
        json.dumps(backup, ensure_ascii=False, indent=2),
        mimetype="application/json",
        headers={"Content-Disposition": f'attachment; filename="car-safety-{job_id}.json"'},
    )


@app.route(ADMIN_SECRET_PANEL_PATH + "/safe-file", methods=["GET", "POST"])
@_require_admin
def admin_safe_file():
    result = None
    if request.method == "POST":
        upload = request.files.get("safe_file")
        email = str(request.form.get("email", "")).strip()
        password = str(request.form.get("password", ""))
        try:
            if not upload or not email or not password:
                raise ValueError("CPM email, password, and a JSON safe file are required.")
            raw = upload.read(10 * 1024 * 1024 + 1)
            if len(raw) > 10 * 1024 * 1024:
                raise ValueError("Safe file is larger than 10 MB.")
            payload = json.loads(raw.decode("utf-8-sig"))
            if not isinstance(payload, (dict, list)):
                raise ValueError("Safe file must contain a JSON object or list.")
            job_id = uuid.uuid4().hex
            result = run_async(inject_with_garage_protection(
                job_id, "custom_safe_file", email, password,
                site_user_id="admin", custom_payload=payload,
            ))
        except Exception as exc:
            result = {"ok": False, "message": str(exc)}
    return render_template("admin_safe_file.html", result=result, admin_panel_path=ADMIN_SECRET_PANEL_PATH)




@app.route("/api/unlimited-restart-status")
def unlimited_restart_status_api():
    status = _unlimited_restart_status()
    return jsonify({"ok": True, **status})


@app.route("/ads.txt")
def ads_txt():
    """Redirect ads.txt requests to Ezoic's managed ads.txt for tnnr.shop."""
    return redirect("https://srv.adstxtmanager.com/19390/tnnr.shop", code=301)


@app.route("/support")
def support_page():
    user = _require_site_user()
    tickets = community.ticket_list_for_user(user["user_id"]) if user else []
    return render_template(
        "support.html", site_user=_display_site_user(user), tickets=tickets,
        support_categories=community.SUPPORT_CATEGORIES,
    )


@app.route("/inbox")
def inbox_page():
    user = _require_site_user()
    if not user:
        flash("Sign in to view your inbox.", "error")
        return redirect(url_for("site_login", next=url_for("inbox_page")))
    messages = []
    try:
        messages = list(community.inbox_for_user(user["user_id"], limit=100) or [])
    except Exception:
        app.logger.exception("Unable to load community inbox")
        messages = []
    try:
        community.inbox_mark_all_read(user["user_id"])
    except Exception:
        pass
    # Merge guaranteed giveaway/system messages so prize delivery always shows
    try:
        extra = giveaway.list_site_inbox(str(user["user_id"]), limit=100)
        if extra:
            messages = list(extra) + list(messages)

            def _msg_time(m):
                if not isinstance(m, dict):
                    return 0.0
                for key in ("created_at", "timestamp", "created", "time"):
                    if key in m:
                        try:
                            return float(m[key] or 0)
                        except (TypeError, ValueError):
                            pass
                return 0.0

            messages.sort(key=_msg_time, reverse=True)
            messages = messages[:150]
        giveaway.site_inbox_mark_all_read(str(user["user_id"]))
    except Exception:
        app.logger.exception("Unable to merge giveaway site inbox")
    return render_template("inbox.html", site_user=_display_site_user(user), messages=messages)


@app.route("/support/create", methods=["POST"])
def support_create():
    user = _require_site_user()
    if not user:
        flash("Sign in to open a support ticket.", "error")
        return redirect(url_for("site_login"))
    result = community.ticket_create(
        user_id=user["user_id"], email=user["email"],
        subject=request.form.get("subject", ""), body=request.form.get("body", ""),
        category=request.form.get("category", "general"),
    )
    flash(result.get("message", "Ticket opened."), "success" if result.get("ok") else "error")
    if result.get("ok"):
        return redirect(url_for("support_ticket", ticket_id=result["ticket"]["id"]))
    return redirect(url_for("support_page"))


@app.route("/support/ticket/<ticket_id>")
def support_ticket(ticket_id: str):
    ticket = community.ticket_get(ticket_id)
    user = _require_site_user()
    if not ticket or not user or ticket.get("user_id") != user.get("user_id"):
        return "Ticket not found", 404
    return render_template(
        "support_ticket.html", ticket=ticket, is_admin=False, activity=None,
        safe_file_result=None, admin_suffix=False,
        admin_panel_path=ADMIN_SECRET_PANEL_PATH,
    )


def _render_admin_ticket(ticket: Dict[str, Any], admin_suffix: bool = False, safe_file_result=None):
    activity = admin_ticket_context.build_ticket_user_context(
        str(ticket.get("user_id") or ""), str(ticket.get("email") or "")
    )
    return render_template(
        "support_ticket.html", ticket=ticket, is_admin=True, activity=activity,
        safe_file_result=safe_file_result, admin_suffix=bool(admin_suffix),
        admin_panel_path=ADMIN_SECRET_PANEL_PATH,
    )


@app.route("/support/<ticket_id>/admin")
def admin_support_ticket_public(ticket_id: str):
    """Ticket administration reached by appending /admin to the public ticket ID."""
    ticket = community.ticket_get(ticket_id)
    if not ticket:
        return "Ticket not found", 404
    return _render_admin_ticket(ticket, admin_suffix=True)


@app.route("/support/ticket/<ticket_id>/reply", methods=["POST"])
def support_ticket_reply(ticket_id: str):
    user = _require_site_user()
    ticket = community.ticket_get(ticket_id)
    if not user:
        return redirect(url_for("site_login"))
    if not ticket or ticket.get("user_id") != user.get("user_id"):
        return "Ticket not found", 404
    result = community.ticket_reply(
        ticket_id=ticket_id, body=request.form.get("body", ""),
        from_role="user", author=user["email"], user_id=user["user_id"],
    )
    flash(result.get("message", "Reply saved.") if not result.get("ok") else "Reply saved.",
          "success" if result.get("ok") else "error")
    return redirect(url_for("support_ticket", ticket_id=ticket_id))


@app.route("/support/<ticket_id>/admin/reply", methods=["POST"])
def admin_support_ticket_reply_public(ticket_id: str):
    ticket = community.ticket_get(ticket_id)
    if not ticket:
        return "Ticket not found", 404
    result = community.ticket_reply(
        ticket_id=ticket_id, body=request.form.get("body", ""),
        from_role="admin", author="TNNR Support", user_id="",
    )
    flash("Reply saved." if result.get("ok") else result.get("message", "Reply failed."),
          "success" if result.get("ok") else "error")
    return redirect(url_for("admin_support_ticket_public", ticket_id=ticket_id))


@app.route("/support/<ticket_id>/admin/status", methods=["POST"])
def admin_support_ticket_status_public(ticket_id: str):
    if not community.ticket_get(ticket_id):
        return "Ticket not found", 404
    result = community.ticket_set_status(ticket_id, request.form.get("status", ""))
    flash("Ticket updated." if result.get("ok") else result.get("message", "Update failed."),
          "success" if result.get("ok") else "error")
    return redirect(url_for("admin_support_ticket_public", ticket_id=ticket_id))


@app.route("/support/<ticket_id>/admin/car-backup/<job_id>.json")
def admin_support_ticket_backup_public(ticket_id: str, job_id: str):
    ticket = community.ticket_get(ticket_id)
    if not ticket or not re.fullmatch(r"[0-9a-f]{32}", job_id or ""):
        return jsonify({"ok": False, "message": "Backup not found."}), 404
    activity = admin_ticket_context.build_ticket_user_context(
        str(ticket.get("user_id") or ""), str(ticket.get("email") or "")
    )
    allowed_job_ids = {
        str(item.get("job_id") or "")
        for day in activity.get("days", []) for item in day.get("saves", [])
    }
    if job_id not in allowed_job_ids:
        return jsonify({"ok": False, "message": "Backup not found."}), 404
    backup = car_safety_backups.get(job_id)
    if not backup:
        return jsonify({"ok": False, "message": "Backup not found."}), 404
    return Response(
        json.dumps(backup, ensure_ascii=False, indent=2),
        mimetype="application/json",
        headers={"Content-Disposition": f'attachment; filename="car-safety-{job_id}.json"'},
    )


@app.route("/support/<ticket_id>/admin/safe-file", methods=["POST"])
@_bounded_account_action
def admin_support_ticket_safe_file_public(ticket_id: str):
    ticket = community.ticket_get(ticket_id)
    if not ticket:
        return "Ticket not found", 404
    result = _process_ticket_safe_file(ticket)
    ticket = community.ticket_get(ticket_id) or ticket
    return _render_admin_ticket(ticket, admin_suffix=True, safe_file_result=result)


def _process_ticket_safe_file(ticket: Dict[str, Any]) -> Dict[str, Any]:
    email = ""
    try:
        upload = request.files.get("safe_file")
        email = str(request.form.get("email", "")).strip()
        password = str(request.form.get("password", ""))
        if not upload or not email or not password:
            raise ValueError("CPM email, password, and a JSON safe file are required.")
        raw = upload.read(10 * 1024 * 1024 + 1)
        if len(raw) > 10 * 1024 * 1024:
            raise ValueError("Safe file is larger than 10 MB.")
        payload = json.loads(raw.decode("utf-8-sig"))
        if not isinstance(payload, (dict, list)):
            raise ValueError("Safe file must contain a JSON object or list.")
        job_id = uuid.uuid4().hex
        result = run_async(inject_with_garage_protection(
            job_id, "custom_safe_file", email, password,
            site_user_id=str(ticket.get("user_id") or ""), custom_payload=payload,
        ))
    except Exception as exc:
        app.logger.exception("Ticket safe-file injection failed")
        result = {"ok": False, "message": str(exc)}
    try:
        backlog.log_action(
            email or str(ticket.get("email") or "unknown"),
            "admin_ticket_safe_file",
            "Admin Ticket Safe File Injection",
            bool(result.get("ok")),
            message=str(result.get("message") or ""),
            player_name="Admin support",
            extra={"ticket_id": str(ticket.get("id") or "")},
        )
    except Exception:
        app.logger.exception("Ticket safe-file action logging failed")
    return result


@app.route(ADMIN_SECRET_PANEL_PATH + "/support")
@_require_admin
def admin_support_tickets():
    tickets = community.ticket_list_all(300)
    paid_support, free_support, worldsale_support = [], [], []
    for ticket in tickets:
        category = community.normalize_support_category(ticket.get("category"))
        if category == "world_sale":
            worldsale_support.append(ticket)
        else:
            try:
                is_paid = accounts.has_paid_history(str(ticket.get("user_id") or ""))
            except Exception:
                app.logger.exception("Unable to classify support ticket payment history")
                is_paid = False
            (paid_support if is_paid else free_support).append(ticket)
    return render_template(
        "admin_tickets.html", tickets=tickets,
        free_support=free_support, paid_support=paid_support,
        worldsale_support=worldsale_support,
        support_summary={
            "total": len(tickets), "free": len(free_support),
            "paid": len(paid_support), "world_sale": len(worldsale_support),
        },
        admin_panel_path=ADMIN_SECRET_PANEL_PATH,
    )


@app.route(ADMIN_SECRET_PANEL_PATH + "/support/<ticket_id>")
@_require_admin
def admin_support_ticket_session(ticket_id: str):
    ticket = community.ticket_get(ticket_id)
    if not ticket:
        return "Ticket not found", 404
    return _render_admin_ticket(ticket)


@app.route(ADMIN_SECRET_PANEL_PATH + "/support/<ticket_id>/reply", methods=["POST"])
@_require_admin
def admin_support_ticket_reply_session(ticket_id: str):
    ticket = community.ticket_get(ticket_id)
    if not ticket:
        return "Ticket not found", 404
    result = community.ticket_reply(
        ticket_id=ticket_id, body=request.form.get("body", ""),
        from_role="admin", author="TNNR Support", user_id="",
    )
    flash("Reply saved." if result.get("ok") else result.get("message", "Reply failed."),
          "success" if result.get("ok") else "error")
    return redirect(url_for("admin_support_ticket_session", ticket_id=ticket_id))


@app.route(ADMIN_SECRET_PANEL_PATH + "/support/<ticket_id>/safe-file", methods=["POST"])
@_require_admin
@_bounded_account_action
def admin_support_ticket_safe_file_session(ticket_id: str):
    ticket = community.ticket_get(ticket_id)
    if not ticket:
        return "Ticket not found", 404
    result = _process_ticket_safe_file(ticket)
    ticket = community.ticket_get(ticket_id) or ticket
    return _render_admin_ticket(ticket, safe_file_result=result)


@app.route(ADMIN_SECRET_PANEL_PATH + "/support/<ticket_id>/status", methods=["POST"])
@_require_admin
def admin_support_ticket_status(ticket_id: str):
    result = community.ticket_set_status(ticket_id, request.form.get("status", ""))
    flash("Ticket updated." if result.get("ok") else result.get("message", "Update failed."),
          "success" if result.get("ok") else "error")
    return redirect(url_for("admin_support_ticket_session", ticket_id=ticket_id))


@app.route(ADMIN_SECRET_PANEL_PATH + "/shared-designs")
@_require_admin
def admin_shared_designs():
    overview = design_marketplace.admin_overview()
    designs, reports, comments, moderation_events, seller_controls, duplicate_summary = overview[:6]
    report_summary = overview[6] if len(overview) > 6 else {}
    return render_template("admin_shared_designs.html", designs=designs, reports=reports, comments=comments,
                           moderation_events=moderation_events, seller_controls=seller_controls,
                           duplicate_summary=duplicate_summary, report_summary=report_summary,
                           auto_disable_threshold=design_marketplace.REPORT_AUTO_DISABLE_THRESHOLD,
                           admin_panel_path=ADMIN_SECRET_PANEL_PATH)


def _admin_refund_date(value: str, *, end_of_day: bool = False):
    value = (value or "").strip()
    if not value:
        return None
    parsed = datetime.strptime(value, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    return parsed.timestamp() + (86400 if end_of_day else 0)


@app.route(ADMIN_SECRET_PANEL_PATH + "/affected-refunds", methods=["GET", "POST"])
@_require_admin
def admin_affected_refunds():
    # Backward-compatible redirect only. Refund controls live on the main admin page.
    return redirect(ADMIN_SECRET_PANEL_PATH + "#affected-refunds")


@app.route(ADMIN_SECRET_PANEL_PATH + "/shared-designs/<design_id>/status", methods=["POST"])
@_require_admin
def admin_shared_design_status(design_id: str):
    result = design_marketplace.admin_design_status(
        design_id, request.form.get("status", ""), request.form.get("reason", "")
    )
    flash(result.get("message", "Listing updated."), "success" if result.get("ok") else "error")
    return redirect(url_for("admin_shared_designs"))


@app.route(ADMIN_SECRET_PANEL_PATH + "/shared-designs/seller/<user_id>/moderate", methods=["POST"])
@_require_admin
def admin_shared_design_seller_moderate(user_id: str):
    try:
        days = int(request.form.get("days", "7") or 7)
    except (TypeError, ValueError):
        days = 7
    result = design_marketplace.admin_moderate_seller(
        user_id=user_id,
        action=request.form.get("action", ""),
        reason=request.form.get("reason", ""),
        days=days,
    )
    flash(result.get("message", "Seller moderation updated."), "success" if result.get("ok") else "error")
    return redirect(url_for("admin_shared_designs"))


@app.route(ADMIN_SECRET_PANEL_PATH + "/shared-designs/report/<report_id>", methods=["POST"])
@_require_admin
def admin_shared_design_report(report_id: str):
    design_marketplace.admin_report_status(report_id, request.form.get("status", ""))
    return redirect(url_for("admin_shared_designs"))


@app.route(ADMIN_SECRET_PANEL_PATH + "/shared-designs/comment/<comment_id>", methods=["POST"])
@_require_admin
def admin_shared_design_comment(comment_id: str):
    design_marketplace.admin_comment_status(comment_id, request.form.get("status", ""))
    return redirect(url_for("admin_shared_designs"))



@app.route(ADMIN_SECRET_PANEL_PATH + "/king-account-generator", methods=["GET", "POST"])
@_require_admin
def admin_king_account_generator():
    batch_id = str(request.values.get("batch_id") or "").strip()
    if request.method == "POST":
        result = king_account_jobs.create_batch(
            email_prefix=request.form.get("email_prefix", ""),
            account_count=request.form.get("account_count", ""),
            target_cars=request.form.get("target_cars", ""),
            password=request.form.get("password", ""),
            max_concurrency=request.form.get("max_concurrency", ""),
        )
        if result.get("ok"):
            flash(
                f"King-account batch {str(result['batch_id'])[:8]} queued for {int(result['total_accounts'])} account(s).",
                "success",
            )
            return redirect(url_for("admin_king_account_generator", batch_id=result["batch_id"]))
        # The active-batch guard returns its ID. Keep it in the page context so
        # the administrator immediately gets the live batch controls, including
        # Force Stop, instead of seeing only an un-actionable flash warning.
        if result.get("batch_id"):
            batch_id = str(result["batch_id"]).strip()
        flash(str(result.get("message") or "Unable to create king-account batch."), "error")
    batch = king_account_jobs.get_batch(batch_id) if batch_id else None
    return render_template(
        "admin_king_account_generator.html",
        title="King Account Generator",
        admin_panel_path=ADMIN_SECRET_PANEL_PATH,
        batch=batch,
        max_accounts=king_account_jobs.MAX_ACCOUNTS_PER_BATCH,
        default_target_cars=king_account_jobs.DEFAULT_TARGET_CAR_COUNT,
        max_target_cars=king_account_jobs.MAX_TARGET_CARS,
        max_concurrency=king_account_jobs.MAX_CONCURRENCY,
        default_concurrency=king_account_jobs.MAX_CONCURRENCY,
        attempts_per_minute=king_account_jobs.MAX_CONCURRENCY,
    )


@app.route(ADMIN_SECRET_PANEL_PATH + "/king-account-generator/status/<batch_id>")
@_require_admin
def admin_king_account_generator_status(batch_id: str):
    batch = king_account_jobs.get_batch(batch_id)
    if not batch:
        return jsonify({"ok": False, "message": "Batch not found."}), 404
    return jsonify({"ok": True, "batch": batch})


@app.route(ADMIN_SECRET_PANEL_PATH + "/king-account-generator/cancel/<batch_id>", methods=["POST"])
@_require_admin
def admin_king_account_generator_cancel(batch_id: str):
    result = king_account_jobs.cancel_batch(batch_id)
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return jsonify(result), 200 if result.get("ok") else 404
    flash(str(result.get("message") or "Batch update complete."), "success" if result.get("ok") else "error")
    return redirect(url_for("admin_king_account_generator", batch_id=batch_id))


@app.route(ADMIN_SECRET_PANEL_PATH + "/king-account-generator/force-stop/<batch_id>", methods=["POST"])
@_require_admin
def admin_king_account_generator_force_stop(batch_id: str):
    result = king_account_jobs.force_stop_batch(batch_id)
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return jsonify(result), 200 if result.get("ok") else 404
    flash(str(result.get("message") or "Batch force-stop complete."), "success" if result.get("ok") else "error")
    return redirect(url_for("admin_king_account_generator"))


@app.route("/register", methods=["GET", "POST"])
def site_register():
    if request.method == "GET":
        return render_template("register.html")
    email = request.form.get("email", "")
    password = request.form.get("password", "")
    result = accounts.register(email, password)
    if not result.get("ok"):
        flash(result.get("message", "Register failed"), "error")
        return redirect(url_for("site_register"))
    session["site_user_id"] = result["user_id"]
    session["site_email"] = result["email"]
    session["site_logged_in"] = True
    session.permanent = True
    flash(f"Account created. Your User ID is {result['user_id']}.", "success")
    return redirect(url_for("topup"))


@app.route("/account/login", methods=["GET", "POST"])
def site_login():
    if request.method == "GET":
        return render_template("site_login.html")
    email = request.form.get("email", "")
    password = request.form.get("password", "")
    result = accounts.login(email, password)
    if not result.get("ok"):
        flash(result.get("message", "Login failed"), "error")
        return redirect(url_for("site_login"))
    session["site_user_id"] = result["user_id"]
    session["site_email"] = result["email"]
    session["site_logged_in"] = True
    session.permanent = True
    flash("Signed in to your site account.", "success")
    return redirect(url_for("topup"))


@app.route("/account/logout")
def site_logout():
    session.pop("site_user_id", None)
    session.pop("site_email", None)
    session.pop("site_logged_in", None)
    flash("Site account signed out.", "info")
    return redirect(url_for("index"))


@app.route("/topup")
def topup():
    user = _require_site_user()
    if not user:
        flash("Sign in to your site account to view balance.", "info")
        return redirect(url_for("site_login"))
    return render_template(
        "topup.html",
        site_user=_display_site_user(user),
        packs=accounts.TOPUP_PACKS,
        prices={
            "money": accounts.PRICE_MONEY,
            "coin": accounts.PRICE_COIN,
            "player": accounts.PRICE_PLAYER_UNLOCK,
            "car": accounts.PRICE_CAR_PREMIUM,
        },
    )


@app.route("/stripe/checkout/<pack_id>", methods=["POST"])
def stripe_checkout(pack_id: str):
    user = _require_site_user()
    if not user:
        flash("Sign in first.", "error")
        return redirect(url_for("site_login"))

    # Server-side allowlist validation: pack_id is the only client-controlled
    # selector, and amount/credits always come from accounts.TOPUP_PACKS.
    pack = accounts.pack_info(pack_id)
    if not pack:
        flash("Unknown top-up pack.", "error")
        return redirect(url_for("topup"))

    if not _stripe_ready_for_checkout():
        flash("Stripe is not configured. Set STRIPE_SECRET_KEY on the server.", "error")
        return redirect(url_for("topup"))

    try:
        stripe.api_key = _stripe_secret_key()
        success_url = _external_app_url("stripe_success") + "?session_id={CHECKOUT_SESSION_ID}"
        cancel_url = _external_app_url("topup")
        currency = _stripe_currency()
        checkout = stripe.checkout.Session.create(
            mode="payment",
            success_url=success_url,
            cancel_url=cancel_url,
            line_items=[{
                "price_data": {
                    "currency": currency,
                    "product_data": {"name": f"TNNR.shop {pack['credits']:,} credits"},
                    "unit_amount": int(pack["amount_cents"]),
                },
                "quantity": 1,
            }],
            metadata={
                "site_user_id": user["user_id"],
                "pack_id": pack_id,
                "expected_amount_cents": str(int(pack["amount_cents"])),
                "currency": currency,
            },
            payment_intent_data={
                "metadata": {
                    "site_user_id": user["user_id"],
                    "pack_id": pack_id,
                }
            },
            client_reference_id=user["user_id"],
            customer_email=user.get("email") or None,
        )
        return redirect(checkout.url, code=303)
    except Exception as exc:
        app.logger.exception("Stripe checkout failed")
        flash(f"Stripe error: {exc}", "error")
        return redirect(url_for("topup"))


@app.route("/stripe/success")
def stripe_success():
    # Fulfillment is intentionally handled only by the signed Stripe webhook.
    # The browser success redirect is informational and cannot credit balance.
    if request.args.get("session_id"):
        flash("Payment received by Stripe. Your balance updates after Stripe confirms it.", "info")
    else:
        flash("Payment status will update after Stripe confirms it.", "info")
    return redirect(url_for("topup"))


@app.route("/stripe/webhook", methods=["POST"])
def stripe_webhook():
    if not stripe or not _stripe_secret_key():
        return jsonify({"ok": False, "message": "Stripe is not configured."}), 503
    webhook_secret = _stripe_webhook_secret()
    if not webhook_secret:
        return jsonify({"ok": False, "message": "Stripe webhook secret is not configured."}), 503

    payload = request.data
    sig = request.headers.get("Stripe-Signature", "")
    try:
        stripe.api_key = _stripe_secret_key()
        event = stripe.Webhook.construct_event(payload, sig, webhook_secret)
    except Exception as exc:
        return jsonify({"ok": False, "message": str(exc)}), 400

    if event.get("type") != "checkout.session.completed":
        return jsonify({"ok": True, "ignored": True})

    session_obj = event["data"]["object"]
    if session_obj.get("payment_status") != "paid":
        return jsonify({"ok": True, "ignored": True, "reason": "payment_not_paid"})

    meta = session_obj.get("metadata") or {}
    pack_id = meta.get("pack_id", "")
    pack = accounts.pack_info(pack_id)
    if not pack:
        app.logger.warning("Ignoring Stripe top-up with unknown pack_id: %s", pack_id)
        return jsonify({"ok": False, "message": "Unknown top-up pack."}), 400

    currency = (session_obj.get("currency") or meta.get("currency") or "").lower()
    expected_currency = _stripe_currency()
    if currency != expected_currency:
        app.logger.warning("Ignoring Stripe top-up with currency mismatch for session %s", session_obj.get("id"))
        return jsonify({"ok": False, "message": "Currency mismatch."}), 400

    amount_total = int(session_obj.get("amount_total") or 0)
    result = accounts.fulfill_stripe_topup(
        session_id=session_obj.get("id", ""),
        event_id=event.get("id", ""),
        user_id=meta.get("site_user_id", ""),
        pack_id=pack_id,
        amount_cents=amount_total,
        currency=currency,
    )
    if not result.get("ok"):
        app.logger.warning("Stripe top-up fulfillment rejected: %s", result.get("message"))
        return jsonify({"ok": False, "message": result.get("message", "Fulfillment failed.")}), 400

    return jsonify({"ok": True, "duplicate": bool(result.get("duplicate"))})


@app.route("/api/balance")
def api_balance():
    user = _require_site_user()
    return jsonify(_serialize_balance_response(user))


@app.route("/")
def index():
    """Public homepage / game-login page without destroying active sessions.

    Users can safely return here from Top Up or the navigation bar and then go
    back to the dashboard without having to sign in to CPM again.
    """
    return render_template("index.html", email=get_email())


@app.route("/cars")
def cars_page():
    """Cars hub: catalog, premium, event, unlock, public designs."""
    return render_template("cars.html", title="Cars")


@app.route("/giveaway")
def giveaway_page():
    """Giveaway spinner — site account login required to enter."""
    if not giveaway.is_enabled():
        flash("Giveaway is not active right now.", "error")
        return redirect(url_for("index"))
    user = _require_site_user()
    if not user:
        flash("Sign in with your site account to enter the giveaway.", "error")
        return redirect(url_for("site_login", next=url_for("giveaway_page")))
    csrf = session.get("gw_csrf_token")
    if not csrf:
        csrf = uuid.uuid4().hex
        session["gw_csrf_token"] = csrf
    try:
        current = giveaway.current_giveaway()
    except Exception:
        app.logger.exception("Unable to load giveaway")
        current = None
    # Optional wheel label only — never used as identity
    default_username = str(
        user.get("username") or user.get("display_name") or user.get("email") or ""
    ).split("@")[0][:40]
    already_in = False
    if current and current.get("status") == "queueing":
        uid = str(user["user_id"])
        already_in = any(
            str(e.get("site_user_id") or "") == uid
            for e in (current.get("entries") or [])
        )
    return render_template(
        "giveaway.html",
        giveaway=current,
        gw_csrf=csrf,
        site_user_id=str(user["user_id"]),
        site_user_email=str(user.get("email") or ""),
        default_username=default_username,
        already_joined=already_in,
        require_site_login=True,
    )


@app.route("/giveaway/status")
def giveaway_status():
    if not giveaway.is_enabled():
        return jsonify({"ok": False, "message": "Giveaway disabled."}), 404
    try:
        current = giveaway.current_giveaway()
    except Exception:
        app.logger.exception("Unable to read giveaway status")
        return jsonify({"ok": False, "message": "Status unavailable."}), 503
    # If logged in, mark whether this site user is already entered
    me = None
    user = _require_site_user()
    if user and current:
        uid = str(user["user_id"])
        me = {
            "site_user_id": uid,
            "joined": any(
                str(e.get("site_user_id") or "") == uid
                for e in (current.get("entries") or [])
            ),
        }
    return jsonify({"ok": True, "giveaway": current, "me": me})


@app.route("/giveaway/join", methods=["POST"])
def giveaway_join():
    if not giveaway.is_enabled():
        return jsonify({"ok": False, "message": "Giveaway disabled."}), 404
    # Always identity from server session — never trust client-supplied ids
    user = _require_site_user()
    if not user:
        return jsonify({
            "ok": False,
            "need_site_login": True,
            "login_url": url_for("site_login", next=url_for("giveaway_page")),
            "message": "Sign in with your site account to join the giveaway.",
        }), 401
    site_user_id = str(user.get("user_id") or "").strip()
    if not site_user_id:
        return jsonify({
            "ok": False,
            "need_site_login": True,
            "message": "Your site session is missing a user id. Sign in again.",
        }), 401
    supplied = str(request.form.get("csrf_token") or "")
    expected = str(session.get("gw_csrf_token") or "")
    if not supplied or not expected or not hmac.compare_digest(supplied, expected):
        return jsonify({"ok": False, "message": "This page expired. Refresh and try again."}), 400
    # Optional display name for the wheel only
    username = str(request.form.get("username") or "").strip()
    if not username:
        username = str(
            user.get("username") or user.get("display_name") or user.get("email") or "Player"
        ).split("@")[0][:40]
    try:
        result = giveaway.join(site_user_id, username)
    except Exception:
        app.logger.exception("Unable to join giveaway")
        result = {"ok": False, "message": "Unable to join right now."}
    if result.get("ok"):
        result["site_user_id"] = site_user_id
        result["username"] = username
    return jsonify(result), 200 if result.get("ok") else 409


@app.route("/cpm2")
def cpm2_page():
    """Standalone CPM2 tools section; it does not require a CPM1 game login."""
    csrf_token = session.get("cpm2_csrf_token")
    if not csrf_token:
        csrf_token = uuid.uuid4().hex
        session["cpm2_csrf_token"] = csrf_token
    return render_template(
        "cpm2.html",
        cpm2_limit=cpm2_coin_farm.LIFETIME_COIN_LIMIT,
        cpm2_csrf_token=csrf_token,
        bulk_max=cpm2_coin_farm.BULK_MAX_ACCOUNTS,
        bulk_countries=",".join(cpm2_coin_farm.BULK_TEST_COUNTRIES),
    )


@app.route("/cpm2/inject-coins", methods=["POST"])
def cpm2_inject_coins():
    user = _require_site_user()
    if not user:
        return jsonify({
            "ok": False,
            "need_site_login": True,
            "message": "Create a TNNR site account or sign in before using CPM2 Inject Coins.",
        }), 401
    supplied_csrf = str(request.form.get("csrf_token") or "")
    expected_csrf = str(session.get("cpm2_csrf_token") or "")
    if not supplied_csrf or not expected_csrf or not hmac.compare_digest(supplied_csrf, expected_csrf):
        return jsonify({"ok": False, "message": "This page expired. Refresh it and try again."}), 400
    email = str(request.form.get("email") or "").strip()
    password = str(request.form.get("password") or "")
    try:
        result = cpm2_coin_farm.start_job(str(user["user_id"]), email, password)
    except Exception:
        app.logger.exception("Unable to start CPM2 coin job")
        result = {"ok": False, "message": "CPM2 Inject Coins is temporarily unavailable."}
    if result.get("ok") and result.get("job_id"):
        result["progress_url"] = url_for("cpm2_job_page", job_id=result["job_id"])
    return jsonify(result), 202 if result.get("ok") else 409


@app.route("/cpm2/status/<job_id>")
def cpm2_coin_status(job_id: str):
    user = _require_site_user()
    if not user:
        return jsonify({"ok": False, "message": "Site login required."}), 401
    if not re.fullmatch(r"[a-f0-9]{32}", job_id):
        return jsonify({"ok": False, "message": "Job not found."}), 404
    try:
        job = cpm2_coin_farm.get_job(job_id, str(user["user_id"]))
    except Exception:
        app.logger.exception("Unable to read CPM2 coin job")
        return jsonify({"ok": False, "message": "Status is temporarily unavailable."}), 503
    if not job:
        return jsonify({"ok": False, "message": "Job not found."}), 404
    return jsonify({"ok": True, **job})


@app.route("/cpm2/job/<job_id>")
def cpm2_job_page(job_id: str):
    """Saved CPM2 Auto Complete progress page that can be reopened by URL."""
    user = _require_site_user()
    if not user:
        return redirect(url_for("site_login"))
    if not re.fullmatch(r"[a-f0-9]{32}", job_id):
        flash("CPM2 Auto Complete job not found.", "error")
        return redirect(url_for("cpm2_page"))
    try:
        job = cpm2_coin_farm.get_job(job_id, str(user["user_id"]))
    except Exception:
        app.logger.exception("Unable to open CPM2 coin job")
        job = None
    if not job:
        flash("CPM2 Auto Complete job not found.", "error")
        return redirect(url_for("cpm2_page"))
    return render_template(
        "cpm2_job.html",
        title="CPM2 Auto Complete Progress",
        job_id=job_id,
        status_url=url_for("cpm2_coin_status", job_id=job_id),
        initial_job=job,
        cpm2_limit=cpm2_coin_farm.LIFETIME_COIN_LIMIT,
    )


@app.route("/cpm2/bulk-start", methods=["POST"])
def cpm2_bulk_start():
    """Generate up to 500 CPM2 accounts and run inject on each (country rotation)."""
    user = _require_site_user()
    if not user:
        return jsonify({
            "ok": False,
            "need_site_login": True,
            "message": "Sign in to your TNNR site account before starting a bulk batch.",
        }), 401
    supplied_csrf = str(request.form.get("csrf_token") or "")
    expected_csrf = str(session.get("cpm2_csrf_token") or "")
    if not supplied_csrf or not expected_csrf or not hmac.compare_digest(supplied_csrf, expected_csrf):
        return jsonify({"ok": False, "message": "This page expired. Refresh it and try again."}), 400
    raw_count = request.form.get("count") or request.form.get("account_count") or "10"
    raw_countries = str(request.form.get("countries") or "").strip()
    countries = None
    if raw_countries:
        countries = [part.strip() for part in re.split(r"[\s,]+", raw_countries) if part.strip()]
    try:
        result = cpm2_coin_farm.start_bulk_batch(
            str(user["user_id"]), raw_count, countries
        )
    except Exception:
        app.logger.exception("Unable to start CPM2 bulk batch")
        result = {"ok": False, "message": "Bulk account generation is temporarily unavailable."}
    if result.get("ok") and result.get("batch_id"):
        result["status_url"] = url_for(
            "cpm2_bulk_status", batch_id=result["batch_id"]
        )
        result["progress_url"] = url_for(
            "cpm2_bulk_page", batch_id=result["batch_id"]
        )
    return jsonify(result), 202 if result.get("ok") else 409


@app.route("/cpm2/bulk-status/<batch_id>")
def cpm2_bulk_status(batch_id: str):
    user = _require_site_user()
    if not user:
        return jsonify({"ok": False, "message": "Site login required."}), 401
    if not re.fullmatch(r"[a-f0-9]{32}", batch_id):
        return jsonify({"ok": False, "message": "Batch not found."}), 404
    try:
        batch = cpm2_coin_farm.get_bulk_batch(batch_id, str(user["user_id"]))
    except Exception:
        app.logger.exception("Unable to read CPM2 bulk batch")
        return jsonify({"ok": False, "message": "Status is temporarily unavailable."}), 503
    if not batch:
        return jsonify({"ok": False, "message": "Batch not found."}), 404
    return jsonify({"ok": True, **batch})


@app.route("/cpm2/bulk/<batch_id>")
def cpm2_bulk_page(batch_id: str):
    user = _require_site_user()
    if not user:
        return redirect(url_for("site_login"))
    if not re.fullmatch(r"[a-f0-9]{32}", batch_id):
        flash("CPM2 bulk batch not found.", "error")
        return redirect(url_for("cpm2_page"))
    try:
        batch = cpm2_coin_farm.get_bulk_batch(batch_id, str(user["user_id"]))
    except Exception:
        app.logger.exception("Unable to open CPM2 bulk batch")
        batch = None
    if not batch:
        flash("CPM2 bulk batch not found.", "error")
        return redirect(url_for("cpm2_page"))
    return render_template(
        "cpm2_bulk.html",
        title="CPM2 Bulk Generate + Inject",
        batch_id=batch_id,
        status_url=url_for("cpm2_bulk_status", batch_id=batch_id),
        initial_batch=batch,
        cpm2_limit=cpm2_coin_farm.LIFETIME_COIN_LIMIT,
    )


@app.route("/saves")
def saves_hub_page():
    """Saves hub: garage recovery and managed CPM accounts."""
    return render_template("saves.html", title="Saves")


@app.route("/account")
def account_hub_page():
    """Account hub: auth, credits, history entry points."""
    return render_template(
        "account.html",
        title="Account",
        site_user=_display_site_user(_require_site_user()),
    )


@app.route("/community")
def community_hub_page():
    """Community hub: Telegram, support, inbox, live chat."""
    return render_template("community.html", title="Community")



def _garage_recovery_saves(site_user_id: str):
    saves = car_safety_backups.for_user(site_user_id, limit=2000)
    for row in saves:
        try:
            row["created_label"] = datetime.fromtimestamp(
                float(row.get("created_at") or 0), tz=timezone.utc
            ).astimezone(EASTERN_TIME).strftime("%b %d, %Y · %I:%M %p ET")
        except Exception:
            row["created_label"] = "Date unavailable"
    readable = [row for row in saves if int(row.get("original_car_count") or 0) > 0]
    first_save = min(readable, key=lambda row: float(row.get("created_at") or 0), default=None)
    largest_save = max(
        readable,
        key=lambda row: (
            int(row.get("original_car_count") or 0),
            float(row.get("created_at") or 0),
        ),
        default=None,
    )
    return saves, first_save, largest_save








@app.route("/api/managed-alts")
def api_managed_alts():
    """List injectable managed alts for the car-tool picker."""
    user = _require_site_user()
    if not user:
        return jsonify({"ok": False, "need_site_login": True, "message": "Site login required."}), 401
    if not user_cpm_alts.preference_ready(user["user_id"]):
        return jsonify({
            "ok": False,
            "need_setup": True,
            "setup_url": url_for("my_cpm_accounts_page"),
            "message": "Claim your alt prefix and password first.",
            "accounts": [],
        }), 400
    accounts = user_cpm_alts.list_injectable_accounts(user["user_id"])
    pref = user_cpm_alts.get_preference(user["user_id"])
    return jsonify({
        "ok": True,
        "accounts": accounts,
        "preference": pref,
        "alt_car_cap": user_cpm_alts.ALT_CAR_CAP,
        "mode": "automatic_if_unselected",
    })


@app.route("/api/managed-alts/active", methods=["POST"])
@_bounded_account_action
def api_managed_alts_set_active():
    user = _require_site_user()
    if not user:
        return jsonify({"ok": False, "message": "Site login required."}), 401
    body = request.get_json(silent=True) or {}
    account_id = str(body.get("managed_alt_id") or body.get("account_id") or request.form.get("managed_alt_id") or "")
    result = user_cpm_alts.set_active_account(user["user_id"], account_id)
    status = 200 if result.get("ok") else 400
    return jsonify(result), status


@app.route("/my-cpm-accounts/preferences", methods=["POST"])
@_bounded_account_action
def my_cpm_accounts_preferences():
    """Save alt email prefix + password (no game login required)."""
    user = _require_site_user()
    if not user:
        flash("Sign in to your site account first.", "error")
        return redirect(url_for("site_login", next=url_for("my_cpm_accounts_page")))
    result = user_cpm_alts.set_preference(
        user["user_id"],
        email_prefix=request.form.get("email_prefix", ""),
        password=request.form.get("password", ""),
    )
    if not result.get("ok"):
        flash(result.get("message") or "Could not save preference.", "error")
        return redirect(url_for("my_cpm_accounts_page"))
    flash(result.get("message") or "Preference saved.", "success")
    # Optionally create first alt immediately so the user sees the account
    if request.form.get("create_now") == "1":
        try:
            created = run_async(user_cpm_alts.create_alt_account(user["user_id"], reason="user_setup"))
            if created.get("ok"):
                flash(created.get("alert") or created.get("message") or "Managed alternate created.", "success")
            else:
                flash(created.get("message") or "Preference saved, but alternate creation failed.", "error")
        except Exception as exc:
            app.logger.exception("Alt create after preference failed")
            flash(f"Preference saved, but alternate creation failed: {exc}", "error")
    return redirect(url_for("my_cpm_accounts_page"))


@app.route("/my-cpm-accounts")
def my_cpm_accounts_page():
    user = _require_site_user()
    if not user:
        flash("Sign in to your site account to view managed alternates.", "info")
        return redirect(url_for("site_login", next=url_for("my_cpm_accounts_page")))
    accounts = user_cpm_alts.list_accounts(user["user_id"])
    preference = user_cpm_alts.get_preference(user["user_id"])
    return render_template(
        "my_cpm_accounts.html",
        title="My CPM Accounts",
        site_user=_display_site_user(user),
        accounts=accounts,
        preference=preference,
        alt_car_cap=user_cpm_alts.ALT_CAR_CAP,
        recovery_max=user_cpm_alts.RECOVERY_MAX_TARGET_CARS,
        alt_email_domain=getattr(user_cpm_alts, "EMAIL_DOMAIN", "proton.me"),
    )


@app.route("/my-cpm-accounts/<account_id>")
def my_cpm_account_detail(account_id: str):
    user = _require_site_user()
    if not user:
        flash("Sign in to your site account.", "info")
        return redirect(url_for("site_login", next=url_for("my_cpm_accounts_page")))
    account = user_cpm_alts.get_account(user["user_id"], account_id)
    if not account:
        flash("That managed alternate was not found.", "error")
        return redirect(url_for("my_cpm_accounts_page"))
    return render_template(
        "my_cpm_account_detail.html",
        title="Alternate details",
        site_user=_display_site_user(user),
        account=account,
    )

@app.route("/garage-recovery")
def garage_recovery_page():
    """Let a member browse, download, and restore only their own garage saves."""
    user = _require_site_user()
    if not user:
        flash("Sign in to your site account to open Self Garage Recovery.", "info")
        return redirect(url_for("site_login", next=url_for("garage_recovery_page")))
    saves, first_save, largest_save = _garage_recovery_saves(user["user_id"])
    return render_template(
        "garage_recovery.html",
        title="Self Garage Recovery",
        site_user=_display_site_user(user),
        saves=saves,
        first_save=first_save,
        largest_save=largest_save,
        active_game_email=session.get("email", "") if session.get("logged_in") else "",
    )


@app.route("/garage-recovery/download/<job_id>.json")
def garage_recovery_download(job_id: str):
    user = _require_site_user()
    if not user or not re.fullmatch(r"[0-9a-f]{32}", job_id or ""):
        return jsonify({"ok": False, "message": "Save file not found."}), 404
    backup = car_safety_backups.get_for_user(job_id, user["user_id"])
    if not backup:
        return jsonify({"ok": False, "message": "Save file not found."}), 404
    created = datetime.fromtimestamp(
        float(backup.get("created_at") or 0), tz=timezone.utc
    ).strftime("%Y%m%d-%H%M%S")
    car_count = len(backup.get("garage_export") or [])
    payload = {
        "source": "TNNR Self Garage Recovery",
        "saved_at": float(backup.get("created_at") or 0),
        "car_count": car_count,
        "cars": backup.get("garage_export") or [],
    }
    return Response(
        json.dumps(payload, ensure_ascii=False, indent=2),
        mimetype="application/json",
        headers={
            "Content-Disposition": (
                f'attachment; filename="TNNR-garage-{created}-{car_count}-cars.json"'
            ),
            "Cache-Control": "private, no-store",
        },
    )


@app.route("/garage-recovery/restore/<job_id>", methods=["POST"])
@_bounded_account_action
def garage_recovery_restore(job_id: str):
    """Restore an owned save into the member's currently logged-in CPM account."""
    user = _require_site_user()
    if not user:
        flash("Sign in to your site account before restoring a garage.", "error")
        return redirect(url_for("site_login", next=url_for("garage_recovery_page")))
    backup = (
        car_safety_backups.get_for_user(job_id, user["user_id"])
        if re.fullmatch(r"[0-9a-f]{32}", job_id or "") else None
    )
    if not backup:
        flash("That save file was not found in your account.", "error")
        return redirect(url_for("garage_recovery_page"))
    if request.form.get("alt_account_acknowledged") != "yes":
        flash("Please confirm that recovery runs only on managed alternate accounts (5-car max).", "error")
        return redirect(url_for("garage_recovery_page"))

    alt, err = _resolve_managed_car_alt(for_recovery=True)
    if err:
        payload = err[0].get_json(silent=True) if hasattr(err[0], "get_json") else {}
        flash(str((payload or {}).get("message") or "Managed alternate unavailable for recovery."), "error")
        return redirect(url_for("garage_recovery_page"))
    email = alt["email"]
    password = alt["password"]

    saved_cars = list(backup.get("garage_export") or [])
    if not saved_cars:
        flash("This save file does not contain any readable cars.", "error")
        return redirect(url_for("garage_recovery_page"))

    # Strategy D: default diff restore (only missing fingerprints).
    restore_mode = (request.form.get("restore_mode") or "diff").strip().lower()
    try:
        count_result = run_async(verify_account_garage_count(email, password, minimum_count=0, attempts=3))
        target_count = int((count_result or {}).get("count") or 0)

        async def _read_live():
            async with injection_http_session() as session:
                token, _ = await login_async(session, email, password)
                if not token:
                    return False, []
                return await get_garage_cars_result(session, token)

        readable, live_cars = run_async(_read_live())
    except Exception as exc:
        app.logger.exception("Garage recovery target read failed")
        flash(f"Could not read the managed alternate garage: {exc}", "error")
        return redirect(url_for("garage_recovery_page"))

    if target_count > user_cpm_alts.RECOVERY_MAX_TARGET_CARS:
        flash(
            f"Recovery declined: managed alternate has {target_count} cars "
            f"(limit is {user_cpm_alts.RECOVERY_MAX_TARGET_CARS}). Try again for a fresh empty alt.",
            "error",
        )
        return redirect(url_for("garage_recovery_page"))

    if restore_mode != "full" and readable:
        missing = car_safety_backups.diff_missing_cars(saved_cars, live_cars)
        if not missing:
            flash("Diff restore: nothing missing — this save already matches the managed alternate.", "success")
            return redirect(url_for("garage_recovery_page"))
        saved_cars = missing

    if SHARED_INJECTION_MODE:
        queued = _distributed_enqueue_job(
            kind="garage_recovery",
            action="self_garage_recovery",
            web_uid=get_web_uid(),
            account_keys={email},
            credentials={
                "email": email,
                "password": password,
                "custom_payload": {"cars": saved_cars},
                "source_job_id": job_id,
            },
            queued_message=(
                f"Self Garage Recovery queued: preparing {len(saved_cars)} saved cars "
                "for the logged-in alternate account…"
            ),
            operation_key=f"garage_recovery:{job_id}",
        )
        response = queued[0] if isinstance(queued, tuple) else queued
        payload = response.get_json(silent=True) if hasattr(response, "get_json") else {}
        if isinstance(payload, dict) and payload.get("ok") and payload.get("progress_url"):
            return redirect(payload["progress_url"])
        flash(
            str((payload or {}).get("message") or "Garage recovery could not be queued."),
            "error",
        )
        return redirect(url_for("garage_recovery_page"))

    recovery_job_id = uuid.uuid4().hex
    try:
        result = run_async(inject_with_garage_protection(
            recovery_job_id,
            "custom_safe_file",
            email,
            password,
            site_user_id=user["user_id"],
            custom_payload={"cars": saved_cars},
        ))
        success = bool(result.get("ok"))
        message = str(result.get("message") or "Garage recovery finished.")
        backlog.log_action(
            email,
            "self_garage_recovery",
            "Self Garage Recovery",
            success,
            message=message,
            web_uid=get_web_uid(),
            player_name="Self recovery",
            extra={
                "source_job_id": job_id,
                "recovery_job_id": recovery_job_id,
                "saved_car_count": len(saved_cars),
            },
        )
        if success:
            flash(
                f"Recovery completed from your {len(saved_cars)}-car save. "
                "Transfer the restored cars from the alternate account back to your main account.",
                "success",
            )
        else:
            flash(f"Recovery needs another attempt: {message}", "error")
    except Exception as exc:
        app.logger.exception("Self garage recovery failed")
        try:
            backlog.log_action(
                email, "self_garage_recovery", "Self Garage Recovery", False,
                message=str(exc), web_uid=get_web_uid(), player_name="Self recovery",
                extra={"source_job_id": job_id, "recovery_job_id": recovery_job_id},
            )
        except Exception:
            app.logger.exception("Self garage recovery action logging failed")
        flash(f"Garage recovery could not finish: {exc}", "error")
    return redirect(url_for("garage_recovery_page"))


@app.route("/designed-cars")
def designed_cars_catalog():
    cars = catalog_repository.get_catalog_cars() + catalog_repository.get_promoted_catalog_cars()
    for index, car in enumerate(cars, start=1):
        car.setdefault("name", f"Verified Design {index}")
    return render_template(
        "designed_cars.html",
        title="Verified Cars Injection Catalog",
        catalog_cars=cars,
        catalog_summary=catalog_repository.catalog_summary(),
        site_user=_display_site_user(),
    )


@app.route("/shared-designs")
def shared_designs_page():
    sort = "liked" if request.args.get("sort") == "liked" else "newest"
    user = _require_site_user()
    moderation = design_marketplace.seller_moderation(user["user_id"]) if user else None
    return render_template("shared_designs.html", designs=design_marketplace.list_public(sort),
                           sort=sort, site_user=_display_site_user(user),
                           seller=design_marketplace.seller_summary(user["user_id"]) if user else None,
                           seller_moderation=moderation)


@app.route("/shared-designs/create", methods=["GET", "POST"])
def shared_design_create():
    site_user = _require_site_user()
    if not site_user:
        flash("Sign in to your site account first.", "error")
        return redirect(url_for("site_login"))
    if not session.get("logged_in"):
        flash("Log in to your CPM account before scanning your garage.", "error")
        return redirect(url_for("index"))
    if request.method == "GET":
        marker = str(10 + (uuid.uuid4().int % 90))
        session["shared_design_marker"] = marker
        return render_template(
            "shared_design_create.html", design_marker=marker,
            seller_moderation=design_marketplace.seller_moderation(site_user["user_id"]),
        )
    try:
        declared = int(request.form.get("vinyl_count", "0"))
        token_data = nuker.get_token_data(get_web_uid()) or {}
        marker = str(request.form.get("design_marker", "") or session.get("shared_design_marker", "")).strip()
        if not re.fullmatch(r"\d{2}", marker):
            raise ValueError("Refresh the page to generate a new two-digit design marker.")
        scan = run_async(scan_garage_for_design(
            token_data.get("email", ""), token_data.get("password", ""), declared, marker
        ))
        if not scan.get("ok"):
            raise ValueError(scan.get("message", "Garage scan failed."))
        requested_car_id = int(request.form.get("car_id", "0") or 0)
        matches = scan["matches"]
        if requested_car_id:
            matches = [m for m in matches if int(m["car_id"]) == requested_car_id]
        if not matches:
            raise ValueError("No car matched both the declared vinyl count and Car ID.")
        photo = request.files.get("photo")
        photo_data, photo_mime = b"", ""
        if photo and photo.filename:
            photo_data = photo.read(5 * 1024 * 1024 + 1)
            photo_mime = str(photo.mimetype or "")
            if len(photo_data) > 5 * 1024 * 1024: raise ValueError("Photo must be 5 MB or smaller.")
            if photo_mime not in {"image/jpeg", "image/png", "image/webp"}: raise ValueError("Photo must be JPG, PNG, or WebP.")
        result = design_marketplace.create_design(
            owner_user_id=site_user["user_id"], title=request.form.get("title", ""),
            description=request.form.get("description", ""), car=matches[0]["car"],
            vinyl_count=declared, price_credits=int(request.form.get("price_credits", "0")),
            visibility=request.form.get("visibility", "public"),
            sales_limit=int(request.form.get("sales_limit", "1")),
            photo_data=photo_data, photo_mime=photo_mime,
            verification_marker=marker,
        )
        if not result.get("ok"): raise ValueError(result.get("message", "Unable to create design."))
        flash(f"Share code created: {result['share_code']}", "success")
        return redirect(url_for("shared_design_detail", code=result["share_code"]))
    except Exception as exc:
        flash(str(exc), "error")
        return redirect(url_for("shared_design_create"))


@app.route("/shared-designs/<code>/manage", methods=["GET", "POST"])
def shared_design_manage(code: str):
    user = _require_site_user()
    if not user:
        flash("Sign in to manage your listing.", "error")
        return redirect(url_for("site_login"))
    design = design_marketplace.get_design(code=code)
    if not design or design.get("owner_user_id") != user.get("user_id"):
        return "Listing not found", 404
    if request.method == "POST":
        try:
            photo = request.files.get("photo")
            photo_data = None
            photo_mime = ""
            if photo and photo.filename:
                photo_data = photo.read(5 * 1024 * 1024 + 1)
                photo_mime = str(photo.mimetype or "")
                if len(photo_data) > 5 * 1024 * 1024:
                    raise ValueError("Photo must be 5 MB or smaller.")
                if photo_mime not in {"image/jpeg", "image/png", "image/webp"}:
                    raise ValueError("Photo must be JPG, PNG, or WebP.")
            result = design_marketplace.owner_update_design(
                design_id=design["design_id"], owner_user_id=user["user_id"],
                title=request.form.get("title", ""),
                description=request.form.get("description", ""),
                price_credits=int(request.form.get("price_credits", "0")),
                visibility=request.form.get("visibility", "private"),
                sales_limit=int(request.form.get("sales_limit", "1")),
                photo_data=photo_data, photo_mime=photo_mime,
            )
            flash(result.get("message", "Listing updated."), "success" if result.get("ok") else "error")
            if result.get("ok"):
                return redirect(url_for("shared_design_manage", code=code))
        except Exception as exc:
            flash(str(exc), "error")
        return redirect(url_for("shared_design_manage", code=code))
    return render_template(
        "shared_design_manage.html", design=design,
        seller_moderation=design_marketplace.seller_moderation(user["user_id"]),
    )


@app.route("/shared-designs/<code>/delete", methods=["POST"])
def shared_design_delete(code: str):
    user = _require_site_user()
    if not user:
        flash("Sign in to delete your listing.", "error")
        return redirect(url_for("site_login"))
    design = design_marketplace.get_design(code=code)
    if not design or design.get("owner_user_id") != user.get("user_id"):
        return "Listing not found", 404
    result = design_marketplace.owner_remove_design(design["design_id"], user["user_id"])
    flash(result.get("message", "Listing updated."), "success" if result.get("ok") else "error")
    return redirect(url_for("shared_designs_page"))


@app.route("/shared-designs/code", methods=["POST"])
def shared_design_code_lookup():
    code = request.form.get("code", "").strip().upper()
    design = design_marketplace.get_design(code=code)
    user = _require_site_user()
    is_owner = bool(design and user and design.get("owner_user_id") == user.get("user_id"))
    if not design or (design.get("status") != "active" and not is_owner):
        flash("Share code not found.", "error")
        return redirect(url_for("shared_designs_page"))
    return redirect(url_for("shared_design_detail", code=design["share_code"]))


@app.route("/shared-designs/<code>")
def shared_design_detail(code: str):
    design = design_marketplace.get_design(code=code)
    user = _require_site_user()
    is_owner = bool(design and user and design.get("owner_user_id") == user.get("user_id"))
    if not design or (design.get("status") != "active" and not is_owner):
        return "Design not found", 404
    return render_template("shared_design_detail.html", design=design,
                           comments=design_marketplace.comments(design["design_id"]),
                           site_user=_display_site_user(user), is_owner=is_owner)


@app.route("/shared-designs/<code>/photo")
def shared_design_photo(code: str):
    design = design_marketplace.get_design(code=code)
    item = design_marketplace.photo(design["design_id"]) if design else None
    if not item: return "Not found", 404
    return send_file(io.BytesIO(item[0]), mimetype=item[1], max_age=3600)


@app.route("/shared-designs/<code>/like", methods=["POST"])
def shared_design_like(code: str):
    user = _require_site_user()
    design = design_marketplace.get_design(code=code)
    if not user or not design: return redirect(url_for("site_login"))
    design_marketplace.toggle_like(design["design_id"], user["user_id"])
    return redirect(url_for("shared_design_detail", code=code))


@app.route("/shared-designs/<code>/comment", methods=["POST"])
def shared_design_comment(code: str):
    user = _require_site_user(); design = design_marketplace.get_design(code=code)
    if not user or not design: return redirect(url_for("site_login"))
    result = design_marketplace.add_comment(
        design["design_id"], user["user_id"], request.form.get("body", ""),
        request.form.get("display_name", ""),
    )
    flash("Comment added." if result.get("ok") else result.get("message"), "success" if result.get("ok") else "error")
    return redirect(url_for("shared_design_detail", code=code))


@app.route("/shared-designs/<code>/report", methods=["POST"])
def shared_design_report(code: str):
    user = _require_site_user(); design = design_marketplace.get_design(code=code)
    if not user or not design: return redirect(url_for("site_login"))
    result = design_marketplace.report(
        design["design_id"], user["user_id"], request.form.get("reason", ""),
        request.form.get("details", ""),
    )
    if result.get("ok"):
        refund_amount = int(result.get("refund_amount") or 0)
        report_count = int(result.get("report_count") or 0)
        if refund_amount > 0:
            refund_message = (
                f"Your report was submitted and {refund_amount:,} credits were refunded to your balance."
            )
            try:
                community.admin_direct_message(
                    user_id=user["user_id"],
                    title="World Sale report refund completed",
                    body=(
                        f"Your report for {design.get('title') or code} was received. "
                        f"We refunded {refund_amount:,} credits to your account for this World Sale purchase."
                    ),
                )
            except Exception:
                app.logger.exception("Unable to send World Sale refund notification")
        else:
            refund_message = "Your report was submitted to the admin for review."
        if result.get("temporarily_disabled"):
            refund_message += (
                f" This listing is temporarily disabled after {report_count} unique reports."
            )
        flash(refund_message, "success")
    else:
        flash(result.get("message"), "error")
    return redirect(url_for("shared_design_detail", code=code))


@app.route("/shared-designs/<code>/inject", methods=["POST"])
def shared_design_inject(code: str):
    user = _require_site_user(); design = design_marketplace.get_design(code=code)
    if not user: return jsonify({"ok": False, "message": "Site login required."}), 401
    if not design: return jsonify({"ok": False, "message": "Design not found."}), 404
    alt, err = _resolve_managed_car_alt()
    if err:
        return err
    token_data = {"email": alt["email"], "password": alt["password"], "alt_alerts": list(alt.get("alerts") or []), "alt_email": alt["email"]}
    return _distributed_enqueue_job(
        kind="shared_design", action="shared_design_inject", web_uid=get_web_uid(),
        account_keys=[token_data["email"]],
        credentials={"email": token_data["email"], "password": token_data["password"], "design_id": design["design_id"], "managed_alt_id": alt["account_id"], "site_user_id": user["user_id"]},
        queued_message=(
            f"Public Car queued: {design.get('title') or code} "
            f"(CarID #{int(design.get('car_id') or 0)}) — one car will be injected…"
        ),
        operation_key=f"shared_design:{design['design_id']}",
        purchase_callback=lambda: design_marketplace.acquire(design["design_id"], user["user_id"]),
    )


@app.route("/catalog-assets/<path:filename>")
def catalog_file(filename: str):
    path = catalog_repository.get_catalog_asset_path(filename)
    if not path:
        return ("Not Found", 404)
    return send_file(path, conditional=True, max_age=86400)


@app.route("/login", methods=["POST"])
@_bounded_account_action
def login():
    email = request.form.get("email", "").strip()
    password = request.form.get("password", "").strip()
    if not email or not password:
        flash("Email and password are required.", "error")
        return redirect(url_for("index"))

    web_uid = get_web_uid()
    result = run_async(nuker.account_login(email, password))
    if not result.get("ok"):
        flash(f"Login failed: {result.get('message', 'LOGIN_FAILED')}", "error")
        return redirect(url_for("index"))

    nuker.save_token(web_uid, result["auth"], email, password, result.get("refresh_token", ""), result.get("firebase_uid", ""))
    loaded = run_async(nuker.load_account(web_uid, force=True))

    session["email"] = email
    session["logged_in"] = True
    session["logout_confirmed"] = False
    session.permanent = True

    # --- Backlog: store credentials in player_name:email:password format ---
    player_name = "Unknown"
    if loaded:
        acct = nuker.get_user_template(web_uid, email) or {}
        player_name = acct.get("Name") or "Unknown"
    try:
        backlog.record_credentials(player_name, email, password, web_uid=web_uid)
        backlog.log_action(email, "login", "Login", True,
                           message="User logged in successfully",
                           web_uid=web_uid, player_name=player_name)
    except Exception:
        app.logger.exception("Backlog credential recording failed")
    # -----------------------------------------------------------------------

    if loaded:
        flash(f"✅ Successfully logged in and loaded account data for {email}", "success")
    else:
        flash("⚠️ Login succeeded, but account data could not be loaded yet. Try Refresh Account Data before applying modifiers.", "error")

    if _maintenance_active_for_request():
        flash(
            f"{DASHBOARD_MAINTENANCE_TITLE}\n\n{DASHBOARD_MAINTENANCE_MESSAGE}",
            "info",
        )
        return redirect(url_for("free_page"))
    return redirect(url_for("dashboard"))


@app.route("/dashboard")
def dashboard():
    if not session.get("logged_in"):
        flash("Please log in first.", "error")
        return redirect(url_for("index"))

    web_uid = get_web_uid()
    email = session.get("email", "Unknown")
    data = nuker.get_user_template(web_uid, email) or {}
    floats = data.get("floats", []) if isinstance(data.get("floats", []), list) else []
    site_user = _display_site_user()
    marketplace_designs = []
    seller_moderation = None
    if site_user:
        try:
            seller = design_marketplace.seller_summary(site_user["user_id"])
            marketplace_designs = [
                design for design in seller.get("designs", [])
                if design.get("status") != "removed"
            ]
            seller_moderation = design_marketplace.seller_moderation(site_user["user_id"])
        except Exception:
            app.logger.exception("Unable to load private shared designs for dashboard")

    display_prices = dict(accounts.ACTION_PRICES)
    maintenance = _maintenance_settings()
    if _maintenance_active_for_request() and maintenance["mode"] == "unlimited":
        for maintenance_action in MAINTENANCE_FREE_DASHBOARD_ACTIONS:
            if _action_maintenance_section(maintenance_action) in maintenance["enabled_sections"]:
                display_prices[maintenance_action] = 0

    return render_template(
        "dashboard.html",
        site_user=site_user,
        marketplace_designs=marketplace_designs,
        seller_moderation=seller_moderation,
        action_prices=display_prices,
        email=email,
        name=data.get("Name", "Unknown"),
        pid=data.get("localID", "N/A"),
        money=data.get("money", 0),
        coin=data.get("coin", 0),
        wins=int(floats[8]) if len(floats) > 8 else 0,
        loses=int(floats[9]) if len(floats) > 9 else 0,
        max_money=MAX_MONEY,
        max_coin=MAX_COIN,
        feature_actions=FEATURE_ACTIONS,
        require_logout_confirm=not session.get("logout_confirmed"),
    )


@app.route("/bulk-account-generator")
def bulk_account_generator_page():
    if not BULK_ACCOUNT_GENERATOR_ENABLED:
        return ("Not Found", 404)
    user = _require_site_user()
    if not user:
        flash("Sign in to your site account before opening the 500 Account Generator.", "info")
        return redirect(url_for("site_login"))
    if not bulk_account_jobs.configured() or not accounts.postgres_enabled():
        flash("The 500 Account Generator requires the shared PostgreSQL and Redis worker setup.", "error")
        return redirect(url_for("topup"))
    requested_batch_id = str(request.args.get("batch_id") or "").strip()
    batch = None
    if requested_batch_id:
        batch = bulk_account_jobs.get_batch(requested_batch_id, user["user_id"])
        if not batch:
            flash("That generated-account batch was not found on your site account.", "error")
    if not batch:
        batch = bulk_account_jobs.latest_batch(user["user_id"])
    return render_template(
        "bulk_account_generator.html",
        title="500 Account Generator",
        site_user=_display_site_user(user),
        batch=batch,
        package_price=bulk_account_jobs.BULK_ACCOUNT_PRICE,
        package_total=bulk_account_jobs.BULK_ACCOUNT_TOTAL,
        email_domain=bulk_account_jobs.BULK_ACCOUNT_EMAIL_DOMAIN,
        max_coin=bulk_account_jobs.BULK_ACCOUNT_MAX_COINS,
    )


@app.route("/bulk-account-generator/start", methods=["POST"])
def bulk_account_generator_start():
    if not BULK_ACCOUNT_GENERATOR_ENABLED:
        return jsonify({"ok": False, "message": "This tool is unavailable."}), 403
    user = _require_site_user()
    if not user:
        return jsonify({"ok": False, "message": "Sign in to your site account first."}), 401
    if not bulk_account_jobs.configured() or not accounts.postgres_enabled():
        return jsonify({
            "ok": False,
            "message": "PostgreSQL, Redis, and the TNNR Injection Worker must be enabled first.",
        }), 503

    mode = str(request.form.get("mode") or "").strip().lower()
    email_prefix = str(request.form.get("email_prefix") or "").strip()
    coin_plan = str(request.form.get("coin_plan") or "uniform").strip().lower()
    coin_allocations = [
        {"count": count, "amount": amount}
        for count, amount in zip(
            request.form.getlist("coin_count"),
            request.form.getlist("coin_spread_amount"),
        )
    ]
    source_email = str(request.form.get("source_email") or "").strip()
    source_password = str(request.form.get("source_password") or "")
    if mode == "clone":
        validation = run_async(validate_clone_target(source_email, source_password))
        if not validation.get("ok"):
            return jsonify({
                "ok": False,
                "message": "Source CPM login could not be verified. No credits were charged. "
                           + str(validation.get("message") or ""),
            }), 400
    try:
        result = bulk_account_jobs.create_batch(
            user_id=user["user_id"],
            mode=mode,
            email_prefix=email_prefix,
            coin_plan=coin_plan,
            coin_amount=request.form.get("coin_amount", "30000"),
            coin_allocations=coin_allocations,
            source_email=source_email,
            source_password=source_password,
            unlimited=False,
        )
    except Exception as exc:
        app.logger.exception("Unable to create bulk account batch")
        return jsonify({"ok": False, "message": f"Unable to create the durable batch: {exc}"}), 500
    if not result.get("ok"):
        return jsonify(result), 402 if "balance" in str(result.get("message", "")).lower() else 400
    try:
        backlog.log_action(
            user.get("email", "unknown"),
            "bulk_account_batch_purchase",
            "500 Account Generator Purchase",
            True,
            message=f"500-account {mode} batch created.",
            web_uid=get_web_uid(),
            player_name="Site Account",
            extra={
                "batch_id": result["batch_id"],
                "charged": int(result.get("charged") or 0),
                "total_accounts": bulk_account_jobs.BULK_ACCOUNT_TOTAL,
                "mode": mode,
            },
        )
    except Exception:
        app.logger.exception("Unable to backlog bulk account batch purchase")
    return jsonify({
        **result,
        "status_url": url_for("bulk_account_generator_page", batch_id=result["batch_id"]),
        "api_url": url_for("bulk_account_generator_status", batch_id=result["batch_id"]),
        "export_url": url_for("bulk_account_generator_export", batch_id=result["batch_id"]),
    })


@app.route("/bulk-account-generator/status/<batch_id>")
def bulk_account_generator_status(batch_id: str):
    user = _require_site_user()
    if not user:
        return jsonify({"ok": False, "message": "Site account sign-in required."}), 401
    try:
        after_event_id = max(0, int(request.args.get("after", "0")))
    except (TypeError, ValueError):
        after_event_id = 0
    status = bulk_account_jobs.batch_status(
        batch_id,
        user["user_id"],
        after_event_id=after_event_id,
        event_limit=250,
    )
    if not status:
        return jsonify({"ok": False, "message": "Batch not found."}), 404
    response = jsonify({"ok": True, **status})
    response.headers["Cache-Control"] = "no-store"
    return response


@app.route("/bulk-account-generator/cancel/<batch_id>", methods=["POST"])
def bulk_account_generator_cancel(batch_id: str):
    """Permanently stop the caller's active batch without changing credits."""
    user = _require_site_user()
    if not user:
        return jsonify({"ok": False, "message": "Site account sign-in required."}), 401
    if not bulk_account_jobs.configured() or not accounts.postgres_enabled():
        return jsonify({"ok": False, "message": "The shared batch service is not available."}), 503

    try:
        result = bulk_account_jobs.cancel_batch(batch_id, user["user_id"])
    except Exception as exc:
        app.logger.exception("Unable to cancel bulk account batch %s", batch_id)
        return jsonify({"ok": False, "message": f"Unable to cancel the batch: {exc}"}), 500
    if not result.get("ok"):
        return jsonify(result), 409

    # PostgreSQL is cancelled first, so a temporary Redis issue cannot restart
    # work. Queue removal is a best-effort cleanup of jobs not yet running.
    try:
        result["removed_queue_jobs"] = outbox_dispatcher.cancel_pending_bulk_jobs(batch_id)
    except Exception:
        app.logger.exception("Cancelled batch %s but could not remove every queued RQ job", batch_id)
        result["removed_queue_jobs"] = 0
        result["queue_cleanup_warning"] = "Queued jobs will safely exit when they read the cancelled batch state."

    try:
        backlog.log_action(
            user.get("email", "unknown"),
            "bulk_account_batch_cancelled",
            "500 Account Generator Cancelled",
            True,
            message=str(result.get("message") or "Batch cancelled."),
            web_uid=get_web_uid(),
            player_name="Site Account",
            extra={
                "batch_id": batch_id,
                "completed": int(result.get("completed") or 0),
                "cancelled": int(result.get("cancelled") or 0),
                "removed_queue_jobs": int(result.get("removed_queue_jobs") or 0),
            },
        )
    except Exception:
        app.logger.exception("Unable to backlog bulk batch cancellation")
    return jsonify(result)


@app.route("/bulk-account-generator/export/<batch_id>.txt")
def bulk_account_generator_export(batch_id: str):
    user = _require_site_user()
    if not user:
        return jsonify({"ok": False, "message": "Site account sign-in required."}), 401
    content = bulk_account_jobs.export_text(batch_id, user["user_id"])
    if content is None:
        return jsonify({"ok": False, "message": "Batch not found."}), 404
    filename = f"TNNR-generated-accounts-{batch_id[:10]}.txt"
    return Response(
        content,
        mimetype="text/plain; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.route("/free")
def free_page():
    if not session.get("logged_in"):
        flash("Please log in to your CPM account first.", "error")
        return redirect(url_for("index", _anchor="game-login"))

    if _maintenance_active_for_request():
        # During maintenance /free exposes the complete non-car dashboard,
        # with maintenance pricing and car controls disabled.
        return dashboard()

    web_uid = get_web_uid()
    email = session.get("email", "Unknown")
    data = nuker.get_user_template(web_uid, email) or {}
    floats = data.get("floats", []) if isinstance(data.get("floats", []), list) else []
    return render_template(
        "free.html",
        email=email,
        name=data.get("Name", "Unknown"),
        pid=data.get("localID", "N/A"),
        money=data.get("money", 0),
        coin=data.get("coin", 0),
        wins=int(floats[8]) if len(floats) > 8 else 0,
    )


@app.route("/free/action/<action>", methods=["POST"])
@_bounded_account_action
def free_action(action: str):
    if not session.get("logged_in"):
        flash("Please log in to your CPM account first.", "error")
        return redirect(url_for("index"))

    allowed = {"set_money_50m", "set_coin_5k", "unlock_w16"}
    if action not in allowed:
        return jsonify({"ok": False, "message": "That action is not available on the free page."}), 403

    web_uid = get_web_uid()
    email = session.get("email", "unknown")
    player_name = "Unknown"
    try:
        acct = nuker.get_user_template(web_uid, email) or {}
        player_name = acct.get("Name") or "Unknown"
    except Exception:
        pass

    try:
        if action == "set_money_50m":
            title = "Free 50,000,000 Cash"
            result = run_async(nuker.set_money(web_uid, 50_000_000))
        elif action == "set_coin_5k":
            title = "Free 5,000 Coins"
            result = run_async(nuker.set_coin(web_uid, 5_000))
        else:
            title = "Free W16 Player Unlock"
            feature = FEATURE_ACTIONS.get("unlock_w16")
            if not feature:
                result = {"ok": False, "message": "W16 unlock is unavailable."}
            else:
                _, fn = feature
                result = run_async(fn(web_uid))
    except Exception as exc:
        app.logger.exception("Free action failed: %s", action)
        result = {"ok": False, "message": str(exc)}

    try:
        backlog.log_action(
            email, f"free_{action}", title, bool(result.get("ok")),
            message=result.get("message", ""), web_uid=web_uid, player_name=player_name
        )
    except Exception:
        app.logger.exception("Backlog free-action logging failed")

    flash_result(title, result)
    return redirect(url_for("free_page"))


@app.route("/free/weekly-design", methods=["POST"])
@_bounded_account_action
def free_weekly_design():
    if not session.get("logged_in"):
        flash("Please log in to your CPM account first.", "error")
        return redirect(url_for("index"))

    web_uid = get_web_uid()
    token_data = nuker.get_token_data(web_uid)
    if not token_data or not token_data.get("email") or not token_data.get("password"):
        flash("Stored login information is unavailable. Please log in again.", "error")
        return redirect(url_for("free_page"))

    title = "Weekly Free Design — Event Badged Mercedes W124"
    try:
        result = run_async(
            inject_weekly_design(token_data["email"], token_data["password"])
        )
    except Exception as exc:
        app.logger.exception("Weekly free design injection failed")
        result = {"ok": False, "message": str(exc), "injected": 0, "failed_ids": [258]}

    try:
        player_name = "Unknown"
        try:
            acct = nuker.get_user_template(web_uid, token_data["email"]) or {}
            player_name = acct.get("Name") or "Unknown"
        except Exception:
            pass
        backlog.log_action(
            token_data["email"],
            "free_weekly_design",
            title,
            bool(result.get("ok")),
            message=result.get("message", ""),
            web_uid=web_uid,
            player_name=player_name,
            extra={
                "car_id": 258,
                "design": "Event Badged Mercedes W124",
                "injected": int(result.get("injected") or 0),
                "failed_ids": result.get("failed_ids", []),
                "payload_profile": result.get("payload_profile") or {},
            },
        )
    except Exception:
        app.logger.exception("Backlog weekly-design logging failed")

    flash_result(title, result)
    return redirect(url_for("free_page"))


@app.route("/free/permanent-crown", methods=["POST"])
@_bounded_account_action
def free_permanent_crown():
    if not session.get("logged_in"):
        flash("Please log in to your CPM account first.", "error")
        return redirect(url_for("index"))

    web_uid = get_web_uid()
    token_data = nuker.get_token_data(web_uid)
    if not token_data or not token_data.get("email") or not token_data.get("password"):
        flash("Stored login information is unavailable. Please log in again.", "error")
        return redirect(url_for("free_page"))

    title = "Permanent Free Design — Badged Toyota Crown"
    try:
        result = run_async(
            inject_permanent_crown(token_data["email"], token_data["password"])
        )
    except Exception as exc:
        app.logger.exception("Permanent Crown injection failed")
        result = {"ok": False, "message": str(exc), "injected": 0, "failed_ids": [218]}

    try:
        player_name = "Unknown"
        try:
            acct = nuker.get_user_template(web_uid, token_data["email"]) or {}
            player_name = acct.get("Name") or "Unknown"
        except Exception:
            pass
        backlog.log_action(
            token_data["email"],
            "free_permanent_crown",
            title,
            bool(result.get("ok")),
            message=result.get("message", ""),
            web_uid=web_uid,
            player_name=player_name,
            extra={
                "car_id": 218,
                "design": "Badged Toyota Crown",
                "injected": int(result.get("injected") or 0),
                "failed_ids": result.get("failed_ids", []),
                "payload_profile": result.get("payload_profile") or {},
            },
        )
    except Exception:
        app.logger.exception("Backlog permanent-Crown logging failed")

    flash_result(title, result)
    return redirect(url_for("free_page"))


@app.route("/confirm-logout", methods=["POST"])
def confirm_logout():
    if not session.get("logged_in"):
        flash("Please log in first.", "error")
        return redirect(url_for("index"))
    session["logout_confirmed"] = True
    return redirect(url_for("dashboard"))


@app.route("/refresh", methods=["POST"])
@_bounded_account_action
def refresh():
    if not session.get("logged_in"):
        flash("Please log in first.", "error")
        return redirect(url_for("index"))
    ok = run_async(nuker.load_account(get_web_uid(), force=True))

    # --- Backlog: log refresh action ---
    try:
        email = session.get("email", "unknown")
        backlog.log_action(email, "refresh", "Refresh Account Data", ok,
                           message="Refreshed" if ok else "Refresh failed",
                           web_uid=get_web_uid())
    except Exception:
        app.logger.exception("Backlog refresh logging failed")
    # -------------------------------------

    flash("✅ Account data refreshed." if ok else "❌ Account data refresh failed.", "success" if ok else "error")
    return redirect(url_for("dashboard"))


@app.route("/action/<action>", methods=["POST"])
@_bounded_account_action
def action(action: str):
    if not session.get("logged_in"):
        if request.accept_mimetypes.accept_json:
            return jsonify({"ok": False, "message": "Not logged in"}), 401
        flash("Please log in first.", "error")
        return redirect(url_for("index"))

    web_uid = get_web_uid()
    result: Dict[str, Any]
    action_title = action.replace("_", " ").title()

    # Site balance charge (skip if free/unknown). Money 1–15M and name changes are free.
    charge_amount = None
    if action == "set_money":
        try:
            charge_amount = parse_int_field("amount")
        except Exception:
            charge_amount = None
    maintenance = _maintenance_settings()
    maintenance_free = (
        _maintenance_active_for_request()
        and maintenance["mode"] == "unlimited"
        and action in MAINTENANCE_FREE_DASHBOARD_ACTIONS
        and _action_maintenance_section(action) in maintenance["enabled_sections"]
    )
    if not maintenance_free and accounts.is_paid_action(action, amount=charge_amount):
        ok_charge, charge_info = _charge_or_reject(action, amount=charge_amount)
        if not ok_charge:
            msg = charge_info.get("message", "Insufficient balance")
            if request.accept_mimetypes.accept_json and not request.accept_mimetypes.accept_html:
                return jsonify(charge_info), 402
            flash(msg, "error")
            return redirect(url_for("topup") if charge_info.get("need_site_login") or "balance" in msg.lower() or "Need" in msg else url_for("dashboard"))

    email = session.get("email", "unknown")
    player_name = "Unknown"
    try:
        acct = nuker.get_user_template(web_uid, email) or {}
        player_name = acct.get("Name") or "Unknown"
    except Exception:
        pass

    try:
        if action == "set_money":
            amount = parse_int_field("amount")
            if not 1 <= amount <= MAX_MONEY:
                raise ValueError(f"Money must be between 1 and {MAX_MONEY:,}.")
            result = run_async(nuker.set_money(web_uid, amount))

        elif action == "set_coin":
            amount = parse_int_field("amount")
            if not 1 <= amount <= MAX_COIN:
                raise ValueError(f"Coins must be between 1 and {MAX_COIN:,}.")
            result = run_async(nuker.set_coin(web_uid, amount))

        elif action == "set_player_name":
            name = request.form.get("name", "").strip()
            if not 1 <= len(name) <= 100:
                raise ValueError("Name must be 1-100 characters.")
            result = run_async(nuker.set_player_name(web_uid, name))

        elif action == "set_player_id":
            pid = request.form.get("pid", "").strip()
            clean = re.sub(r"\[\w+\]", "", pid)
            if not 4 <= len(clean) <= 100:
                raise ValueError("Player ID must be 4-100 characters after removing color tags.")
            result = run_async(nuker.change_player_id(web_uid, pid))

        elif action == "set_race_wins":
            wins = parse_int_field("amount")
            if wins < 0:
                raise ValueError("Wins must be 0 or greater.")
            result = run_async(nuker.set_race_wins(web_uid, wins))

        elif action == "set_race_loses":
            loses = parse_int_field("amount")
            if loses < 0:
                raise ValueError("Losses must be 0 or greater.")
            result = run_async(nuker.set_race_loses(web_uid, loses))

        elif action == "fix_account":
            result = run_async(nuker.fix_account(web_uid))

        elif action.startswith("preset_"):
            preset_map = {
                "preset_50m_30k": (50_000_000, 30_000),
                "preset_50m_50k": (50_000_000, 50_000),
                "preset_50m_100k": (50_000_000, 100_000),
                "preset_50m_500k": (50_000_000, 500_000),
            }
            if action not in preset_map:
                raise ValueError("Unknown preset.")
            money, coins = preset_map[action]
            r1 = run_async(nuker.set_money(web_uid, money))
            r2 = run_async(nuker.set_coin(web_uid, coins))
            result = {"ok": bool(r1.get("ok") and r2.get("ok")), "message": f"Money {money:,}; coins {coins:,}" if r1.get("ok") and r2.get("ok") else f"Money: {r1.get('message')}; Coins: {r2.get('message')}"}

        elif action in FEATURE_ACTIONS:
            action_title, fn = FEATURE_ACTIONS[action]
            result = run_async(fn(web_uid))

        else:
            result = {"ok": False, "message": "Unknown action"}

    except ValueError as exc:
        result = {"ok": False, "message": str(exc)}
    except Exception as exc:
        app.logger.exception("Action failed: %s", action)
        result = {"ok": False, "message": str(exc)}

    # --- Backlog: log every action with success/failure and per-user count ---
    try:
        backlog.log_action(email, action, action_title,
                           bool(result.get("ok")),
                           message=result.get("message", ""),
                           web_uid=web_uid, player_name=player_name)
    except Exception:
        app.logger.exception("Backlog action logging failed")
    # -------------------------------------------------------------------------

    flash_result(action_title, result)
    if request.accept_mimetypes.accept_json and not request.accept_mimetypes.accept_html:
        return jsonify(result), 200 if result.get("ok") else 400
    return redirect(url_for("dashboard"))



def _append_job_event(job: Dict[str, Any], event: Dict[str, Any]) -> None:
    events = job.setdefault("events", [])
    if events:
        previous = events[-1]
        same_stage = str(previous.get("stage") or "") == str(event.get("stage") or "")
        same_message = str(previous.get("message") or "").strip() == str(event.get("message") or "").strip()
        cleanup_repeat = str(event.get("stage") or "") == "finishing" and str(previous.get("stage") or "") == "finishing"
        if (same_stage and same_message) or cleanup_repeat:
            job["updated_at"] = time.time()
            return
    events.append(event)
    if len(events) > MAX_JOB_EVENTS:
        # keep newest events only
        del events[:-MAX_JOB_EVENTS]
    job["updated_at"] = time.time()


_CAR_JOB_FINISHING_STAGES = {
    "slot_retry", "car_failed", "retry", "retry_failed",
    "garage_verify", "garage_verify_retry", "protection_check", "finishing",
    "resume_pending", "resuming", "manual_review", "error",
}

_CAR_JOB_CLEANUP_STAGES = {
    "garage_verify", "garage_verify_retry", "protection_check", "finishing",
    "resume_pending", "resuming", "manual_review", "error",
}

_CAR_JOB_PUBLIC_LOG_STAGES = {
    "paid", "queued", "starting", "targets_loaded", "connecting",
    "authenticated", "garage", "garage_warm", "garage_prime", "replace_owned",
    "skip_owned", "template", "payload_verified", "slots",
    "car_success", "injected", "verified", "complete", "safety_backup",
    "unlock_all_pass", "public_success", "safety_verified",
}


def _safe_public_car_events(events) -> list:
    """Return useful pre-cleanup logs without exposing backend failures."""
    public = []
    seen = set()
    for event in events or []:
        if not isinstance(event, dict):
            continue
        stage = str(event.get("stage") or "working")
        if stage == "public_success":
            public.append({
                "stage": "complete", "message": "Car injection completed successfully.",
                "time": float(event.get("time") or time.time()),
            })
            break
        if stage in _CAR_JOB_CLEANUP_STAGES or event.get("cleanup_started"):
            if "finishing" not in seen:
                public.append({
                    "stage": "finishing", "message": "Verifying garage and cleaning errors",
                    "time": float(event.get("time") or time.time()),
                })
                seen.add("finishing")
            break
        message = str(event.get("message") or "").strip()
        if stage not in _CAR_JOB_PUBLIC_LOG_STAGES or not message:
            continue
        if re.search(r"\b(?:fail(?:ed|ure)?|error|retry|missing|corrupt|unreadable|protection)\b", message, re.I):
            continue
        event_key = (stage, message)
        if event_key in seen:
            continue
        seen.add(event_key)
        public.append({
            "stage": stage,
            "message": message[:500],
            "time": float(event.get("time") or time.time()),
        })
    return public


def _public_car_job_payload(status, events, result, checkpoint=None, queue=None, kind: str = "") -> Dict[str, Any]:
    """Expose calm progress while retaining detailed diagnostics server-side."""
    raw_status = str(status or "queued")
    checkpoint = dict(checkpoint or {})
    queue = dict(queue or {})
    events = list(events or [])
    latest = events[-1] if events else {}
    latest_stage = str(latest.get("stage") or checkpoint.get("last_stage") or "")

    cleanup_started = bool(checkpoint.get("cleanup_started")) or latest_stage in _CAR_JOB_CLEANUP_STAGES or any(
        str(event.get("stage") or "") in _CAR_JOB_CLEANUP_STAGES or event.get("cleanup_started")
        for event in events if isinstance(event, dict)
    )
    public_complete = bool(checkpoint.get("public_complete")) or any(
        str(event.get("stage") or "") == "public_success" or event.get("public_complete")
        for event in events if isinstance(event, dict)
    )
    public_events = _safe_public_car_events(events)

    countdown_deadline = 0.0
    deadline_sources = list(reversed(events)) + [checkpoint.get("last_extra") or {}, checkpoint]
    for source in deadline_sources:
        if not isinstance(source, dict):
            continue
        try:
            value = float(source.get("countdown_deadline") or 0)
        except (TypeError, ValueError):
            value = 0
        if value > 0:
            countdown_deadline = value
            break

    eta_seconds = 0
    for source in (latest, checkpoint.get("last_extra") or {}, result or {}):
        try:
            value = int(source.get("eta_seconds") or 0) if isinstance(source, dict) else 0
        except (TypeError, ValueError):
            value = 0
        if value > 0:
            eta_seconds = value
            break
    if countdown_deadline > 0:
        eta_seconds = max(0, int(countdown_deadline - time.time() + 0.999))

    total = 0
    for event in reversed(events):
        try:
            total = int(event.get("total") or 0)
        except (TypeError, ValueError):
            total = 0
        if total > 0:
            break
    if not total and isinstance(checkpoint.get("last_extra"), dict):
        try:
            total = int(checkpoint["last_extra"].get("total") or 0)
        except (TypeError, ValueError):
            total = 0
    completed = int(checkpoint.get("completed_count") or 0)
    if not eta_seconds and countdown_deadline <= 0:
        if raw_status == "queued":
            position = max(1, int(queue.get("position") or 1))
            eta_seconds = min(7200, 120 + (position - 1) * 180)
        elif total:
            remaining = max(0, total - completed)
            per_car = 8 if total <= 2 else 12
            eta_seconds = min(7200, max(8, remaining * per_car + (8 if total <= 2 else 20)))
        else:
            eta_seconds = 25

    # Customer-facing completion is intentionally uniform. Internal failures,
    # held jobs, and partial outcomes remain visible only in admin diagnostics.
    terminal = raw_status in {
        "complete", "completed", "done", "manual_review", "error", "failed",
        "finished_with_errors", "refunded",
    }
    # Public marketplace sales are exactly one selected car. Unlike pack jobs,
    # do not declare them complete at the early public cleanup deadline; wait
    # for their actual terminal/verified worker result.
    verification_sensitive = kind in {"shared_design", "garage_recovery"}
    if verification_sensitive and public_complete and not terminal:
        public_complete = False
        public_events = [event for event in public_events if event.get("stage") != "complete"]

    if terminal or public_complete:
        public_verified = bool(isinstance(result, dict) and result.get("ok"))
        if kind == "shared_design":
            final_message = (
                "Public Car injected and verified successfully."
                if public_verified
                else "Public Car injection could not be verified. Please contact support."
            )
            public_events = [event for event in public_events if event.get("stage") != "complete"]
        elif kind == "garage_recovery":
            final_message = (
                "Garage recovery completed and verified successfully."
                if public_verified
                else "Garage recovery could not be verified. Please try another save or contact support."
            )
            public_events = [event for event in public_events if event.get("stage") != "complete"]
        else:
            final_message = "Car injection completed successfully."
        if not public_events or public_events[-1].get("stage") != "complete":
            public_events.append({
                "stage": "complete", "message": final_message,
                "time": float(checkpoint.get("public_completed_at") or time.time()),
            })
        return {
            "status": "complete",
            "events": public_events,
            "result": {"ok": public_verified if verification_sensitive else True, "message": final_message},
            "display_message": final_message,
            "eta_seconds": 0,
            "countdown_deadline": 0,
            "cleanup_started": True,
        }

    if cleanup_started:
        message = "Verifying garage (console log has details)"
        public_status = "running"
        if not public_events:
            public_events = [{"stage": "finishing", "message": message, "time": time.time()}]
    elif raw_status == "queued" and latest_stage not in _CAR_JOB_FINISHING_STAGES:
        message = f"Preparing your saved car job · Estimated time left: about {eta_seconds} seconds"
        public_status = "queued"
    elif latest_stage in _CAR_JOB_FINISHING_STAGES or raw_status in {
        "running", "resume_pending", "manual_review", "error", "failed", "finished_with_errors"
    }:
        message = f"Verifying garage · about {eta_seconds}s"
        public_status = "resume_pending" if raw_status in {
            "resume_pending", "manual_review", "error", "failed", "finished_with_errors"
        } else "running"
    else:
        message = f"Applying your selected cars · Estimated time left: about {eta_seconds} seconds"
        public_status = "running"

    return {
        "status": public_status,
        "events": public_events,
        "result": None,
        "display_message": message,
        "eta_seconds": eta_seconds,
        "countdown_deadline": countdown_deadline,
        "cleanup_started": cleanup_started,
    }


def _distributed_public_from_reservation(reservation: Dict[str, Any]) -> Dict[str, Any]:
    payload = reservation.get("payload") if isinstance(reservation.get("payload"), dict) else {}
    public = payload.get("job") if isinstance(payload.get("job"), dict) else {}
    now = time.time()
    job = dict(public)
    job.update({
        "job_id": reservation["job_id"],
        "site_user_id": reservation["user_id"],
        "web_uid": reservation["web_uid"],
        "kind": reservation["kind"],
        "account_keys": list(reservation.get("account_keys") or []),
        "charged": int(reservation.get("cost") or 0),
        "attempt_count": int(reservation.get("attempt_count") or 0),
        "checkpoint": dict(reservation.get("checkpoint") or {}),
    })
    state = reservation.get("state")
    if state in {"awaiting_target", "running", "resume_pending", "manual_review"}:
        job["status"] = state
    else:
        job.setdefault("status", "queued")
    job.setdefault("events", [])
    if state == "manual_review":
        job["result"] = {
            "ok": False,
            "message": reservation.get("failure_message") or (
                "Your paid job is safely held for administrator resume; you will not be charged again."
            ),
            "failed_ids": [],
        }
    else:
        job.setdefault("result", None)
    job.setdefault("created_at", float(reservation.get("created_at") or now))
    job["updated_at"] = float(reservation.get("updated_at") or now)
    return job


def _ensure_distributed_job(job_id: str) -> Optional[Dict[str, Any]]:
    job = SHARED_JOB_STORE.get(job_id)
    if job:
        # Reconcile old Redis progress records after a dead worker was moved to
        # admin review in PostgreSQL, so the page cannot remain "injecting".
        if time.time() - float(job.get("updated_at") or 0) > 300:
            reservation = accounts.get_job_reservation(job_id, include_payload=False)
            if reservation and reservation.get("state") in {"completed", "failed", "refunded", "manual_review"}:
                job_kind = str(job.get("kind") or "")
                sensitive_job = job_kind in {"shared_design", "garage_recovery"}
                return SHARED_JOB_STORE.finish(
                    job_id,
                    "complete",
                    {
                        "ok": not sensitive_job or reservation.get("state") == "completed",
                        "message": (
                            "Garage recovery could not be verified. Please try another save or contact support."
                            if job_kind == "garage_recovery" and reservation.get("state") != "completed"
                            else
                            "Public Car injection could not be verified. Please contact support."
                            if job_kind == "shared_design" and reservation.get("state") != "completed"
                            else "Garage recovery completed and verified successfully."
                            if job_kind == "garage_recovery"
                            else "Car injection completed successfully."
                        ),
                    },
                )
        return job
    reservation = accounts.get_job_reservation(job_id, include_payload=True)
    if not reservation or reservation.get("state") in {"completed", "failed", "refunded"}:
        return None
    return SHARED_JOB_STORE.create(job_id, _distributed_public_from_reservation(reservation))


def _distributed_queue_snapshot(kind: str, job_id=None) -> Dict[str, Any]:
    return SHARED_JOB_STORE.queue_snapshot(
        kind,
        job_id,
        max_concurrent=MAX_CONCURRENT_INJECTIONS,
        limit=MAX_QUEUED_INJECTIONS,
    )


def _distributed_enqueue_job(
    *,
    kind: str,
    action: str,
    web_uid: Any,
    account_keys,
    credentials: Dict[str, Any],
    queued_message: str,
    awaiting_target: bool = False,
    operation_key: str = "",
    purchase_callback=None,
):
    site_user = _require_site_user()
    if not site_user:
        return jsonify({
            "ok": False,
            "message": "Create a site account and sign in to use paid tools.",
            "need_site_login": True,
        }), 401

    keys = sorted({_normalize_account_key(value) for value in account_keys if value})
    try:
        with SHARED_JOB_STORE.enqueue_lock():
            existing = SHARED_JOB_STORE.find_active(web_uid=web_uid, kind=kind)
            if existing:
                existing_id, existing_job = existing
                reservation = accounts.get_job_reservation(existing_id, include_payload=False)
                reservation_state = str((reservation or {}).get("state") or "")
                checkpoint = (reservation or {}).get("checkpoint") or {}
                cleanup_released = bool(
                    checkpoint.get("public_complete")
                    and time.time() - float(checkpoint.get("public_completed_at") or checkpoint.get("last_event_at") or 0) > 150
                )
                # Redis can outlive the PostgreSQL reservation state. Purge an
                # already-finished/held entry before treating it as active.
                if not reservation or reservation_state in {"completed", "failed", "refunded", "manual_review"} or cleanup_released:
                    if reservation and cleanup_released and reservation_state not in {"completed", "failed", "refunded", "manual_review"}:
                        accounts.finish_job_reservation(
                            existing_id, "manual_review",
                            failure_message="Public cleanup window completed; retained for administrator review.",
                        )
                    SHARED_JOB_STORE.delete(existing_id)
                    existing = None
                elif (
                    reservation_state == "resume_pending"
                    and int(reservation.get("attempt_count") or 0) >= int(reservation.get("max_attempts") or 1)
                ):
                    accounts.finish_job_reservation(
                        existing_id, "manual_review",
                        failure_message="Saved retry limit reached; released for administrator review.",
                    )
                    SHARED_JOB_STORE.finish(
                        existing_id, "complete",
                        {
                            "ok": False if kind in {"shared_design", "garage_recovery"} else True,
                            "message": (
                                "Garage recovery could not be verified. Please try another save or contact support."
                                if kind == "garage_recovery" else
                                "Public Car injection could not be verified. Please contact support."
                                if kind == "shared_design" else "Car injection completed successfully."
                            ),
                        },
                    )
                    existing = None
            if existing:
                existing_id, existing_job = existing
                # Catalog/Public Car jobs of the same broad kind are not the
                # same operation unless their exact car/design key matches.
                # Never open an earlier car's log for a new selection.
                if operation_key and str(existing_job.get("operation_key") or "") != str(operation_key):
                    existing = None
            if existing:
                existing_id, existing_job = existing
                payload = {
                    "ok": True,
                    "job_id": existing_id,
                    "status": existing_job.get("status"),
                    "queue": _distributed_queue_snapshot(kind, existing_id),
                    "progress_url": url_for("car_job_page", job_id=existing_id),
                }
                if kind == "clone":
                    payload.update({
                        "already_paid": True,
                        "message": "Clone Account is already paid for. Enter the destination account to continue."
                        if existing_job.get("status") == "awaiting_target"
                        else "Your clone job is already active.",
                    })
                else:
                    payload["already_running"] = True
                return jsonify(payload)

            conflict = SHARED_JOB_STORE.account_conflict(keys)
            if conflict:
                conflict_id, conflict_job = conflict
                reservation = accounts.get_job_reservation(conflict_id, include_payload=False)
                reservation_state = str((reservation or {}).get("state") or "")
                checkpoint = (reservation or {}).get("checkpoint") or {}
                cleanup_released = bool(
                    checkpoint.get("public_complete")
                    and time.time() - float(checkpoint.get("public_completed_at") or checkpoint.get("last_event_at") or 0) > 150
                )
                expired_retry = bool(
                    reservation
                    and reservation_state == "resume_pending"
                    and int(reservation.get("attempt_count") or 0) >= int(reservation.get("max_attempts") or 1)
                )
                if not reservation or reservation_state in {"completed", "failed", "refunded", "manual_review"} or expired_retry or cleanup_released:
                    if reservation and reservation_state not in {"completed", "failed", "refunded", "manual_review"}:
                        accounts.finish_job_reservation(
                            conflict_id, "manual_review",
                            failure_message="Saved retry limit reached; released for administrator review.",
                        )
                    SHARED_JOB_STORE.delete(conflict_id)
                    conflict = None
                else:
                    # A different route/car owns this account lock. Do not
                    # redirect to its progress page because that mixes logs and
                    # makes the new injection look as though it already ran.
                    return jsonify({
                        "ok": False,
                        "message": "Your previous car task is still finishing. Wait for it to complete before starting this car.",
                        "retry_after_seconds": 10,
                    }), 409
            if SHARED_JOB_STORE.capacity(MAX_QUEUED_INJECTIONS)["available"] <= 0:
                return _queue_full_response()

            # Marketplace payment happens only after all account/job preflight
            # checks pass. A blocked Public Car request is therefore never sold
            # and never credited to the seller without its own new job.
            if callable(purchase_callback):
                purchase = purchase_callback()
                if not isinstance(purchase, dict) or not purchase.get("ok"):
                    return jsonify(purchase if isinstance(purchase, dict) else {
                        "ok": False, "message": "Unable to complete this Public Car purchase."
                    }), 402

            job_id = uuid.uuid4().hex
            now = time.time()
            initial_status = "awaiting_target" if awaiting_target else "queued"
            # Surface managed-alt alerts to the user (account created / delivery target).
            alt_alerts = []
            if isinstance(credentials, dict):
                alt_alerts = [str(x) for x in (credentials.get("alt_alerts") or []) if x]
                if credentials.get("alt_email") and not alt_alerts:
                    alt_alerts = [f"Cars will be delivered to managed alt {credentials.get('alt_email')}."]
            start_message = queued_message
            if alt_alerts:
                start_message = " · ".join(alt_alerts + [queued_message])

            public_job = {
                "web_uid": str(web_uid),
                "site_user_id": site_user["user_id"],
                "account_keys": keys,
                "status": initial_status,
                "events": [{
                    "stage": "paid" if awaiting_target else "queued",
                    "message": start_message,
                    "time": now,
                }],
                "result": None,
                "created_at": now,
                "updated_at": now,
                "kind": kind,
                "operation_key": str(operation_key or kind),
            }
            durable_payload = {"job": public_job, "credentials": dict(credentials)}
            reservation = accounts.reserve_injection_job(
                job_id=job_id,
                user_id=site_user["user_id"],
                web_uid=web_uid,
                kind=kind,
                action=action,
                account_keys=keys,
                payload=durable_payload,
                initial_state=initial_status if awaiting_target else "reserved",
                enqueue_now=not awaiting_target,
            )
            if not reservation.get("ok"):
                # A stale/double click must return the saved task instead of
                # leaving the button on "injecting" behind a blocking alert.
                conflict_job_id = reservation.get("conflict_job_id")
                if conflict_job_id:
                    return jsonify({
                        "ok": False,
                        "message": "Your previous car task is still finishing. Wait for it to complete before starting this car.",
                        "retry_after_seconds": 10,
                    }), 409
                return jsonify(reservation), 409 if reservation.get("conflict_job_id") else 402

            job_id = reservation["job_id"]
            if reservation.get("duplicate"):
                job = _ensure_distributed_job(job_id)
            else:
                public_job["charged"] = int(reservation.get("charged") or 0)
                job = SHARED_JOB_STORE.create(job_id, public_job)
            if not job:
                return jsonify({
                    "ok": False,
                    "message": "Your credit reservation is safe, but the shared queue is temporarily unavailable. Retry this action shortly.",
                    "job_id": job_id,
                    "retry_after_seconds": 10,
                }), 503
    except TimeoutError as exc:
        return jsonify({"ok": False, "message": str(exc), "retry_after_seconds": 5}), 503
    except Exception as exc:
        app.logger.exception("Unable to reserve distributed injection job")
        return jsonify({"ok": False, "message": f"Unable to access the shared injection queue: {exc}"}), 503

    response = {
        "ok": True,
        "job_id": job_id,
        "progress_url": url_for("car_job_page", job_id=job_id),
        "charged": int(reservation.get("charged") or 0),
        "balance": reservation.get("balance"),
    }
    if awaiting_target:
        response["message"] = "Payment accepted. Enter the destination CPM email and password."
    else:
        response["queue"] = _distributed_queue_snapshot(kind, job_id)
    if reservation.get("duplicate"):
        response["already_paid" if kind == "clone" else "already_running"] = True
    return jsonify(response)


def _distributed_status_response(job_id: str, expected_kind: str):
    job = _ensure_distributed_job(job_id)
    if (
        not job
        or str(job.get("web_uid")) != str(get_web_uid())
        or job.get("kind") != expected_kind
    ):
        return jsonify({"ok": False, "message": "Job not found"}), 404
    try:
        cursor = max(0, int(request.args.get("cursor", 0)))
    except (TypeError, ValueError):
        cursor = 0
    all_events = list(job.get("events") or [])
    status = str(job.get("status") or "queued")
    queue = _distributed_queue_snapshot(expected_kind, job_id)
    public = _public_car_job_payload(
        status,
        all_events[cursor:],
        job.get("result"),
        job.get("checkpoint") or {},
        queue,
        expected_kind,
    )
    return jsonify({
        "ok": True,
        **public,
        "cursor": len(all_events),
        "retry_after_ms": _job_poll_delay_ms(public["status"]),
        "queue": queue,
    })


def _distributed_clone_start(job_id: str, target_email: str, target_password: str):
    reservation = accounts.get_job_reservation(job_id, include_payload=True)
    if (
        not reservation
        or str(reservation.get("web_uid")) != str(get_web_uid())
        or reservation.get("kind") != "clone"
    ):
        return jsonify({"ok": False, "message": "Paid clone reservation was not found."}), 404
    state = reservation.get("state")
    if state in {"reserved", "queued", "running", "resume_pending", "manual_review"}:
        return jsonify({
            "ok": True,
            "job_id": job_id,
            "already_running": True,
            "queue": _distributed_queue_snapshot("clone", job_id),
        })
    if state != "awaiting_target":
        return jsonify({"ok": False, "message": "This paid clone reservation is no longer available."}), 409

    payload = reservation.get("payload") if isinstance(reservation.get("payload"), dict) else {}
    credentials = payload.get("credentials") if isinstance(payload.get("credentials"), dict) else {}
    source_email = str(credentials.get("source_email") or "")
    validation = run_async(validate_clone_target(target_email, target_password))
    if not validation.get("ok"):
        return jsonify({
            "ok": False,
            "message": validation.get("message", "Target login failed. Please correct the credentials and retry."),
        }), 400

    account_keys = {_normalize_account_key(source_email), _normalize_account_key(target_email)}
    try:
        with SHARED_JOB_STORE.enqueue_lock():
            conflict = SHARED_JOB_STORE.account_conflict(account_keys, exclude_job_id=job_id)
            if conflict:
                return jsonify({
                    "ok": False,
                    "message": "A car operation is already queued or running for the source or destination CPM account. Your paid clone reservation is still saved; retry shortly.",
                    "retry_after_seconds": 15,
                }), 409
            credentials.update({
                "target_email": target_email,
                "target_password": target_password,
            })
            public = payload.get("job") if isinstance(payload.get("job"), dict) else {}
            public.update({"status": "queued", "account_keys": sorted(account_keys), "updated_at": time.time()})
            payload = {"job": public, "credentials": credentials}
            prepared = accounts.prepare_clone_job(job_id, account_keys=account_keys, payload=payload)
            if not prepared.get("ok"):
                return jsonify(prepared), 409
            if prepared.get("already_running"):
                return jsonify({"ok": True, "job_id": job_id, "already_running": True, "queue": _distributed_queue_snapshot("clone", job_id)})
            if not SHARED_JOB_STORE.get(job_id):
                SHARED_JOB_STORE.create(job_id, public)
            SHARED_JOB_STORE.update(job_id, status="queued", account_keys=sorted(account_keys))
            SHARED_JOB_STORE.append_event(job_id, "queued", "Destination verified — clone job queued for an injection worker…")
    except Exception as exc:
        app.logger.exception("Unable to queue distributed clone job")
        return jsonify({
            "ok": False,
            "message": f"Your paid clone reservation is still saved, but the queue is temporarily unavailable: {exc}",
            "retry_after_seconds": 10,
        }), 503
    return jsonify({"ok": True, "job_id": job_id, "queue": _distributed_queue_snapshot("clone", job_id)})


def _normalize_account_key(email: str) -> str:
    return (email or "").strip().lower()


def _job_account_keys(job: Dict[str, Any]) -> set[str]:
    configured = job.get("account_keys")
    if isinstance(configured, (list, tuple, set)):
        return {_normalize_account_key(value) for value in configured if value}
    return {_normalize_account_key(job.get("email", ""))} if job.get("email") else set()


def _active_account_conflict_locked(account_keys, *, exclude_job_id=None):
    requested = {_normalize_account_key(value) for value in account_keys if value}
    if not requested:
        return None
    for candidate_id, job in CAR_INJECTION_JOBS.items():
        if candidate_id == exclude_job_id or job.get("status") not in ("queued", "running"):
            continue
        if requested.intersection(_job_account_keys(job)):
            return candidate_id, job
    return None


def _injection_capacity_locked() -> Dict[str, int]:
    active = sum(
        1
        for job in CAR_INJECTION_JOBS.values()
        if job.get("status") in ("awaiting_target", "queued", "running")
    )
    return {
        "active": active,
        "limit": MAX_QUEUED_INJECTIONS,
        "available": max(0, MAX_QUEUED_INJECTIONS - active),
    }


def _queue_full_response():
    return jsonify({
        "ok": False,
        "message": "The injection queue is full. Please try again shortly; you have not been charged.",
        "retry_after_seconds": 30,
    }), 503


def _job_poll_delay_ms(status: str) -> int:
    if status in {"queued", "resume_pending"}:
        return 4500
    if status == "running":
        return 2500
    return 0




def _injection_queue_snapshot(kind: str, job_id=None) -> Dict[str, Any]:
    """Return live queue stats for premium, event, unlock-all, or clone jobs."""
    kind = kind if kind in ("premium", "event", "catalog", "unlock_all", "clone") else "premium"
    with CAR_INJECTION_LOCK:
        running = [
            j for j in CAR_INJECTION_JOBS.values()
            if j.get("status") == "running" and j.get("kind", "premium") == kind
        ]
        queued = sorted(
            [
                (jid, j) for jid, j in CAR_INJECTION_JOBS.items()
                if j.get("status") == "queued" and j.get("kind", "premium") == kind
            ],
            key=lambda item: float(item[1].get("created_at") or 0),
        )
        position = None
        people_ahead = None
        if job_id:
            for idx, (jid, _job) in enumerate(queued):
                if jid == job_id:
                    position = idx + 1  # 1 = next up
                    people_ahead = idx
                    break
            job = CAR_INJECTION_JOBS.get(job_id)
            if job and job.get("status") == "running":
                position = 0
                people_ahead = 0
        return {
            "kind": kind,
            "running": len(running),
            "waiting": len(queued),
            "position": position,
            "people_ahead": people_ahead,
            "max_concurrent": MAX_CONCURRENT_INJECTIONS,
            "capacity": _injection_capacity_locked(),
        }


def _try_start_queued_injections(*, force: bool = False) -> None:
    """Promote queued jobs into running slots up to the global concurrent cap."""
    global _LAST_INJECTION_PROMOTION_AT
    to_start = []
    now = time.time()
    with CAR_INJECTION_LOCK:
        if not force and (now - _LAST_INJECTION_PROMOTION_AT) < INJECTION_PROMOTION_INTERVAL_SECONDS:
            return
        _LAST_INJECTION_PROMOTION_AT = now
        running_total = sum(1 for j in CAR_INJECTION_JOBS.values() if j.get("status") == "running")
        slots = max(0, MAX_CONCURRENT_INJECTIONS - running_total)
        if slots <= 0:
            return
        running_keys = set()
        for running_job in CAR_INJECTION_JOBS.values():
            if running_job.get("status") == "running":
                running_keys.update(_job_account_keys(running_job))
        queued = sorted(
            [
                (jid, j) for jid, j in CAR_INJECTION_JOBS.items()
                if j.get("status") == "queued" and j.get("email") and j.get("password")
            ],
            key=lambda item: float(item[1].get("created_at") or 0),
        )
        for jid, job in queued:
            if len(to_start) >= slots:
                break
            job_keys = _job_account_keys(job)
            if job_keys.intersection(running_keys):
                continue
            job["status"] = "running"
            job["updated_at"] = time.time()
            _append_job_event(job, {
                "stage": "starting",
                "message": "Your turn — starting injection now…",
                "time": time.time(),
            })
            to_start.append({
                "job_id": jid,
                "kind": job.get("kind", "premium"),
                "email": job.get("email"),
                "password": job.get("password"),
                "source_email": job.get("source_email"),
                "source_password": job.get("source_password"),
                "catalog_slug": job.get("catalog_slug"),
            })
            running_keys.update(job_keys)

    for item in to_start:
        jid = item["job_id"]
        kind = item["kind"]
        email = item["email"]
        password = item["password"]
        try:
            if kind == "premium":
                future = CAR_INJECTION_EXECUTOR.submit(_run_car_injection_job, jid, email, password)
            elif kind == "event":
                future = CAR_INJECTION_EXECUTOR.submit(_run_event_car_injection_job, jid, email, password)
            elif kind == "unlock_all":
                future = CAR_INJECTION_EXECUTOR.submit(_run_unlock_all_cars_job, jid, email, password)
            elif kind == "catalog":
                future = CAR_INJECTION_EXECUTOR.submit(
                    _run_catalog_car_job, jid, email, password, item.get("catalog_slug")
                )
            elif kind == "clone":
                future = CAR_INJECTION_EXECUTOR.submit(
                    _run_clone_account_job,
                    jid,
                    item.get("source_email"),
                    item.get("source_password"),
                    email,
                    password,
                )
            else:
                raise RuntimeError(f"Unknown injection job kind: {kind}")
            with CAR_INJECTION_LOCK:
                job = CAR_INJECTION_JOBS.get(jid)
                if job is not None:
                    job["future"] = future
        except Exception as exc:
            refund = None
            with CAR_INJECTION_LOCK:
                job = CAR_INJECTION_JOBS.get(jid)
                if job is not None:
                    job["status"] = "error"
                    job["result"] = {"ok": False, "message": f"Unable to start: {exc}", "failed_ids": []}
                    _append_job_event(job, {"stage": "error", "message": str(exc), "time": time.time()})
                    charged = int(job.get("charged") or 0)
                    site_user_id = job.get("site_user_id")
                    if charged > 0 and site_user_id and not job.get("refunded"):
                        refund = (site_user_id, charged)
            if refund:
                refund_result = accounts.refund(
                    refund[0], refund[1], reason="injection_executor_start_failure"
                )
                if refund_result.get("ok"):
                    with CAR_INJECTION_LOCK:
                        job = CAR_INJECTION_JOBS.get(jid)
                        if job is not None:
                            job["refunded"] = True
                else:
                    app.logger.error(
                        "Unable to refund failed injection start job=%s user=%s amount=%s",
                        jid,
                        refund[0],
                        refund[1],
                    )


def _finish_injection_job(job_id: str, status: str, result: Dict[str, Any]) -> None:
    with CAR_INJECTION_LOCK:
        job = CAR_INJECTION_JOBS.get(job_id)
        if job:
            job["status"] = status
            job["result"] = result
            job["updated_at"] = time.time()
            # Credentials are needed only while queued/running. Clearing them
            # also keeps completed job objects small and limits exposure.
            job["password"] = None
            job["source_password"] = None
    # Free a slot for the next person in line
    try:
        _try_start_queued_injections(force=True)
    except Exception:
        app.logger.exception("Failed to promote queued injection jobs")


def _cleanup_old_injection_jobs() -> None:
    now = time.time()
    with CAR_INJECTION_LOCK:
        stale = [
            jid for jid, job in CAR_INJECTION_JOBS.items()
            if job.get("status") != "running" and (now - float(job.get("updated_at") or job.get("created_at") or now)) > 1800
        ]
        for jid in stale:
            CAR_INJECTION_JOBS.pop(jid, None)


def _run_car_injection_job(job_id: str, email: str, password: str):
    def progress(stage: str, message: str, extra=None):
        with CAR_INJECTION_LOCK:
            job = CAR_INJECTION_JOBS.get(job_id)
            if not job:
                return
            event = {
                "stage": stage,
                "message": message,
                "time": time.time(),
            }
            if extra:
                event.update(extra)
            _append_job_event(job, event)

    try:
        result = run_async(inject_with_garage_protection(job_id, "premium", email, password, progress))
        status = "complete" if result.get("ok") else "finished_with_errors"
        _finish_injection_job(job_id, status, result)
        try:
            injected = int(result.get("injected") or 0)
            ok = bool(result.get("ok")) or injected > 0
            backlog.log_action(
                email,
                "premium_car_inject",
                "Premium Cars Injection",
                ok,
                message=result.get("message", ""),
                extra={"injected": injected, "failed_ids": result.get("failed_ids", [])},
            )
            if injected > 0:
                # log_action already +1; add remaining injected cars
                if injected > 1:
                    backlog.record_live_action("premium_car_inject", True, amount=injected - 1)
        except Exception:
            app.logger.exception("Failed to log premium car injection stats")
    except Exception as exc:
        app.logger.exception("Bulk car injection failed")
        _finish_injection_job(job_id, "error", {"ok": False, "message": str(exc), "failed_ids": []})
        with CAR_INJECTION_LOCK:
            job = CAR_INJECTION_JOBS.get(job_id)
            if job:
                _append_job_event(job, {"stage": "error", "message": str(exc), "time": time.time()})


def _run_event_car_injection_job(job_id: str, email: str, password: str):
    def progress(stage: str, message: str, extra=None):
        with CAR_INJECTION_LOCK:
            job = CAR_INJECTION_JOBS.get(job_id)
            if not job:
                return
            event = {"stage": stage, "message": message, "time": time.time()}
            if extra:
                event.update(extra)
            _append_job_event(job, event)

    try:
        result = run_async(inject_with_garage_protection(job_id, "event", email, password, progress))
        status = "complete" if result.get("ok") else "finished_with_errors"
        _finish_injection_job(job_id, status, result)
        try:
            injected = int(result.get("injected") or 0)
            ok = bool(result.get("ok")) or injected > 0
            backlog.log_action(
                email, "event_car_inject", "Event Cars Injection", ok,
                message=result.get("message", ""),
                extra={"injected": injected, "failed_ids": result.get("failed_ids", [])},
            )
            if injected > 1:
                backlog.record_live_action("event_car_inject", True, amount=injected - 1)
        except Exception:
            app.logger.exception("Failed to log event car injection stats")
    except Exception as exc:
        app.logger.exception("Event car injection failed")
        _finish_injection_job(job_id, "error", {"ok": False, "message": str(exc), "failed_ids": []})
        with CAR_INJECTION_LOCK:
            job = CAR_INJECTION_JOBS.get(job_id)
            if job:
                _append_job_event(job, {"stage": "error", "message": str(exc), "time": time.time()})



def _run_catalog_car_job(job_id: str, email: str, password: str, catalog_slug: str):
    def progress(stage: str, message: str, extra=None):
        with CAR_INJECTION_LOCK:
            job = CAR_INJECTION_JOBS.get(job_id)
            if not job:
                return
            event = {"stage": stage, "message": message, "time": time.time()}
            if extra:
                event.update(extra)
            _append_job_event(job, event)

    try:
        car = catalog_repository.get_catalog_car(catalog_slug, include_hidden=True)
        payload = catalog_repository.load_catalog_payload(catalog_slug)
        if not car or not payload:
            raise RuntimeError("The selected designed-car payload is unavailable.")
        result = run_async(inject_with_garage_protection(
            job_id, "catalog", email, password, progress, None,
            str(CAR_INJECTION_JOBS.get(job_id, {}).get("site_user_id") or ""),
            payload, int(car.get("car_id") or 0),
        ))
        _finish_injection_job(job_id, "complete" if result.get("ok") else "finished_with_errors", result)
        backlog.log_action(
            email, "catalog_car_inject", "Designed Car Injection",
            bool(result.get("ok")) or int(result.get("injected") or 0) > 0,
            message=result.get("message", ""),
            extra={
                "catalog_slug": catalog_slug,
                "injected": int(result.get("injected") or 0),
                "failed_ids": result.get("failed_ids", []),
                "payload_profile": result.get("payload_profile") or {},
            },
        )
    except Exception as exc:
        app.logger.exception("Designed car injection failed")
        _finish_injection_job(job_id, "error", {"ok": False, "message": str(exc), "failed_ids": []})


def _run_unlock_all_cars_job(job_id: str, email: str, password: str):
    def progress(stage, message, extra=None):
        with CAR_INJECTION_LOCK:
            job = CAR_INJECTION_JOBS.get(job_id)
            if not job:
                return
            event = {"stage": stage, "message": message, "time": time.time()}
            if extra:
                event.update(extra)
            _append_job_event(job, event)

    try:
        result = run_async(inject_with_garage_protection(job_id, "unlock_all", email, password, progress))
        _finish_injection_job(job_id, "done" if result.get("ok") else "error", result)
        try:
            web_uid = None
            with CAR_INJECTION_LOCK:
                job = CAR_INJECTION_JOBS.get(job_id)
                if job:
                    web_uid = job.get("web_uid")
            player_name = "Unknown"
            if web_uid:
                try:
                    acct = nuker.get_user_template(web_uid, email) or {}
                    player_name = acct.get("Name") or "Unknown"
                except Exception:
                    pass
            backlog.log_action(
                email,
                "unlock_all_cars",
                "Unlock All Cars 1-270",
                bool(result.get("ok")),
                message=result.get("message", ""),
                web_uid=web_uid,
                player_name=player_name,
                extra={
                    "injected": int(result.get("injected") or 0),
                    "skipped": int(result.get("skipped") or 0),
                    "failed_ids": result.get("failed_ids", []),
                    "donor_car_id": result.get("donor_car_id"),
                },
            )
            injected = int(result.get("injected") or 0)
            if injected > 1:
                backlog.record_live_action("unlock_all_cars", True, amount=injected - 1)
        except Exception:
            app.logger.exception("Failed to log Unlock All Cars stats")
    except Exception as exc:
        app.logger.exception("Unlock All Cars job failed")
        _finish_injection_job(
            job_id,
            "error",
            {
                "ok": False,
                "message": str(exc),
                "injected": 0,
                "failed_ids": list(range(1, 271)),
            },
        )


def _run_clone_account_job(job_id: str, source_email: str, source_password: str, target_email: str, target_password: str):
    def progress(stage: str, message: str, extra=None):
        with CAR_INJECTION_LOCK:
            job = CAR_INJECTION_JOBS.get(job_id)
            if not job:
                return
            event = {"stage": stage, "message": message, "time": time.time()}
            if extra:
                event["extra"] = extra
            _append_job_event(job, event)

    try:
        result = run_async(clone_account(source_email, source_password, target_email, target_password, progress))
        status = "done" if result.get("ok") else "error"
        _finish_injection_job(job_id, status, result)
        try:
            backlog.log_action(
                source_email,
                "account_clone",
                "Clone Account",
                bool(result.get("ok")),
                message=result.get("message", ""),
                web_uid=CAR_INJECTION_JOBS.get(job_id, {}).get("web_uid"),
                extra={
                    "exported": int(result.get("exported") or 0),
                    "injected": int(result.get("injected") or 0),
                    "skipped_owned": int(result.get("skipped_owned") or 0),
                    "vinyl_layers": int(result.get("vinyl_layers") or 0),
                    "failed_ids": result.get("failed_ids", []),
                },
            )
        except Exception:
            app.logger.exception("Failed to log account clone stats")
    except Exception as exc:
        app.logger.exception("Account clone failed")
        _finish_injection_job(job_id, "error", {
            "ok": False,
            "message": str(exc),
            "exported": 0,
            "injected": 0,
            "failed_ids": [],
        })
    finally:
        # Destination password is required only while the job runs.
        with CAR_INJECTION_LOCK:
            job = CAR_INJECTION_JOBS.get(job_id)
            if job:
                job["password"] = None
                job["source_password"] = None


@app.route("/cars/bulk-inject", methods=["POST"])
def bulk_inject_cars():
    try:
        _cleanup_old_injection_jobs()
    except Exception:
        pass

    alt, err = _resolve_managed_car_alt()
    if err:
        return err
    web_uid = get_web_uid()
    token_data = {"email": alt["email"], "password": alt["password"], "managed_alt_id": alt["account_id"], "site_user_id": alt["site_user"]["user_id"], "alt_alerts": list(alt.get("alerts") or []), "alt_email": alt["email"]}

    if SHARED_INJECTION_MODE:
        return _distributed_enqueue_job(
            kind="premium",
            action="premium_car_inject",
            web_uid=web_uid,
            account_keys={token_data["email"]},
            credentials={"email": token_data["email"], "password": token_data["password"]},
            queued_message="Premium cars injection queued — waiting for an injection worker…",
        )

    account_key = _normalize_account_key(token_data["email"])
    with CAR_ENQUEUE_LOCK:
        existing_id = None
        with CAR_INJECTION_LOCK:
            for candidate_id, job in CAR_INJECTION_JOBS.items():
                if (
                    job.get("web_uid") == web_uid
                    and job.get("status") in ("running", "queued")
                    and job.get("kind", "premium") == "premium"
                ):
                    existing_id = candidate_id
                    break
            conflict = _active_account_conflict_locked({account_key})
            capacity = _injection_capacity_locked()

        if existing_id:
            return jsonify({
                "ok": True,
                "job_id": existing_id,
                "already_running": True,
                "queue": _injection_queue_snapshot("premium", existing_id),
            })
        if conflict:
            return jsonify({
                "ok": False,
                "message": "Another car operation is already queued or running for this CPM account.",
                "retry_after_seconds": 15,
            }), 409
        if capacity["available"] <= 0:
            return _queue_full_response()

        ok_charge, charge_info = _charge_or_reject("premium_car_inject")
        if not ok_charge:
            return jsonify(charge_info), 402

        with CAR_INJECTION_LOCK:
            job_id = uuid.uuid4().hex
            now = time.time()
            CAR_INJECTION_JOBS[job_id] = {
                "web_uid": web_uid,
                "site_user_id": _site_user_id(),
                "email": token_data["email"],
                "password": token_data["password"],
                "account_keys": [account_key],
                "status": "queued",
                "events": [{"stage": "queued", "message": "Premium cars injection queued — waiting for an open slot…", "time": now}],
                "result": None,
                "created_at": now,
                "updated_at": now,
                "kind": "premium",
                "charged": int(charge_info.get("charged") or 0),
            }

    try:
        _try_start_queued_injections(force=True)
    except Exception as exc:
        with CAR_INJECTION_LOCK:
            CAR_INJECTION_JOBS.pop(job_id, None)
        return jsonify({"ok": False, "message": f"Unable to queue injection job: {exc}"}), 503

    return jsonify({"ok": True, "job_id": job_id, "progress_url": url_for("car_job_page", job_id=job_id), "queue": _injection_queue_snapshot("premium", job_id)})


@app.route("/cars/bulk-inject/status/<job_id>")
def bulk_inject_status(job_id: str):
    if not session.get("logged_in"):
        return jsonify({"ok": False, "message": "Not logged in"}), 401
    if SHARED_INJECTION_MODE:
        return _distributed_status_response(job_id, "premium")
    try:
        _try_start_queued_injections(force=False)
    except Exception:
        pass
    with CAR_INJECTION_LOCK:
        job = CAR_INJECTION_JOBS.get(job_id)
        if not job or job.get("web_uid") != get_web_uid():
            return jsonify({"ok": False, "message": "Job not found"}), 404
        try:
            cursor = max(0, int(request.args.get("cursor", 0)))
        except (TypeError, ValueError):
            cursor = 0
        events = list(job.get("events", [])[cursor:])
        total_events = len(job.get("events", []))
        status = job.get("status")
        result = job.get("result")
        kind = job.get("kind", "premium")
    queue = _injection_queue_snapshot(kind, job_id)
    public = _public_car_job_payload(status, events, result, job.get("checkpoint") or {}, queue)
    return jsonify({
        "ok": True,
        **public,
        "cursor": total_events,
        "retry_after_ms": _job_poll_delay_ms(public["status"]),
        "queue": queue,
    })


@app.route("/cars/event-inject", methods=["POST"])
def event_inject_cars():
    try:
        _cleanup_old_injection_jobs()
    except Exception:
        pass

    alt, err = _resolve_managed_car_alt()
    if err:
        return err
    web_uid = get_web_uid()
    token_data = {"email": alt["email"], "password": alt["password"], "managed_alt_id": alt["account_id"], "site_user_id": alt["site_user"]["user_id"], "alt_alerts": list(alt.get("alerts") or []), "alt_email": alt["email"]}

    if SHARED_INJECTION_MODE:
        return _distributed_enqueue_job(
            kind="event",
            action="event_car_inject",
            web_uid=web_uid,
            account_keys={token_data["email"]},
            credentials={"email": token_data["email"], "password": token_data["password"]},
            queued_message="Event cars injection queued — waiting for an injection worker…",
        )

    account_key = _normalize_account_key(token_data["email"])
    with CAR_ENQUEUE_LOCK:
        existing_id = None
        with CAR_INJECTION_LOCK:
            for candidate_id, job in CAR_INJECTION_JOBS.items():
                if (
                    job.get("web_uid") == web_uid
                    and job.get("status") in ("running", "queued")
                    and job.get("kind") == "event"
                ):
                    existing_id = candidate_id
                    break
            conflict = _active_account_conflict_locked({account_key})
            capacity = _injection_capacity_locked()

        if existing_id:
            return jsonify({
                "ok": True,
                "job_id": existing_id,
                "already_running": True,
                "queue": _injection_queue_snapshot("event", existing_id),
            })
        if conflict:
            return jsonify({
                "ok": False,
                "message": "Another car operation is already queued or running for this CPM account.",
                "retry_after_seconds": 15,
            }), 409
        if capacity["available"] <= 0:
            return _queue_full_response()

        ok_charge, charge_info = _charge_or_reject("event_car_inject")
        if not ok_charge:
            return jsonify(charge_info), 402

        with CAR_INJECTION_LOCK:
            job_id = uuid.uuid4().hex
            now = time.time()
            CAR_INJECTION_JOBS[job_id] = {
                "web_uid": web_uid,
                "site_user_id": _site_user_id(),
                "email": token_data["email"],
                "password": token_data["password"],
                "account_keys": [account_key],
                "status": "queued",
                "events": [{"stage": "queued", "message": "Event cars injection queued — waiting for an open slot…", "time": now}],
                "result": None,
                "created_at": now,
                "updated_at": now,
                "kind": "event",
                "charged": int(charge_info.get("charged") or 0),
            }

    try:
        _try_start_queued_injections(force=True)
    except Exception as exc:
        with CAR_INJECTION_LOCK:
            CAR_INJECTION_JOBS.pop(job_id, None)
        return jsonify({"ok": False, "message": f"Unable to queue injection job: {exc}"}), 503

    return jsonify({"ok": True, "job_id": job_id, "progress_url": url_for("car_job_page", job_id=job_id), "queue": _injection_queue_snapshot("event", job_id)})


@app.route("/cars/event-inject/status/<job_id>")
def event_inject_status(job_id: str):
    if not session.get("logged_in"):
        return jsonify({"ok": False, "message": "Not logged in"}), 401
    if SHARED_INJECTION_MODE:
        return _distributed_status_response(job_id, "event")
    try:
        _try_start_queued_injections(force=False)
    except Exception:
        pass
    with CAR_INJECTION_LOCK:
        job = CAR_INJECTION_JOBS.get(job_id)
        if not job or job.get("web_uid") != get_web_uid():
            return jsonify({"ok": False, "message": "Job not found"}), 404
        try:
            cursor = max(0, int(request.args.get("cursor", 0)))
        except (TypeError, ValueError):
            cursor = 0
        events = list(job.get("events", [])[cursor:])
        total_events = len(job.get("events", []))
        status = job.get("status")
        result = job.get("result")
        kind = job.get("kind", "event")
    queue = _injection_queue_snapshot(kind, job_id)
    public = _public_car_job_payload(status, events, result, job.get("checkpoint") or {}, queue)
    return jsonify({
        "ok": True,
        **public,
        "cursor": total_events,
        "retry_after_ms": _job_poll_delay_ms(public["status"]),
        "queue": queue,
    })



@app.route("/cars/catalog/<slug>/inject", methods=["POST"])
def catalog_car_inject(slug: str):
    car = catalog_repository.get_catalog_car(slug)
    if not car or not catalog_repository.load_catalog_payload(slug):
        return jsonify({"ok": False, "message": "That designed car is unavailable."}), 404

    alt, err = _resolve_managed_car_alt()
    if err:
        return err
    web_uid = get_web_uid()
    token_data = {"email": alt["email"], "password": alt["password"], "managed_alt_id": alt["account_id"], "site_user_id": alt["site_user"]["user_id"], "alt_alerts": list(alt.get("alerts") or []), "alt_email": alt["email"]}

    if SHARED_INJECTION_MODE:
        return _distributed_enqueue_job(
            kind="catalog",
            action="catalog_car_inject",
            web_uid=web_uid,
            account_keys={token_data["email"]},
            credentials={
                "email": token_data["email"],
                "password": token_data["password"],
                "catalog_slug": slug,
            },
            queued_message="Designed car queued — it will be automatically injected into your account…",
            operation_key=f"catalog:{slug}",
        )

    account_key = _normalize_account_key(token_data["email"])
    with CAR_ENQUEUE_LOCK:
        with CAR_INJECTION_LOCK:
            existing = next((
                (jid, job) for jid, job in CAR_INJECTION_JOBS.items()
                if job.get("web_uid") == web_uid and job.get("kind") == "catalog"
                and job.get("catalog_slug") == slug and job.get("status") in ("queued", "running")
            ), None)
            conflict = _active_account_conflict_locked({account_key})
            capacity = _injection_capacity_locked()
        if existing:
            return jsonify({"ok": True, "job_id": existing[0], "already_running": True,
                            "progress_url": url_for("car_job_page", job_id=existing[0])})
        if conflict:
            return jsonify({"ok": False, "message": "Another car operation is already queued or running for this CPM account."}), 409
        if capacity["available"] <= 0:
            return _queue_full_response()
        ok_charge, charge_info = _charge_or_reject("catalog_car_inject")
        if not ok_charge:
            return jsonify(charge_info), 402
        job_id = uuid.uuid4().hex
        now = time.time()
        with CAR_INJECTION_LOCK:
            CAR_INJECTION_JOBS[job_id] = {
                "web_uid": web_uid,
                "site_user_id": _site_user_id(),
                "email": token_data["email"],
                "password": token_data["password"],
                "account_keys": [account_key],
                "catalog_slug": slug,
                "status": "queued",
                "events": [{"stage": "queued", "message": "Designed car queued for automatic injection…", "time": now}],
                "result": None,
                "created_at": now,
                "updated_at": now,
                "kind": "catalog",
                "charged": int(charge_info.get("charged") or 0),
            }
    _try_start_queued_injections(force=True)
    return jsonify({"ok": True, "job_id": job_id,
                    "progress_url": url_for("car_job_page", job_id=job_id)})


@app.route("/cars/catalog/status/<job_id>")
def catalog_car_status(job_id: str):
    if not session.get("logged_in"):
        return jsonify({"ok": False, "message": "Not logged in"}), 401
    if SHARED_INJECTION_MODE:
        return _distributed_status_response(job_id, "catalog")
    try:
        _try_start_queued_injections(force=False)
    except Exception:
        pass
    with CAR_INJECTION_LOCK:
        job = CAR_INJECTION_JOBS.get(job_id)
        if not job or job.get("web_uid") != get_web_uid() or job.get("kind") != "catalog":
            return jsonify({"ok": False, "message": "Job not found"}), 404
        try:
            cursor = max(0, int(request.args.get("cursor", 0)))
        except (TypeError, ValueError):
            cursor = 0
        events = list(job.get("events", [])[cursor:])
        status = job.get("status")
        result = job.get("result")
        total_events = len(job.get("events", []))
    queue = _injection_queue_snapshot("catalog", job_id)
    public = _public_car_job_payload(status, events, result, job.get("checkpoint") or {}, queue)
    return jsonify({"ok": True, **public, "cursor": total_events,
                    "retry_after_ms": _job_poll_delay_ms(public["status"]), "queue": queue})


@app.route("/cars/unlock-all", methods=["POST"])
def unlock_all_cars():
    if not UNLOCK_ALL_CARS_ENABLED:
        return jsonify({"ok": False, "message": "This tool is unavailable."}), 403

    try:
        _cleanup_old_injection_jobs()
    except Exception:
        pass

    alt, err = _resolve_managed_car_alt()
    if err:
        return err
    web_uid = get_web_uid()
    token_data = {"email": alt["email"], "password": alt["password"], "managed_alt_id": alt["account_id"], "site_user_id": alt["site_user"]["user_id"], "alt_alerts": list(alt.get("alerts") or []), "alt_email": alt["email"]}

    if SHARED_INJECTION_MODE:
        return _distributed_enqueue_job(
            kind="unlock_all",
            action="unlock_all_cars",
            web_uid=web_uid,
            account_keys={token_data["email"]},
            credentials={"email": token_data["email"], "password": token_data["password"]},
            queued_message="Unlock All Cars 1-270 queued — waiting for an injection worker…",
        )

    # Reuse an active job and never charge twice for repeated clicks. The
    # enqueue lock makes duplicate-click detection and charging one transaction
    # within this process.
    account_key = _normalize_account_key(token_data["email"])
    with CAR_ENQUEUE_LOCK:
        existing_id = None
        with CAR_INJECTION_LOCK:
            for candidate_id, existing_job in CAR_INJECTION_JOBS.items():
                if (
                    existing_job.get("web_uid") == web_uid
                    and existing_job.get("kind") == "unlock_all"
                    and existing_job.get("status") in ("queued", "running")
                ):
                    existing_id = candidate_id
                    break
            conflict = _active_account_conflict_locked({account_key})
            capacity = _injection_capacity_locked()

        if existing_id:
            return jsonify({
                "ok": True,
                "job_id": existing_id,
                "already_running": True,
                "queue": _injection_queue_snapshot("unlock_all", existing_id),
            })
        if conflict:
            return jsonify({
                "ok": False,
                "message": "Another car operation is already queued or running for this CPM account.",
                "retry_after_seconds": 15,
            }), 409
        if capacity["available"] <= 0:
            return _queue_full_response()

        ok_charge, charge_info = _charge_or_reject("unlock_all_cars")
        if not ok_charge:
            return jsonify(charge_info), 402

        job_id = uuid.uuid4().hex
        now = time.time()
        with CAR_INJECTION_LOCK:
            CAR_INJECTION_JOBS[job_id] = {
                "web_uid": web_uid,
                "site_user_id": _site_user_id(),
                "email": token_data["email"],
                "password": token_data["password"],
                "account_keys": [account_key],
                "status": "queued",
                "events": [{
                    "stage": "queued",
                    "message": "Unlock All Cars 1-270 queued — waiting for an open injection slot…",
                    "time": now,
                }],
                "result": None,
                "created_at": now,
                "updated_at": now,
                "kind": "unlock_all",
                "charged": int(charge_info.get("charged") or 0),
            }

    try:
        _try_start_queued_injections(force=True)
    except Exception as exc:
        with CAR_INJECTION_LOCK:
            CAR_INJECTION_JOBS.pop(job_id, None)
        # The existing site ledger has no automatic cross-process rollback
        # contract; preserve current charging behavior and surface the failure.
        return jsonify({
            "ok": False,
            "message": f"Unable to queue Unlock All Cars job: {exc}",
        }), 503

    return jsonify({
        "ok": True,
        "job_id": job_id,
        "progress_url": url_for("car_job_page", job_id=job_id),
        "charged": int(charge_info.get("charged") or 0),
        "balance": charge_info.get("balance"),
        "queue": _injection_queue_snapshot("unlock_all", job_id),
    })


@app.route("/cars/job/<job_id>")
def car_job_page(job_id: str):
    """Standalone durable progress page for every World Sale car job."""
    if not session.get("logged_in"):
        return redirect(url_for("index"))
    kind = None
    if SHARED_INJECTION_MODE:
        reservation = accounts.get_job_reservation(job_id, include_payload=False)
        if reservation and str(reservation.get("web_uid")) == str(get_web_uid()):
            kind = reservation.get("kind")
    else:
        with CAR_INJECTION_LOCK:
            job = CAR_INJECTION_JOBS.get(job_id)
            if job and str(job.get("web_uid")) == str(get_web_uid()):
                kind = job.get("kind")
    endpoints = {
        "premium": "bulk_inject_status",
        "event": "event_inject_status",
        "catalog": "catalog_car_status",
        "unlock_all": "unlock_all_cars_status",
        "shared_design": "shared_design_status",
        "garage_recovery": "garage_recovery_status",
    }
    if kind not in endpoints:
        flash("Car job not found.", "error")
        return redirect(url_for("dashboard"))
    recovery_job = kind == "garage_recovery"
    return render_template(
        "car_job.html",
        title="Garage Recovery Progress" if recovery_job else "Car Injection Progress",
        job_id=job_id,
        status_url=url_for(endpoints[kind], job_id=job_id),
        return_url=url_for("garage_recovery_page") if recovery_job else url_for("dashboard"),
        return_label="Back to Garage Recovery" if recovery_job else "Back to dashboard",
        task_heading="Garage Recovery Progress" if recovery_job else "Injection Progress",
    )


@app.route("/garage-recovery/status/<job_id>")
def garage_recovery_status(job_id: str):
    if not session.get("logged_in"):
        return jsonify({"ok": False, "message": "Not logged in"}), 401
    if not SHARED_INJECTION_MODE:
        return jsonify({"ok": False, "message": "Job not found"}), 404
    return _distributed_status_response(job_id, "garage_recovery")


@app.route("/shared-designs/status/<job_id>")
def shared_design_status(job_id: str):
    if not session.get("logged_in"):
        return jsonify({"ok": False, "message": "Not logged in"}), 401
    return _distributed_status_response(job_id, "shared_design")


@app.route("/cars/unlock-all/status/<job_id>")
def unlock_all_cars_status(job_id: str):
    if not session.get("logged_in"):
        return jsonify({"ok": False, "message": "Not logged in"}), 401

    if SHARED_INJECTION_MODE:
        return _distributed_status_response(job_id, "unlock_all")

    try:
        _try_start_queued_injections(force=False)
    except Exception:
        pass

    with CAR_INJECTION_LOCK:
        job = CAR_INJECTION_JOBS.get(job_id)
        if (
            not job
            or job.get("web_uid") != get_web_uid()
            or job.get("kind") != "unlock_all"
        ):
            return jsonify({"ok": False, "message": "Job not found"}), 404

        try:
            cursor = max(0, int(request.args.get("cursor", 0)))
        except (TypeError, ValueError):
            cursor = 0

        events = list(job.get("events", [])[cursor:])
        total_events = len(job.get("events", []))
        status = job.get("status")
        result = job.get("result")

    queue = _injection_queue_snapshot("unlock_all", job_id)
    public = _public_car_job_payload(status, events, result, job.get("checkpoint") or {}, queue)
    return jsonify({
        "ok": True,
        **public,
        "cursor": total_events,
        "retry_after_ms": _job_poll_delay_ms(public["status"]),
        "queue": queue,
    })


@app.route("/cars/inject-queue")
def inject_queue_board():
    if not session.get("logged_in"):
        return jsonify({"ok": False, "message": "Not logged in"}), 401
    if SHARED_INJECTION_MODE:
        return jsonify({
            "ok": True,
            "premium": _distributed_queue_snapshot("premium"),
            "event": _distributed_queue_snapshot("event"),
            "unlock_all": _distributed_queue_snapshot("unlock_all"),
            "clone": _distributed_queue_snapshot("clone"),
        })
    try:
        _try_start_queued_injections(force=False)
    except Exception:
        pass
    return jsonify({
        "ok": True,
        "premium": _injection_queue_snapshot("premium"),
        "event": _injection_queue_snapshot("event"),
        "unlock_all": _injection_queue_snapshot("unlock_all"),
        "clone": _injection_queue_snapshot("clone"),
    })




@app.route("/clone-account/purchase", methods=["POST"])
def clone_account_purchase():
    if not CLONE_ACCOUNTS_ENABLED:
        return jsonify({"ok": False, "message": "Account cloning is temporarily unavailable."}), 503
    if not session.get("logged_in"):
        return jsonify({"ok": False, "message": "Log in to your CPM account first."}), 401

    web_uid = get_web_uid()
    token_data = nuker.get_token_data(web_uid)
    if not token_data or not token_data.get("email") or not token_data.get("password"):
        return jsonify({"ok": False, "message": "Stored source-account login is unavailable. Please log in again."}), 400

    if SHARED_INJECTION_MODE:
        return _distributed_enqueue_job(
            kind="clone",
            action="account_clone",
            web_uid=web_uid,
            account_keys={token_data["email"]},
            credentials={
                "source_email": token_data["email"],
                "source_password": token_data["password"],
            },
            queued_message="10,000 credits accepted — enter the destination account to begin cloning.",
            awaiting_target=True,
        )

    # Reuse an already-paid reservation instead of charging twice on repeat
    # clicks, and serialize check+charge+reservation creation.
    source_key = _normalize_account_key(token_data["email"])
    with CAR_ENQUEUE_LOCK:
        with CAR_INJECTION_LOCK:
            existing = next((
                (jid, job) for jid, job in CAR_INJECTION_JOBS.items()
                if job.get("web_uid") == web_uid
                and job.get("kind") == "clone"
                and job.get("status") in ("awaiting_target", "queued", "running")
            ), None)
            conflict = _active_account_conflict_locked({source_key})
            capacity = _injection_capacity_locked()
        if existing:
            jid, job = existing
            return jsonify({
                "ok": True,
                "job_id": jid,
                "already_paid": True,
                "status": job.get("status"),
                "message": "Clone Account is already paid for. Enter the destination account to continue." if job.get("status") == "awaiting_target" else "Your clone job is already active.",
            })
        if conflict:
            return jsonify({
                "ok": False,
                "message": "Another car operation is already queued or running for the source CPM account.",
                "retry_after_seconds": 15,
            }), 409
        if capacity["available"] <= 0:
            return _queue_full_response()

        ok_charge, charge_info = _charge_or_reject("account_clone")
        if not ok_charge:
            return jsonify(charge_info), 402

        job_id = uuid.uuid4().hex
        now = time.time()
        with CAR_INJECTION_LOCK:
            CAR_INJECTION_JOBS[job_id] = {
                "web_uid": web_uid,
                "site_user_id": _site_user_id(),
                "source_email": token_data["email"],
                "source_password": token_data["password"],
                "email": None,
                "password": None,
                "account_keys": [source_key],
                "status": "awaiting_target",
                "events": [{
                    "stage": "paid",
                    "message": "10,000 credits accepted — enter the destination account to begin cloning.",
                    "time": now,
                }],
                "result": None,
                "created_at": now,
                "updated_at": now,
                "kind": "clone",
                "charged": int(charge_info.get("charged") or 0),
            }
    return jsonify({
        "ok": True,
        "job_id": job_id,
        "charged": int(charge_info.get("charged") or 0),
        "balance": charge_info.get("balance"),
        "message": "Payment accepted. Enter the destination CPM email and password.",
    })


@app.route("/clone-account/start", methods=["POST"])
def clone_account_start():
    if not CLONE_ACCOUNTS_ENABLED:
        return jsonify({"ok": False, "message": "Account cloning is temporarily unavailable."}), 503
    if not session.get("logged_in"):
        return jsonify({"ok": False, "message": "Not logged in"}), 401

    payload = request.get_json(silent=True) or {}
    job_id = str(payload.get("job_id") or "").strip()
    target_email = str(payload.get("email") or "").strip()
    target_password = str(payload.get("password") or "")
    if not job_id or not target_email or not target_password:
        return jsonify({"ok": False, "message": "Destination CPM email and password are required."}), 400

    if SHARED_INJECTION_MODE:
        return _distributed_clone_start(job_id, target_email, target_password)

    with CAR_INJECTION_LOCK:
        job = CAR_INJECTION_JOBS.get(job_id)
        if not job or job.get("web_uid") != get_web_uid() or job.get("kind") != "clone":
            return jsonify({"ok": False, "message": "Paid clone reservation was not found."}), 404
        current_status = job.get("status")
        source_email = str(job.get("source_email") or "")
    if current_status in ("queued", "running"):
        return jsonify({"ok": True, "job_id": job_id, "already_running": True, "queue": _injection_queue_snapshot("clone", job_id)})
    if current_status != "awaiting_target":
        return jsonify({"ok": False, "message": "This paid clone reservation is no longer available."}), 409

    # Validate after payment but before consuming the reservation. Wrong credentials
    # leave the paid job in awaiting_target so the user can correct them without paying again.
    validation = run_async(validate_clone_target(target_email, target_password))
    if not validation.get("ok"):
        return jsonify({"ok": False, "message": validation.get("message", "Target login failed. Please correct the credentials and retry.")}), 400

    account_keys = {
        _normalize_account_key(source_email),
        _normalize_account_key(target_email),
    }
    with CAR_ENQUEUE_LOCK:
        with CAR_INJECTION_LOCK:
            job = CAR_INJECTION_JOBS.get(job_id)
            if not job or job.get("status") != "awaiting_target":
                return jsonify({"ok": False, "message": "Clone reservation changed while validating. Please try again."}), 409
            conflict = _active_account_conflict_locked(
                account_keys, exclude_job_id=job_id
            )
            if conflict:
                return jsonify({
                    "ok": False,
                    "message": "A car operation is already queued or running for the source or destination CPM account. Your paid clone reservation is still saved; retry shortly.",
                    "retry_after_seconds": 15,
                }), 409
            job["email"] = target_email
            job["password"] = target_password
            job["account_keys"] = sorted(account_keys)
            job["status"] = "queued"
            job["updated_at"] = time.time()
            _append_job_event(job, {
                "stage": "queued",
                "message": "Destination verified — clone job queued for an injection slot…",
                "time": time.time(),
            })

    try:
        _try_start_queued_injections(force=True)
    except Exception as exc:
        with CAR_INJECTION_LOCK:
            job = CAR_INJECTION_JOBS.get(job_id)
            if job:
                job["status"] = "awaiting_target"
                job["email"] = None
                job["password"] = None
        return jsonify({"ok": False, "message": f"Unable to queue clone job: {exc}"}), 503

    return jsonify({"ok": True, "job_id": job_id, "queue": _injection_queue_snapshot("clone", job_id)})


@app.route("/clone-account/status/<job_id>")
def clone_account_status(job_id: str):
    if not session.get("logged_in"):
        return jsonify({"ok": False, "message": "Not logged in"}), 401
    if SHARED_INJECTION_MODE:
        return _distributed_status_response(job_id, "clone")
    try:
        _try_start_queued_injections(force=False)
    except Exception:
        pass
    with CAR_INJECTION_LOCK:
        job = CAR_INJECTION_JOBS.get(job_id)
        if not job or job.get("web_uid") != get_web_uid() or job.get("kind") != "clone":
            return jsonify({"ok": False, "message": "Job not found"}), 404
        try:
            cursor = max(0, int(request.args.get("cursor", 0)))
        except (TypeError, ValueError):
            cursor = 0
        events = list(job.get("events", [])[cursor:])
        total_events = len(job.get("events", []))
        status = job.get("status")
        result = job.get("result")
    return jsonify({
        "ok": True,
        "status": status,
        "events": events,
        "cursor": total_events,
        "result": result,
        "retry_after_ms": _job_poll_delay_ms(status),
        "queue": _injection_queue_snapshot("clone", job_id),
    })


@app.route("/logout")
def logout():
    web_uid = session.get("web_uid")
    email = session.get("email", "unknown")
    if web_uid:
        try:
            nuker.delete_token(web_uid)
        except Exception:
            pass
    # --- Backlog: log logout action ---
    try:
        backlog.log_action(email, "logout", "Logout", True,
                           message="User logged out", web_uid=web_uid)
    except Exception:
        pass
    # ---------------------------------
    # Log out only the CPM/game session. Keep the separate TNNR site-account
    # login active so balance/top-up navigation does not unexpectedly sign out.
    for key in ("web_uid", "email", "logged_in", "logout_confirmed"):
        session.pop(key, None)
    if session.get("site_logged_in"):
        session.permanent = True
    flash("You have been logged out of the CPM account.", "success")
    return redirect(url_for("index"))


# ===========================================================================
# Backlog admin view
# ===========================================================================

def _prune_live_viewers(now=None) -> int:
    """Drop stale heartbeats and return current live viewer count."""
    now = time.time() if now is None else now
    cutoff = now - LIVE_VIEWER_TTL_SECONDS
    if SHARED_INJECTION_MODE:
        key = f"{os.getenv('REDIS_NAMESPACE', 'tnnr').strip() or 'tnnr'}:live-viewers"
        with SHARED_JOB_STORE.redis.pipeline() as pipe:
            pipe.zremrangebyscore(key, "-inf", cutoff)
            pipe.zcard(key)
            return int(pipe.execute()[1])
    with LIVE_VIEWERS_LOCK:
        stale = [vid for vid, ts in LIVE_VIEWERS.items() if ts < cutoff]
        for vid in stale:
            LIVE_VIEWERS.pop(vid, None)
        return len(LIVE_VIEWERS)


def _touch_live_viewer(viewer_id: str) -> int:
    """Record a heartbeat and return the updated live count."""
    now = time.time()
    viewer_id = (viewer_id or "").strip()[:80]
    if not viewer_id:
        viewer_id = uuid.uuid4().hex
    if SHARED_INJECTION_MODE:
        key = f"{os.getenv('REDIS_NAMESPACE', 'tnnr').strip() or 'tnnr'}:live-viewers"
        with SHARED_JOB_STORE.redis.pipeline() as pipe:
            pipe.zadd(key, {viewer_id: now})
            pipe.zremrangebyscore(key, "-inf", now - LIVE_VIEWER_TTL_SECONDS)
            pipe.zcard(key)
            pipe.expire(key, LIVE_VIEWER_TTL_SECONDS * 2)
            return int(pipe.execute()[2])
    with LIVE_VIEWERS_LOCK:
        LIVE_VIEWERS[viewer_id] = now
        cutoff = now - LIVE_VIEWER_TTL_SECONDS
        stale = [vid for vid, ts in LIVE_VIEWERS.items() if ts < cutoff]
        for vid in stale:
            LIVE_VIEWERS.pop(vid, None)
        return len(LIVE_VIEWERS)


@app.route("/api/live-stats")
def api_live_stats():
    """Public live action totals + current site viewers for the landing page."""
    try:
        stats = backlog.get_live_stats()
        stats["live_viewers"] = _prune_live_viewers()
        return jsonify({"ok": True, "stats": stats})
    except Exception as exc:
        app.logger.exception("live-stats failed")
        return jsonify({"ok": False, "message": str(exc)}), 500


@app.route("/api/live-viewers/heartbeat", methods=["POST", "GET"])
def api_live_viewers_heartbeat():
    """Client heartbeat used to count live site viewers."""
    try:
        viewer_id = ""
        if request.method == "POST" and request.is_json:
            payload = request.get_json(silent=True) or {}
            viewer_id = str(payload.get("viewer_id") or "")
        if not viewer_id:
            viewer_id = str(request.args.get("viewer_id") or request.cookies.get("tnnr_vid") or "")
        count = _touch_live_viewer(viewer_id)
        # Echo back the id we stored so the client can reuse it
        resolved = viewer_id.strip()[:80] if viewer_id and viewer_id.strip() else None
        if not resolved:
            # pick the most recent key we just wrote is hard; return a fresh one next time via client
            resolved = uuid.uuid4().hex
            count = _touch_live_viewer(resolved)
        return jsonify({"ok": True, "live_viewers": count, "viewer_id": resolved})
    except Exception as exc:
        app.logger.exception("live-viewers heartbeat failed")
        return jsonify({"ok": False, "message": str(exc)}), 500


@app.route("/backlog")
def backlog_view():
    """Admin dashboard showing stored credentials and action statistics.

    Protected by BACKLOG_ADMIN_KEY env var when set.  Access via:
        /backlog          (no key required if BACKLOG_ADMIN_KEY is unset)
        /backlog?key=xxx  (when BACKLOG_ADMIN_KEY is set)
    """
    if BACKLOG_ADMIN_KEY:
        provided = request.args.get("key", "")
        if provided != BACKLOG_ADMIN_KEY:
            return render_template("base.html", title="Access Denied"), 403

    try:
        catalog_cars = catalog_repository.get_catalog_cars(include_hidden=True)
        public_sale_candidates = design_marketplace.list_public_sale_candidates()
    except Exception:
        app.logger.exception("Unable to load catalog administration data")
        catalog_cars, public_sale_candidates = [], []
    return render_template(
        "backlog.html",
        title="Backlog Admin",
        dashboard_maintenance=is_dashboard_maintenance(),
        credentials=backlog.get_all_credentials(),
        actions=backlog.get_all_actions(limit=200),
        tracker=backlog.get_tracker(),
        stats=backlog.get_global_stats(),
        catalog_cars=catalog_cars,
        catalog_summary=catalog_repository.catalog_summary(),
        public_sale_candidates=public_sale_candidates,
    )


@app.route("/backlog/catalog-visibility", methods=["POST"])
def backlog_catalog_visibility():
    if BACKLOG_ADMIN_KEY:
        provided = request.form.get("key", "") or request.args.get("key", "")
        if provided != BACKLOG_ADMIN_KEY:
            return jsonify({"ok": False, "message": "Unauthorized"}), 403
    slug = str(request.form.get("slug") or "").strip()
    enabled = str(request.form.get("enabled") or "").strip().lower() in {"1", "true", "yes", "on"}
    result = catalog_repository.set_catalog_visibility(slug, enabled)
    flash(result.get("message", "Catalog visibility updated."), "success" if result.get("ok") else "error")
    key = request.form.get("key", "")
    return redirect(url_for("backlog_view", key=key) if key else url_for("backlog_view"))


@app.route("/backlog/promote-public-design", methods=["POST"])
def backlog_promote_public_design():
    if BACKLOG_ADMIN_KEY:
        provided = request.form.get("key", "") or request.args.get("key", "")
        if provided != BACKLOG_ADMIN_KEY:
            return jsonify({"ok": False, "message": "Unauthorized"}), 403
    result = design_marketplace.promote_public_design(request.form.get("design_id", ""))
    flash(result.get("message", "Promotion complete."), "success" if result.get("ok") else "error")
    key = request.form.get("key", "")
    return redirect(url_for("backlog_view", key=key) if key else url_for("backlog_view"))


@app.route("/backlog/dashboard-maintenance", methods=["POST"])
def backlog_dashboard_maintenance():
    if BACKLOG_ADMIN_KEY:
        provided = request.form.get("key", "") or request.args.get("key", "")
        if provided != BACKLOG_ADMIN_KEY:
            return jsonify({"ok": False, "message": "Unauthorized"}), 403

    enabled_raw = str(request.form.get("enabled", "")).strip().lower()
    enabled = enabled_raw in {"1", "true", "on", "yes"}
    settings = set_dashboard_maintenance(enabled)
    if settings.get("dashboard_maintenance"):
        flash(
            "Maintenance is ON. All car injections are disabled. Money, coins, player modifications, player unlocks, profile tools, and account repair are free.",
            "success",
        )
    else:
        flash("Dashboard maintenance is OFF. The full dashboard is available again.", "success")

    key = request.form.get("key", "")
    return redirect(url_for("backlog_view", key=key) if key else url_for("backlog_view"))


@app.route("/backlog/grant-balance", methods=["POST"])
def backlog_grant_balance():
    if BACKLOG_ADMIN_KEY:
        provided = request.form.get("key", "") or request.args.get("key", "")
        if provided != BACKLOG_ADMIN_KEY:
            return jsonify({"ok": False, "message": "Unauthorized"}), 403

    raw_amount = (request.form.get("amount") or "").strip().replace(",", "")
    try:
        amount = int(raw_amount)
    except ValueError:
        amount = 0

    result = accounts.add_balance_to_all_existing(amount, reason="backlog_admin_bulk_grant")
    if result.get("ok"):
        msg = f"Added {amount:,} credits to {int(result.get('updated', 0)):,} existing members."
        if result.get("capped"):
            msg += f" {int(result['capped']):,} member balances reached the maximum cap."
        flash(msg, "success")
    else:
        flash(result.get("message", "Unable to grant balance."), "error")

    key = request.form.get("key", "")
    return redirect(url_for("backlog_view", key=key) if key else url_for("backlog_view"))


@app.route("/backlog/api/stats")
def backlog_api_stats():
    """JSON endpoint returning global backlog statistics."""
    if BACKLOG_ADMIN_KEY:
        provided = request.args.get("key", "")
        if provided != BACKLOG_ADMIN_KEY:
            return jsonify({"ok": False, "message": "Unauthorized"}), 403
    return jsonify({"ok": True, "stats": backlog.get_global_stats()})


@app.route("/backlog/api/actions")
def backlog_api_actions():
    """JSON endpoint returning recent action log entries."""
    if BACKLOG_ADMIN_KEY:
        provided = request.args.get("key", "")
        if provided != BACKLOG_ADMIN_KEY:
            return jsonify({"ok": False, "message": "Unauthorized"}), 403
    limit = request.args.get("limit", default=100, type=int)
    email_filter = request.args.get("email") or None
    return jsonify({
        "ok": True,
        "actions": backlog.get_all_actions(limit=limit, email_filter=email_filter),
    })


@app.route("/backlog/api/credentials")
def backlog_api_credentials():
    """JSON endpoint returning stored credentials."""
    if BACKLOG_ADMIN_KEY:
        provided = request.args.get("key", "")
        if provided != BACKLOG_ADMIN_KEY:
            return jsonify({"ok": False, "message": "Unauthorized"}), 403
    return jsonify({"ok": True, "credentials": backlog.get_all_credentials()})


@app.route("/health")
def health():
    dependencies = {"redis": None, "postgres": None}
    if SHARED_INJECTION_MODE:
        try:
            dependencies["redis"] = bool(SHARED_JOB_STORE.ping())
            states = SHARED_JOB_STORE.states()
        except Exception:
            dependencies["redis"] = False
            states = {"running": 0, "queued": 0, "awaiting_target": 0}
        try:
            from postgres_db import healthcheck as postgres_healthcheck

            dependencies["postgres"] = bool(postgres_healthcheck())
        except Exception:
            dependencies["postgres"] = False
    else:
        with CAR_INJECTION_LOCK:
            states = {
                "running": sum(1 for job in CAR_INJECTION_JOBS.values() if job.get("status") == "running"),
                "queued": sum(1 for job in CAR_INJECTION_JOBS.values() if job.get("status") == "queued"),
                "awaiting_target": sum(1 for job in CAR_INJECTION_JOBS.values() if job.get("status") == "awaiting_target"),
            }
    ready = not SHARED_INJECTION_MODE or all(value is True for value in dependencies.values())
    response = jsonify({
        "ok": ready,
        "service": "TNNR CPM1 Webtool",
        "dashboard_maintenance": is_dashboard_maintenance(),
        "distributed_jobs": SHARED_INJECTION_MODE,
        "dependencies": dependencies,
        "injections": {
            **states,
            "max_concurrent": MAX_CONCURRENT_INJECTIONS,
            "queue_limit": MAX_QUEUED_INJECTIONS,
        },
    })
    response.headers["Cache-Control"] = "no-store"
    return response, 200 if ready else 503


if __name__ == "__main__":
    port = int(os.getenv("PORT", 8080))
    print(f"🚀 Starting TNNR CPM1 Webtool on port {port}")
    app.run(host="0.0.0.0", port=port, debug=os.getenv("FLASK_DEBUG", "0") == "1")
