import importlib
import json
import os
import tempfile
import unittest
from pathlib import Path

# Test secrets are fake placeholders only; they are never sent to Stripe.
os.environ.setdefault("FLASK_SECRET_KEY", "test-flask-secret")
os.environ.setdefault("STRIPE_SECRET_KEY", "test-stripe-secret")
os.environ.setdefault("STRIPE_WEBHOOK_SECRET", "test-webhook-secret")
os.environ.setdefault("APP_BASE_URL", "https://example.test")
os.environ.setdefault("TOPUP_CURRENCY", "usd")

import accounts
import app as app_module


class _FakeCheckoutSessionResult:
    url = "https://checkout.stripe.test/session"


class _FakeCheckoutSession:
    last_kwargs = None

    @staticmethod
    def create(**kwargs):
        _FakeCheckoutSession.last_kwargs = kwargs
        return _FakeCheckoutSessionResult()


class _FakeWebhook:
    next_event = None

    @staticmethod
    def construct_event(payload, sig_header, secret):
        if not sig_header:
            raise ValueError("missing signature")
        if secret != os.environ["STRIPE_WEBHOOK_SECRET"]:
            raise ValueError("bad secret")
        if _FakeWebhook.next_event is not None:
            return _FakeWebhook.next_event
        return json.loads(payload.decode("utf-8"))


class _FakeStripe:
    api_key = None

    class checkout:
        Session = _FakeCheckoutSession

    Webhook = _FakeWebhook


class StripeTopUpTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old_accounts_file = accounts.ACCOUNTS_FILE
        accounts.ACCOUNTS_FILE = str(Path(self.tmp.name) / "site_accounts.json")
        app_module.app.config.update(TESTING=True, SECRET_KEY="test-flask-secret")
        self.old_stripe = app_module.stripe
        app_module.stripe = _FakeStripe
        _FakeCheckoutSession.last_kwargs = None
        _FakeWebhook.next_event = None

    def tearDown(self):
        app_module.stripe = self.old_stripe
        accounts.ACCOUNTS_FILE = self.old_accounts_file
        self.tmp.cleanup()

    def _register_and_login_session(self, client):
        result = accounts.register("buyer@example.test", "password")
        self.assertTrue(result["ok"])
        with client.session_transaction() as sess:
            sess["site_user_id"] = result["user_id"]
            sess["site_email"] = result["email"]
            sess["site_logged_in"] = True
        return result

    def test_topup_pack_allowlist_contains_existing_and_new_amounts(self):
        self.assertEqual(accounts.pack_info("pack_2k"), {"credits": 2_000, "amount_cents": 50})
        self.assertEqual(accounts.pack_info("pack_5k"), {"credits": 5_000, "amount_cents": 100})
        self.assertEqual(accounts.pack_info("pack_10k"), {"credits": 10_000, "amount_cents": 199})
        self.assertEqual(accounts.pack_info("pack_50k"), {"credits": 50_000, "amount_cents": 799})
        self.assertEqual(accounts.pack_info("pack_150k"), {"credits": 150_000, "amount_cents": 1999})
        self.assertEqual(accounts.pack_info("pack_500k"), {"credits": 500_000, "amount_cents": 4999})
        self.assertIsNone(accounts.pack_info("pack_client_supplied_999999"))

    def test_checkout_session_uses_server_side_allowlist_amount(self):
        client = app_module.app.test_client()
        user = self._register_and_login_session(client)

        response = client.post("/stripe/checkout/pack_2k")

        self.assertEqual(response.status_code, 303)
        self.assertEqual(response.headers["Location"], _FakeCheckoutSessionResult.url)
        kwargs = _FakeCheckoutSession.last_kwargs
        self.assertIsNotNone(kwargs)
        self.assertEqual(kwargs["mode"], "payment")
        self.assertEqual(kwargs["success_url"], "https://example.test/stripe/success?session_id={CHECKOUT_SESSION_ID}")
        line_item = kwargs["line_items"][0]
        self.assertEqual(line_item["quantity"], 1)
        self.assertEqual(line_item["price_data"]["unit_amount"], 50)
        self.assertEqual(line_item["price_data"]["currency"], "usd")
        self.assertEqual(kwargs["metadata"]["site_user_id"], user["user_id"])
        self.assertEqual(kwargs["metadata"]["pack_id"], "pack_2k")
        self.assertEqual(kwargs["metadata"]["expected_amount_cents"], "50")

    def test_checkout_rejects_unknown_pack_before_calling_stripe(self):
        client = app_module.app.test_client()
        self._register_and_login_session(client)

        response = client.post("/stripe/checkout/not_allowed")

        self.assertEqual(response.status_code, 302)
        self.assertIsNone(_FakeCheckoutSession.last_kwargs)

    def test_signed_webhook_fulfills_once_and_retries_do_not_double_credit(self):
        client = app_module.app.test_client()
        user = accounts.register("buyer@example.test", "password")
        self.assertTrue(user["ok"])
        event = {
            "id": "evt_test_1",
            "type": "checkout.session.completed",
            "data": {"object": {
                "id": "cs_test_1",
                "payment_status": "paid",
                "amount_total": 50,
                "currency": "usd",
                "metadata": {"site_user_id": user["user_id"], "pack_id": "pack_2k"},
            }},
        }

        first = client.post("/stripe/webhook", data=json.dumps(event), headers={"Stripe-Signature": "sig"})
        second = client.post("/stripe/webhook", data=json.dumps(event), headers={"Stripe-Signature": "sig"})

        self.assertEqual(first.status_code, 200)
        self.assertEqual(first.get_json(), {"ok": True, "duplicate": False})
        self.assertEqual(second.status_code, 200)
        self.assertEqual(second.get_json(), {"ok": True, "duplicate": True})
        self.assertEqual(accounts.get_balance(user["user_id"]), 2_000)

    def test_webhook_rejects_amount_mismatch_without_credit(self):
        client = app_module.app.test_client()
        user = accounts.register("buyer@example.test", "password")
        self.assertTrue(user["ok"])
        event = {
            "id": "evt_bad_amount",
            "type": "checkout.session.completed",
            "data": {"object": {
                "id": "cs_bad_amount",
                "payment_status": "paid",
                "amount_total": 999,
                "currency": "usd",
                "metadata": {"site_user_id": user["user_id"], "pack_id": "pack_2k"},
            }},
        }

        response = client.post("/stripe/webhook", data=json.dumps(event), headers={"Stripe-Signature": "sig"})

        self.assertEqual(response.status_code, 400)
        self.assertEqual(accounts.get_balance(user["user_id"]), 0)

    def test_existing_charge_and_free_money_behavior_remain(self):
        user = accounts.register("buyer@example.test", "password")
        self.assertTrue(user["ok"])
        self.assertEqual(accounts.price_for("set_money", amount=15_000_000), 0)
        self.assertEqual(accounts.price_for("set_money", amount=15_000_001), accounts.PRICE_MONEY)
        accounts.add_balance(user["user_id"], 1_000, reason="test")
        charged = accounts.charge(user["user_id"], "set_coin")
        self.assertTrue(charged["ok"])
        self.assertEqual(charged["charged"], accounts.PRICE_COIN)
        self.assertEqual(accounts.get_balance(user["user_id"]), 1_000 - accounts.PRICE_COIN)


if __name__ == "__main__":
    unittest.main()
