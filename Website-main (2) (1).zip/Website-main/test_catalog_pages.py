import os
import tempfile
import unittest


class CatalogPageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        os.environ.pop("DATABASE_URL", None)
        os.environ["DATA_DIR"] = cls.tmp.name
        import app as app_module
        cls.app_module = app_module
        cls.app_module.app.config.update(TESTING=True, SECRET_KEY="test-flask-secret")

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_cars_hub_has_requested_order(self):
        html = self.app_module.app.test_client().get("/cars").get_data(as_text=True)
        labels = [
            "Verified Cars Injection Catalog",
            "Public Sale Cars Injection Catalog",
            "Event Cars Injections",
            "Premium Cars Injections",
        ]
        positions = [html.index(label) for label in labels]
        self.assertEqual(positions, sorted(positions))
        self.assertIn("To report a public-sale car", html)

    def test_public_catalog_directs_reports_to_listing_form(self):
        original_list_public = self.app_module.design_marketplace.list_public
        self.app_module.design_marketplace.list_public = lambda sort="newest", limit=100: []
        try:
            html = self.app_module.app.test_client().get("/shared-designs").get_data(as_text=True)
        finally:
            self.app_module.design_marketplace.list_public = original_list_public
        self.assertIn("Report Design", html)
        self.assertIn("Do not open a general support ticket", html)

    def test_verified_catalog_route_renders_without_database(self):
        response = self.app_module.app.test_client().get("/designed-cars")
        self.assertEqual(response.status_code, 200)
        self.assertIn("Verified Cars Injection Catalog", response.get_data(as_text=True))

    def test_backlog_catalog_admin_page_renders_promotion_controls(self):
        original_candidates = self.app_module.design_marketplace.list_public_sale_candidates
        self.app_module.design_marketplace.list_public_sale_candidates = lambda limit=300: [{
            "design_id": "public-1", "share_code": "TNNR-PUBLIC1", "title": "Public Track Car",
            "owner_email": "seller@example.com", "car_id": 123, "vinyl_count": 42,
            "sales_count": 0, "sales_limit": 1, "report_count": 0, "is_promoted": False,
        }]
        try:
            response = self.app_module.app.test_client().get("/backlog")
        finally:
            self.app_module.design_marketplace.list_public_sale_candidates = original_candidates
        self.assertEqual(response.status_code, 200)
        html = response.get_data(as_text=True)
        self.assertIn("Copy a public design into the Verified Cars Injection Catalog", html)
        self.assertIn("/backlog/promote-public-design", html)


if __name__ == "__main__":
    unittest.main()
