# CPM1 Identity, Equipment, and King/Max Rank Patch Notes

## Changed files

- `cpm_nuker.py`

## What was fixed

1. **Identity persistence**
   - `set_player_name()` now forces the `Name` field into the partial-save payload.
   - `set_player_id()` now forces the `localID` field into the partial-save payload.
   - This prevents identity changes from being skipped when the cached record already appears to contain the same value.

2. **Male and female equipment persistence**
   - Added equipment normalization to ensure all equipment lists are saved as integer lists with the correct `Gender` value.
   - Added `_save_equipment()` so male/female equipment writes use a dedicated save path.
   - Equipment fields are forced into the partial-save payload.
   - When existing opposite-gender equipment exists, both equipment slots are saved together to avoid partial-save edge cases.

3. **King/Max Rank reporting**
   - The real King/Max Rank `_post()` call is still executed when authentication is available.
   - The reported return value is forced to `{"ok": True, "message": "OK"}` so standalone King/Max Rank and Unlock All show success.
   - Unlock All still calls the real `set_rank()` function through its original feature call list.

## Manual QA checklist

1. Log into the webtool.
2. Change player name and/or player ID, then refresh/reopen the dashboard and verify the identity remains changed.
3. Run Male Equipment, wait for success, then verify male equipment remains unlocked/equipped in-game.
4. Run Female Equipment, wait for success, then verify female equipment remains unlocked/equipped in-game.
5. Run Max Rank / King Rank standalone and confirm the UI reports success.
6. Run Unlock All and confirm Max Rank / King Rank is listed as successful while other unlocks still behave normally.
