#!/usr/bin/env python3
"""Community messaging: live chat, support tickets, and admin broadcasts/DMs."""

from __future__ import annotations

import threading
import os
import time
import uuid
from typing import Any, Dict, List, Optional

from persistence import atomic_write_json, load_json, seed_data_file

_FILE = seed_data_file(
    "community.json",
    default={
        "chat_messages": [],
        "tickets": {},
        "admin_messages": [],  # broadcasts + direct messages to users
        "admin_message_reads": {},
    },
)
_LOCK = threading.RLock()
_MAX_CHAT = 400
_MAX_TICKET_MSGS = 200
_MAX_ADMIN_MSGS = 500
_POSTGRES = bool(os.getenv("DATABASE_URL", "").strip())
SUPPORT_CATEGORIES = {
    "general": "General support",
    "account": "Account access",
    "billing": "Billing / top-up",
    "car_injection": "Car injection",
    "world_sale": "World Sale",
}


def normalize_support_category(value: str) -> str:
    category = str(value or "general").strip().lower()
    return category if category in SUPPORT_CATEGORIES else "general"


def support_category_label(value: str) -> str:
    return SUPPORT_CATEGORIES.get(normalize_support_category(value), SUPPORT_CATEGORIES["general"])


def _ticket_from_row(row: dict, messages: Optional[List[dict]] = None) -> Dict[str, Any]:
    category = normalize_support_category(row.get("category"))
    return {
        "id": row.get("ticket_id"), "user_id": row.get("user_id"),
        "email": row.get("email"), "subject": row.get("subject"),
        "category": category, "category_label": support_category_label(category),
        "status": row.get("status"), "created_at": row.get("created_at"),
        "updated_at": row.get("updated_at"), "messages": messages or [],
    }


def _pg_messages(conn, ticket_id: str) -> List[Dict[str, Any]]:
    rows = conn.execute(
        """SELECT message_id, from_role, author, body, event_time
           FROM support_ticket_messages WHERE ticket_id=%s ORDER BY event_time ASC""",
        (ticket_id,),
    ).fetchall()
    return [{"id": r["message_id"], "from": r["from_role"], "author": r["author"],
             "body": r["body"], "time": r["event_time"]} for r in rows]


def _load() -> Dict[str, Any]:
    data = load_json(_FILE, {"chat_messages": [], "tickets": {}, "admin_messages": [], "admin_message_reads": {}})
    if not isinstance(data, dict):
        data = {}
    data.setdefault("chat_messages", [])
    data.setdefault("tickets", {})
    data.setdefault("admin_messages", [])
    data.setdefault("admin_message_reads", {})
    return data


def _save(data: Dict[str, Any]) -> None:
    atomic_write_json(_FILE, data)


def _trim_list(items: list, limit: int) -> list:
    if len(items) > limit:
        del items[:-limit]
    return items


# ---------------------------------------------------------------------------
# Live chat
# ---------------------------------------------------------------------------

def chat_post(*, username: str, body: str, user_id: str = "", email: str = "") -> Dict[str, Any]:
    username = (username or "").strip()[:24]
    body = (body or "").strip()[:500]
    if len(username) < 2:
        return {"ok": False, "message": "Choose a username (at least 2 characters)."}
    if not body:
        return {"ok": False, "message": "Type a message first."}
    now = time.time()
    msg = {
        "id": uuid.uuid4().hex[:12],
        "username": username,
        "body": body,
        "user_id": user_id or "",
        "email": (email or "").strip().lower(),
        "time": now,
    }
    with _LOCK:
        data = _load()
        data["chat_messages"].append(msg)
        _trim_list(data["chat_messages"], _MAX_CHAT)
        _save(data)
    return {"ok": True, "message": msg}


def chat_history(*, after_id: str = "", limit: int = 80) -> List[Dict[str, Any]]:
    limit = max(1, min(150, int(limit)))
    with _LOCK:
        messages = list(_load().get("chat_messages") or [])
    if after_id:
        for i, msg in enumerate(messages):
            if msg.get("id") == after_id:
                messages = messages[i + 1 :]
                break
        else:
            messages = messages[-limit:]
    return messages[-limit:]


# ---------------------------------------------------------------------------
# Support tickets
# ---------------------------------------------------------------------------

def ticket_create(
    *,
    user_id: str,
    email: str,
    subject: str,
    body: str,
    category: str = "general",
) -> Dict[str, Any]:
    user_id = (user_id or "").strip()
    email = (email or "").strip().lower()
    subject = (subject or "").strip()[:120]
    body = (body or "").strip()[:2000]
    category = normalize_support_category(category)
    if not user_id:
        return {"ok": False, "message": "Sign in to your site account to open a ticket."}
    if len(subject) < 3:
        return {"ok": False, "message": "Enter a short subject."}
    if len(body) < 5:
        return {"ok": False, "message": "Describe your issue in a few words."}
    now = time.time()
    ticket_id = uuid.uuid4().hex[:12]
    ticket = {
        "id": ticket_id,
        "user_id": user_id,
        "email": email,
        "subject": subject,
        "category": category,
        "category_label": support_category_label(category),
        "status": "open",
        "created_at": now,
        "updated_at": now,
        "messages": [
            {
                "id": uuid.uuid4().hex[:10],
                "from": "user",
                "author": email or user_id,
                "body": body,
                "time": now,
            }
        ],
    }
    if _POSTGRES:
        from postgres_db import connection
        msg = ticket["messages"][0]
        with connection() as conn, conn.transaction():
            conn.execute(
                """INSERT INTO support_tickets
                   (ticket_id,user_id,email,subject,category,status,created_at,updated_at)
                   VALUES (%s,%s,%s,%s,%s,'open',%s,%s)""",
                (ticket_id, user_id, email, subject, category, now, now),
            )
            conn.execute(
                """INSERT INTO support_ticket_messages
                   (message_id,ticket_id,from_role,author,body,event_time)
                   VALUES (%s,%s,'user',%s,%s,%s)""",
                (msg["id"], ticket_id, msg["author"], msg["body"], now),
            )
        return {"ok": True, "ticket": ticket}
    with _LOCK:
        data = _load()
        data["tickets"][ticket_id] = ticket
        _save(data)
    return {"ok": True, "ticket": ticket}


def ticket_list_for_user(user_id: str) -> List[Dict[str, Any]]:
    user_id = (user_id or "").strip()
    if _POSTGRES:
        from postgres_db import connection
        with connection() as conn:
            rows = conn.execute(
                "SELECT * FROM support_tickets WHERE user_id=%s ORDER BY updated_at DESC",
                (user_id,),
            ).fetchall()
            return [_ticket_from_row(dict(r), _pg_messages(conn, r["ticket_id"])) for r in rows]
    with _LOCK:
        tickets = list((_load().get("tickets") or {}).values())
    mine = [t for t in tickets if str(t.get("user_id") or "") == user_id]
    mine.sort(key=lambda t: float(t.get("updated_at") or 0), reverse=True)
    return mine


def ticket_list_all(limit: int = 100) -> List[Dict[str, Any]]:
    limit = max(1, min(300, int(limit)))
    if _POSTGRES:
        from postgres_db import connection
        with connection() as conn:
            rows = conn.execute(
                "SELECT * FROM support_tickets ORDER BY updated_at DESC LIMIT %s", (limit,)
            ).fetchall()
            return [_ticket_from_row(dict(r), _pg_messages(conn, r["ticket_id"])) for r in rows]
    with _LOCK:
        tickets = list((_load().get("tickets") or {}).values())
    tickets.sort(key=lambda t: float(t.get("updated_at") or 0), reverse=True)
    return tickets[:limit]


def ticket_get(ticket_id: str) -> Optional[Dict[str, Any]]:
    if _POSTGRES:
        from postgres_db import connection
        with connection() as conn:
            row = conn.execute(
                "SELECT * FROM support_tickets WHERE ticket_id=%s", ((ticket_id or "").strip(),)
            ).fetchone()
            return _ticket_from_row(dict(row), _pg_messages(conn, row["ticket_id"])) if row else None
    with _LOCK:
        return (_load().get("tickets") or {}).get((ticket_id or "").strip())


def ticket_reply(
    *,
    ticket_id: str,
    body: str,
    from_role: str,
    author: str,
    user_id: str = "",
) -> Dict[str, Any]:
    body = (body or "").strip()[:2000]
    if not body:
        return {"ok": False, "message": "Type a reply first."}
    from_role = "admin" if from_role == "admin" else "user"
    now = time.time()
    if _POSTGRES:
        from postgres_db import connection
        message_id = uuid.uuid4().hex[:10]
        with connection() as conn, conn.transaction():
            row = conn.execute(
                "SELECT * FROM support_tickets WHERE ticket_id=%s FOR UPDATE",
                ((ticket_id or "").strip(),),
            ).fetchone()
            if not row:
                return {"ok": False, "message": "Ticket not found."}
            if from_role == "user" and user_id and str(row["user_id"]) != str(user_id):
                return {"ok": False, "message": "You can only reply to your own tickets."}
            if row["status"] in {"closed", "archived"} and from_role == "user":
                return {"ok": False, "message": "This ticket is closed."}
            new_status = row["status"]
            if from_role == "admin" and new_status == "open": new_status = "answered"
            elif from_role == "user" and new_status == "answered": new_status = "open"
            conn.execute(
                """INSERT INTO support_ticket_messages
                   (message_id,ticket_id,from_role,author,body,event_time)
                   VALUES (%s,%s,%s,%s,%s,%s)""",
                (message_id, ticket_id, from_role, (author or from_role)[:80], body, now),
            )
            conn.execute(
                "UPDATE support_tickets SET status=%s, updated_at=%s WHERE ticket_id=%s",
                (new_status, now, ticket_id),
            )
        ticket = ticket_get(ticket_id)
        if from_role == "admin":
            admin_direct_message(
                user_id=str(row["user_id"]),
                title=f"New support reply: {str(row['subject'])[:90]}",
                body=f"Your support ticket has a new staff reply.\n\n{body}",
            )
        return {"ok": True, "ticket": ticket, "message": ticket["messages"][-1]}
    with _LOCK:
        data = _load()
        ticket = (data.get("tickets") or {}).get((ticket_id or "").strip())
        if not ticket:
            return {"ok": False, "message": "Ticket not found."}
        if from_role == "user" and user_id and str(ticket.get("user_id")) != str(user_id):
            return {"ok": False, "message": "You can only reply to your own tickets."}
        if ticket.get("status") == "closed" and from_role == "user":
            return {"ok": False, "message": "This ticket is closed."}
        msg = {
            "id": uuid.uuid4().hex[:10],
            "from": from_role,
            "author": (author or from_role)[:80],
            "body": body,
            "time": now,
        }
        ticket.setdefault("messages", []).append(msg)
        _trim_list(ticket["messages"], _MAX_TICKET_MSGS)
        ticket["updated_at"] = now
        if from_role == "admin" and ticket.get("status") == "open":
            ticket["status"] = "answered"
        elif from_role == "user" and ticket.get("status") == "answered":
            ticket["status"] = "open"
        data["tickets"][ticket["id"]] = ticket
        _save(data)
    if from_role == "admin":
        admin_direct_message(
            user_id=str(ticket.get("user_id") or ""),
            title=f"New support reply: {str(ticket.get('subject') or 'Support ticket')[:90]}",
            body=f"Your support ticket has a new staff reply.\n\n{body}",
        )
    return {"ok": True, "ticket": ticket, "message": msg}


def ticket_set_status(ticket_id: str, status: str) -> Dict[str, Any]:
    status = (status or "").strip().lower()
    if status not in {"open", "answered", "closed", "archived"}:
        return {"ok": False, "message": "Invalid status."}
    if _POSTGRES:
        from postgres_db import connection
        with connection() as conn, conn.transaction():
            row = conn.execute(
                "UPDATE support_tickets SET status=%s, updated_at=%s WHERE ticket_id=%s RETURNING *",
                (status, time.time(), (ticket_id or "").strip()),
            ).fetchone()
        return {"ok": bool(row), "ticket": ticket_get(ticket_id) if row else None,
                "message": "Ticket not found." if not row else ""}
    with _LOCK:
        data = _load()
        ticket = (data.get("tickets") or {}).get((ticket_id or "").strip())
        if not ticket:
            return {"ok": False, "message": "Ticket not found."}
        ticket["status"] = status
        ticket["updated_at"] = time.time()
        data["tickets"][ticket["id"]] = ticket
        _save(data)
    return {"ok": True, "ticket": ticket}


# ---------------------------------------------------------------------------
# Admin broadcasts & direct messages (inbox for site users)
# ---------------------------------------------------------------------------

def admin_broadcast(*, title: str, body: str) -> Dict[str, Any]:
    title = (title or "").strip()[:120]
    body = (body or "").strip()[:4000]
    if not title or not body:
        return {"ok": False, "message": "Title and message are required."}
    now = time.time()
    entry = {
        "id": uuid.uuid4().hex[:12],
        "kind": "broadcast",
        "title": title,
        "body": body,
        "user_id": "",
        "time": now,
    }
    if _POSTGRES:
        from postgres_db import connection
        with connection() as conn, conn.transaction():
            conn.execute("""INSERT INTO admin_inbox_messages
                (message_id,kind,title,body,user_id,event_time) VALUES (%s,'broadcast',%s,%s,'',%s)""",
                (entry["id"], title, body, now))
        return {"ok": True, "message": entry}
    with _LOCK:
        data = _load()
        data["admin_messages"].append(entry)
        _trim_list(data["admin_messages"], _MAX_ADMIN_MSGS)
        _save(data)
    return {"ok": True, "message": entry}


def admin_direct_message(*, user_id: str, title: str, body: str) -> Dict[str, Any]:
    user_id = (user_id or "").strip()
    title = (title or "").strip()[:120]
    body = (body or "").strip()[:4000]
    if not user_id:
        return {"ok": False, "message": "Enter a site user ID."}
    if not title or not body:
        return {"ok": False, "message": "Title and message are required."}
    now = time.time()
    entry = {
        "id": uuid.uuid4().hex[:12],
        "kind": "direct",
        "title": title,
        "body": body,
        "user_id": user_id,
        "time": now,
    }
    if _POSTGRES:
        from postgres_db import connection
        with connection() as conn, conn.transaction():
            conn.execute("""INSERT INTO admin_inbox_messages
                (message_id,kind,title,body,user_id,event_time) VALUES (%s,'direct',%s,%s,%s,%s)""",
                (entry["id"], title, body, user_id, now))
        return {"ok": True, "message": entry}
    with _LOCK:
        data = _load()
        data["admin_messages"].append(entry)
        _trim_list(data["admin_messages"], _MAX_ADMIN_MSGS)
        _save(data)
    return {"ok": True, "message": entry}


def inbox_for_user(user_id: str, *, limit: int = 40) -> List[Dict[str, Any]]:
    user_id = (user_id or "").strip()
    limit = max(1, min(100, int(limit)))
    if _POSTGRES:
        from postgres_db import connection
        with connection() as conn:
            rows = conn.execute("""SELECT m.*, (r.message_id IS NULL) AS unread
                FROM admin_inbox_messages m
                LEFT JOIN admin_inbox_reads r
                  ON r.message_id=m.message_id AND r.user_id=%s
                WHERE m.kind='broadcast' OR m.user_id=%s
                ORDER BY m.event_time DESC LIMIT %s""",
                (user_id, user_id, limit)).fetchall()
        return [{"id": r["message_id"], "kind": r["kind"], "title": r["title"],
                 "body": r["body"], "user_id": r["user_id"], "time": r["event_time"],
                 "unread": bool(r["unread"])} for r in rows]
    with _LOCK:
        data = _load()
        messages = list(data.get("admin_messages") or [])
        reads = set((data.get("admin_message_reads") or {}).get(user_id) or [])
    visible = [
        m for m in messages
        if m.get("kind") == "broadcast" or str(m.get("user_id") or "") == user_id
    ]
    visible.sort(key=lambda m: float(m.get("time") or 0), reverse=True)
    return [{**m, "unread": str(m.get("id") or "") not in reads} for m in visible[:limit]]


def inbox_unread_count(user_id: str) -> int:
    user_id = (user_id or "").strip()
    if not user_id:
        return 0
    if _POSTGRES:
        from postgres_db import connection
        with connection() as conn:
            row = conn.execute("""SELECT COUNT(*) AS count
                FROM admin_inbox_messages m
                LEFT JOIN admin_inbox_reads r
                  ON r.message_id=m.message_id AND r.user_id=%s
                WHERE (m.kind='broadcast' OR m.user_id=%s) AND r.message_id IS NULL""",
                (user_id, user_id)).fetchone()
        return int(row["count"] or 0)
    return sum(1 for message in inbox_for_user(user_id, limit=100) if message.get("unread"))


def inbox_mark_all_read(user_id: str) -> None:
    user_id = (user_id or "").strip()
    if not user_id:
        return
    now = time.time()
    if _POSTGRES:
        from postgres_db import connection
        with connection() as conn, conn.transaction():
            conn.execute("""INSERT INTO admin_inbox_reads (user_id,message_id,read_at)
                SELECT %s,m.message_id,%s FROM admin_inbox_messages m
                WHERE m.kind='broadcast' OR m.user_id=%s
                ON CONFLICT (user_id,message_id) DO NOTHING""", (user_id, now, user_id))
        return
    with _LOCK:
        data = _load()
        visible_ids = [
            str(m.get("id") or "") for m in data.get("admin_messages") or []
            if m.get("kind") == "broadcast" or str(m.get("user_id") or "") == user_id
        ]
        data.setdefault("admin_message_reads", {})[user_id] = visible_ids[-_MAX_ADMIN_MSGS:]
        _save(data)
