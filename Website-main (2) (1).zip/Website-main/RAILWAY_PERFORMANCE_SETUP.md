# TNNR.shop Performance Setup

> Redis/RQ/PostgreSQL multi-instance support is now implemented. Follow
> `RAILWAY_MULTI_INSTANCE_SETUP.md` for the production migration and replica
> rollout. The values below remain the single-instance fallback configuration.

## Single-instance fallback retained in this build

- Without both Redis and PostgreSQL enabled, the site automatically stays on one Gunicorn worker with 12 bounded request threads and process-local injection state.
- Gunicorn request recycling and preload are disabled so active in-memory jobs are not destroyed by routine worker replacement.
- Forced five-minute Unlimited Currency restarts are disabled by default. They can only be re-enabled deliberately with `UNLIMITED_AUTO_RESTART_ENABLED=1`.
- Car work has a bounded global queue, serialized duplicate-click charging, configurable concurrency, and a per-CPM-account lock. Different accounts can run concurrently; the same account cannot run overlapping car operations.
- Status polling is adaptive, slower, jittered, and visibility-aware. The duplicate landing-page heartbeat was removed.
- Settings and the 4 MB site-account JSON are cached and refreshed when their backing files change.
- Credential logging now appends JSONL instead of reparsing and rewriting the complete credential list on every login.
- CPM token SQLite uses WAL mode, a busy timeout, and a thread-safe memory cache.
- Consecutive injection jobs reuse pooled HTTP connections on each worker event loop.
- Heavy login/player actions have bounded concurrency, queue admission has backpressure, and failed executor starts refund the captured charge.
- `/health` now reports readiness and queue pressure. Slow non-poll requests also emit a warning and every response includes a `Server-Timing` duration.

## Fallback Railway settings

1. Deploy this build, then open the web service's **Settings** page.
2. Set the Start Command to:

   ```text
   gunicorn app:app --config gunicorn.conf.py
   ```

   Remove any older command containing `--workers`, `--max-requests`, or `--preload` so it cannot override the checked-in configuration.
3. Set the health-check path to `/health` with a 300-second deployment timeout. Railway uses health checks while switching deployments, but it does not continuously monitor the service afterward: [Railway health checks](https://docs.railway.com/deployments/healthchecks).
4. Keep **Replicas = 1**. The current job queue is in process memory, and Railway volumes cannot be used with replicas: [Railway volume caveats](https://docs.railway.com/volumes/reference).
5. Use **On Failure** with 10 retries for the restart policy. Do not use scheduled process exits as a performance tool: [Railway restart policies](https://docs.railway.com/deployments/restart-policy).
6. Keep the existing volume mounted at `/app/data` and confirm `DATA_DIR=/app/data`.
7. Add or confirm these variables:

   ```text
   WEB_THREADS=12
   MAX_CONCURRENT_INJECTIONS=1
   MAX_QUEUED_INJECTIONS=40
   MAX_CONCURRENT_ACCOUNT_ACTIONS=4
   MAX_JOB_EVENTS=600
   UNLIMITED_AUTO_RESTART_ENABLED=0
   SETTINGS_CACHE_TTL_SECONDS=1
   SLOW_REQUEST_SECONDS=1
   INJECTION_HTTP_CONNECTION_LIMIT=12
   INJECTION_HTTP_PER_HOST=8
   CPM_SQLITE_BUSY_TIMEOUT_SECONDS=10
   ```

   Leave `GUNICORN_ACCESS_LOG` unset. Set it temporarily to `-` only when you need every request in Railway logs.
8. Leave maintenance mode ON for the first test. Confirm `/health`, CPM login, and the free dashboard work before turning the paid dashboard back on from `/backlog`.

## Safe concurrency test

1. Start with `MAX_CONCURRENT_INJECTIONS=1` and run one premium job to completion.
2. Queue two different CPM accounts. Confirm one runs and one waits, status updates continue, and ordinary pages remain responsive.
3. Watch Railway **Metrics** for CPU, memory, network, disk, HTTP error rate, and latency. Railway documents these metrics and CLI filters here: [Railway metrics](https://docs.railway.com/observability/metrics) and [`railway metrics`](https://docs.railway.com/cli/metrics).
4. If CPU is below 70%, memory is stable, HTTP p95 is acceptable, and CPM does not begin rejecting World Sale calls, test `MAX_CONCURRENT_INJECTIONS=2`.
5. Do not exceed 2 in production until repeated load tests show the upstream CPM service tolerates it. The code hard-caps the value at 4 as a final safety boundary.

## Horizontal scaling implementation

Redis job state, the RQ worker, PostgreSQL balances/ledger/Stripe idempotency,
atomic paid-job reservations, the transactional outbox, and the migration tool
are now included. Follow `RAILWAY_MULTI_INSTANCE_SETUP.md` before raising web
workers or adding replicas. It includes the exact credit-preserving migration,
verification, worker-service configuration, volume-removal, and rollback order.

## What not to change yet

- Do not enable multiple web workers or replicas while jobs are stored in memory.
- Do not raise both request threads and injection concurrency at the same time; change one variable per test.
- Do not turn `UNLIMITED_AUTO_RESTART_ENABLED` back on unless you accept that an in-progress job can be interrupted.
- Do not remove queue/account locks to make jobs appear faster. That shifts load to CPM and increases collisions, duplicate charges, and failed injections.
