#!/usr/bin/env python3
"""PostgreSQL-backed user design codes, marketplace, and moderation."""

from __future__ import annotations

import secrets
import string
import time
import uuid
import re
import hashlib
import json
import os
import unicodedata
from typing import Any, Dict, Optional

from postgres_db import connection


_LAST_DUPLICATE_SCAN = 0.0
_DUPLICATE_SCAN_INTERVAL_SECONDS = max(30, int(os.getenv("SHARED_DESIGN_DUPLICATE_SCAN_SECONDS", "300")))
REPORT_AUTO_DISABLE_THRESHOLD = max(1, int(os.getenv("SHARED_DESIGN_REPORT_AUTO_DISABLE_THRESHOLD", "5")))


def _normalized_title(value: str) -> str:
    value = unicodedata.normalize("NFKC", str(value or "")).casefold()
    return " ".join(re.sub(r"[^a-z0-9]+", " ", value).split())[:140]


def _marker_neutral_payload(value: Any, marker: str) -> Any:
    """Replace only the generated marker so reposts cannot evade payload matching."""
    if isinstance(value, dict):
        return {str(k): _marker_neutral_payload(v, marker) for k, v in sorted(value.items(), key=lambda item: str(item[0]))}
    if isinstance(value, list):
        return [_marker_neutral_payload(item, marker) for item in value]
    if isinstance(value, str) and marker and value.strip() == marker:
        return "__TNNR_VERIFICATION_MARKER__"
    return value


def _payload_fingerprint(car: dict, marker: str) -> str:
    canonical = json.dumps(
        _marker_neutral_payload(car, marker), ensure_ascii=False,
        sort_keys=True, separators=(",", ":"), default=str,
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def _photo_fingerprint(photo_data: bytes) -> str:
    return hashlib.sha256(photo_data).hexdigest() if photo_data else ""


def _duplicate_reasons(candidate: Dict[str, Any], existing: Dict[str, Any]) -> list[str]:
    reasons = []
    if candidate.get("payload_fingerprint") and candidate.get("payload_fingerprint") == existing.get("payload_fingerprint"):
        reasons.append("identical car payload")
    if candidate.get("photo_fingerprint") and candidate.get("photo_fingerprint") == existing.get("photo_fingerprint"):
        reasons.append("identical listing photo")
    if (
        candidate.get("normalized_title")
        and candidate.get("normalized_title") == existing.get("normalized_title")
        and int(candidate.get("car_id") or 0) == int(existing.get("car_id") or 0)
        and int(candidate.get("vinyl_count") or 0) == int(existing.get("vinyl_count") or 0)
    ):
        reasons.append("same normalized title, Car ID, and vinyl count")
    if (
        candidate.get("verification_marker")
        and candidate.get("verification_marker") == existing.get("verification_marker")
        and int(candidate.get("car_id") or 0) == int(existing.get("car_id") or 0)
    ):
        reasons.append("same verification number and Car ID")
    return reasons


def _seller_control_in_transaction(conn, user_id: str) -> Dict[str, Any]:
    now = time.time()
    conn.execute("""INSERT INTO shared_design_seller_controls
        (user_id,public_selling_status,suspended_until,reason,warning_count,updated_at)
        VALUES (%s,'active',NULL,'',0,%s) ON CONFLICT (user_id) DO NOTHING""",
        (user_id, now))
    row = conn.execute(
        "SELECT * FROM shared_design_seller_controls WHERE user_id=%s FOR UPDATE",
        (user_id,),
    ).fetchone()
    if not row:
        raise RuntimeError("Unable to initialize marketplace seller controls.")
    result = dict(row)
    if (
        result.get("public_selling_status") == "temporary"
        and result.get("suspended_until")
        and float(result["suspended_until"]) <= now
    ):
        conn.execute("""UPDATE shared_design_seller_controls
            SET public_selling_status='active',suspended_until=NULL,reason='',updated_at=%s
            WHERE user_id=%s""", (now, user_id))
        result.update(public_selling_status="active", suspended_until=None, reason="", updated_at=now)
    return result


def _public_selling_error(control: Dict[str, Any]) -> str:
    status = str(control.get("public_selling_status") or "active")
    reason = str(control.get("reason") or "Marketplace rule violations.")
    if status == "permanent":
        return f"Your public selling access was permanently removed by an administrator. Reason: {reason}"
    if status == "temporary":
        until = time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime(float(control.get("suspended_until") or 0)))
        return f"Your public selling access is temporarily suspended until {until}. Reason: {reason}"
    return ""


def _log_moderation_event(conn, *, user_id: str, event_type: str, reason: str,
                          design_id: str = "", details: Optional[Dict[str, Any]] = None) -> None:
    from psycopg.types.json import Jsonb
    conn.execute("""INSERT INTO shared_design_moderation_events
        (event_id,user_id,design_id,event_type,reason,details,created_at)
        VALUES (%s,%s,%s,%s,%s,%s,%s)""",
        (uuid.uuid4().hex, user_id, design_id or None, event_type,
         str(reason or "")[:1000], Jsonb(details or {}), time.time()))


def _public(row: dict) -> Dict[str, Any]:
    result = dict(row)
    result.pop("payload", None)
    result.pop("photo_data", None)
    return result


def create_design(*, owner_user_id: str, title: str, description: str, car: dict,
                  vinyl_count: int, price_credits: int, visibility: str,
                  sales_limit: int,
                  photo_data: bytes = b"", photo_mime: str = "",
                  verification_marker: str = "") -> Dict[str, Any]:
    title = (title or "").strip()[:100]
    description = (description or "").strip()[:1000]
    visibility = "public" if visibility == "public" else "private"
    price_credits = int(price_credits)
    sales_limit = int(sales_limit)
    vinyl_count = int(vinyl_count)
    if len(title) < 2: return {"ok": False, "message": "Enter a design title."}
    if price_credits < 0 or price_credits > 10000:
        return {"ok": False, "message": "Price must be between 0 and 10,000 credits."}
    if sales_limit < 1 or sales_limit > 10000:
        return {"ok": False, "message": "Copies for sale must be between 1 and 10,000."}
    if visibility == "public" and vinyl_count < 30:
        return {"ok": False, "message": "Public designs require at least 30 vinyls."}
    if visibility == "public" and not photo_data:
        return {"ok": False, "message": "Public designs require an in-game photo."}
    car_id = int(car.get("CarID", car.get("carID", 0)) or 0)
    if car_id <= 0: return {"ok": False, "message": "The selected garage car is invalid."}
    verification_marker = str(verification_marker or "").strip()[:20]
    normalized_title = _normalized_title(title)
    payload_fingerprint = _payload_fingerprint(car, verification_marker)
    photo_fingerprint = _photo_fingerprint(bytes(photo_data or b""))
    candidate = {
        "normalized_title": normalized_title,
        "verification_marker": verification_marker,
        "payload_fingerprint": payload_fingerprint,
        "photo_fingerprint": photo_fingerprint,
        "car_id": car_id,
        "vinyl_count": vinyl_count,
    }
    now = time.time()
    design_id = uuid.uuid4().hex
    alphabet = string.ascii_uppercase + string.digits
    from psycopg.types.json import Jsonb
    with connection() as conn, conn.transaction():
        if visibility == "public":
            control = _seller_control_in_transaction(conn, owner_user_id)
            restriction_message = _public_selling_error(control)
            if restriction_message:
                _log_moderation_event(
                    conn, user_id=owner_user_id, event_type="restricted_publish_blocked",
                    reason=restriction_message,
                    details={"title": title, "car_id": car_id, "vinyl_count": vinyl_count},
                )
                return {"ok": False, "message": restriction_message}

            existing_rows = conn.execute("""SELECT * FROM shared_car_designs
                WHERE owner_user_id=%s AND visibility='public' AND status='active'
                ORDER BY sales_count DESC, created_at ASC FOR UPDATE""", (owner_user_id,)).fetchall()
            for raw in existing_rows:
                existing = dict(raw)
                payload = existing.get("payload") or {}
                existing_car = (payload.get("cars") or [{}])[0] if isinstance(payload, dict) else {}
                stored_marker = str(existing.get("verification_marker") or "")
                existing["normalized_title"] = existing.get("normalized_title") or _normalized_title(existing.get("title"))
                existing["payload_fingerprint"] = existing.get("payload_fingerprint") or _payload_fingerprint(existing_car, stored_marker)
                existing["photo_fingerprint"] = existing.get("photo_fingerprint") or _photo_fingerprint(bytes(existing.get("photo_data") or b""))
                conn.execute("""UPDATE shared_car_designs SET normalized_title=%s,
                    payload_fingerprint=%s,photo_fingerprint=%s WHERE design_id=%s""",
                    (existing["normalized_title"], existing["payload_fingerprint"],
                     existing["photo_fingerprint"], existing["design_id"]))
                reasons = _duplicate_reasons(candidate, existing)
                if reasons:
                    reason = "Duplicate public listing blocked: " + ", ".join(reasons)
                    _log_moderation_event(
                        conn, user_id=owner_user_id, event_type="duplicate_publish_blocked",
                        reason=reason, design_id=existing["design_id"],
                        details={"existing_share_code": existing.get("share_code"), "title": title,
                                 "car_id": car_id, "vinyl_count": vinyl_count,
                                 "verification_marker": verification_marker},
                    )
                    return {
                        "ok": False,
                        "message": (
                            f"This appears to duplicate your existing public listing {existing['share_code']}. "
                            "The attempt was logged and no new listing was created. Repeated rule violations "
                            "may result in an administrator temporarily or permanently removing public selling access."
                        ),
                    }

        for _ in range(10):
            code = "TNNR-" + "".join(secrets.choice(alphabet) for _ in range(8))
            if not conn.execute("SELECT 1 FROM shared_car_designs WHERE share_code=%s", (code,)).fetchone():
                break
        conn.execute("""INSERT INTO shared_car_designs
            (design_id,share_code,owner_user_id,title,description,car_id,vinyl_count,
             price_credits,visibility,status,payload,photo_data,photo_mime,created_at,updated_at,sales_limit,
             normalized_title,verification_marker,payload_fingerprint,photo_fingerprint)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,'active',%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (design_id, code, owner_user_id, title, description, car_id, vinyl_count,
             price_credits, visibility, Jsonb({"cars": [car]}), photo_data or None,
             photo_mime or None, now, now, sales_limit, normalized_title,
             verification_marker, payload_fingerprint, photo_fingerprint))
    return {"ok": True, "design_id": design_id, "share_code": code}


def monitor_public_duplicates(force: bool = False) -> Dict[str, int]:
    """Remove duplicate public listings while retaining an audit record."""
    global _LAST_DUPLICATE_SCAN
    monotonic_now = time.monotonic()
    if not force and monotonic_now - _LAST_DUPLICATE_SCAN < _DUPLICATE_SCAN_INTERVAL_SECONDS:
        return {"scanned": 0, "removed": 0, "review": 0}
    _LAST_DUPLICATE_SCAN = monotonic_now
    scanned = removed = review = 0
    with connection() as conn, conn.transaction():
        lock = conn.execute("SELECT pg_try_advisory_xact_lock(784611924) AS locked").fetchone()
        if not lock or not lock["locked"]:
            return {"scanned": 0, "removed": 0, "review": 0}
        rows = conn.execute("""SELECT * FROM shared_car_designs
            WHERE visibility='public' AND status='active'
            ORDER BY owner_user_id, sales_count DESC, created_at ASC
            LIMIT 2000 FOR UPDATE""").fetchall()
        retained: Dict[str, list[Dict[str, Any]]] = {}
        for raw in rows:
            design = dict(raw)
            scanned += 1
            payload = design.get("payload") or {}
            car = (payload.get("cars") or [{}])[0] if isinstance(payload, dict) else {}
            marker = str(design.get("verification_marker") or "")
            design["normalized_title"] = design.get("normalized_title") or _normalized_title(design.get("title"))
            design["payload_fingerprint"] = design.get("payload_fingerprint") or _payload_fingerprint(car, marker)
            design["photo_fingerprint"] = design.get("photo_fingerprint") or _photo_fingerprint(bytes(design.get("photo_data") or b""))
            conn.execute("""UPDATE shared_car_designs SET normalized_title=%s,
                payload_fingerprint=%s,photo_fingerprint=%s WHERE design_id=%s""",
                (design["normalized_title"], design["payload_fingerprint"],
                 design["photo_fingerprint"], design["design_id"]))
            owner_designs = retained.setdefault(str(design["owner_user_id"]), [])
            duplicate = None
            duplicate_reasons = []
            for existing in owner_designs:
                duplicate_reasons = _duplicate_reasons(design, existing)
                if duplicate_reasons:
                    duplicate = existing
                    break
            if not duplicate:
                owner_designs.append(design)
                continue
            reason = "Duplicate public listing: " + ", ".join(duplicate_reasons)
            removed += 1
            conn.execute("""UPDATE shared_car_designs
                SET status='removed',duplicate_of=%s,moderation_note=%s,updated_at=%s
                WHERE design_id=%s""",
                (duplicate["design_id"], reason, time.time(), design["design_id"]))
            _log_moderation_event(
                conn, user_id=design["owner_user_id"], design_id=design["design_id"],
                event_type="duplicate_auto_removed", reason=reason,
                details={"duplicate_of": duplicate["design_id"],
                         "kept_share_code": duplicate["share_code"], "removed_share_code": design["share_code"]},
            )
    return {"scanned": scanned, "removed": removed, "review": review}


def list_public(sort: str = "newest", limit: int = 100):
    try:
        monitor_public_duplicates()
    except Exception:
        # Marketplace browsing remains available if a background moderation pass fails.
        pass
    order = "like_count DESC, d.created_at DESC" if sort == "liked" else "d.created_at DESC"
    with connection() as conn:
        rows = conn.execute(f"""SELECT d.*,
            (SELECT count(*) FROM shared_design_likes l WHERE l.design_id=d.design_id) AS like_count,
            (SELECT count(*) FROM shared_design_comments c WHERE c.design_id=d.design_id AND c.status='visible') AS comment_count
            FROM shared_car_designs d WHERE d.visibility='public' AND d.status='active'
            ORDER BY {order} LIMIT %s""", (max(1, min(200, int(limit))),)).fetchall()
    return [_public(dict(r)) for r in rows]


def list_active_public_payloads(limit: int = 2000) -> list[Dict[str, Any]]:
    """Return active public design payloads for a controlled admin collection plan.

    This intentionally bypasses neither listing visibility nor moderation status.
    It is separate from public browsing because the collection planner needs the
    stored car payload to select one verified design per unique CarID.
    """
    try:
        monitor_public_duplicates()
    except Exception:
        pass
    with connection() as conn:
        rows = conn.execute("""SELECT design_id,share_code,title,car_id,payload,
            sales_count,sales_limit,created_at
            FROM shared_car_designs
            WHERE visibility='public' AND status='active' AND sales_count < sales_limit
            ORDER BY sales_count DESC,created_at DESC
            LIMIT %s""", (max(1, min(2000, int(limit))),)).fetchall()
    return [dict(row) for row in rows]


def seller_summary(user_id: str) -> Dict[str, Any]:
    with connection() as conn:
        rows = conn.execute("""SELECT * FROM shared_car_designs
            WHERE owner_user_id=%s ORDER BY created_at DESC""", (user_id,)).fetchall()
    designs = [_public(dict(r)) for r in rows]
    current_designs = [d for d in designs if d.get("status") != "removed"]
    active_designs = [d for d in designs if d.get("status") == "active"]
    return {
        "designs": designs,
        "total_listings": len(current_designs),
        "total_sales": sum(int(d.get("sales_count") or 0) for d in designs),
        "credits_earned": sum(int(d.get("sales_count") or 0) * int(d.get("price_credits") or 0) for d in designs),
        "copies_available": sum(max(0, int(d.get("sales_limit") or 0) - int(d.get("sales_count") or 0)) for d in active_designs),
    }


def seller_moderation(user_id: str, limit: int = 8) -> Dict[str, Any]:
    with connection() as conn, conn.transaction():
        control = _seller_control_in_transaction(conn, user_id)
        events = conn.execute("""SELECT event_type,reason,design_id,details,created_at
            FROM shared_design_moderation_events WHERE user_id=%s
            ORDER BY created_at DESC LIMIT %s""",
            (user_id, max(1, min(25, int(limit))))).fetchall()
    return {"control": control, "events": [dict(row) for row in events]}


def admin_moderate_seller(user_id: str, action: str, reason: str, days: int = 7) -> Dict[str, Any]:
    allowed = {"warn", "suspend_temporary", "suspend_permanent", "restore"}
    if action not in allowed:
        return {"ok": False, "message": "Invalid seller moderation action."}
    reason = " ".join(str(reason or "").strip().split())[:1000]
    if action != "restore" and not reason:
        return {"ok": False, "message": "Enter a specific reason for this action."}
    days = max(1, min(365, int(days or 7)))
    now = time.time()
    with connection() as conn, conn.transaction():
        user = conn.execute("SELECT email FROM site_users WHERE user_id=%s FOR UPDATE", (user_id,)).fetchone()
        if not user:
            return {"ok": False, "message": "Seller account not found."}
        control = _seller_control_in_transaction(conn, user_id)
        warning_count = int(control.get("warning_count") or 0)
        if action == "warn":
            warning_count += 1
            conn.execute("""UPDATE shared_design_seller_controls
                SET warning_count=%s,reason=%s,updated_at=%s WHERE user_id=%s""",
                (warning_count, reason, now, user_id))
            event_type = "admin_warning"
            message = f"Warning sent to {user['email']}."
        elif action == "suspend_temporary":
            until = now + days * 86400
            conn.execute("""UPDATE shared_design_seller_controls
                SET public_selling_status='temporary',suspended_until=%s,reason=%s,updated_at=%s
                WHERE user_id=%s""", (until, reason, now, user_id))
            conn.execute("""UPDATE shared_car_designs SET status='hidden',moderation_note=%s,updated_at=%s
                WHERE owner_user_id=%s AND visibility='public' AND status='active'""",
                (f"Seller suspended: {reason}", now, user_id))
            event_type = "admin_temporary_suspension"
            message = f"Public selling suspended for {days} day(s). Existing public listings were hidden."
        elif action == "suspend_permanent":
            conn.execute("""UPDATE shared_design_seller_controls
                SET public_selling_status='permanent',suspended_until=NULL,reason=%s,updated_at=%s
                WHERE user_id=%s""", (reason, now, user_id))
            conn.execute("""UPDATE shared_car_designs SET status='hidden',moderation_note=%s,updated_at=%s
                WHERE owner_user_id=%s AND visibility='public' AND status='active'""",
                (f"Seller permanently suspended: {reason}", now, user_id))
            event_type = "admin_permanent_suspension"
            message = "Public selling access permanently removed. Existing public listings were hidden."
        else:
            conn.execute("""UPDATE shared_design_seller_controls
                SET public_selling_status='active',suspended_until=NULL,reason='',updated_at=%s
                WHERE user_id=%s""", (now, user_id))
            event_type = "admin_selling_restored"
            reason = reason or "Public selling access restored by administrator."
            message = "Public selling access restored. Hidden listings remain hidden until reviewed."
        _log_moderation_event(
            conn, user_id=user_id, event_type=event_type, reason=reason,
            details={"days": days if action == "suspend_temporary" else None,
                     "warning_count": warning_count},
        )
    return {"ok": True, "message": message}


def get_design(*, design_id: str = "", code: str = "", include_payload: bool = False) -> Optional[Dict[str, Any]]:
    where, value = ("design_id", design_id) if design_id else ("upper(share_code)", (code or "").strip().upper())
    with connection() as conn:
        row = conn.execute(f"""SELECT d.*,
            (SELECT count(*) FROM shared_design_likes l WHERE l.design_id=d.design_id) AS like_count
            FROM shared_car_designs d WHERE {where}=%s""", (value,)).fetchone()
    if not row: return None
    result = dict(row)
    if not include_payload: result = _public(result)
    return result


def list_public_sale_candidates(limit: int = 300) -> list[Dict[str, Any]]:
    """Return active public listings eligible for an admin verified boost."""
    with connection() as conn:
        rows = conn.execute("""SELECT d.design_id,d.share_code,d.title,d.description,d.car_id,
            d.vinyl_count,d.price_credits,d.status,d.sales_count,d.sales_limit,d.created_at,
            u.email AS owner_email,
            (SELECT count(*) FROM shared_design_reports r WHERE r.design_id=d.design_id) AS report_count,
            EXISTS(SELECT 1 FROM verified_catalog_promotions p
                   WHERE p.source_design_id=d.design_id AND p.enabled=TRUE) AS is_promoted
            FROM shared_car_designs d
            JOIN site_users u ON u.user_id=d.owner_user_id
            WHERE d.visibility='public' AND d.status='active'
            ORDER BY d.created_at DESC LIMIT %s""",
            (max(1, min(1000, int(limit))),)).fetchall()
    return [dict(row) for row in rows]


def list_verified_promotions(*, include_disabled: bool = False) -> list[Dict[str, Any]]:
    query = """SELECT promotion_id,source_design_id,source_share_code,title,description,
        car_id,vinyl_count,source_owner_user_id,enabled,created_at,updated_at
        FROM verified_catalog_promotions"""
    if not include_disabled:
        query += " WHERE enabled=TRUE"
    query += " ORDER BY created_at ASC"
    with connection() as conn:
        rows = conn.execute(query).fetchall()
    return [dict(row) for row in rows]


def get_verified_promotion(promotion_id: str, *, include_disabled: bool = False) -> Optional[Dict[str, Any]]:
    query = "SELECT * FROM verified_catalog_promotions WHERE promotion_id=%s"
    params = [str(promotion_id or "")]
    if not include_disabled:
        query += " AND enabled=TRUE"
    with connection() as conn:
        row = conn.execute(query, tuple(params)).fetchone()
    return dict(row) if row else None


def promote_public_design(design_id: str) -> Dict[str, Any]:
    """Snapshot an active public listing into the verified catalog.

    The marketplace row remains public and sellable; this creates a separate
    verified-catalog copy with its own payload and photo snapshot.
    """
    design_id = str(design_id or "").strip()
    if not design_id:
        return {"ok": False, "message": "A public listing is required."}
    now = time.time()
    from psycopg.types.json import Jsonb
    with connection() as conn, conn.transaction():
        design = conn.execute(
            "SELECT * FROM shared_car_designs WHERE design_id=%s FOR UPDATE", (design_id,)
        ).fetchone()
        if not design:
            return {"ok": False, "message": "Public listing not found."}
        if design["visibility"] != "public" or design["status"] != "active":
            return {"ok": False, "message": "Only active public-sale listings can be promoted."}
        payload = design.get("payload")
        if not isinstance(payload, dict) or not payload:
            return {"ok": False, "message": "The listing has no usable saved payload."}
        existing = conn.execute("""SELECT promotion_id,enabled
            FROM verified_catalog_promotions WHERE source_design_id=%s FOR UPDATE""",
            (design_id,)).fetchone()
        if existing:
            if not existing["enabled"]:
                conn.execute("""UPDATE verified_catalog_promotions
                    SET enabled=TRUE,updated_at=%s WHERE promotion_id=%s""",
                    (now, existing["promotion_id"]))
            return {"ok": True, "already_promoted": True, "promotion_id": existing["promotion_id"],
                    "message": "This public-sale design is already in the verified catalog."}

        promotion_id = "wsv-" + uuid.uuid4().hex
        conn.execute("""INSERT INTO verified_catalog_promotions
            (promotion_id,source_design_id,source_share_code,title,description,car_id,vinyl_count,
             payload,photo_data,photo_mime,source_owner_user_id,enabled,created_at,updated_at)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,TRUE,%s,%s)""",
            (promotion_id, design_id, design["share_code"], design["title"], design["description"],
             design["car_id"], design["vinyl_count"], Jsonb(payload), design.get("photo_data"),
             design.get("photo_mime"), design["owner_user_id"], now, now))
        _log_moderation_event(
            conn, user_id=design["owner_user_id"], design_id=design_id,
            event_type="admin_verified_catalog_promotion",
            reason="Public-sale design copied into the verified injection catalog.",
            details={"promotion_id": promotion_id, "share_code": design["share_code"],
                     "kept_public": True},
        )
    return {"ok": True, "promotion_id": promotion_id,
            "message": "Public-sale design copied into the verified catalog; its public listing remains active."}


def owner_update_design(*, design_id: str, owner_user_id: str, title: str,
                        description: str, price_credits: int, visibility: str,
                        sales_limit: int, photo_data: Optional[bytes] = None,
                        photo_mime: str = "") -> Dict[str, Any]:
    title = str(title or "").strip()[:100]
    description = str(description or "").strip()[:1000]
    visibility = "public" if visibility == "public" else "private"
    price_credits = int(price_credits)
    sales_limit = int(sales_limit)
    if len(title) < 2:
        return {"ok": False, "message": "Enter a design title."}
    if price_credits < 0 or price_credits > 10000:
        return {"ok": False, "message": "Price must be between 0 and 10,000 credits."}
    if sales_limit < 1 or sales_limit > 10000:
        return {"ok": False, "message": "Copies for sale must be between 1 and 10,000."}
    now = time.time()
    with connection() as conn, conn.transaction():
        row = conn.execute("""SELECT * FROM shared_car_designs
            WHERE design_id=%s AND owner_user_id=%s FOR UPDATE""",
            (design_id, owner_user_id)).fetchone()
        if not row:
            return {"ok": False, "message": "Listing not found on your account."}
        design = dict(row)
        if design.get("status") == "removed":
            return {"ok": False, "message": "A removed listing cannot be edited."}
        if sales_limit < int(design.get("sales_count") or 0):
            return {"ok": False, "message": "Copies available cannot be lower than the number already sold."}
        new_photo = bytes(photo_data) if photo_data is not None else bytes(design.get("photo_data") or b"")
        new_photo_mime = photo_mime or str(design.get("photo_mime") or "")
        if visibility == "public":
            if int(design.get("vinyl_count") or 0) < 30:
                return {"ok": False, "message": "Public designs require at least 30 vinyls."}
            if not new_photo:
                return {"ok": False, "message": "Public designs require an in-game photo."}
            control = _seller_control_in_transaction(conn, owner_user_id)
            restriction_message = _public_selling_error(control)
            if restriction_message:
                return {"ok": False, "message": restriction_message}
        normalized_title = _normalized_title(title)
        candidate = {
            "normalized_title": normalized_title,
            "verification_marker": design.get("verification_marker") or "",
            "payload_fingerprint": design.get("payload_fingerprint") or "",
            "photo_fingerprint": _photo_fingerprint(new_photo),
            "car_id": design.get("car_id"),
            "vinyl_count": design.get("vinyl_count"),
        }
        if visibility == "public":
            others = conn.execute("""SELECT * FROM shared_car_designs
                WHERE owner_user_id=%s AND design_id<>%s AND visibility='public' AND status='active'
                ORDER BY sales_count DESC,created_at ASC FOR UPDATE""",
                (owner_user_id, design_id)).fetchall()
            for raw in others:
                existing = dict(raw)
                existing_payload = existing.get("payload") or {}
                existing_car = (existing_payload.get("cars") or [{}])[0] if isinstance(existing_payload, dict) else {}
                existing_marker = str(existing.get("verification_marker") or "")
                existing["normalized_title"] = existing.get("normalized_title") or _normalized_title(existing.get("title"))
                existing["payload_fingerprint"] = existing.get("payload_fingerprint") or _payload_fingerprint(existing_car, existing_marker)
                existing["photo_fingerprint"] = existing.get("photo_fingerprint") or _photo_fingerprint(bytes(existing.get("photo_data") or b""))
                reasons = _duplicate_reasons(candidate, existing)
                if reasons:
                    reason = "Duplicate public listing edit blocked: " + ", ".join(reasons)
                    _log_moderation_event(
                        conn, user_id=owner_user_id, design_id=design_id,
                        event_type="duplicate_edit_blocked", reason=reason,
                        details={"existing_share_code": existing.get("share_code")},
                    )
                    return {"ok": False, "message": (
                        f"These changes would duplicate your listing {existing['share_code']}. "
                        "The attempt was logged and the listing was not changed."
                    )}
        conn.execute("""UPDATE shared_car_designs SET title=%s,description=%s,
            price_credits=%s,visibility=%s,sales_limit=%s,normalized_title=%s,
            photo_data=%s,photo_mime=%s,photo_fingerprint=%s,updated_at=%s
            WHERE design_id=%s""",
            (title, description, price_credits, visibility, sales_limit, normalized_title,
             new_photo or None, new_photo_mime or None, _photo_fingerprint(new_photo), now, design_id))
        _log_moderation_event(
            conn, user_id=owner_user_id, design_id=design_id,
            event_type="owner_listing_updated", reason="Listing details updated.",
            details={"visibility": visibility, "price_credits": price_credits,
                     "sales_limit": sales_limit},
        )
    return {"ok": True, "message": "Listing updated."}


def owner_remove_design(design_id: str, owner_user_id: str) -> Dict[str, Any]:
    now = time.time()
    with connection() as conn, conn.transaction():
        row = conn.execute("""UPDATE shared_car_designs
            SET status='removed',moderation_note='Deleted by owner',updated_at=%s
            WHERE design_id=%s AND owner_user_id=%s AND status<>'removed'
            RETURNING share_code""", (now, design_id, owner_user_id)).fetchone()
        if not row:
            return {"ok": False, "message": "Listing not found or already removed."}
        _log_moderation_event(
            conn, user_id=owner_user_id, design_id=design_id,
            event_type="owner_listing_removed", reason="Listing deleted by its owner.",
            details={"share_code": row["share_code"]},
        )
    return {"ok": True, "message": "Listing deleted from the marketplace."}


def _masked_comment_name(email: str) -> str:
    value = str(email or "user")
    return value[:3] + ("*" * max(3, len(value) - 3))


def comments(design_id: str):
    with connection() as conn:
        rows = conn.execute("""SELECT c.*, u.email FROM shared_design_comments c
            JOIN site_users u ON u.user_id=c.user_id
            WHERE c.design_id=%s AND c.status='visible' ORDER BY c.created_at ASC""", (design_id,)).fetchall()
    result = []
    for row in rows:
        comment = dict(row)
        comment["author_name"] = (
            str(comment.get("display_name") or "").strip()
            or _masked_comment_name(comment.get("email"))
        )
        result.append(comment)
    return result


def toggle_like(design_id: str, user_id: str) -> Dict[str, Any]:
    with connection() as conn, conn.transaction():
        deleted = conn.execute("DELETE FROM shared_design_likes WHERE design_id=%s AND user_id=%s RETURNING 1", (design_id, user_id)).fetchone()
        liked = not bool(deleted)
        if liked:
            conn.execute("INSERT INTO shared_design_likes (design_id,user_id,created_at) VALUES (%s,%s,%s)", (design_id, user_id, time.time()))
        count = conn.execute("SELECT count(*) AS n FROM shared_design_likes WHERE design_id=%s", (design_id,)).fetchone()["n"]
    return {"ok": True, "liked": liked, "like_count": int(count)}


def add_comment(design_id: str, user_id: str, body: str, display_name: str = "") -> Dict[str, Any]:
    body = (body or "").strip()[:1000]
    if not body: return {"ok": False, "message": "Enter a comment."}
    display_name = " ".join(str(display_name or "").strip().split())[:30]
    if display_name:
        reserved_check = re.sub(r"[^a-z0-9]", "", display_name.lower())
        if "tnnr" in reserved_check or "tanner" in reserved_check:
            return {"ok": False, "message": "That comment name is reserved."}
        if len(display_name) < 2:
            return {"ok": False, "message": "Comment names must be at least 2 characters."}
        if not all(ch.isalnum() or ch in " ._-" for ch in display_name):
            return {"ok": False, "message": "Use letters, numbers, spaces, periods, underscores, or hyphens for your comment name."}
    with connection() as conn, conn.transaction():
        user = conn.execute("SELECT email FROM site_users WHERE user_id=%s", (user_id,)).fetchone()
        if not user:
            return {"ok": False, "message": "Site account not found."}
        author_name = display_name or _masked_comment_name(user["email"])
        conn.execute("""INSERT INTO shared_design_comments
            (comment_id,design_id,user_id,display_name,body,status,created_at)
            VALUES (%s,%s,%s,%s,%s,'visible',%s)""",
            (uuid.uuid4().hex, design_id, user_id, author_name, body, time.time()))
    return {"ok": True}


def report(design_id: str, user_id: str, reason: str, details: str) -> Dict[str, Any]:
    """Record a report and refund this user's paid purchases exactly once."""
    allowed = {"photo_mismatch", "injecting_weirdly", "inappropriate", "other"}
    if reason not in allowed:
        return {"ok": False, "message": "Choose a report reason."}
    user_id = str(user_id or "").strip()
    design_id = str(design_id or "").strip()
    if not user_id or not design_id:
        return {"ok": False, "message": "A signed-in user and listing are required."}

    now = time.time()
    refund_amount = 0
    report_count = 0
    report_id = ""
    temporarily_disabled = False
    purchase_source_keys = []
    with connection() as conn, conn.transaction():
        design = conn.execute(
            "SELECT * FROM shared_car_designs WHERE design_id=%s FOR UPDATE", (design_id,)
        ).fetchone()
        if not design:
            return {"ok": False, "message": "Design unavailable."}

        report_row = conn.execute("""INSERT INTO shared_design_reports
            (report_id,design_id,reporter_user_id,reason,details,status,created_at)
            VALUES (%s,%s,%s,%s,%s,'open',%s)
            ON CONFLICT (design_id,reporter_user_id) DO UPDATE SET reason=EXCLUDED.reason,
            details=EXCLUDED.details,status='open',created_at=EXCLUDED.created_at,resolved_at=NULL
            RETURNING report_id""",
            (uuid.uuid4().hex, design_id, user_id, reason,
             (details or "").strip()[:1000], now)).fetchone()
        report_id = str(report_row["report_id"])
        report_count = int(conn.execute(
            "SELECT count(*) AS n FROM shared_design_reports WHERE design_id=%s", (design_id,)
        ).fetchone()["n"] or 0)

        # acquire() writes one unique source key per paid marketplace purchase.
        purchases = conn.execute("""SELECT source_key, amount
            FROM credit_ledger
            WHERE user_id=%s AND entry_type='debit' AND amount>0
              AND source_key LIKE %s
            ORDER BY event_time ASC FOR UPDATE""",
            (user_id, f"design-inject-buy:{design_id}:%")).fetchall()
        purchase_source_keys = [str(row["source_key"]) for row in purchases if row.get("source_key")]
        refund_amount = sum(int(row["amount"] or 0) for row in purchases)

        existing_refund = conn.execute(
            "SELECT refund_id,amount,status FROM shared_design_report_refunds WHERE report_id=%s FOR UPDATE",
            (report_id,),
        ).fetchone()
        if existing_refund:
            # The first report submission owns the refund decision forever.
            refund_amount = int(existing_refund["amount"] or 0)
            purchase_source_keys = []
        elif refund_amount > 0:
            buyer = conn.execute(
                "SELECT balance FROM site_users WHERE user_id=%s FOR UPDATE", (user_id,)
            ).fetchone()
            if not buyer:
                return {"ok": False, "message": "Site account not found."}
            balance_after = int(buyer["balance"] or 0) + refund_amount
            conn.execute(
                "UPDATE site_users SET balance=%s,updated_at=%s WHERE user_id=%s",
                (balance_after, now, user_id),
            )
            from psycopg.types.json import Jsonb
            conn.execute("""INSERT INTO credit_ledger
                (user_id,entry_type,amount,reason,balance_after,event_time,meta,source_key)
                VALUES (%s,'credit',%s,%s,%s,%s,%s,%s)
                ON CONFLICT (source_key) DO NOTHING""",
                (user_id, refund_amount, "World Sale report refund", balance_after, now,
                 Jsonb({"world_sale_report_refund": True, "report_id": report_id,
                        "design_id": design_id, "purchase_source_keys": purchase_source_keys}),
                 f"world-sale-report-refund:{report_id}"))
            conn.execute("""INSERT INTO shared_design_report_refunds
                (refund_id,report_id,design_id,reporter_user_id,amount,purchase_source_keys,
                 status,created_at,credited_at)
                VALUES (%s,%s,%s,%s,%s,%s,'refunded',%s,%s)""",
                (uuid.uuid4().hex, report_id, design_id, user_id, refund_amount,
                 Jsonb(purchase_source_keys), now, now))
        else:
            from psycopg.types.json import Jsonb
            conn.execute("""INSERT INTO shared_design_report_refunds
                (refund_id,report_id,design_id,reporter_user_id,amount,purchase_source_keys,
                 status,created_at,credited_at)
                VALUES (%s,%s,%s,%s,0,%s,'no_purchase',%s,NULL)""",
                (uuid.uuid4().hex, report_id, design_id, user_id, Jsonb([]), now))

        if report_count > REPORT_AUTO_DISABLE_THRESHOLD and design["status"] == "active":
            temporarily_disabled = True
            note = f"Temporarily disabled after {report_count} unique user reports."
            conn.execute("""UPDATE shared_car_designs
                SET status='hidden',moderation_note=%s,updated_at=%s WHERE design_id=%s""",
                (note, now, design_id))
            _log_moderation_event(
                conn, user_id=design["owner_user_id"], design_id=design_id,
                event_type="report_threshold_auto_disabled", reason=note,
                details={"report_count": report_count, "threshold": REPORT_AUTO_DISABLE_THRESHOLD},
            )

    return {
        "ok": True, "report_id": report_id, "report_count": report_count,
        "refund_amount": refund_amount, "refunded": bool(refund_amount > 0),
        "temporarily_disabled": temporarily_disabled,
        "threshold": REPORT_AUTO_DISABLE_THRESHOLD,
    }


def acquire(design_id: str, buyer_user_id: str) -> Dict[str, Any]:
    """Atomically charge every injection and transfer 100% to the seller."""
    now = time.time()
    with connection() as conn, conn.transaction():
        d = conn.execute("SELECT * FROM shared_car_designs WHERE design_id=%s FOR UPDATE", (design_id,)).fetchone()
        if not d: return {"ok": False, "message": "Design unavailable."}
        if d["status"] != "active": return {"ok": False, "message": "Design unavailable."}
        if d["owner_user_id"] == buyer_user_id:
            return {"ok": False, "message": "You cannot purchase your own listing. Use Manage Listing for owner controls."}
        if int(d["sales_count"]) >= int(d["sales_limit"]):
            return {"ok": False, "message": "All available copies have been sold."}
        price = int(d["price_credits"])
        buyer = conn.execute("SELECT balance FROM site_users WHERE user_id=%s FOR UPDATE", (buyer_user_id,)).fetchone()
        if not buyer: return {"ok": False, "message": "Site account required."}
        if int(buyer["balance"]) < price:
            return {"ok": False, "message": f"Not enough paid credits. Need {price:,}."}
        if price:
            seller = conn.execute("SELECT balance FROM site_users WHERE user_id=%s FOR UPDATE", (d["owner_user_id"],)).fetchone()
            buyer_after = int(buyer["balance"]) - price
            seller_after = int(seller["balance"]) + price
            sale_id = uuid.uuid4().hex
            conn.execute("UPDATE site_users SET balance=%s,updated_at=%s WHERE user_id=%s", (buyer_after, now, buyer_user_id))
            conn.execute("UPDATE site_users SET balance=%s,updated_at=%s WHERE user_id=%s", (seller_after, now, d["owner_user_id"]))
            conn.execute("""INSERT INTO credit_ledger
                (user_id,entry_type,amount,reason,balance_after,event_time,meta,source_key)
                VALUES (%s,'debit',%s,'Shared design purchase',%s,%s,'{}'::jsonb,%s),
                       (%s,'credit',%s,'Shared design sale',%s,%s,'{}'::jsonb,%s)""",
                (buyer_user_id, price, buyer_after, now, f"design-inject-buy:{design_id}:{sale_id}",
                 d["owner_user_id"], price, seller_after, now, f"design-inject-sell:{design_id}:{sale_id}"))
        conn.execute("UPDATE shared_car_designs SET sales_count=sales_count+1,updated_at=%s WHERE design_id=%s", (now, design_id))
    return {"ok": True, "charged": price}


def photo(design_id: str):
    with connection() as conn:
        row = conn.execute("SELECT photo_data,photo_mime FROM shared_car_designs WHERE design_id=%s", (design_id,)).fetchone()
    return (bytes(row["photo_data"]), row["photo_mime"] or "image/jpeg") if row and row["photo_data"] else None


def admin_overview():
    try:
        duplicate_summary = monitor_public_duplicates(force=True)
    except Exception:
        duplicate_summary = {"scanned": 0, "removed": 0, "review": 0}
    with connection() as conn:
        designs = conn.execute("""SELECT d.*,u.email AS owner_email,
            COALESCE(sc.public_selling_status,'active') AS seller_status,
            COALESCE(sc.warning_count,0) AS seller_warning_count,
            (SELECT count(*) FROM shared_design_likes l WHERE l.design_id=d.design_id) AS like_count,
            (SELECT count(*) FROM shared_design_reports rp WHERE rp.design_id=d.design_id) AS report_count,
            (SELECT count(*) FROM shared_design_reports rp WHERE rp.design_id=d.design_id AND rp.status='open') AS open_report_count
            FROM shared_car_designs d JOIN site_users u ON u.user_id=d.owner_user_id
            LEFT JOIN shared_design_seller_controls sc ON sc.user_id=d.owner_user_id
            ORDER BY d.created_at DESC LIMIT 500""").fetchall()
        reports = conn.execute("""SELECT r.*,d.title,d.share_code,d.status AS design_status,
            ru.email AS reporter_email,
            (SELECT count(*) FROM shared_design_reports rp WHERE rp.design_id=r.design_id) AS report_count,
            rr.amount AS refund_amount,rr.status AS refund_status,rr.credited_at
            FROM shared_design_reports r JOIN shared_car_designs d ON d.design_id=r.design_id
            JOIN site_users ru ON ru.user_id=r.reporter_user_id
            LEFT JOIN shared_design_report_refunds rr ON rr.report_id=r.report_id
            ORDER BY r.created_at DESC LIMIT 300""").fetchall()
        report_summary = conn.execute("""SELECT
            count(*)::bigint AS total_reports,
            count(*) FILTER (WHERE r.status='open')::bigint AS open_reports,
            count(*) FILTER (WHERE rr.status='refunded')::bigint AS refunded_reports,
            COALESCE(sum(CASE WHEN rr.status='refunded' THEN rr.amount ELSE 0 END),0)::bigint AS refunded_credits,
            count(*) FILTER (WHERE d.status='hidden' AND d.moderation_note LIKE 'Temporarily disabled after %')::bigint AS auto_disabled_listings
            FROM shared_design_reports r
            JOIN shared_car_designs d ON d.design_id=r.design_id
            LEFT JOIN shared_design_report_refunds rr ON rr.report_id=r.report_id""").fetchone()
        comment_rows = conn.execute("""SELECT c.*,d.title,d.share_code,u.email
            FROM shared_design_comments c JOIN shared_car_designs d ON d.design_id=c.design_id
            JOIN site_users u ON u.user_id=c.user_id ORDER BY c.created_at DESC LIMIT 300""").fetchall()
        events = conn.execute("""SELECT e.*,u.email,d.share_code,d.title
            FROM shared_design_moderation_events e
            JOIN site_users u ON u.user_id=e.user_id
            LEFT JOIN shared_car_designs d ON d.design_id=e.design_id
            ORDER BY e.created_at DESC LIMIT 300""").fetchall()
        controls = conn.execute("""SELECT sc.*,u.email FROM shared_design_seller_controls sc
            JOIN site_users u ON u.user_id=sc.user_id
            WHERE sc.warning_count>0 OR sc.public_selling_status<>'active'
            ORDER BY sc.updated_at DESC LIMIT 300""").fetchall()
    return ([_public(dict(r)) for r in designs], [dict(r) for r in reports],
            [dict(r) for r in comment_rows], [dict(r) for r in events],
            [dict(r) for r in controls], duplicate_summary,
            dict(report_summary or {}))


def admin_design_status(design_id: str, status: str, reason: str = ""):
    if status not in {"active", "hidden", "removed"}: return {"ok": False, "message": "Invalid status."}
    reason = " ".join(str(reason or "").strip().split())[:1000]
    with connection() as conn, conn.transaction():
        design = conn.execute("SELECT * FROM shared_car_designs WHERE design_id=%s FOR UPDATE", (design_id,)).fetchone()
        if not design:
            return {"ok": False, "message": "Listing not found."}
        if status == "active":
            control = _seller_control_in_transaction(conn, design["owner_user_id"])
            restriction_message = _public_selling_error(control)
            if restriction_message:
                return {"ok": False, "message": restriction_message}
        conn.execute("""UPDATE shared_car_designs SET status=%s,moderation_note=%s,updated_at=%s
            WHERE design_id=%s""", (status, reason, time.time(), design_id))
        _log_moderation_event(
            conn, user_id=design["owner_user_id"], design_id=design_id,
            event_type=f"admin_listing_{status}",
            reason=reason or f"Listing status changed to {status} by administrator.",
            details={"share_code": design["share_code"]},
        )
    return {"ok": True, "message": f"Listing marked {status}."}


def admin_report_status(report_id: str, status: str):
    if status not in {"open", "resolved", "dismissed"}: return {"ok": False, "message": "Invalid status."}
    with connection() as conn, conn.transaction():
        row = conn.execute("UPDATE shared_design_reports SET status=%s,resolved_at=%s WHERE report_id=%s RETURNING 1", (status, time.time() if status != 'open' else None, report_id)).fetchone()
    return {"ok": bool(row)}


def admin_comment_status(comment_id: str, status: str):
    if status not in {"visible", "hidden"}: return {"ok": False, "message": "Invalid status."}
    with connection() as conn, conn.transaction():
        row = conn.execute("UPDATE shared_design_comments SET status=%s WHERE comment_id=%s RETURNING 1", (status, comment_id)).fetchone()
    return {"ok": bool(row)}


def note_injection(design_id: str):
    with connection() as conn, conn.transaction():
        conn.execute("UPDATE shared_car_designs SET injection_count=injection_count+1 WHERE design_id=%s", (design_id,))
