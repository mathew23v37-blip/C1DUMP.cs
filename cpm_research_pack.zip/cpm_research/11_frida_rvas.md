# Frida RVAs (dump, rebase every launch)

Module is UnityFramework (attach), not the outer CPMS image from spawn.

Documented in project memory / earlier captures:

```
MemoryPackUtil.GetXorKey     0x2450304
MemoryPackUtil.Xor           0x245028C
MemoryPackUtil.BrotliCompress 0x244FFC4
FirebaseWrappedFunctionFactory.Create  0x279CC58
FirebaseSaveLoadService.Init           0x24C5E98
FirebaseCarsService.Init               0x24CF668
ES3Settings password ctor              0x2809758
```

VinylsEditor (dump method list; rebase from current UnityFramework base):
  Init(VinylsType)
  MenuChangedHandler
  CopyVinyls
  FlipX
  SaveVinyl / SaveOneVinyl
  LoadAllCarVinylsArray(carId, type)

Observational test for "clipboard across cars":
  hook CopyVinyls → log sticker count
  hook Init / MenuChangedHandler → count resets to the new car
Do not treat an injected paste as proof the shipping UI can paste across cars.

Spawn+attach crashed this title; attach to a running CarParking process worked.
