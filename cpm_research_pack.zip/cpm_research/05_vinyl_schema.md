# Vinyl schema

## Saved (VinylData)  namespace DataEntities.Vinyl
```
Vector3 position        0x10    x,y on panel; z = layer index
Vector3 scaleRotation   0x1C    x,y scale; z = degrees
Vector3 iconPosition    0x28    panel anchor (few clusters per car)
string  text            0x38    empty for shapes; "(","*",letters for text stamps
uint    color           0x40    PackColor ARGB
long    packedData      0x48    BitMaskPacker bitmask
```
MemoryPack: VinylDataFormatter Serialize 0x141D0E8 / Deserialize 0x219DDB8

## Live editor (StickerItem / OneVinyl)
```
OneVinyl
  pos, Euler, scale
  color
  text, fontIndex, italic, bold
  stickerIndex
  flipX

StickerItem
  Order, stckerIndex
  position, positionIcon, euler, scale
  xAngle, yAngle, flipX
  isText, text, fontIndex, italic, bold
```

## Converters (VinylsUtility)
ConvertOneVinylToVinylData
VinylDataFromStickerItem
ParseVinylDataToStickerItem
PopulateVinylInstantiationData
UnpackVinylInstantiationData
GetFilePathByID(stickerIndex, VinylsType)  -> catalog sprite path

## Older network object (CPM.Database.OneVynil)
vectors[], v[], floats[], text
Same idea, list-of-floats form used in some player-record paths.

## Car 257 geometry notes
pos.x range about -0.58 .. 0.45
pos.y range about 0.38 .. 0.47
scale.x about -2.59 .. 6.24
rot.z 0 .. 359.4
43 unique iconPosition values, two dominant clusters:
  (0.0089, 0.1883, -2.1976)   ~195 vinyls
  (0.0003, -0.032,  2.2102)   ~214 vinyls
Those clusters = the two xAngle/yAngle families in packedData.
