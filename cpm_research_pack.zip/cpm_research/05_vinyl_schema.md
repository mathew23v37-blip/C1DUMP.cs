# VinylData schema

Shared by body and window lists.

```
position        Vector3   x,y on the panel; z = layer / draw order
scaleRotation   Vector3   scaleX, scaleY, rotation degrees
iconPosition    Vector3   panel / UV hint
text            string    empty for stamps; letters for isText
color           uint      ARGB (example 4278206424 = 255,0,63,216)
packedData      long      BitMaskPacker (see 06_packeddata.md)
```

## Types

VinylsType: CarVinyls, PlateVinyls, WindowVinyls, ClanVinyls.

Load:  LoadAllCarVinylsArray(carId, VinylsType)
Save:  VinylsEditor.SaveVinyl / SaveVinylsData / OneCar.Save

## In-game editor (same car only)

Class VinylsEditor:
  Init(VinylsType)
  LoadAllCarVinylsArray(current car)
  CopyVinyls()          // duplicates selection on THIS mesh
  FlipX()               // mirror on THIS body
  OnGroupButtonPressed
  SaveVinyl()
  MenuChangedHandler    // tears session down; no clipboard field

CopyVinyls has no targetCarId. Switching cars reloads B's list and drops A's live StickerItems.
