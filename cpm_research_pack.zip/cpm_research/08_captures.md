# Captures

## captures - Copy.zip
155 decomp_out_*.bin, 10 xor_*.bin, index.jsonl, xorkey.txt

decomp classification:
  134 start 02 xx 01 00 00 06 + floats   = car/vinyl geometry
   20 other small structs
    1 starts 19 f2 ff ff ff + Player_*   = friends/player list, not a car

Largest cars: 25252, 24013, 20474 bytes.
0129_decomp_out_25252.bin first floats == vinyl 0 of carVinyls257.

XOR files starting 0x1B are brotli-then-xor writes.
xorkey.txt in that zip was UID C301Sj... / key Ct1SjWR3...

## login startup log.txt
1288 BROTLI DECOMPRESS, repeating fragment sizes:
  36   ~8 ints
  24   5 ints
  64   15 floats
  220  54 floats
  288  71 ints (BoughtParts width)
  340  28-wide vector block
  4    empty

## Cache era
iOS Cache.db / httpstorages pointed at the same Cloud Function host.
GetAllCars2 response was stored as an external UUID blob
(328DFDA6-ACBE-4DEE-81B4-7E17BE42A377).
