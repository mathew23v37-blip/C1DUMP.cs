# Confirmed vs unknown

## Confirmed
- Server is authoritative; ES3 is cache
- Login function list and order
- XOR key = shuffled Firebase UID
- Write: Brotli then XOR (when both fire)
- Load cars: mostly Brotli fragments, XOR on some full saves
- VinylData field layout
- packedData bit layout (BitMaskPacker)
- color uint = PackColor ARGB
- ES3 key path 81Acars/carVinyls{id}
- ES3 password is short and account-derived, not in EasySave3.dll
- Frida decomp floats == ES3 vinyl transforms
- Layered catalog stamps are how busy cars are drawn (450 on car 257)

## Wrong or overdone
- Global ES3 password inside EasySave3.dll
- Network XOR/Brotli as the disk vinyl format
- JSON keys named simply "carData"
- Hooking module CPMS with UnityFramework RVAs
- Spawn-from-Frida as a reliable launch on this jailbreak
- Bot keys 483j6t / 4ebcBg unlocking every account's ES3

## Still unknown
- Sprite filename for each stickerIndex (runtime GetFilePathByID)
- Exact MemoryPack bytes of a full OneCar besides the vinyl list
- Whether server hash/censor rejects edited vinyl lists
- ES3 KDF iteration count on this build (password itself is known per account)
- Window / plate / clan vinyl files (same schema expected, not dumped here)
