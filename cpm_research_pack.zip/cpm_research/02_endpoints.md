# Cloud Functions observed

Direction is from the game's point of view.

| Function | Direction | Notes |
|----------|-----------|--------|
| WSGetCarIDnStatusV3 | server → game | ownership / status, small JSON |
| GetAllCars2 | server → game | full garage; large packed OneCar list |
| WSGetPoolCarsAsMasterClientV3 | server → game | multiplayer pool |
| WSGetDeletedCarListV3 | server → game | deleted ids |
| SaveCarsPartially8 | game → server | persist OneCar changes (vinyls, floats, …) |
| GetPlayerRecords3 / GetPlayerRecords4 | server → game | player blob |
| SavePlayerRecordsPartially8 | game → server | persist player blob |
| GetUserConnectionData2 | server → game | session |
| GetClanId / HasClanRequests | server → game | clan |
| GetRaceProgress | server → game | races |
| GetDailyTaskCall / GetUnusedDailyReward | server → game | dailies |
| GetOffersForPlayer | server → game | shop offers |
| SetUserRating7 / GetUserRatingCall1 | both | ratings |

All of these ran behind Firebase Bearer. The functions do not accept anonymous junk.

Save that matters for vinyls/tint: SaveCarsPartially8 of the OneCar that already contains Vynils, WindowVinyls, and floats.
