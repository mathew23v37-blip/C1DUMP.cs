# Cloud Functions observed live

Factory: FirebaseWrappedFunctionFactory.Create(name)
RVA: 0x279CC58
Auth: Firebase JWT on the request

## Login / garage pull
| Function | Role |
|---|---|
| GetUserConnectionData2 | session |
| GetClanId | clan id |
| GetRaceProgress | race |
| WSGetCarIDnStatusV3 | car ids + ownership status |
| GetDailyTaskCall | dailies |
| GetUnusedDailyReward | rewards |
| GetPlayerRecords4 | player record blob |
| GetAllCars2 | full car dataset (large) |
| SetUserRating7 | rating write |
| GetUserRatingCall1 | rating read |
| GetOffersForPlayer | shop offers (often x3) |
| HasClanRequests | clan inbox |
| WSGetDeletedCarListV3 | deleted cars |
| WSGetPoolCarsAsMasterClientV3 | seen in cache era, pool cars |

## Writes
| Function | Role |
|---|---|
| SavePlayerRecordsPartially8 | player-record partial |
| SaveCarsPartially8 | car partial |

Older bot sources also mention GetPlayerRecords3 / SetUserRating4.
Names are versioned; live iOS build used the *4 / *7 / *8 names above.

## Login order (attach + re-login)
GetUserConnectionData2
GetClanId
GetRaceProgress
WSGetCarIDnStatusV3
GetDailyTaskCall
GetUnusedDailyReward
GetPlayerRecords4
GetAllCars2
SetUserRating7
GetOffersForPlayer
HasClanRequests
WSGetCarIDnStatusV3 (again)
WSGetDeletedCarListV3
SavePlayerRecordsPartially8   (XOR fired here)
