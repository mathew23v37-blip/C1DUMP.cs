# Window settings (car 62 vs stock 13)

Test pair from GetAllCars2 + ES3, same account.

Car 13 = stock mule (display in an older dump was Civic; this pair is the empty car).
Car 62 = built car with glass stamps + out-of-range slider.

## Three shop knobs vs save slots

| Shop control | OneCar slot | Stock 13 | Car 62 |
|--------------|-------------|----------|--------|
| Transparency slider | floats[46] | 1 | 3 |
| Color graph | floats[21-23] | 0,0,0 | 0.950, 0.678, 0.699  (#F2ADB2) |
| Specular graph | floats[24-26] | 0,0,0 | 0.182, 0.861, 0.548  (#2EDC8C) |

floats[46]=3 is the old H5GG "search 0.3, write 3" value, persisted.
Stock legal slider in this snapshot is 1, not 0.3 (0.3 was the live shop stop they searched).

floats[34]= -0.3 on 62 is NOT the slider. Stock there is 2 (unused sentinel).

floats[48-51] repeats [23-26]. Same color+spec, second copy.

## WindowVinyls are stickers

Car 13: empty marker 8b01800000000003
Car 62: 32 stamps, all color 4278206424 (ARGB 255,0,63,216), sticker 130/97.
Those are decals on glass, not the tint graphs.

## Live fields (dump)

VehicleData.WindowMainColor Color @ 0x920
VehicleData.SetWindowColor()
bodyKitValues.GlassWindows[]
VehicleMultiplayerPos.WindowColor / WindowColorReflective

On spawn the game rebuilds materials from floats + vinyls.

## Shader note

Old glass: slider 3 looked like X-ray (see-through).
Current + bloom: same 3 is HDR → LED slab.
Bloom off: solid blown color.
