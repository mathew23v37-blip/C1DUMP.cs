# GetAllCars2 structure

Response shape:

```
{ "result": "<json string of OneCar[]>" }
```

Each element is one car. Two encodings appear in the same garage:

1. Expanded JSON (lists of numbers / VinylData objects)
2. dataVersion = 3: heavy fields are Base64(Brotli(...))

Always 28 vectors and 54 floats when expanded.
On the wire, Brotli payload for floats starts with int32 count=54, then 54 float32 LE.

## vectors[28]

Vector3 slots for part colors / state.
Unused / stock mule cars are filled with (2,2,2).
Built car 62 examples:
  v[1]  (0.051, 0.051, 0.043) dark grey
  v[10] (0.878, 0.494, 0)     orange
  v[14] / v[23] (1, 0.992, 0.816) cream
  v[15] / v[24] (-2,-2,-2)    another sentinel
  v[18] / v[19] (16, 0, 0.021) pair

These are NOT vinyl UVs. Vinyl UVs live inside Vynils / WindowVinyls.

## floats[54]  (0-based after the count prefix)

Proven / high-confidence on the 13 vs 62 pair:

| Index | Stock 13 | Car 62 | Role |
|------|----------|--------|------|
| 0–8 | tunes mostly 0 | built-car tunes | power / ratios style values |
| 9 | 68 | 113 | duplicated at [47]; car-stat, not glass |
| 10–11 | 0.22 | 0.22 / 0.20 | small pair |
| 21–23 | 0 | 0.950, 0.678, 0.699 | glass/paint color RGB #F2ADB2 |
| 24–26 | 0 | 0.182, 0.861, 0.548 | specular RGB #2EDC8C |
| 33–34 | 2, 2 | 0.1, -0.3 | unused sentinel 2 on stock; not the glass slider |
| 39–42 | 1,1,1,1 | ~0.58 | smoothness-style cluster |
| 46 | 1 | 3 | glass slider (H5GG wrote 3; stock legal 1) |
| 47 | 68 | 113 | copy of [9] |
| 48–51 | 0 | copy of [23–26] | same color+spec repeated |
| 52 | 0 | 15 | extra |

Other floats are engine/tune (RPM-ish, boost, etc.) and differ because 62 is a built car, not because of tint.

## Vynils / WindowVinyls on the wire

Empty window list: Base64 iwGAAAAAAAM= → 8b01800000000003
Car 62 windows: 753 B Brotli → 1700 B decoded, u32 count = 32 (matches ES3).
Car 62 body Vynils: 5034 B Brotli → large MemoryPack stamp stream.

## texts

Expanded or packed. Contains generated id like TY127060_13QT318 or kit strings.
Not the ES3 password.

## What GetAllCars2 is for

It is the garage snapshot. Bots that "copy a car" parse this array, mutate one OneCar (or many), and send SaveCarsPartially8.
