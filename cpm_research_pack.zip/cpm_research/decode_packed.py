"""Read-only packedData decoder. Official masks from dump.cs BitMaskPacker."""
IS_TEXT, ITALIC, BOLD, FLIPX = 1, 2, 4, 8
FONT, STICKER, XANG, YANG = 496, 261632, 133955584, 68585259008

def unpack(packed):
    p = int(packed)
    return {
        "isText": bool(p & IS_TEXT),
        "italic": bool(p & ITALIC),
        "bold": bool(p & BOLD),
        "flipX": bool(p & FLIPX),
        "fontIndex": (p & FONT) >> 4,
        "stickerIndex": (p & STICKER) >> 9,
        "xAngle": (p & XANG) >> 18,
        "yAngle": (p & YANG) >> 27,
    }

if __name__ == "__main__":
    import sys
    for a in sys.argv[1:] or ["2061564416", "5463931392", "0x7ae00201"]:
        print(a, unpack(int(a, 0)))
