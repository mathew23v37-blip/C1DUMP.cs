# Confirmed vs unknown

## Proven

- Server OneCar from GetAllCars2 is authoritative.
- ES3 password = decodedPath[:3] + UID[:3]; AES-CBC PBKDF2-SHA1 100 rounds; 81AHmo opened both 62 files.
- VinylData schema + BitMaskPacker packedData.
- Two ES3 files per car: carVinyls{id}, windowVinyls{id}.
- XOR key from UID; Brotli magic 0x1b on packed GetAllCars2 fields.
- floats[46] stock=1, car62=3 is the saved glass slider.
- floats[21-23] / [24-26] are the color / specular triples on that pair.
- WindowVinyls empty marker vs 32 stamps on 62.
- Same-account vinyl copy = copy Vynils/WindowVinyls onto other OneCars + SaveCarsPartially8.
- VinylsEditor.CopyVinyls is same-car only (no targetCarId).
- Save is a still frame; no GIF field on VinylData.

## Inferred

- Exact C# names of floats[21-26] / [46] (dump has WindowMainColor + SetWindowColor, not a labeled float index).
- Friend bot hash handling (VinylsCensor / CarsHashesPool).
- H5GG 12.2/12.3/12.4 markers (not in dump.cs).

## Open (only if a report needs them)

- SetWindowColor method body mapping slider → floats[46].
- Whether SaveCarsPartially8 recomputes vinyl hashes or clients must send them.
- Official paste-across-cars UI: not implemented; data would allow it.

## Not true

- ES3 is the live car.
- Window vinyls are the tint slider.
- EasySave3.dll holds the account password.
- XOR/Brotli is used on .es3 files.
- Typing JSON onto disk shows after login.
- A saved OneCar can contain an animated GIF vinyl.
