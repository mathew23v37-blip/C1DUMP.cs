# packedData (solved)

Class: CPM.Scripts.VinylDrawer.BitMaskPacker
Enum:  PackedDataMask

```
IsTextMask        = 1                 bit 0
ItalicMask        = 2                 bit 1
BoldMask          = 4                 bit 2
FlipXMask         = 8                 bit 3
FontIndexMask     = 496               bits 4-8     0..31
StickerIndexMask  = 261632            bits 9-17    0..511
XAngleMask        = 133955584         bits 18-26
YAngleMask        = 68585259008       bits 27-35
```

Pack(isText, italic, bold, flipX, fontIndex, stickerIndex, xAngle, yAngle)
Unpack(bitmask, out ...)

## Car 257 unique packs
See packeddata_unique.csv

Dominant stickerIndex values:
  1    257   text/symbol stamp  ( ** .. * B M W )
  125  106   main shape
  89    20
  117   16
  124   12
  90    10
  others: 0,4,52,87,95,97,100,127

Two angle sides:
  xAngle=184 yAngle=15   packs 0x7AE0....
  xAngle=363 yAngle=40   packs 0x145AC....

isText bit matched nonempty text on all 450 rows.

Sprite file for each stickerIndex is NOT in the JSON.
It is resolved by GetFilePathByID at runtime.
