# packedData (BitMaskPacker)

From dump:

```
IsTextMask      = 1
ItalicMask      = 2
BoldMask        = 4
FlipXMask       = 8
FontIndexMask   = 496
StickerIndexMask= 261632
XAngleMask      = 133955584
YAngleMask      = 68585259008
```

Unpack:

```
isText   = packed & 1
italic   = packed & 2
bold     = packed & 4
flipX    = packed & 8
font     = (packed & 496) >> 4
sticker  = (packed & 261632) >> 9
xAngle   = (packed & 133955584) >> 18
yAngle   = (packed & 68585259008) >> 27
```

Window vinyls on car 62: sticker 130 x30, sticker 97 x2, all color 4278206424, no text.
