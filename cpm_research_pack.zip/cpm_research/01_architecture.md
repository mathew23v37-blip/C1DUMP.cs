# Architecture

```
iOS client (Unity IL2CPP)
  |
  +-- Firebase Auth
  |     Bearer idToken
  |     account / localId = Firebase UID
  |
  +-- Cloud Functions  europe-west1-cp-multiplayer
  |     GetAllCars2 / GetPlayerRecords4 / WSGetCarIDnStatusV3
  |     SaveCarsPartially8 / SavePlayerRecordsPartially8
  |     SOURCE OF TRUTH for cars and player records
  |
  +-- In-memory services
  |     FirebaseSaveLoadService
  |     FirebaseCarsService
  |     PlayerDataStorage
  |     VinylsEditor / VinylDrawer / VynilsDataUtility
  |
  +-- Local cache (Easy Save 3)
        Application persistentData / es3 /
          81Acars/carVinyls{carId}     VinylsType.CarVinyls
          (plates / window / clan are other keys)
        Overwritten on successful login
```

## Authority
- What you see after login comes from GetAllCars2 + GetPlayerRecords4 + status calls.
- Local ES3 is a cache of the same VinylData list.
- Editing only ES3 does not survive a sync if the server copy differs.
- A cloned account kept inner vinyl/plate strings and generated-id prefixes;
  the XOR key changed because the Firebase UID changed.

## Two encodings of the same vinyl
1. Disk: ES3 JSON dictionary "0".."N" of VinylData
2. Memory / some network blobs: packed floats starting `02 xx 01 00 00 06`
   then position.xy, scale.xy, rot, icon.xy ...
   First vinyl of carVinyls257 matches Frida blob 0129_decomp_out_25252.bin
   float-for-float.

## Object tree (player car, from dump + live scripts)
```
VehicleData
├── CarMat                 body material
├── Powertrain
├── Wheel[4]
├── LightController
├── FuelTank
├── Axle
└── vinyls via VinylsEditor / VynilsDataUtility
      StickerItem (live UI)
        -> VinylData (saved)
        -> OneVynil (older network list: vectors / floats / text)
```

VinylsMultiplayerData counts:
  carVinylsCount, front/rear plate vinyls, clanVinylsCount, windowVinylsCount
