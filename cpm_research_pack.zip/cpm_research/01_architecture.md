# Architecture

```
CPM app
  → Firebase Auth (Bearer + localId / UID)
  → Cloud Functions (europe-west1-cp-multiplayer)
  → game database

Local disk
  → Easy Save 3 AES files under 81Acars/
     carVinyls{id}      body stamps
     windowVinyls{id}   glass stamps
```

## Authority

| Store | Role | Wins after login? |
|--------|------|-------------------|
| GetAllCars2 OneCar | Full car: tunes, paint, glass, both vinyl lists | YES |
| ES3 carVinyls* / windowVinyls* | JSON cache of stamp lists only | No — rewritten from OneCar |
| Live WindowMainColor / materials | Shader this frame | Built from OneCar.floats + vinyls |

Airplane-mode rename of an ES3 file does not survive GetAllCars2.

## OneCar (dump)

```
vectors[28]          Vector3 part/color slots; (2,2,2) = unused
floats[54]           tunes + paint/glass PBR + slider
gears[]
typeToInstall[]
BoughtParts[]
texts[]              generated id + kit string
CarID                catalog id
Vynils.allVynils[]   body VinylData
WindowVinyls[]       glass VinylData
flagID
fsoData[]
installedPoliceLights[]
dataVersion          3 = fields Brotli-packed on the wire
bodyKitMeshMods / B64
```

dataVersion 3 on the wire: each heavy field is Base64(Brotli(...)).
Magic 0x1b = Brotli. Empty WindowVinyls is 8 bytes 8b01800000000003.

## Two vinyl channels

Body stamps != window tint.
Tint / chrome / matte live in floats (and live Color on VehicleData).
Stickers on glass live in WindowVinyls.
