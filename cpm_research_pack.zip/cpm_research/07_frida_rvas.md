# Frida RVAs that worked
Base: UnityFramework (ASLR slides these; add module.base)

| Symbol | RVA |
|---|---|
| FirebaseWrappedFunctionFactory.Create | 0x279CC58 |
| FirebaseSaveLoadService.Init | 0x24C5E98 |
| FirebaseSaveLoadService.GetPlayerRecords | 0x24C5FC4 |
| FirebaseCarsService.Init | 0x24CF668 |
| FirebaseCarsService.GetCarIDnStatus | 0x24CFDAC |
| MemoryPackUtil.GetXorKey | 0x2450304 |
| MemoryPackUtil.Xor | 0x245028C |
| MemoryPackUtil.BrotliCompress | 0x244FFC4 |
| MemoryPackUtil.DecompressBrotli | 0x2450640 |
| ES3Settings(password ctor) | 0x2809758 |
| AES.Encrypt | 0x283078C |
| AES.Decrypt | 0x2830A30 |
| BitMaskPacker.Pack | 0x268156C |
| BitMaskPacker.Unpack | 0x26815C4 |
| BitMaskPacker.PackColor | 0x2681740 |
| VinylsUtility.GetFilePathByID | 0x2699910 |
| VinylsUtility.ConvertOneVinylToVinylData | 0x2699B74 |
| VinylData.Serialize | 0x141D0E8 |
| VinylData.Deserialize | 0x219DDB8 |
| VinylsEditor.CreateVinyl | 0x2688F00 |
| Texture2D.LoadImage | 0x62C5348 |

## Practical notes
- Attach to running CarParking. Spawn often crashes Unity on Dopamine.
- Do not match module name /cpm/i — that hits CPMS with the wrong base.
- IL2CPP byte[]: length at +0x18, payload at +0x20.
- IL2CPP string: length at +0x10, UTF16 at +0x14.
- Python Frida host must forward type==log or hooks look dead.
- Capture after login or log out/in while attached, or GetAllCars2 is missed.
