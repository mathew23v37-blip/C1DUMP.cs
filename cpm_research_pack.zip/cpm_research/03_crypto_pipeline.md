# Encode / decode pipelines

## Network write (Frida-confirmed)
```
raw binary (MemoryPack VinylData / player record)
    -> MemoryPackUtil.BrotliCompress     (optional; often present)
    -> MemoryPackUtil.Xor(uidKey)        (1:1 length)
    -> Cloud Function body
```
Brotli output commonly starts 0x1B.

## Network read (login cars)
```
many Brotli fragments
    -> DecompressBrotli
    -> raw VinylData / field pieces in memory
```
Clone login: 1288 decompress calls, only one XOR, and that XOR
was on SavePlayerRecordsPartially8. XOR is primarily a write wrapper.

## XOR key (solved)
```
chars = list(firebaseUid)
swap index 1 and 8
delete index 2
append the new index 4
encode UTF-8
```
Examples (research captures):
  UID hUyJH2ude8QMZzVlkAbniA22uqi1 -> heJH2udU8QMZzVlkAbniA22uqi12
  UID zaHH4zvUcDW5QaI4TxgYR06YN902 -> zcH4zvUaDW5QaI4TxgYR06YN902z
  UID C301SjWRtJQgTsUUInGGrrWIOnJ2 -> Ct1SjWR3JQgTsUUInGGrrWIOnJ2j

Round-trip verified on capture pairs 0174/0175 and 0172/0173.
Do not mix two accounts in one captures folder.

## Local ES3
Not the network pipeline.
Encrypted size ~= plaintext size on carVinyls257 (201328 vs 201299)
=> AES of JSON, not Brotli/MemoryPack on disk.
Password is a short account-derived string (6 chars seen: 81ARQ9, CF69P3).
Not hardcoded in EasySave3.dll. encryptionPassword sits on ES3Settings+0x28
and is assigned at runtime.
Classic ES3: AES-CBC, PBKDF2-SHA1, 16-byte salt prefix, IV often = salt.
Bot keys 483j6t / 4ebcBg failed on other-account iOS files because
the password is per-account.

## Color packing
BitMaskPacker.PackColor(Color) / UnpackColor(uint)
JSON "color" is that uint (ARGB).
  4294967295 = white
  4278190080 = opaque black
