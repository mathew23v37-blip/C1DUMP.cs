# Network crypto (not ES3)

Write path seen in Frida:

```
OneCar / vinyl list
  → MemoryPack
  → BrotliCompress     (output starts 0x1b)
  → MemoryPackUtil.Xor (key from GetXorKey(accountID))
  → Cloud Function body
```

Read path is the reverse.

## XOR key

GetXorKey(accountID) derived from Firebase UID.
Observed transform on one capture: swap/drop/append on UID chars, UTF-8, length 28.
XOR is repeating-key over the Brotli payload.

Same UID ⇒ same XOR key. That is why same-account vinyl copy needs no "key B".
Different UID ⇒ different XOR. Cross-account clone must re-wrap with the dest UID key.

## ES3 is a different stack

ES3 = AES-128-CBC, PBKDF2-SHA1, 100 iterations, IV = first 16 bytes of the file.
Do not run XOR/Brotli on an .es3 file. Do not run AES on a GetAllCars2 field.
