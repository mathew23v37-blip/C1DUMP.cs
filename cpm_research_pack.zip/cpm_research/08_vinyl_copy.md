# How vinyls get from car A to car B

Three different pipes. Do not mix them.

## 1. Official shop (same car)

VinylsEditor.CopyVinyls / FlipX / grouping.
Duplicates StickerItems on the spawned mesh.
No targetCarId. MenuChangedHandler + Init reload one car and drop live objects.
That is why "copy on A, switch to B, paste" is not a button.

## 2. Same-account bot / "copy to this car / all cars"

Same UID ⇒ same XOR key ⇒ same ES3 prefix 81A.
The bot does not rename ES3 and does not open the shop.

```
GetAllCars2
  cars = [ OneCar, ... ]

src = cars[A].Vynils.allVynils
      cars[A].WindowVinyls     // if the button includes glass stamps

for each target B (one id or every id):
  B.Vynils.allVynils  = copy(src body list)
  B.WindowVinyls      = copy(src window list)
  B.CarID             = still B
  B.floats / vectors  = left alone   // paint and tint stay on B

SaveCarsPartially8(those OneCars)
game draws B, then writes
  81Acars/carVinyls{B}
  81Acars/windowVinyls{B}
```

That is the whole trick. Portable payload is List<VinylData>.
UVs are A's coordinates. Different body ⇒ player nudges in the shop.
Same body family ⇒ looks right immediately.

"Copy to all" is the same loop with every CarID.

Tint does not jump unless the bot also copies floats
(slider [46], color [21-23], spec [24-26]).

## 3. Cross-account clone

Copy the whole OneCar onto another UID, re-XOR with dest GetXorKey,
SaveCarsPartially8 as that user.
floats go with it, so X-ray slider=3 survives.
ES3 "key A → key B" is only re-encrypting the local cache
(path[:3] + destUid[:3]). Optional. Server OneCar is what you see after login.

Cheap CPM1→CPM2 scripts that only AES-rekey an ES3 file do not translate schemas.
They wrap the same JSON for a different password. Garage functions that failed
were the ones that needed OneCar, not ES3.

## 4. Memory isolate (H5GG class of trick)

Isolate a live vinyl-list field by changing stamp count, write, then SaveVinyl.
Dest car must be in the shop with a non-empty list ("add 2 stickers").
Scan numbers like 12.2 / 12.3 / 12.4 are NOT in dump.cs. Treat as personal markers.
Persists because SaveVinyl hits the same OneCar path as (2).

## Why ES3 replace fails

GetAllCars2 runs after login and overwrites the cache.
Renaming carVinyls62 onto another filename never changes B.Vynils on the server.
