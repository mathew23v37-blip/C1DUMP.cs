# Out-of-range visuals (save is a still frame)

Legal shop range is roughly 0..1 (glass slider about 0.3..1).
The file will store numbers outside that. The shader still reads them.

## Axes

slider  >1  HDR / LED / old X-ray     <0  hole / inverted pane
color   >1  neon albedo               <0  crushed / inverted hue
spec    >1  chrome / mirror           <0  matte void

Bloom on turns >1 into a light. Bloom off turns it into a slab.

## Combos that are actually different looks

- LED windows: slider >1 + any strong color (car 62).
- Teal projector: slider >1 + dark color + mint spec.
- Chrome greenhouse: slider ~1 + spec >1.
- Matte privacy film: slider ~1 + spec <0.
- Glow stamps on dead glass: spec <0 + bright WindowVinyls.
- Body chrome: smoothness/spec cluster >1 (not the glass slider).
- Body matte + lit vinyls: spec cluster <0 + bright Vynils.
- Dark car / lit cabin: body matte + glass slider >1.
- Split RGB: one channel HDR on color, another on spec.

All three axes illegal at once is usually broken lighting, not a new style.

## What a save cannot store

No GIF vinyl field. No frame index. No _Time.
Rainbow / flash / moving stamps need runtime code or a shader that already ticks
(police meshes blink because the game already animates them; the save only says installed).

A "GIF vinyl" that survives logout is not supported by VinylData.
