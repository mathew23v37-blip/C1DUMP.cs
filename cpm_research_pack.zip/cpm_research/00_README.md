# CPM1 research pack
Date: 2026-09-03
Game: Car Parking Multiplayer (CPM1) iOS
Unity 2022.3.62f2 IL2CPP
Bundle: com.aidana.cardriving.ios
Frida process: CarParking
Code module: UnityFramework (not CPMS)

Dump repo: https://github.com/mathew23v37-blip/C1DUMP.cs
(dump.cs, script.json, il2cpp.txt, captures - Copy.zip)

This pack is documentation of what was observed and proven.
It is not a save editor, injector, or Cloud Function client.

## Files
- 00_README.md                 this index
- 01_architecture.md           client / cache / server tree
- 02_endpoints.md              Cloud Functions seen live
- 03_crypto_pipeline.md        XOR + Brotli + AES/ES3
- 04_es3_local.md              local save layout
- 05_vinyl_schema.md           VinylData / OneVinyl / types
- 06_packeddata.md             BitMaskPacker (solved)
- 07_frida_rvas.md             hooks that worked
- 08_captures.md               what the blob dumps are
- 09_confirmed_vs_unknown.md   scorecard
- vinyls257_decoded.csv        all 450 vinyls from carVinyls257
- packeddata_unique.csv        28 unique packs decoded
- decode_packed.py             reference unpacker (read-only)
