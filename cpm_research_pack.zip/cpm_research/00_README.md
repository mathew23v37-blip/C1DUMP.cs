# CPM1 research pack (updated 2026-09-06)

Factual knowledge base from IL2CPP dump, Frida captures, GetAllCars2 blobs,
ES3 decrypts, and a stock-vs-tinted test pair (CarID 13 vs 62).

## How to read this

| File | Topic |
|------|--------|
| 01_architecture.md | Who wins: server OneCar vs ES3 cache |
| 02_endpoints.md | Cloud Functions seen on the wire |
| 03_crypto_pipeline.md | MemoryPack + Brotli + XOR (network) |
| 04_es3_local.md | Local AES files + 6-char password formula |
| 05_vinyl_schema.md | VinylData + packedData |
| 06_packeddata.md | BitMaskPacker |
| 07_getallcars2.md | OneCar layout, vectors[28], floats[54] |
| 08_vinyl_copy.md | How same-account bots copy vinyls |
| 09_window_tint.md | Slider / color / specular on car 62 |
| 10_visuals_outofrange.md | Out-of-range PBR looks |
| 11_frida_rvas.md | Hook RVAs |
| 12_confirmed_vs_unknown.md | Proven vs inferred vs open |
| vinyls257_decoded.csv | Older body-vinyl decode |
| packeddata_unique.csv | Unique packedData values |

## One-line truth

After login, **GetAllCars2 OneCar is the car**. ES3 is a photocopy.
Vinyl copy between cars is **copy `Vynils` / `WindowVinyls` onto another OneCar**, not rename an ES3 file.

No account passwords, bot tokens, or Firebase API keys are stored in this pack.
