# Local ES3

## Path convention
ES3 filename is base64 of an internal key:
  ODFBY2Fycy9jYXJWaW55bHMyNTc=  ->  81Acars/carVinyls257
  ODFBY2Fycy9jYXJWaW55bHMyMDU=  ->  81Acars/carVinyls205

VinylsUtility.GetFilePathByID(id, VinylsType)
VinylsUtility.GetVinylSuffix(type)
VinylsUtility.DeleteVinylsFile(carId, type)

VinylsType:
  None=0 CarVinyls=1 PlateVinyls=2 ClanVinyls=3 WindowVinyls=4

## File body (after decrypt)
JSON object whose keys are "0" .. "N-1".
Each value is:
  { "__type": "DataEntities.Vinyl.VinylData,Assembly-CSharp",
    "value": { position, scaleRotation, iconPosition, text, color, packedData } }
Some entries wrap an extra System.Object layer; fields are the same.

Car 257: 450 entries, z == index for every row.

## What ES3 is not
- Not the server car record
- Not MemoryPack
- Not XOR'd with the UID key
