# Local ES3

Filenames are Base64 of a path:

```
ODFBY2Fycy9jYXJWaW55bHM2Mg==     →  81Acars/carVinyls62
ODFBY2Fycy93aW5kb3dWaW55bHM2Mg== →  81Acars/windowVinyls62
```

## Password (proven)

```
ES3 password = decodedPath[:3] + firebaseUid[:3]
```

Example: path 81Acars/... + UID starting Hmo → 81AHmo.
That password opened both carVinyls62 and windowVinyls62 (AES-CBC, PBKDF2-SHA1, 100 rounds, IV=file[0:16]).

The 6 characters are not a hash of the vinyls and are not inside EasySave3.dll.
Email/password are only used to obtain localId. The AES key uses those 3 UID chars.

"Key A" vs "Key B" is the same formula on two UIDs. Nothing in the game "triggers" key B.

## File body after decrypt

JSON dictionary of VinylData:

```
"0": { "__type": "DataEntities.Vinyl.VinylData,Assembly-CSharp", "value": { position, scaleRotation, iconPosition, text, color, packedData } }
```

carVinyls62 = 256 body stamps.
windowVinyls62 = 32 glass stamps.

ES3 does not store floats[46] or the glass RGB triples. Those are only on OneCar.
