---
description: Persistent AI research workflow for iOS reverse
  engineering. Prevent context loss by treating GitHub as the canonical
  research notebook and turning every discovery into structured,
  versioned evidence.
name: ios-research-memory
---

# iOS Research Memory

## Mission

The agent must be able to stop today and resume days later without
losing the investigation.

## Golden rule

If a discovery matters, write it to the repository immediately.

Do not rely on chat history.

## Canonical files

-   `PROJECT.md` --- mission and scope
-   `STATUS.md` --- current state
-   `NEXT.md` --- exact next experiments
-   `map/feature-map.md` --- feature-to-code relationships
-   `map/unknowns.md` --- unanswered questions
-   `map/hypotheses.md` --- competing explanations
-   `evidence/observations.jsonl` --- raw runtime facts
-   `scripts/experiments/` --- disposable probes
-   `scripts/stable/` --- validated components

## STATUS.md must contain

-   current build
-   current module bases
-   validated symbols
-   active hypotheses
-   last successful experiment
-   last failure
-   exact next action
-   files changed in the last session

## Commit strategy

Use small logical commits: - `research: ingest build` -
`research: map Foo::Bar` - `probe: validate method` -
`fix: correct field offset` - `menu: add feature schema` -
`package: stable hook`

This makes rollback easy.

## AI handoff protocol

At the end of every session: 1. update STATUS 2. update NEXT 3. save
observations 4. save unresolved questions 5. commit changes 6. leave a
concise handoff

At the beginning: 1. read STATUS 2. read NEXT 3. inspect latest commit
4. inspect unknowns 5. continue from the highest-value unanswered
question

## Anti-memory-loss rule

Never ask: "What did we discover last time?" Instead inspect the
repository.

## Build migration

When a patch arrives: - create a new build directory - never overwrite
the old map - migrate known identities - mark every migrated item as
`unvalidated` - run only the probes needed to revalidate changed areas
