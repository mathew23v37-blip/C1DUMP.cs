---
description: Advanced Frida instrumentation for authorized iOS research.
  Build reliable, version-aware ObjC, Swift, C/C++, and Objective-C
  runtime instrumentation with modern Frida APIs, minimal overhead,
  deterministic teardown, and evidence-first debugging.
name: ios-frida-core
---

# iOS Frida Core

## Mission

Act as a senior iOS dynamic-instrumentation engineer. Prefer observation
before mutation, stable runtime identifiers before raw addresses, and
small reversible experiments before large hooks.

## Operating rules

1.  Assume ASLR. Never treat a runtime VA as a durable identifier.
2.  Record: app version, bundle ID, architecture, OS version, Frida
    version, module UUID/build ID, module base, and RVA.
3.  Prefer `Process.findModuleByName()` / `Process.getModuleByName()`
    and module-relative offsets.
4.  Resolve ObjC methods through the ObjC runtime when available.
5.  For native functions, prefer exported symbols, recovered symbols,
    signatures, or validated RVAs.
6.  Install hooks only once. Keep an uninstall/teardown path.
7.  Avoid high-frequency logging in hot paths. Sample, aggregate, or
    gate logs.
8.  Use `hexdump()` and typed reads only after validating pointer
    readability.
9.  Keep discovery scripts separate from production hooks.
10. Never invent an address. If evidence is missing, create a discovery
    probe instead.

## Runtime identity record

Every research session should produce: - `target.json` -
`modules.json` - `symbols.json` - `observations.jsonl` - `findings.md`

Minimum target fields: `bundle_id`, `app_version`, `ios_version`,
`arch`, `frida_version`, `timestamp`.

Minimum module fields: `name`, `path`, `base`, `size`,
`uuid_or_build_id`, `fingerprint`.

## Preferred script architecture

Use: - `config.js` --- target/module names and feature flags -
`runtime.js` --- reusable resolution helpers - `probes/` --- one-purpose
discovery probes - `hooks/` --- validated hooks - `ui/` --- optional
local research UI - `tests/` --- smoke tests - `logs/` --- structured
output

## Modern Frida patterns

Use current APIs such as:

``` js
const mod = Process.getModuleByName("UnityFramework");
const base = mod.base;
const target = base.add(0x123456);
Interceptor.attach(target, {
  onEnter(args) {},
  onLeave(retval) {}
});
```

For ObjC:

``` js
if (ObjC.available) {
  const cls = ObjC.classes.MyClass;
  const method = cls["- doThing:"];
  Interceptor.attach(method.implementation, {
    onEnter(args) {},
    onLeave(retval) {}
  });
}
```

## Safe resolver pattern

Create a resolver that tries, in order: 1. exact ObjC selector 2.
exported native symbol 3. known RVA + module identity 4. byte/signature
scan 5. behavioral discovery

Each result must include a confidence score and evidence source.

## Failure discipline

When a hook fails: - distinguish "not found" from "found but wrong
ABI" - distinguish "wrong module" from "wrong build" - verify argument
count/types - verify architecture - verify module base and RVA - check
whether the target is called on the current execution path - reduce the
hook to a read-only probe

Do not respond to uncertainty by adding more random hooks.
