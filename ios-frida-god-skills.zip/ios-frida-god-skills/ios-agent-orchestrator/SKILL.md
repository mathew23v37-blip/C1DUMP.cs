---
description: Orchestrate an AI agent through a long-running iOS Frida
  investigation using repository state, automated artifact ingestion,
  experiment generation, validation, and promotion to stable code.
name: ios-agent-orchestrator
---

# iOS Agent Orchestrator

## Mission

Operate like a research lead, not a code autocomplete tool.

The agent cycles:
`INGEST -> MODEL -> HYPOTHESIZE -> PROBE -> OBSERVE -> VALIDATE -> RECORD -> PROMOTE -> REPEAT`

## Inputs

Accept: - Git repository - `dump.cs` - `script.json` - `il2cpp.h` -
`global-metadata.dat` - Mach-O metadata - Frida logs - screenshots/log
snippets - user-defined research goals

## First-pass ingestion

Create: - build manifest - module manifest - symbol index - class
index - method index - field index - unknown index

Do not attempt to understand everything at once.

## Prioritization

Score unknowns using: `value × evidence_gap × feasibility × reuse`

Prefer questions that unlock many downstream features.

## Probe generation

For each unknown generate: - smallest possible probe - expected
evidence - timeout - cleanup - output schema

Prefer read-only probes.

## Validation

A finding is stable only when: - the target identity is known - the
build identity matches - the behavior reproduces - evidence is stored -
the probe can be rerun

## Promotion

Move scripts: `experiments/ -> validated/ -> stable/`

Never copy a failed experiment directly into stable.

## Autonomous next-step selection

After each experiment: 1. update evidence 2. update graph 3. recalculate
unknown priorities 4. select one next experiment 5. explain why it has
the highest expected information gain

## GitHub as external memory

The agent should continuously maintain: - STATUS.md - NEXT.md -
CHANGELOG.md - map/ - evidence/ - scripts/

This makes long investigations resumable across models and sessions.

## Hard boundary

Use this workflow for applications and binaries the researcher is
authorized to analyze. Do not use it to defeat authentication, payment
controls, access restrictions, or security protections on systems
without authorization.
