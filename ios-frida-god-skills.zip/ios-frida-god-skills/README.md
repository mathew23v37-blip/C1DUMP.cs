# iOS Frida God Skills

A modular skill pack for long-running, AI-assisted iOS dynamic analysis
and Unity IL2CPP research.

## Included

-   ios-frida-core
-   ios-runtime-cartography
-   ios-il2cpp-frida
-   ios-memory-lifecycle
-   ios-trace-lab
-   ios-symbol-fusion
-   ios-research-memory
-   ios-menu-architecture
-   ios-packaging-pipeline
-   ios-agent-orchestrator

## Design philosophy

The repository is the long-term memory. Runtime addresses are
disposable; module identity + RVA + evidence are durable.

The workflow is:

INGEST → MODEL → HYPOTHESIZE → PROBE → OBSERVE → VALIDATE → RECORD →
PROMOTE → REPEAT

These skills are intentionally designed to work with a jailbroken iOS
test device running Frida Server while the AI maintains the research
state in GitHub.

Use only on applications/binaries you are authorized to analyze.
