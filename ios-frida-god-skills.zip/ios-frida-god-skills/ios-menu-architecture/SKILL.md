---
description: Design a modular research/debug UI that consumes validated
  runtime capabilities and can later be packaged as a dylib or tweak
  without coupling UI code to fragile offsets.
name: ios-menu-architecture
---

# iOS Menu Architecture

## Mission

Build the final UI as a consumer of a capability layer, not as a pile of
hooks.

## Separation

Use four layers:

1.  `resolver`
    -   maps build identity to validated symbols/fields
2.  `runtime`
    -   exposes typed operations
3.  `features`
    -   feature-level capabilities
4.  `ui`
    -   buttons, sliders, toggles, status, logs

The UI must not contain raw RVAs.

## Capability contract

Example:

``` json
{
  "id": "feature.example",
  "label": "Example Feature",
  "type": "toggle",
  "status": "validated",
  "requires": ["symbol.foo", "field.bar"],
  "implementation": "features/example.js"
}
```

## Runtime safety

Every capability must declare: - required build - required module -
required symbols - read/write mode - failure behavior - cleanup behavior

## UI states

Show: - available - unavailable - needs validation - active - failed

Do not show a feature as working merely because a script loaded.

## Packaging path

Design the project so the same feature layer can later be hosted by: -
Frida agent - development dylib - jailbreak tweak/package

Keep platform glue separate.

## Local-only development

For authorized research, a local development server can provide: -
script manifests - feature metadata - test profiles - logs

Do not put secrets, private signing material, or privileged credentials
into the repository.
