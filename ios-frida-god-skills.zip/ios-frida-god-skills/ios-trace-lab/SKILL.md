---
description: Design controlled Frida experiments on iOS using
  hypothesis-driven tracing, event correlation, call graphs, state
  transitions, and minimal-overhead probes.
name: ios-trace-lab
---

# iOS Trace Lab

## Mission

Replace guessing with experiments.

Every experiment has: - question - hypothesis - probe - expected
signal - observed signal - conclusion - next experiment

## Experiment template

``` yaml
id: EXP-0001
question: "Which subsystem changes this state?"
hypothesis:
  - "A"
  - "B"
probe: "read-only hook on candidate methods"
expected:
  - "A emits event X"
observed: []
conclusion: "unknown"
confidence: 0.0
next: []
```

## Trace levels

Level 0: lifecycle and module inventory Level 1: method entry/exit Level
2: selected arguments/returns Level 3: object fields and state
transitions Level 4: call graph / Stalker-style focused tracing Level 5:
narrow native dataflow analysis

Escalate only when the previous level cannot answer the question.

## Correlation

Attach a monotonically increasing event ID to observations.

Correlate: - UI action - managed method - native method - field write -
return value - network/storage event when appropriate

## Stalker discipline

Use focused windows, not permanent whole-process tracing.

Start tracing: - immediately before the suspected action - stop
immediately after enough evidence is collected

Filter aggressively by module/range when possible.

## Output

Write machine-readable JSONL and a human-readable summary.

The summary should answer: "What changed, where, when, and what evidence
proves it?"
