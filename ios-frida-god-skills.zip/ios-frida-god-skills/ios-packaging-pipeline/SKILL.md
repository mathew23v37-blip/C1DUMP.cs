---
description: Convert validated iOS runtime research into maintainable
  dylib/tweak/package architecture with reproducible builds, version
  gates, smoke tests, and rollback paths.
name: ios-packaging-pipeline
---

# iOS Packaging Pipeline

## Mission

Packaging is the final stage, not the first.

Only promote a feature after: - runtime validation - repeatability -
build identity verification - teardown test - crash test - performance
sanity check

## Artifact states

`experiment -> candidate -> validated -> packaged -> retired`

## Build metadata

Every artifact records: - git commit - target bundle ID - supported iOS
range - supported app versions - architecture - dependency versions -
feature list

## Version gates

At load time: 1. identify bundle 2. identify app version 3. identify
relevant module 4. compare known build identity 5. enable only
compatible capabilities

If unknown: - keep the UI available if safe - mark capabilities
unavailable - do not guess offsets

## Packaging architecture

``` text
package/
  control/
  resolver/
  runtime/
  features/
  ui/
  resources/
  tests/
```

## Smoke tests

Before release: - process launch - module discovery - resolver
validation - UI load - enable/disable each capability - teardown -
relaunch

## Rollback

Keep previous package and previous commit available. A failed release
should be reversible in minutes.
