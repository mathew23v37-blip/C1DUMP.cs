---
description: Advanced Unity IL2CPP on iOS workflow combining dump.cs,
  script.json, metadata, native Mach-O analysis, and Frida runtime
  validation for authorized research.
name: ios-il2cpp-frida
---

# iOS IL2CPP + Frida

## Mission

Bridge the gap between C# concepts and native runtime reality.

Primary inputs: - `dump.cs` - `script.json` - `il2cpp.h` -
`global-metadata.dat` - `UnityFramework` - Frida runtime observations

## Core rule

Never assume a `dump.cs` RVA is a valid runtime pointer without
identifying the correct module and build.

Use: `runtime_address = module_base + RVA`

Then validate: - module identity - executable mapping - expected
function prologue/signature - runtime call behavior

## Build ingestion

For each build store: - Unity version if known - metadata version -
architecture - module UUID - binary hash - metadata hash - dump
timestamp - tool versions

## Method record

Represent every important method as:

``` json
{
  "name": "Namespace.Type::Method",
  "rva": "0x...",
  "signature": "...",
  "module": "UnityFramework",
  "confidence": 0.0,
  "static_evidence": [],
  "runtime_evidence": [],
  "status": "unknown|candidate|validated|retired"
}
```

## Field record

Track: - declaring type - field name - offset - size if known - type -
static/instance - readers - writers - runtime object observations

## Generic method traps

Treat generic methods, virtual dispatch, interface calls, thunks,
wrappers, and generated helpers as separate nodes. Do not collapse them
into one function merely because names look similar.

## Discovery strategy

For a feature: 1. Find class/method names in `dump.cs`. 2. Correlate
with `script.json`. 3. Locate candidate RVA. 4. Convert to runtime
address. 5. Attach a low-overhead observation hook. 6. Capture
arguments/return values only when useful. 7. Trace callers/callees if
needed. 8. Identify the state transition. 9. Record evidence. 10. Only
then build a reusable hook.

## Object inspection

When an IL2CPP object is observed: - verify pointer plausibility -
identify candidate type - inspect only known field offsets - never
blindly walk arbitrary memory - record successful layouts in
`map/fields.md`

## Goal

Produce a stable feature specification that can later feed a menu schema
without embedding fragile one-off offsets into UI code.
