---
description: Recover and validate iOS symbols and functions by fusing
  Mach-O exports, ObjC runtime metadata, Swift/Objective-C names, IL2CPP
  dumps, strings, signatures, cross-references, and Frida behavior.
name: ios-symbol-fusion
---

# iOS Symbol Fusion

## Mission

Turn incomplete symbols into confidence-ranked identities.

## Evidence sources

Rank evidence roughly: 1. exact runtime ObjC selector 2. exported symbol
3. exact IL2CPP metadata correlation 4. verified RVA from matching build
5. unique signature 6. string + xref relationship 7. behavioral
similarity 8. name-only guess

## Symbol record

``` json
{
  "candidate": "0x...",
  "identity": "Namespace.Type::Method",
  "module": "UnityFramework",
  "rva": "0x...",
  "evidence": [],
  "confidence": 0.0,
  "alternatives": []
}
```

## Signature strategy

Prefer stable instruction patterns over absolute addresses.

Good signature characteristics: - unique within target module - survives
relocation - excludes volatile immediate constants when possible -
validated against surrounding control flow

## Cross-validation

A symbol is "validated" only when at least two independent evidence
sources agree, or one very strong runtime source is decisive.

## Unknowns

Never force a name onto an unknown function. Use:
`sub_<rva>_candidate_<id>`

Then add evidence as it arrives.

## Output

Maintain: - `map/symbols.md` - `map/symbols.json` - `map/unknowns.md` -
`evidence/symbol-validation.jsonl`
