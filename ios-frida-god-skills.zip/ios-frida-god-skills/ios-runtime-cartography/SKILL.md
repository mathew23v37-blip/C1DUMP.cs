---
description: Build a persistent, versioned map of an iOS application's
  runtime architecture from static artifacts and Frida observations.
  Designed for long-running AI-assisted research where the repository is
  the memory.
name: ios-runtime-cartography
---

# iOS Runtime Cartography

## Mission

Turn a dump, Mach-O, `dump.cs`, `script.json`, headers, strings, and
Frida observations into a living architecture map.

The repository is the long-term memory. Never require the model to
remember facts that can be written down.

## Repository contract

Use this structure:

``` text
research/
  target.json
  builds/
    <build-id>/
      manifest.json
      binary/
      metadata/
      dump/
      static/
      runtime/
  map/
    modules.md
    classes.md
    methods.md
    fields.md
    callgraph.md
    dataflow.md
    feature-map.md
    unknowns.md
    hypotheses.md
  probes/
    discovery/
    validated/
    retired/
  scripts/
    experiments/
    stable/
  evidence/
    logs/
    traces/
    snapshots/
  menu/
    schema.json
    features.md
  packaging/
    dylib/
    tweak/
```

## Evidence levels

Every fact gets one: - `E0` --- hypothesis - `E1` --- static evidence -
`E2` --- runtime observation - `E3` --- repeated runtime observation -
`E4` --- independently cross-validated

Never silently promote a hypothesis to a fact.

## Address model

Store addresses as: - module name - module UUID/build ID - RVA - runtime
VA only as session data

Example:

``` json
{
  "module": "UnityFramework",
  "rva": "0x123456",
  "runtime_va": "0x105123456",
  "confidence": 0.92,
  "evidence": ["dump.cs:Foo.Bar", "frida:2026-08-31T20:10Z"]
}
```

## Map-building loop

1.  Ingest artifacts.
2.  Normalize names and addresses.
3.  Build candidate relationships.
4.  Mark unknowns.
5.  Design the smallest probe that can answer one unknown.
6.  Run it on the Frida server.
7.  Save structured observations.
8.  Update the map.
9.  Promote only validated findings.
10. Generate the next experiment automatically.

## Never lose position

When a new build appears: - preserve the old build directory - compute
module identity - compare exported symbols - compare string anchors -
compare method signatures - map old RVA -\> new candidate RVA - mark
uncertain mappings - require runtime validation before reuse

## Graph mindset

Model:
`Feature -> UI action -> managed method -> native method -> field -> subsystem -> side effect`

Also model: `class -> method -> caller -> callee` and
`object -> field -> writer -> reader`

The goal is not merely a list of offsets. It is a causal map.
